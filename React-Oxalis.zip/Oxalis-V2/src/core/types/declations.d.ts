declare module 'oxalis/Component' {
    const Component: React.ComponentType;
    export default Component;
}