const useLocalStorage = () => {
    const getLocalStorageItem = (key: string) => localStorage.getItem(key);

    const setLocalStorageItem = (key: string, value: any) => localStorage.setItem(key, value);

    const clearLocalStorage = () => localStorage.clear();

    const clearLocalStorageItem = (key: string) => localStorage.removeItem(key);

    const token = JSON.parse(localStorage.getItem("UserTokenInfo") ?? "{}");

    const access_token = JSON.parse(localStorage.getItem("UserTokenInfo") ?? "{}")?.access_token;

    return { getLocalStorageItem, setLocalStorageItem, clearLocalStorage, clearLocalStorageItem, access_token, token };
};

export default useLocalStorage;