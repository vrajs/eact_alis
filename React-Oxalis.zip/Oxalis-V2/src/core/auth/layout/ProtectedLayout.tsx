import { Outlet } from "react-router-dom"
import ThemeLayout from "../../../layout/layout"
import { OnlineAuthGuard } from "../callback/OnlineAuthGuard"


export const ProtectedLayout = () => {

    return (<OnlineAuthGuard>
        <ThemeLayout>
            <Outlet />
        </ThemeLayout>
    </OnlineAuthGuard>)
}