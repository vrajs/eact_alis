import { ReactNode, useEffect, useState } from "react";
import AuthLoader from "../../components.ts/loaders/AuthLoader";
import useLocalStorage from "../hooks/useLocalStorage";
import { useAuth } from "../provider/AuthProvider";

interface OnlineAuthGuardProps {
    children: ReactNode;
}

export const OnlineAuthGuard: React.FC<OnlineAuthGuardProps> = ({ children }) => {
    const authContext = useAuth();
    const { getLocalStorageItem } = useLocalStorage();
    const [isLoggedIn, setIsLoggedIn] = useState(getLocalStorageItem("UserTokenInfo") ?? "");

    useEffect(() => {
        const handleSignIn = async () => {
            try {
                if (window.location.href.indexOf("auth-callback") <= -1 && !authContext.isAuthenticated()) {
                    authContext.signinRedirect();
                } else if (window.location.href.indexOf("auth-callback") > -1) {
                    await authContext.signinRedirectCallback();
                    setIsLoggedIn(getLocalStorageItem("UserTokenInfo") ?? "");
                } else if (getLocalStorageItem("UserTokenInfo")) {
                    const userToken = JSON.parse(getLocalStorageItem("UserTokenInfo"));
                    const expTime = userToken?.expires_at;
                    const currentTime = new Date().getTime() / 1000;
                    if (currentTime > expTime) {
                        authContext.signinRedirect();
                    }
                }
            } catch (error) {
                console.error("Error during sign-in callback:", error);
            }
        };
        handleSignIn();
    }, []);

    return (
        <>
            {isLoggedIn === "" ? <AuthLoader /> : children}
        </>
    );
};
