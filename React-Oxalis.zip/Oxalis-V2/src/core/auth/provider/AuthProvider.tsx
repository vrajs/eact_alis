import { createContext, useContext } from "react";
import AuthService from "../services/AuthService";

const AuthContext = createContext(AuthService());

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const authServiceInstance = AuthService();
  return <AuthContext.Provider value={authServiceInstance}>{children}</AuthContext.Provider>;
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};

export default AuthContext;