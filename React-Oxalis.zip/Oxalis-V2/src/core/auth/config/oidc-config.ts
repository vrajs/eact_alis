import { UserManagerSettings, WebStorageStateStore } from "oidc-client-ts";

const oidcConfig: UserManagerSettings = {
    authority: import.meta.env.VITE_AUTHORITY ?? "",
    client_id: import.meta.env.VITE_CLIENT_ID ?? "",
    client_secret: import.meta.env.VITE_CLIENT_SECRET,
    redirect_uri: import.meta.env.VITE_REDIRECT_URI ?? "",
    response_type: import.meta.env.VITE_RESPONSE_TYPE,
    scope: import.meta.env.VITE_SCOPE,
    post_logout_redirect_uri: `${import.meta.env.VITE_API_URI}/#/${import.meta.env.VITE_POST_LOGOUT_REDIRECT_URI}`,
    automaticSilentRenew: Boolean(import.meta.env.VITE_AUTOMATIC_SILENT_RENEW),
    silent_redirect_uri: import.meta.env.VITE_SILENT_REDIRECT_URI,
    monitorSession: Boolean(import.meta.env.VITE_MONITOR_SESSION),
    checkSessionIntervalInSeconds: Number(import.meta.env.VITE_INTERVEL_SESSION),
    loadUserInfo: Boolean(import.meta.env.VITE_LOAD_USER_INFO),
    accessTokenExpiringNotificationTimeInSeconds: Number(import.meta.env.VITE_ACCESS_TOKEN_EXPIRING_NOTIFICATION_TIME),
    //   revokeAccessTokenOnSignout: import.meta.env.VITE_REVOKE_ACCESS_TOKEN_ON_SIGNOUT,
    filterProtocolClaims: Boolean(import.meta.env.VITE_FILTER_PROTOCOL_CLAIMS),
    includeIdTokenInSilentRenew: Boolean(import.meta.env.VITE_INCULDE_ID_TOKEN_IN_SILENT_RENEW),
    userStore: new WebStorageStateStore({ store: window.localStorage }),
    //   refresh_token_expiration: import.meta.env.VITE_ACCESS_TOKEN_EXPIRING_NOTIFICATION_TIME,
};

export default oidcConfig;

export const METADATA_OIDC = {
    issuer: import.meta.env.VITE_AUTHORITY,
    jwks_uri: import.meta.env.VITE_AUTHORITY + ".well-known/openid-configuration/jwks",
    authorization_endpoint: import.meta.env.VITE_AUTHORITY + "connect/authorize",
    token_endpoint: import.meta.env.VITE_AUTHORITY + "connect/token",
    userinfo_endpoint: import.meta.env.VITE_AUTHORITY + "connect/userinfo",
    end_session_endpoint: import.meta.env.VITE_AUTHORITY + "connect/endsession",
    check_session_iframe: import.meta.env.VITE_AUTHORITY + "connect/checksession",
    revocation_endpoint: import.meta.env.VITE_AUTHORITY + "connect/revocation",
    introspection_endpoint: import.meta.env.VITE_AUTHORITY + "connect/introspect",
};
