import { UserManager, WebStorageStateStore } from "oidc-client-ts";
import oidcConfig, { METADATA_OIDC } from "../config/oidc-config";
import useLocalStorage from "../hooks/useLocalStorage";

const AuthService = () => {
    const { getLocalStorageItem, setLocalStorageItem, clearLocalStorage } = useLocalStorage();

    const UserManagerInstance = new UserManager({
        ...oidcConfig,
        userStore: new WebStorageStateStore({ store: window.localStorage }),
        metadata: {
            ...METADATA_OIDC,
        },
    });

    const navigateToScreen = async () => {
        localStorage.setItem("UserLoggedInStatus", "true");
        window.location.replace("/");
    };

    UserManagerInstance.events.addUserLoaded((user) => {
        setLocalStorageItem("UserTokenInfo", JSON.stringify(user));
        if (window.location.href.indexOf("auth-callback") !== -1) {
            navigateToScreen();
        }
    });

    UserManagerInstance.events.addSilentRenewError((e) => {
        console.log("silent renew error", e.message);
    });

    const signinSilent = () => {
        UserManagerInstance.signinSilent()
            .then((user) => {
                setLocalStorageItem("UserTokenInfo", JSON.stringify(user));
            })
            .catch((err) => {
                console.log(err);
            });
    };

    UserManagerInstance.events.addAccessTokenExpiring(() => {
        signinSilent();
    });

    const signinSilentCallback = () => {
        UserManagerInstance.signinSilentCallback();
    };

    const signinRedirectCallback = async () => {
        await UserManagerInstance.signinRedirectCallback();
    };

    const getUser = () => {
        UserManagerInstance.getUser().then((user) => {
            if (!user) {
                return UserManagerInstance.signinRedirectCallback();
            }
            return user;
        });
    };

    const parseJwt = (token: string) => {
        const base64Url = token.split(".")[1];
        const base64 = base64Url.replace("-", "+").replace("_", "/");
        return JSON.parse(window.atob(base64));
    };

    const signinRedirect = () => {
        setLocalStorageItem("redirectUri", window.location.pathname);
        UserManagerInstance.signinRedirect().then(() => {
            setLocalStorageItem("loginCalled", "true");
        });
    };

    const isAuthenticated = () => {
        const token = getLocalStorageItem("UserTokenInfo");
        return token !== null && token !== undefined;
    };

    const logout = () => {
        const userToken = getLocalStorageItem("UserTokenInfo");
        const idToken = userToken ? JSON.parse(userToken).id_token : null;
        UserManagerInstance.signoutRedirect({ id_token_hint: idToken });
        UserManagerInstance.clearStaleState();
    };

    const clearSessionStorage = () => {
        sessionStorage.clear();
    };

    const clearAuthSession = () => {
        sessionStorage.removeItem("offline-auth");
    };

    const removeUser = () => {
        UserManagerInstance.removeUser();
    };

    const logoutInternal = () => {
        logout();
        removeUser();
        clearSessionStorage();
        clearLocalStorage();
        setLocalStorageItem("hasUserDismissed", "true");
        window.location.replace(`${import.meta.env.VITE_API_URI}`);
    };

    const signoutRedirectCallback = () => {
        UserManagerInstance.signoutRedirectCallback().then(() => {
            clearLocalStorage();
        });
        UserManagerInstance.clearStaleState();
        setLocalStorageItem("hasUserDismissed", "true");
    };

    return {
        signinSilent,
        signinSilentCallback,
        signinRedirectCallback,
        getUser,
        parseJwt,
        signinRedirect,
        isAuthenticated,
        logout,
        logoutInternal,
        signoutRedirectCallback,
        removeUser,
        clearAuthSession,
    };
};

export default AuthService;
