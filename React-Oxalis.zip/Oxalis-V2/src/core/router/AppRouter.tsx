import { createHashRouter, createRoutesFromElements, Navigate, Route } from "react-router-dom";

import Home from "../../components/Home";
import { CoreLayout } from "../components.ts/layout/CoreLayout";
import GroupSearch from "../../components/operation/group/GroupSearch";
import GroupAddEdit from "../../components/operation/group/GroupAddEdit";
import GroupView from "../../components/operation/group/GroupView";
import ProviderSearch from "../../components/operation/provider/ProviderSearch";
import ProviderAddEdit from "../../components/operation/provider/ProviderAddEdit";
import ProviderView from "../../components/operation/provider/ProviderView";
import LocationList from "../../components/operation/location/locationList";
import LocationAddEdit from "../../components/operation/location/LocationAddEdit";
import LocationView from "../../components/operation/location/LocationView";
import PreEnrollment from "../../components/operation/member-enrollment/pre-enrollment";
import AdjudicationList from "../../components/operation/mass-adjudication/AdjudicationList";
import AdjudicationView from "../../components/operation/mass-adjudication/AdjudicationView";
import MarxFileGeneration from "../../components/operation/cms-correspondence/MarxFileGeneration";
import InvoicePayments from "../../components/operation/billing-payments/InvoicePayments";
import PostMemberPayments from "../../components/operation/billing-payments/PostMemberPayments";
import TRRFallouts from "../../components/operation/cms-correspondence/TRRFallouts";
import MemberCorrespondenceFile from "../../components/operation/member-correspondence/MemberCorrespondenceFile";
import PostMemberDeatils from "../../components/operation/billing-payments/PostMemberAddEdit";
import PremiumAccountSearch from "../../components/operation/billing-payments/PremiumAccountSearch";
import ClaimSearch from "../../components/operation/claims/ClaimSearch";
import TimeLinesReports from "../../components/operation/member-reports/TimelinesReports";
import MemberReportsAudit from "../../components/operation/member-reports/member-audit";
import OECSearch from "../../components/operation/member-enrollment/OECSearch";
import OECUpload from "../../components/operation/member-enrollment/OECUpload";
import EnrollmentSearch from "../../components/operation/member-enrollment/EnrollmentSearch";
import EnrollmentAddEdit from "../../components/operation/member-enrollment/Enrollment-add-edit";
import ClaimView from "../../components/operation/claims/ClaimView";
import ClaimAddEdit from "../../components/operation/claims/ClaimAddEdit";
import { AuthCallBack } from "../../components/auth/authCallback";
import CommonCodeList from "../../components/administration/masters/CommonCodeList";
import CommonCodeAddEdit from "../../components/administration/masters/CommonCodeAddEdit";
import BEQFileGeneration from "../../components/operation/cms-correspondence/beqFileGeneration";
import ZIPCodeList from "../../components/administration/masters/zipCode/ZipCodeList";
import ZipCodeAddEdit from "../../components/administration/masters/zipCode/ZipCodeAddEdit";
import HomeGrownCodeList from "../../components/administration/masters/homeGrownCode/HomeGrownCodeList";
import HomeGrownAddEdit from "../../components/administration/masters/homeGrownCode/HomeGrownAddEdit";
import CustomerSettingList from "../../components/administration/masters/customerSetting/CustomerSettingList";
import CustomerSettingAddEdit from "../../components/administration/masters/customerSetting/CustomerSettingAddEdit";
import CommonTypeList from "../../components/administration/masters/CodeTypeList";
import CommonCodeDisplayConfig from "../../components/administration/masters/CommonCodeDisplayConfig";
import CommonCodeSectionList from "../../components/administration/masters/commonCodeSection/CommonCodeSectionList";
import CommonCodeSectionAddEdit from "../../components/administration/masters/commonCodeSection/commonCodeSectionAddEdit";
import CommonCodeView from "../../components/administration/masters/CommonCodeView";
import ZipCodeView from "../../components/administration/masters/zipCode/ZipCodeView";
import HomeGrownCodeView from "../../components/administration/masters/homeGrownCode/HomeGrownCodeView";
import MemberDashboard from "../../components/operation/member-dashboard/MemberDashboard";

import RolesAddEdit from "../../components/administration/adminSecurity/roles/RolesAddEdit";
import RolesList from "../../components/administration/adminSecurity/roles/RolesList";
import RolesView from "../../components/administration/adminSecurity/roles/RolesView";
import UsersConfig from "../../components/administration/adminSecurity/users/UsersConfig";
import ClearHousingConfig from "../../components/interfaces/clearing-house/ClearingHouseConfig";
import BenefitConfiguration from "../../components/administration/adminconfig/benefits/BenefitConfiguration";
import CopayCoinsuranceList from "../../components/administration/adminconfig/copay-coinsurance/CopayCoinsuranceList";
import ContractsList from "../../components/administration/adminconfig/contracts/ContractsList";
import CopayCoinsuranceAddEdit from "../../components/administration/adminconfig/copay-coinsurance/CopayCoinsuranceAddEdit";
import ContractsAddEdit from "../../components/administration/adminconfig/contracts/ContractsAddEdit";
import LOBList from "../../components/administration/adminconfig/lob/LOBList";
import ContractView from "../../components/administration/adminconfig/contracts/ContractView";
import OrganizationRuleList from "../../components/administration/adminconfig/organization/OrganizationRuleList";
import LOBAddEdit from "../../components/administration/adminconfig/lob/LOBAddEdit";
import OrganizationAddEdit from "../../components/administration/adminconfig/organization/OrganizationAddEdit";
import TRCConfig from "../../components/administration/adminconfig/TRCConfig";
import LOBView from "../../components/administration/adminconfig/lob/LOBView";
import OrganizationView from "../../components/administration/adminconfig/organization/OrganizationView";
import BenefitsList from "../../components/administration/adminconfig/benefits/BenefitsList";
import BenefitView from "../../components/administration/adminconfig/benefits/BenefitView";
import PBPList from "../../components/administration/adminconfig/plan-benefit-package/PBPList";
import PBPConfiguration from "../../components/administration/adminconfig/plan-benefit-package/PBPConfiguration";
import PBPView from "../../components/administration/adminconfig/plan-benefit-package/PBPView";
import CMSFiles from "../../components/operation/cms-correspondence/CMSFiles";


const appRoutes = (
  <>
    <Route path="" element={<CoreLayout />}>
      <Route path="group" element={<GroupSearch />} />
      <Route path="group/group-add-edit" element={<GroupAddEdit />} />
      <Route path="group/group-add-edit/:groupEditId" element={<GroupAddEdit />} />
      <Route path="group/group-view/:groupId" element={<GroupView />} />
      <Route path="provider" element={<ProviderSearch />} />
      <Route path="provider/provider-add-edit" element={<ProviderAddEdit />} />
      <Route path="provider/provider-add-edit/:providerEditId" element={<ProviderAddEdit />} />
      <Route path="provider/provider-view" element={<ProviderView />} />
      <Route path="location" element={<LocationList />} />
      <Route path="location/location-add-edit" element={<LocationAddEdit />} />
      <Route path="location/location-add-edit/:locationId" element={<LocationAddEdit />} />
      <Route path="location/location-view" element={<LocationView />} />
      <Route path="operation/member/member-dashboard" element={<MemberDashboard />} />
      <Route path="operation/member/pre-enrollment" element={<PreEnrollment />} />
      <Route path="operation/member/enrollment" element={<EnrollmentSearch />} />
      <Route path="operation/member/enrollment-add-edit" element={<EnrollmentAddEdit />} />
      <Route path="operation/member/enrollment-add-edit/:memberEditId" element={<EnrollmentAddEdit />} />
      <Route path="operation/member/oec-search" element={<OECSearch />} />
      <Route path="operation/member/oec-upload" element={<OECUpload />} />
      <Route path="claims/search" element={<ClaimSearch />} />
      <Route path="claims/claims-add-edit" element={<ClaimAddEdit />} />
      <Route path="claims/dental" element={<ClaimAddEdit />} />
      <Route path="claims/pharmacy" element={<ClaimAddEdit />} />
      <Route path="claims/claims-add-edit/:claimId" element={<ClaimAddEdit />} />
      <Route path="claims/claims-view" element={<ClaimView />} />
      <Route path="claims/mass-adjudication-list" element={<AdjudicationList />} />
      <Route path="claims/mass-adjudication-view" element={<AdjudicationView />} />
      <Route path="operation/member/cms-correspondence/beq-file-generation" element={<BEQFileGeneration />} />
      <Route path="operation/member/cms-correspondence/cms-files" element={<CMSFiles />} />
      <Route path="operation/member/cms-correspondence/marx-file-generation" element={<MarxFileGeneration />} />
      <Route path="operation/member/cms-correspondence/trr-fallouts" element={<TRRFallouts />} />
      <Route path="operation/member/member-correspondence/letter-generation" element={<MemberCorrespondenceFile />} />
      <Route path="operation/member/member-correspondence/id-cards" element={<MemberCorrespondenceFile />} />
      <Route path="operation/member/member-correspondence/welcome-kits" element={<MemberCorrespondenceFile />} />
      <Route path="operation/member/billing-and-payments/view-invoices" element={<InvoicePayments />} />
      <Route path="operation/member/billing-and-payments/cms-payments" element={<InvoicePayments />} />
      <Route path="operation/member/billing-and-payments/member-payments" element={<InvoicePayments />} />
      <Route path="operation/member/billing-and-payments/post-member-payments" element={<PostMemberPayments />} />
      <Route path="operation/member/billing-and-payments/premium-account-summary" element={<PremiumAccountSearch />} />
      <Route path="operation/member/billing-and-payments/post-member-payments/member-details" element={<PostMemberDeatils />} />
      <Route path="operation/member/reports/timeliness-reports/incomplete-apps" element={<TimeLinesReports />} />
      <Route path="operation/member/reports/timeliness-reports/rfi-Overdue" element={<TimeLinesReports />} />
      <Route path="operation/member/reports/timeliness-reports/denial-report" element={<TimeLinesReports />} />
      <Route path="operation/member/reports/timeliness-reports/cms-rejections-report" element={<TimeLinesReports />} />
      <Route path="operation/member/reports/timeliness-reports/cms-pending-report" element={<TimeLinesReports />} />
      <Route path="operation/member/reports/audit" element={<MemberReportsAudit />} />
      <Route path="administration/masters/common-code" element={<CommonCodeList />} />
      <Route path="administration/masters/common-code-view" element={<CommonCodeView />} />
      <Route path="administration/masters/common-code-add-edit" element={<CommonCodeAddEdit />} />
      <Route path="administration/masters/icd-code" element={<CommonCodeList />} />
      <Route path="administration/masters/revenue-code" element={<CommonCodeList />} />
      <Route path="administration/masters/drg-code" element={<CommonCodeList />} />
      <Route path="administration/masters/pos-code" element={<CommonCodeList />} />
      <Route path="administration/masters/ndc-code" element={<CommonCodeList />} />
      <Route path="administration/masters/hcc-code" element={<CommonCodeList />} />
      <Route path="administration/masters/zip-code" element={<ZIPCodeList />} />
      <Route path="administration/masters/zip-code-view" element={<ZipCodeView />} />
      <Route path="administration/masters/zip-code-add-edit" element={<ZipCodeAddEdit />} />
      <Route path="administration/masters/home-grown-code-list" element={<HomeGrownCodeList />} />
      <Route path="administration/masters/home-grown-add-edit" element={<HomeGrownAddEdit />} />
      <Route path="administration/masters/home-grown-view" element={<HomeGrownCodeView />} />
      <Route path="administration/masters/customer-setting-list" element={<CustomerSettingList />} />
      <Route path="administration/masters/customer-setting-add-edit" element={<CustomerSettingAddEdit />} />
      <Route path="administration/masters/code-type-list" element={<CommonTypeList />} />
      <Route path="administration/masters/common-code-display-configuration" element={<CommonCodeDisplayConfig />} />
      <Route path="administration/masters/common-codesection-list" element={<CommonCodeSectionList />} />
      <Route path="administration/masters/common-codesection-add-edit" element={<CommonCodeSectionAddEdit />} />
      <Route path="administration/security/roles" element={<RolesList />} />
      <Route path="administration/security/roles-add-edit" element={<RolesAddEdit />} />
      <Route path="administration/security/roles-view" element={<RolesView />} />
      <Route path="administration/security/users" element={<UsersConfig />} />
      <Route path="interfaces/clearing-house/professional-list" element={<ClearHousingConfig />} />
      <Route path="interfaces/clearing-house/institutional-list" element={<ClearHousingConfig />} />
      <Route path="interfaces/clearing-house/member-enrollment-list" element={<ClearHousingConfig />} />
      <Route path="interfaces/clearing-house/claim-status-list" element={<ClearHousingConfig />} />
      <Route path="interfaces/clearing-house/member-eligibilty-list" element={<ClearHousingConfig />} />
      <Route path="interfaces/clearing-house/encounter-list" element={<ClearHousingConfig />} />
      <Route path="administration/configuration/contracts-list" element={<ContractsList />} />
      <Route path="administration/configuration/contracts-add-edit" element={<ContractsAddEdit />} />
      <Route path="administration/configuration/contracts-view" element={<ContractView />} />
      <Route path="administration/configuration/copay-coinsurance-list" element={<CopayCoinsuranceList />} />
      <Route path="administration/configuration/copay-coinsurance-add-edit" element={<CopayCoinsuranceAddEdit />} />
      <Route path="administration/configuration/lob-list" element={<LOBList />} />
      <Route path="administration/configuration/lob-add-edit" element={<LOBAddEdit />} />
      <Route path="administration/configuration/lob-view" element={<LOBView />} />
      <Route path="administration/configuration/trc-config-list" element={<TRCConfig />} />
      <Route path="administration/configuration/organization-rule-list" element={<OrganizationRuleList />} />
      <Route path="administration/configuration/organization-add-edit" element={<OrganizationAddEdit />} />
      <Route path="administration/configuration/organization-view" element={<OrganizationView />} />
      <Route path="administration/configuration/benefit-list" element={<BenefitsList />} />
      <Route path="administration/configuration/benefit-add-edit" element={<BenefitConfiguration />} />
      <Route path="administration/configuration/benefit-view" element={<BenefitView />} />
      <Route path="administration/configuration/pbp-list" element={<PBPList />} />
      <Route path="administration/configuration/pbp-add-edit" element={<PBPConfiguration />} />
      <Route path="administration/configuration/pbp-view" element={<PBPView />} />

      {/* <Route path="claims/mass-adjudication-add-edit" element={<AdjudicationAddEdit />} /> */}
      <Route path="home" element={<Home />} />
      <Route path="auth-callback" element={<AuthCallBack />} />
      <Route path="" element={<Navigate to={"/home"} />} />
      <Route path="*" element={<>Not Found</>}></Route>
    </Route>
  </>
);

export const AppRouter = createHashRouter(createRoutesFromElements(appRoutes));
