import { CoreLayout } from "./CoreLayout";

export const CoreThemeLayout = () => {
    return (<CoreLayout />);
};