import { AuthCallBack } from "../../../components/auth/authCallback";
import { ProtectedLayout } from "../../auth/layout/ProtectedLayout";

export const CoreLayout = () => {
    return localStorage.getItem("UserTokenInfo") ? <ProtectedLayout /> : <AuthCallBack />
};