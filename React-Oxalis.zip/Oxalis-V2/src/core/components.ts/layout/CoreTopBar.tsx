export const CoreTopBar = () => {
    return (<>CoreTopBar..</>);
}