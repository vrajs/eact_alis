import loader from "../../../assets/Loader.svg";
const PageLoader = () => {
  return (
    <div className="page-loader">
      <img src={loader}></img>
    </div>
  );
};

export default PageLoader;
