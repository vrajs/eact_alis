const AuthLoader = () => {
  return (
    <div className="flex place-content-center items-center h-screen w-screen justify-between">
      <div className="self-center flex flex-col justify-between items-center m-auto gap-4">
        <div className="relative">
          <>
          </>
        </div>
        <div className="loader-message"></div>
      </div>
    </div>
  );
};

export default AuthLoader;