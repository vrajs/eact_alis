import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import Calendar from "../../../../controls/Calendar";
import CustomForm from "../../../../controls/CustomForm";
import Checkbox from "../../../../controls/CheckBox";
import Dropdown from "../../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";

const BenefitServiceGroups = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [checked, setChecked] = useState(false);
  const [showForm, setShowForm] = useState(false); // State to toggle form display
  const [svcCodeGroup, setSvcCodeGroupList] = useState(null);
  const [svcCodeCategory, setSvcCodeCategoryList] = useState(null);
  const [svcCodeSubCategory, setSvcCodeSubCategoryList] = useState(null);
  const svcCodeSubCategoryList = [{ key: "Test", value: "1" }];
  const svcCodeCategoryList = [{ key: "Debs Sub Group 2", value: "1" }];
  const svcCodeGroupList = [
    { key: "Debs Test 2", value: "1" },
    { key: "DT Test Group", value: "2" },
  ];
  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={() => setShowForm(true)} />
        </div>
      </div>
    );
  };

  const handleSave = () => {
    setShowForm(false);
  };

  return (
    <>
      {showForm ? (
        <div className="pt-3">
          <CustomForm form={undefined}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="svcCodeGroup" label="Claim Type">
                <Dropdown
                  id="svcCodeGroup"
                  options={svcCodeGroupList}
                  value={svcCodeGroup}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setSvcCodeGroupList(event.value)}
                  showClear
                  showHeader
                  multiple
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="svcCodeCategory" label="Capitation Type">
                <Dropdown
                  id="svcCodeCategory"
                  options={svcCodeCategoryList}
                  value={svcCodeCategory}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setSvcCodeCategoryList(event.value)}
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="svcCodeSubCategory" label="Anes Conversation">
                <Dropdown
                  id="svcCodeSubCategory"
                  options={svcCodeSubCategoryList}
                  value={svcCodeSubCategory}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setSvcCodeSubCategoryList(event.value)}
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <div className="flex gap-3 items-center">
                <Checkbox
                  id="exclude-checkbox"
                  type="checkbox"
                  checked={checked}
                  onChange={(e) => setChecked(e.target.checked)}
                  className="p-checkbox"
                  label="Exclude"
                />
              </div>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={() => setShowForm(false)} />
              <Button label="Save" raised onClick={handleSave} />
            </div>
          </CustomForm>
        </div>
      ) : (
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines mt-4"
          showGridlines
          rows={10}
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)}
          selectionMode="single"
        >
          <Column field="svcCodeGroup" header="Svc&nbsp;Code&nbsp;Group" filter sortable />
          <Column field="svcCodeCategory" header="Svc&nbsp;Code&nbsp;Category" filter sortable />
          <Column field="svcCodeSubcategory" header="Svc&nbsp;Code&nbsp;Subcategory" filter sortable />
          <Column field="exclude" header="Exclude" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      )}
    </>
  );
};

export default BenefitServiceGroups;
