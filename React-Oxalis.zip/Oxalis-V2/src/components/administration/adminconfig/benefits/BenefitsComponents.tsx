import { Panel } from "primereact/panel";
import { TabView, TabPanel } from "primereact/tabview";
import BenefitCodes from "./BenefitCodes";
import BenefitServiceGroups from "./BenefitServiceGroup";
import BenefitModifiers from "./BenefitModifiers";
import BenefitProviders from "./BenefitProviders";
import BenefitsCopay from "./BenefitsCopay";
import BenefitCopayPerDiem from "./BenefitsCopayPerDiem";
import BenefitsVisits from "./BenefitsVisits";
import BenefitDeductibleMax from "./BenefitDeductibleMax";

const BenefitComponents = () => {
  const tabs = [
    { header: "Codes", component: <BenefitCodes /> },
    { header: "Service Groups", component: <BenefitServiceGroups /> },
    { header: "Modifiers", component: <BenefitModifiers /> },
    { header: "Diagnosis", component: <BenefitModifiers /> },
    { header: "Place Of Service", component: <BenefitModifiers /> },
    { header: "Bill Types", component: <BenefitModifiers /> },
    { header: "Providers", component: <BenefitProviders /> },
    { header: "Copay/Coinsurance", component: <BenefitsCopay /> },
    { header: "Copay Per Diem", component: <BenefitCopayPerDiem /> },
    { header: "Visits", component: <BenefitsVisits /> },
    { header: "Deductible/Max OOP", component: <BenefitDeductibleMax /> },
  ];

  return (
    <Panel header="Benefit Components" toggleable className="custom-tab-menu">
      <TabView>
        {tabs.map((tab, index) => (
          <TabPanel key={index} header={tab.header}>
            {tab.component}
          </TabPanel>
        ))}
      </TabView>
    </Panel>
  );
};

export default BenefitComponents;
