import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import Calendar from "../../../../controls/Calendar";
import CustomForm from "../../../../controls/CustomForm";
import Dropdown from "../../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import { useState } from "react";
import ViewForm from "../../../../controls/ViewForm";
import { Sidebar } from "primereact/sidebar";
import TermMasterVisit from "../contracts/TermMasterVisit";

const BenefitsVisits = () => {
  const [visitCode, setvisitCodeList] = useState(null);
  const [shareBenefitLimit, setshareBenefitLimitList] = useState(null);

  const visitCodeList = [
    { key: "PQ-RQ-$225", value: "1" },
    { key: "60 Add Days-IP", value: "2" },
  ];
  const [visibleBottom, setVisibleBottom] = useState(false);
  const shareBenefitLimitList = [
    { key: "Acupunture", value: "1" },
    { key: "AMA 123", value: "2" },
  ];
  const headerRecord = [
    { label: "Code", value: "60 Add Days-IP" },
    { label: "Description", value: "60 Additional Reserve Days" },
    { label: "Visit Type", value: "Per Day" },
    { label: "Max Amount", value: "N/A" },
    { label: "Max Unit", value: "N/A" },
    { label: "Time Period", value: "N/A" },
    { label: "SVCS outside US", value: "N/A" },
    { label: "Ben Max Unit", value: "N/A" },
    { label: "Ben Max Unit Time Period", value: "N/A" },
    { label: "Effective Date", value: "N/A" },
    { label: "Term Date", value: "N/A" },
  ];
  return (
    <>
      <div className="pt-3">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="visitCode" label="Visit Code">
              <Dropdown
                id="visitCode"
                options={visitCodeList}
                value={visitCode}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setvisitCodeList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="shareBenefitLimit" label="Share Benefit Limit">
              <Dropdown
                id="shareBenefitLimit"
                options={shareBenefitLimitList}
                value={shareBenefitLimit}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setshareBenefitLimitList(event.value)}
                showClear
                showHeader
                multiple
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
          </div>
          <ViewForm header="Details" data={headerRecord} />
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Create New Visit Code" outlined onClick={() => setVisibleBottom(true)} />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      </div>
      <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-4/6 text-xl"
        header="Master Visit"
      >
        <TermMasterVisit />
      </Sidebar>
    </>
  );
};

export default BenefitsVisits;
