import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "../../../../controls/Button";
import { SelectButton } from "primereact/selectbutton";
import BenefitPlanPackage from "./BenefitPlanPackage";

const BenefitAttachmentPlan = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [showBenefitPlanPackage, setShowBenefitPlanPackage] = useState(false); // State to show/hide BenefitPlanPackage
  const navigate = useNavigate();

  const handleCodeClick = () => {
    navigate(`/administration/configuration/benefit-view`);
  };
  const options = ["Active"];
  const [value, setValue] = useState(options[0]);

  const headerTemplate = () => {
    return (
      <div className="flex justify-content-between gap-3 items-center">
        <label>Attach Plan(s)</label>
        <div className="flex gap-2">
          <SelectButton value={value} onChange={(e) => setValue(e.value)} options={options} />
          <Button outlined label="Create" onClick={() => setShowBenefitPlanPackage(true)} />
          <Button outlined label="Attach" />
          <Button outlined label="Cancel" />
        </div>
      </div>
    );
  };

  const codeData = [
    {
      codesID: 1,
      planCode: "H0001-015",
      planName: "AZ-Dialysis Complete (HMO-POS C-SNP) $37.80* per month",
      productType: "Medicare Advantage",
      lob: "medicare",
      pbp: "015",
      state: "AZ",
      county: "Graham",
      effectiveDate: "1/1/2024",
      termDate: "9/19/2024",
    },
  ];

  return (
    <>
      {!showBenefitPlanPackage ? (
        <div className="pb-4">
          <DataTable
            paginator
            header={headerTemplate}
            className="p-datatable-gridlines"
            showGridlines
            rows={10}
            value={codeData} // Static data added here
            dataKey="codesID"
            emptyMessage="No records found."
            selection={selectedCustomer}
            onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
            selectionMode="single" // Single row selection
          >
            <Column
              field="planCode"
              header="Plan&nbsp;Code"
              body={(rowData) => (
                <a className="underline" onClick={handleCodeClick}>
                  {rowData.planCode}
                </a>
              )}
              filter
              sortable
            />
            <Column field="planName" header="Plan&nbsp;Name" filter sortable />
            <Column field="productType" header="Product&nbsp;Type" filter sortable />
            <Column field="lob" header="Line&nbsp;Of&nbsp;Business" filter sortable />
            <Column field="pbp" header="PBP" filter sortable />
            <Column field="state" header="State" filter sortable />
            <Column field="county" header="County" filter sortable />
            <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
            <Column field="termDate" header="Term&nbsp;Date" filter sortable />
          </DataTable>
        </div>
      ) : (
        <BenefitPlanPackage />
      )}
    </>
  );
};

export default BenefitAttachmentPlan;
