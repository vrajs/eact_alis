import { Panel } from "primereact/panel";
import FormItem from "../../../../controls/FormItem";
import CustomForm from "../../../../controls/CustomForm";
import InputText from "../../../../controls/InputText";
import Button from "../../../../controls/Button";
import { DropdownChangeEvent } from "primereact/dropdown";
import { useState } from "react";
import Dropdown from "../../../../controls/Dropdown";
import Calendar from "../../../../controls/Calendar";
import InputTextarea from "../../../../controls/InputTextarea";
import Checkbox from "../../../../controls/CheckBox";

const BenefitsAddEdit = () => {
  const [remitReason, setRemitReasonList] = useState(null);
  const [eobReason, setEobReasonList] = useState(null);
  const [serviceTypeCode, setServiceTypeCodeList] = useState(null);
  const [claimType, setClaimTypeList] = useState(null);
  const [providerType, setProviderTypeList] = useState(null);
  const [providerStatus, setProviderStatusList] = useState(null);
  const providerStatusList = [{ key: "Letter Of Agreement", value: "1" }];
  const providerTypeList = [{ key: " Dental", value: "1" }];
  const claimTypeList = [{ key: "HCFA", value: "1" }];
  const serviceTypeCodeList = [{ key: "Medical Care", value: "1" }];
  const eobReasonList = [{ key: "Noncovered Service", value: "1" }];
  const remitReasonList = [{ key: "Resubmit To Argus", value: "1" }];
  const [providerSpeciality, setproviderSpecialityList] = useState(null);
  const [gender, setgenderList] = useState(null);
  const genderList = [{ key: "Male", value: "1" }];
  const providerSpecialityList = [{ key: "Addiction Psychiatry, Adolescent Med - Pediatrics", value: "1" }];
  const [benefitCategory, setbenefitCategoryList] = useState(null);
  const [network, setnetworkList] = useState(null);
  const networkList = [{ key: "Amercian Health Alliance", value: "1" }];
  const benefitCategoryList = [{ key: "Mental Health Services", value: "1" }];
  const [checkboxStates, setCheckboxStates] = useState(
    Array(9).fill(false), // initialize each checkbox as unchecked
  );
  const handleCheckboxChange = (index) => {
    const newCheckboxStates = [...checkboxStates];
    newCheckboxStates[index] = !newCheckboxStates[index];
    setCheckboxStates(newCheckboxStates);
  };

  const checkboxLabels = [
    "Auth Required",
    "Manual Review",
    "Emergency",
    "Members PCP",
    "Is PCP",
    "Coinsurance",
    "Copay",
    "Visit Limits",
    "Deductible",
  ];

  return (
    <>
      <Panel header="Benefit Header Information" toggleable className="search-panel mb-4">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="code" label="Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="name" label="Name">
              <InputText placeholder="Enter here" />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="remitReason" label="Remit Reason">
              <Dropdown
                id="remitReason"
                options={remitReasonList}
                value={remitReason}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setRemitReasonList(event.value)}
                showClear
                showHeader
                multiple
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="eobReason" label="EOB Reason">
              <Dropdown
                id="eobReason"
                options={eobReasonList}
                value={eobReason}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setEobReasonList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="serviceTypeCode" label="Service Type Code">
              <Dropdown
                id="serviceTypeCode"
                options={serviceTypeCodeList}
                value={serviceTypeCode}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setServiceTypeCodeList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="claimType" label="Claim Type">
              <Dropdown
                id="claimType"
                options={claimTypeList}
                value={claimType}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setClaimTypeList(event.value)}
                showClear
                showHeader
                multiple
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="providerType" label="Provider Type">
              <Dropdown
                id="providerType"
                options={providerTypeList}
                value={providerType}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setProviderTypeList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="providerStatus" label="Provider Status">
              <Dropdown
                id="providerStatus"
                options={providerStatusList}
                value={providerStatus}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setProviderStatusList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>

            <FormItem name="providerSpeciality" label="Provider Speciality">
              <Dropdown
                id="providerSpeciality"
                options={providerSpecialityList}
                value={providerSpeciality}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setproviderSpecialityList(event.value)}
                showClear
                multiple
                showHeader
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="gender" label="Gender">
              <Dropdown
                id="gender"
                options={genderList}
                value={gender}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setgenderList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="benefitCategory" label="Benefit Category">
              <Dropdown
                id="benefitCategory"
                options={benefitCategoryList}
                value={benefitCategory}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setbenefitCategoryList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <div className="!grid grid-cols-2 !gap-4">
              <FormItem name="ageFrom" label="Age From">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="ageTo" label="Age To">
                <InputText placeholder="Enter here" />
              </FormItem>
            </div>
            <FormItem name="network" label="Network">
              <Dropdown
                id="network"
                options={networkList}
                value={network}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setnetworkList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <div className="col-span-full">
              <FormItem name="desc" label="Description">
                <InputTextarea rows={3} />
              </FormItem>
            </div>
            <div className="flex gap-3 flex-wrap col-span-full">
              {checkboxLabels.map((label, index) => (
                <FormItem key={index} label="" name={label.toLowerCase().replace(" ", "")}>
                  <Checkbox
                    inputId={label.toLowerCase().replace(" ", "")}
                    label={label}
                    checked={checkboxStates[index]}
                    onChange={() => handleCheckboxChange(index)}
                  />
                </FormItem>
              ))}
            </div>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      </Panel>
    </>
  );
};

export default BenefitsAddEdit;
