import { useState } from "react";
import { Steps } from "primereact/steps";
import BenefitsAddEdit from "./BenefitAddEdit";
import { useNavigate } from "react-router-dom";
import BenefitPlanList from "./BenefitPlanList";
import BenefitComponents from "./BenefitsComponents";

const BenefitConfiguration = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const navigate = useNavigate();

  const items = [
    {
      label: "Benefit Configuration",
      command: () => setActiveIndex(0),
    },
    {
      label: "Associate Plans",
      command: () => setActiveIndex(1),
    },
  ];
  const handleNavigate = () => {
    navigate("/administration/configuration/benefit-list");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>
        Benefit Configuration
      </h2>
      <div className="card">
        <Steps model={items} activeIndex={activeIndex} onSelect={(e) => setActiveIndex(e.index)} readOnly={false} className="mb-4" />
        <div className="content">
          {activeIndex === 0 && (
            <>
              <BenefitsAddEdit />
              <BenefitComponents />
            </>
          )}
          {activeIndex === 1 && <BenefitPlanList />}
        </div>
      </div>
    </>
  );
};

export default BenefitConfiguration;
