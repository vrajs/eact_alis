import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import InputText from "../../../../controls/InputText";
import Calendar from "../../../../controls/Calendar";
import CustomForm from "../../../../controls/CustomForm";
import Checkbox from "../../../../controls/CheckBox";

const BenefitCodes = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [checked, setChecked] = useState(false);
  const [showForm, setShowForm] = useState(false); // State to toggle form display

  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={() => setShowForm(true)} />
        </div>
      </div>
    );
  };

  const handleSave = () => {
    setShowForm(false); // Show the data table after saving
    // Add save logic here if necessary
  };

  return (
    <>
      {showForm ? (
        <div className="pt-3">
          <CustomForm form={undefined}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="minCode" label="Min Code">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="maxCode" label="Max Code">
                <InputText placeholder="Enter here" />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <div className="flex gap-3 items-center">
                <Checkbox
                  id="exclude-checkbox"
                  type="checkbox"
                  checked={checked}
                  onChange={(e) => setChecked(e.target.checked)}
                  className="p-checkbox"
                  label="Exclude"
                />
              </div>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={() => setShowForm(false)} />
              <Button label="Save" raised onClick={handleSave} />
            </div>
          </CustomForm>
        </div>
      ) : (
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines mt-4"
          showGridlines
          rows={10}
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column field="codeType" header="Code&nbsp;Type" filter sortable />
          <Column field="minCode" header="Min&nbsp;Code" filter sortable />
          <Column field="maxCode" header="Max&nbsp;Code" filter sortable />
          <Column field="exclude" header="Exclude" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      )}
    </>
  );
};

export default BenefitCodes;
