import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import InputText from "../../../../controls/InputText";
import Calendar from "../../../../controls/Calendar";
import CustomForm from "../../../../controls/CustomForm";

const BenefitCopayPerDiem = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);

  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={() => setShowForm(true)} />
        </div>
      </div>
    );
  };

  const handleSave = () => {
    setShowForm(false);
  };

  return (
    <>
      {showForm ? (
        <div className="pt-3">
          <CustomForm form={undefined}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="startDay" label="Start Day">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="endDay" label="End Day">
                <InputText placeholder="Enter here" />
              </FormItem>
              <FormItem name="perDiem" label="Per Diem">
                <InputText placeholder="Enter here" />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={() => setShowForm(false)} />
              <Button label="Save" raised onClick={handleSave} />
            </div>
          </CustomForm>
        </div>
      ) : (
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines mt-4"
          showGridlines
          rows={10}
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column field="startDay" header="Min&nbsp;Code" filter sortable />
          <Column field="endDay" header="Max&nbsp;Name" filter sortable />
          <Column field="perDiem" header="Exclude" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      )}
    </>
  );
};

export default BenefitCopayPerDiem;
