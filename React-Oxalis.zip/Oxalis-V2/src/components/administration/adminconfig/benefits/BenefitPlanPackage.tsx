import { Panel } from "primereact/panel";
import FormItem from "../../../../controls/FormItem";
import CustomForm from "../../../../controls/CustomForm";
import Button from "../../../../controls/Button";
import { DropdownChangeEvent } from "primereact/dropdown";
import { useState } from "react";
import Dropdown from "../../../../controls/Dropdown";
import Calendar from "../../../../controls/Calendar";
import InputText from "../../../../controls/InputText";
import InputTextarea from "../../../../controls/InputTextarea";

const BenefitPlanPackage = () => {
  const [company, setCompanyList] = useState(null);
  const [subCompany, setSubCompanyList] = useState(null);
  const [lob, setLobList] = useState(null);
  const [product, setProductList] = useState(null);
  const [contractID, setContractIDList] = useState(null);
  const [county, setCountyList] = useState(null);
  const countyList = [{ key: "Test", value: "1" }];
  const [state, setStateList] = useState(null);
  const [approvalStatus, setapprovalStatusList] = useState(null);
  const approvalStatusList = [{ key: "Approved", value: "1" }];

  const stateList = [
    { key: "AL", value: "1" },
    { key: "AZ", value: "2" },
  ];
  const contractIDList = [
    { key: "H0001", value: "H0001" },
    { key: "H0002", value: "H0002" },
  ];
  const [pbpID, setPBPIDList] = useState(null);
  const pbpIDList = [
    { key: "012", value: "012" },
    { key: "013", value: "013" },
  ];
  const productList = [
    { key: "Medicare", value: "1" },
    { key: "Medicaid", value: "2" },
  ];

  const lobList = [
    { key: "Advantage", value: "1" },
    { key: "INET Medicare", value: "2" },
  ];
  const subCompanyList = [{ key: "HPS AaNeel IT", value: "1" }];
  const companyList = [
    { key: "HPS Aaneel", value: "1" },
    { key: "Citrus", value: "2" },
  ];

  return (
    <>
      <Panel header="Plan Benefit Package" toggleable className="search-panel mb-4">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="company" label="Company">
              <Dropdown
                id="company"
                options={companyList}
                value={company}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setCompanyList(event.value)}
                showClear
                showHeader
                multiple
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="subCompany" label="Sub Company">
              <Dropdown
                id="subCompany"
                options={subCompanyList}
                value={subCompany}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setSubCompanyList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="lob" label="Line Of Business">
              <Dropdown
                id="lob"
                options={lobList}
                value={lob}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setLobList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="contractID" label="contract ID">
              <Dropdown
                id="contractID"
                options={contractIDList}
                value={contractID}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setContractIDList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="pbpID" label="PBP ID">
              <Dropdown
                id="pbpID"
                options={pbpIDList}
                value={pbpID}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setPBPIDList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="packageCode" label="Plan Benefit Package Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="packageName" label="Plan Benefit Package Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="product" label="product Type">
              <Dropdown
                id="product"
                options={productList}
                value={product}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setProductList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="state" label="State">
              <Dropdown
                id="state"
                options={stateList}
                value={state}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setStateList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="county" label="County">
              <Dropdown
                id="county"
                options={countyList}
                value={county}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setCountyList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="approvalStatus" label="Approval Status">
              <Dropdown
                id="approvalStatus"
                options={approvalStatusList}
                value={approvalStatus}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setapprovalStatusList(event.value)}
                showClear
                showHeader
                multiple
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="approvalDate" label="Approval Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <div className="col-span-full">
              <FormItem name="desc" label="Plan Benefit Package Description">
                <InputTextarea rows={3} />
              </FormItem>
            </div>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      </Panel>
    </>
  );
};

export default BenefitPlanPackage;
