import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import Calendar from "../../../../controls/Calendar";
import CustomForm from "../../../../controls/CustomForm";
import Dropdown from "../../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import { useState } from "react";
import ViewForm from "../../../../controls/ViewForm";
import { Sidebar } from "primereact/sidebar";
import CopayCoinsuranceAddEdit from "../copay-coinsurance/CopayCoinsuranceAddEdit";

const BenefitsCopay = () => {
  const [code, setCodeList] = useState(null);
  const codeList = [
    { key: "$20 fixed", value: "1" },
    { key: "30%", value: "2" },
  ];
  const [visibleBottom, setVisibleBottom] = useState(false);

  const headerRecord = [
    { label: "Code", value: "N/A" },
    { label: "Fixed Copay", value: "N/A" },
    { label: "Max Copay", value: "N/A" },
    { label: "Max Period", value: "N/A" },
    { label: "Coinsurance", value: "N/A" },
    { label: "Max Copay Per Diem", value: "N/A" },
    { label: "Max Copay Per Diem Period", value: "N/A" },
    { label: "Variable Copay Per Diem", value: "N/A" },
    { label: "Par/Nonpar", value: "N/A" },
    { label: "Network", value: "N/A" },
  ];
  return (
    <>
      <div className="pt-3">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="code" label="Code">
              <Dropdown
                id="code"
                options={codeList}
                value={code}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setCodeList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
          </div>
          <ViewForm header="Details" data={headerRecord} />
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Create New Visit Code" outlined onClick={() => setVisibleBottom(true)} />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      </div>
      <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-4/6 text-xl"
        header="Master Visit"
      >
        <CopayCoinsuranceAddEdit />
      </Sidebar>
    </>
  );
};

export default BenefitsCopay;
