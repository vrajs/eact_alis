import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import InputText from "../../../../controls/InputText";
import Calendar from "../../../../controls/Calendar";
import CustomForm from "../../../../controls/CustomForm";
import Dropdown from "../../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import React from "react";
import Checkbox from "../../../../controls/CheckBox";

const BenefitDeductibleMax = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [showForm, setShowForm] = useState(false); // State to toggle form display
  const [typeOfDeductible, settypeOfDeductibleList] = useState(null);
  const typeOfDeductibleList = [{ key: "Test", value: "1" }];
  const [timePeriod, setTimePeriodList] = useState(null);
  const timePeriodList = [{ key: "5 weeks", value: "1" }];
  const OOPList = [{ key: "After benefit Package", value: "1" }];
  const [OOP, setOOPList] = useState(null);

  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={() => setShowForm(true)} />
        </div>
      </div>
    );
  };

  const handleSave = () => {
    setShowForm(false); // Show the data table after saving
    // Add save logic here if necessary
  };
  const data = [
    { label: "Individual OOP" },
    { label: "Family OOP" },
    { label: "Individual Deductible" },
    { label: "Family Deductible" },
    // Add more items as needed for the repeater
  ];

  return (
    <>
      {showForm ? (
        <div className="pt-3">
          <CustomForm form={undefined}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="typeOfDeductible" label="Type Of Deductible">
                <Dropdown
                  id="typeOfDeductible"
                  options={typeOfDeductibleList}
                  value={typeOfDeductible}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => settypeOfDeductibleList(event.value)}
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="percentageOfIncome" label="Percentage Of Income">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
            </div>
            <div className="!grid grid-cols-3">
              {/* Header Row */}
              <div className="border-1 surface-border p-fluid  p-3"></div>
              <div className="border-1 surface-border p-fluid  p-3">
                <div>In Network</div>
              </div>
              <div className="border-1 surface-border p-fluid  p-3">
                <div>Out Network</div>
              </div>
              {data.map((item, index) => (
                <React.Fragment key={index}>
                  <div className="border-1 surface-border flex justify-center items-center p-3">
                    <div>{item.label}</div>
                  </div>
                  <div className="border-1 surface-border  p-3">
                    <FormItem name="" label="">
                      <InputText type="text" placeholder="Enter here" />
                    </FormItem>
                  </div>
                  <div className="border-1 surface-border  p-3">
                    <FormItem name="" label="">
                      <InputText type="text" placeholder="Enter here" />
                    </FormItem>
                  </div>
                </React.Fragment>
              ))}
              <div className="border-1 surface-border p-fluid p-3 items-center justify-center flex">Time Period</div>
              <div className="border-1 surface-border p-fluid  p-3">
                <FormItem name="timePeriod" label="">
                  <Dropdown
                    id="timePeriod"
                    options={timePeriodList}
                    value={timePeriod}
                    optionLabel="key"
                    optionValue="value"
                    onChange={(event: DropdownChangeEvent) => setTimePeriodList(event.value)}
                    showClear
                    placeholder="Select"
                    className="w-full"
                  />
                </FormItem>
              </div>
              <div className="border-1 surface-border p-fluid   p-3">
                <FormItem name="timePeriod" label="">
                  <Dropdown
                    id="timePeriod"
                    options={timePeriodList}
                    value={timePeriod}
                    optionLabel="key"
                    optionValue="value"
                    onChange={(event: DropdownChangeEvent) => setTimePeriodList(event.value)}
                    showClear
                    placeholder="Select"
                    className="w-full"
                  />
                </FormItem>
              </div>
              <div className="border-1 surface-border p-fluid p-3 items-center justify-center flex">Apply to OOP</div>
              <div className="border-1 surface-border p-fluid  p-3">
                <FormItem name="OOP" label="">
                  <Dropdown
                    id="OOP"
                    options={OOPList}
                    value={OOP}
                    optionLabel="key"
                    optionValue="value"
                    onChange={(event: DropdownChangeEvent) => setOOPList(event.value)}
                    showClear
                    placeholder="Select"
                    className="w-full"
                  />
                </FormItem>
              </div>
              <div className="border-1 surface-border p-fluid   p-3">
                <FormItem name="OOP" label="">
                  <Dropdown
                    id="OOP"
                    options={OOPList}
                    value={OOP}
                    optionLabel="key"
                    optionValue="value"
                    onChange={(event: DropdownChangeEvent) => setOOPList(event.value)}
                    showClear
                    placeholder="Select"
                    className="w-full"
                  />
                </FormItem>
              </div>
              <div className="border-1 surface-border p-fluid p-3 items-center justify-center flex">Include in Max OOP</div>
              <div className="border-1 surface-border p-fluid  p-3 flex flex-wrap gap-3">
                <Checkbox type="checkbox" label="deductible" checked={false} />
                <Checkbox type="checkbox" label="coinsurance" checked={false} />
                <Checkbox type="checkbox" label="copay" checked={false} />
              </div>
              <div className="border-1 surface-border p-fluid flex flex-wrap gap-3 p-3">
                <Checkbox type="checkbox" label="deductible" checked={false} />
                <Checkbox type="checkbox" label="coinsurance" checked={false} />
                <Checkbox type="checkbox" label="copay" checked={false} />
              </div>
            </div>
            <div className="col-span-full py-4">
              <Checkbox
                type="checkbox"
                label=" Roll deductible and OOP amounts when Member plan transfers occur during benefit period "
                checked={false}
              />
            </div>

            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={() => setShowForm(false)} />
              <Button label="Save" raised onClick={handleSave} />
            </div>
          </CustomForm>
        </div>
      ) : (
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines mt-4"
          showGridlines
          rows={10}
          dataKey="typeOfDeductiblesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column field="deductibleType" header="Deductible&nbsp;Type" filter sortable />
          <Column field="network" header="Network" filter sortable />
          <Column field="incomePercentage" header="Income&nbsp;Percentage" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      )}
    </>
  );
};

export default BenefitDeductibleMax;
