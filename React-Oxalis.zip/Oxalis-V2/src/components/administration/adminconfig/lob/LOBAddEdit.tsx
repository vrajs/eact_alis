import { Panel } from "primereact/panel";
import { useNavigate } from "react-router-dom";
import FormItem from "../../../../controls/FormItem";
import CustomForm from "../../../../controls/CustomForm";
import InputText from "../../../../controls/InputText";
import Button from "../../../../controls/Button";
import { DropdownChangeEvent } from "primereact/dropdown";
import { useState } from "react";
import Dropdown from "../../../../controls/Dropdown";
import Calendar from "../../../../controls/Calendar";

const LOBAddEdit = () => {
  const navigate = useNavigate();
  const [company, setCompanyList] = useState(null);
  const [subCompany, setSubCompanyList] = useState(null);
  const [sponser, setSponserList] = useState(null);
  const [category, setCategoryList] = useState(null);
  const [product, setProductList] = useState(null);
  const productList = [
    { key: "Medicare", value: "1" },
    { key: "Medicaid", value: "2" },
  ];
  const categoryList = [
    { key: "HMO", value: "1" },
    { key: "PPO", value: "2" },
  ];
  const sponserList = [
    { key: "CMS", value: "1" },
    { key: "AaNeel Technology", value: "2" },
  ];
  const subCompanyList = [{ key: "HPS AaNeel IT", value: "1" }];
  const companyList = [
    { key: "HPS Aaneel", value: "1" },
    { key: "Citrus", value: "2" },
  ];

  const handleNavigate = () => {
    navigate("/administration/configuration/lob-list");
  };

  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>
        Line of Business Configuration
      </h2>
      <Panel header="LOB Information" toggleable className="search-panel mb-4">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="code" label="Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="name" label="Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="company" label="Company">
              <Dropdown
                id="company"
                options={companyList}
                value={company}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setCompanyList(event.value)}
                showClear
                showHeader
                multiple
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="subCompany" label="Sub Company">
              <Dropdown
                id="subCompany"
                options={subCompanyList}
                value={subCompany}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setSubCompanyList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="sponser" label="Sponser">
              <Dropdown
                id="sponser"
                options={sponserList}
                value={sponser}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setSponserList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="category" label="category">
              <Dropdown
                id="category"
                options={categoryList}
                value={category}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setCategoryList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="product" label="product">
              <Dropdown
                id="product"
                options={productList}
                value={product}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setProductList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      </Panel>
    </>
  );
};

export default LOBAddEdit;
