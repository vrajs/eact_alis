import { useNavigate } from "react-router-dom";
import ViewForm from "../../../../controls/ViewForm";

const LOBView = () => {
  const navigate = useNavigate();

  const headerRecord = [
    { label: "Code", value: "HCPCS Code" },
    { label: "Name", value: "Test2" },
    { label: "Organization", value: "HPS AaNeel IT" },
    { label: "Sponsor", value: "CMS" },
    { label: "Category", value: "HMO" },
    { label: "Product", value: "Medicare" },
    { label: "Effective Date", value: "1/1/2011" },
    { label: "Term Date", value: "1/1/2011" },
  ];
  const handleNavigate = () => {
    navigate("/administration/configuration/lob-list");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Line Of Business
      </h2>
      <ViewForm header="LOB Information" data={headerRecord} />
    </>
  );
};

export default LOBView;
