import { Panel } from "primereact/panel";
import { useNavigate } from "react-router-dom";
import FormItem from "../../../../controls/FormItem";
import CustomForm from "../../../../controls/CustomForm";
import Button from "../../../../controls/Button";
import { DropdownChangeEvent } from "primereact/dropdown";
import { useState } from "react";
import Dropdown from "../../../../controls/Dropdown";
import Calendar from "../../../../controls/Calendar";
import OrganizationComponents from "./OrganizationComponents";

const OrganizationAddEdit = () => {
  const navigate = useNavigate();
  const [company, setCompanyList] = useState(null);
  const [subCompany, setSubCompanyList] = useState(null);
  const [lob, setLobList] = useState(null);
  const [plan, setPlanList] = useState(null);
  const [product, setProductList] = useState(null);
  const productList = [
    { key: "Medicare", value: "1" },
    { key: "Medicaid", value: "2" },
  ];
  const planList = [
    { key: "Key Loomis", value: "1" },
    { key: "AANEEL Family", value: "2" },
  ];
  const lobList = [
    { key: "Advantage", value: "1" },
    { key: "INET Medicare", value: "2" },
  ];
  const subCompanyList = [{ key: "HPS AaNeel IT", value: "1" }];
  const companyList = [
    { key: "HPS Aaneel", value: "1" },
    { key: "Citrus", value: "2" },
  ];

  const handleNavigate = () => {
    navigate("/administration/configuration/organization-rule-list");
  };

  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>
        Organization Rule
      </h2>
      <Panel header="Rule Information" toggleable className="search-panel mb-4">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="company" label="Company">
              <Dropdown
                id="company"
                options={companyList}
                value={company}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setCompanyList(event.value)}
                showClear
                showHeader
                multiple
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="subCompany" label="Sub Company">
              <Dropdown
                id="subCompany"
                options={subCompanyList}
                value={subCompany}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setSubCompanyList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="lob" label="Line Of Business">
              <Dropdown
                id="lob"
                options={lobList}
                value={lob}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setLobList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="plan" label="Plan">
              <Dropdown
                id="plan"
                options={planList}
                value={plan}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setPlanList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="product" label="product Type">
              <Dropdown
                id="product"
                options={productList}
                value={product}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setProductList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      </Panel>
      <OrganizationComponents />
    </>
  );
};

export default OrganizationAddEdit;
