import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import InputText from "../../../../controls/InputText";
import Calendar from "../../../../controls/Calendar";
import CustomForm from "../../../../controls/CustomForm";
import InputNumber from "../../../../controls/InputNumber";
import InputMask from "../../../../controls/InputMask";

const OrganizationClaimAddress = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);

  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={() => setShowForm(true)} />
        </div>
      </div>
    );
  };

  const handleSave = () => {
    setShowForm(false);
  };

  return (
    <>
      {showForm ? (
        <div className="pt-3">
          <CustomForm form={undefined}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="name" label="Name">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="address1" label="Address 1">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="address2" label="Address 2">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="city" label="City">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="state" label="State">
                <InputText placeholder="Enter here" />
              </FormItem>
              <FormItem name="zip" label="Zip">
                <InputNumber placeholder="Enter here" />
              </FormItem>
              <FormItem name="phone" label="Phone">
                <InputMask mask="(999) 999-9999" placeholder="Enter here" />
              </FormItem>
              <FormItem name="fax" label="Fax">
                <InputMask mask="999-999-9999" placeholder="Enter here" />
              </FormItem>
              <FormItem name="emailID" label="Email ID">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={() => setShowForm(false)} />
              <Button label="Save" raised onClick={handleSave} />
            </div>
          </CustomForm>
        </div>
      ) : (
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines mt-4"
          showGridlines
          rows={10}
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column field="name" header="Name" filter sortable />
          <Column field="address1" header="Address&nbsp;1" filter sortable />
          <Column field="address2" header="Address&nbsp;2" filter sortable />
          <Column field="city" header="City" filter sortable />
          <Column field="state" header="State" filter sortable />
          <Column field="zip" header="Zip" filter sortable />
          <Column field="phone" header="Phone" filter sortable />
          <Column field="fax" header="Fax" filter sortable />
          <Column field="email" header="Email" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      )}
    </>
  );
};

export default OrganizationClaimAddress;
