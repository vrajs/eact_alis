import { Panel } from "primereact/panel";
import { TabView, TabPanel } from "primereact/tabview";
import OrganizationTimelyFilling from "./OrganizationTimelyFilling";
import OrganizationCapitation from "./OrganizationCapitation";
import OrganizationFeeSchedule from "./OrganizationDefaultFeeSchedule";
import OrganizationClaimAddress from "./OrganizationClaimAddress";
import OrganizationEOBMessage from "./OrganizationEOBMessage";

const OrganizationComponents = () => {
  const tabs = [
    { header: "Timely Filling", component: <OrganizationTimelyFilling /> },
    { header: "Modifier Discount", component: <OrganizationTimelyFilling /> },
    { header: "Capitation", component: <OrganizationCapitation /> },
    { header: "Default Fee Schedule", component: <OrganizationFeeSchedule /> },
    { header: "Interest", component: <OrganizationTimelyFilling /> },
    { header: "Claim Address", component: <OrganizationClaimAddress /> },
    { header: "EOB Message", component: <OrganizationEOBMessage /> },
    { header: "EOP Message", component: <OrganizationEOBMessage /> },
  ];

  return (
    <Panel header="Rule Components" toggleable className="custom-tab-menu">
      <TabView>
        {tabs.map((tab, index) => (
          <TabPanel key={index} header={tab.header}>
            {tab.component}
          </TabPanel>
        ))}
      </TabView>
    </Panel>
  );
};

export default OrganizationComponents;
