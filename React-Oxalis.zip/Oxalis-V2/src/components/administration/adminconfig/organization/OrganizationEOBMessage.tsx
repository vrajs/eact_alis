import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import InputText from "../../../../controls/InputText";
import Calendar from "../../../../controls/Calendar";
import CustomForm from "../../../../controls/CustomForm";
import InputNumber from "../../../../controls/InputNumber";
import { FileUpload } from "primereact/fileupload";

const OrganizationEOBMessage = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);

  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={() => setShowForm(true)} />
        </div>
      </div>
    );
  };

  const handleSave = () => {
    setShowForm(false);
  };

  return (
    <>
      {showForm ? (
        <div className="pt-3">
          <CustomForm form={undefined}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="englishLanguage" label="English Language">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="alternateLanguage" label="Alternate Language">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="splashMessage" label="Splash Message">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="splashEffectiveDate" label="Splash Effective Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="splashTermDate" label="Splash Term Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="formNumber" label="Form Number">
                <InputNumber placeholder="Enter here" />
              </FormItem>
              <FormItem name="attachment" label="Attachment">
                <FileUpload mode="basic" name="filePreEnroll" maxFileSize={1000000} customUpload auto={false} />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={() => setShowForm(false)} />
              <Button label="Save" raised onClick={handleSave} />
            </div>
          </CustomForm>
        </div>
      ) : (
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines mt-4"
          showGridlines
          rows={10}
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column field="englishLanguage" header="English&nbsp;Language" filter sortable />
          <Column field="alternateLanguage" header="Alternate&nbsp;Language" filter sortable />
          <Column field="splashMessage" header="Splash&nbsp;Message" filter sortable />
          <Column field="formNumber" header="Form&nbsp;Number" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
          <Column field="splasheffectiveDate" header="Splash&nbsp;Effective&nbsp;Date" filter sortable />
          <Column field="splashtermDate" header="Splash&nbsp;Term&nbsp;Date" filter sortable />
        </DataTable>
      )}
    </>
  );
};

export default OrganizationEOBMessage;
