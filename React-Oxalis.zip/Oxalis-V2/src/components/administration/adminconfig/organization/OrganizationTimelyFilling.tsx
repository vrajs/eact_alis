import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import InputText from "../../../../controls/InputText";
import Calendar from "../../../../controls/Calendar";
import CustomForm from "../../../../controls/CustomForm";
import Dropdown from "../../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";

const OrganizationTimelyFilling = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);
  const [schedule, setScheduleList] = useState(null);

  const scheduleList = [
    { key: "Par Provider - 90", value: "1" },
    { key: "Par Hospital - 180", value: "2" },
  ];
  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={() => setShowForm(true)} />
        </div>
      </div>
    );
  };

  const handleSave = () => {
    setShowForm(false);
  };

  return (
    <>
      {showForm ? (
        <div className="pt-3">
          <CustomForm form={undefined}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="schedule" label="Schedule">
                <Dropdown
                  id="schedule"
                  options={scheduleList}
                  value={schedule}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setScheduleList(event.value)}
                  showClear
                  showHeader
                  multiple
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="schedule" label="Schedule Days">
                <InputText placeholder="Enter here" />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={() => setShowForm(false)} />
              <Button label="Save" raised onClick={handleSave} />
            </div>
          </CustomForm>
        </div>
      ) : (
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines mt-4"
          showGridlines
          rows={10}
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column field="schedule" header="Schedule" filter sortable />
          <Column field="scheduleDays" header="Schedule&nbsp;Days" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      )}
    </>
  );
};

export default OrganizationTimelyFilling;
