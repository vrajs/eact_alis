import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "../../../../controls/Button";

const OrganizationRuleList = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const navigate = useNavigate();

  // Handle 'Add' button click
  const handleAddClick = () => {
    navigate("/administration/configuration/organization-add-edit");
  };
  const handleCodeClick = () => {
    navigate(`/administration/configuration/organization-view`);
  };
  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={handleAddClick} />
        </div>
      </div>
    );
  };
  const codeData = [
    {
      codesID: 1,
      companyName: "HPS AaNeel",
      subCompanyName: "N/A",
      lob: "N/A",
      productType: "N/A",
      healthPlanName: "N/A",
      effectiveDate: "9/19/2022",
      termDate: "9/19/2022",
    },
    {
      codesID: 2,
      companyName: "Debs Test Company",
      subCompanyName: "N/A",
      lob: "N/A",
      productType: "N/A",
      healthPlanName: "N/A",
      effectiveDate: "9/19/2022",
      termDate: "9/19/2022",
    },
  ];
  return (
    <>
      <h2 className="pb-4">Organization Rule List</h2>
      <div className="pb-4">
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          value={codeData} // Static data added here
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column
            field="companyName"
            header="Company&nbsp;Name"
            body={(rowData) => (
              <a className="underline" onClick={handleCodeClick}>
                {rowData.companyName}
              </a>
            )}
            filter
            sortable
          />
          <Column field="subCompanyName" header="Sub&nbsp;Company&nbsp;Name" filter sortable />
          <Column field="lob" header="LOB" filter sortable />
          <Column field="productType" header="Product&nbsp;Type" filter sortable />
          <Column field="healthPlanName" header="Health&nbsp;PLan&nbsp;Name" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default OrganizationRuleList;
