import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import Calendar from "../../../../controls/Calendar";
import CustomForm from "../../../../controls/CustomForm";
import Dropdown from "../../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";

const OrganizationFeeSchedule = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);
  const [claimType, setClaimTypeList] = useState(null);
  const [contract, setContractList] = useState(null);
  const [providerType, setProviderTypeList] = useState(null);

  const contractList = [
    { key: "MR", value: "1" },
    { key: "ALF", value: "2" },
  ];
  const claimTypeList = [
    { key: "HCFA", value: "1" },
    { key: "UB04", value: "2" },
  ];
  const providerTypeList = [
    { key: "Dental", value: "1" },
    { key: "Ancillary", value: "2" },
  ];
  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={() => setShowForm(true)} />
        </div>
      </div>
    );
  };

  const handleSave = () => {
    setShowForm(false);
  };

  return (
    <>
      {showForm ? (
        <div className="pt-3">
          <CustomForm form={undefined}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="claimType" label="Claim Type">
                <Dropdown
                  id="claimType"
                  options={claimTypeList}
                  value={claimType}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setClaimTypeList(event.value)}
                  showClear
                  showHeader
                  multiple
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="contract" label="Contract">
                <Dropdown
                  id="contract"
                  options={contractList}
                  value={contract}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setContractList(event.value)}
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="providerType" label="Provider Type">
                <Dropdown
                  id="providerType"
                  options={providerTypeList}
                  value={providerType}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setProviderTypeList(event.value)}
                  showClear
                  showHeader
                  multiple
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={() => setShowForm(false)} />
              <Button label="Save" raised onClick={handleSave} />
            </div>
          </CustomForm>
        </div>
      ) : (
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines mt-4"
          showGridlines
          rows={10}
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column field="claimType" header="Claim&nbsp;Type" filter sortable />
          <Column field="contract" header="Contract" filter sortable />
          <Column field="providerType" header="Provider&nbsp;Type" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      )}
    </>
  );
};

export default OrganizationFeeSchedule;
