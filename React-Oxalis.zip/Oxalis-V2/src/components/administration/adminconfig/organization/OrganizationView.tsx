import { useNavigate } from "react-router-dom";
import ViewForm from "../../../../controls/ViewForm";

const OrganizationView = () => {
  const navigate = useNavigate();

  const headerRecord = [
    { label: "Company", value: "N/A" },
    { label: "Sub Company", value: "N/A" },
    { label: "Plan", value: "N/A" },
    { label: "Product Type", value: "N/A" },
    { label: "Effective Date", value: "10/05/2022" },
    { label: "Term Date", value: "12/31/9999" },
  ];

  const handleNavigate = () => {
    navigate("/administration/configuration/organization-rule-list");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Organization Rule
      </h2>
      <ViewForm header="Organization Information" data={headerRecord} />
    </>
  );
};

export default OrganizationView;
