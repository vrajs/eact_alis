import { useState } from "react";
import { Steps } from "primereact/steps";
import { useNavigate } from "react-router-dom";
import BenefitPlanPackage from "../benefits/BenefitPlanPackage";
import { Panel } from "primereact/panel";
import BenefitDeductibleMax from "../benefits/BenefitDeductibleMax";
import PlanPackageSummary from "./PBPPackageSummary";

const PBPConfiguration = () => {
  const [activeIndex, setActiveIndex] = useState(0);
  const navigate = useNavigate();

  const items = [
    {
      label: "Plan Benefit Package",
      command: () => setActiveIndex(0),
    },
    {
      label: "Package Summary",
      command: () => setActiveIndex(1),
    },
  ];
  const handleNavigate = () => {
    navigate("/administration/configuration/pbp-list");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>
        Plan Benefit Package Configuration
      </h2>
      <div className="card">
        <Steps model={items} activeIndex={activeIndex} onSelect={(e) => setActiveIndex(e.index)} readOnly={false} className="mb-4" />
        <div className="content">
          {activeIndex === 0 && (
            <>
              <BenefitPlanPackage />
              <Panel header="Deductible / Max OOP List" toggleable className="search-panel mb-4 ">
                <div className="-mt-4">
                  <BenefitDeductibleMax />
                </div>
              </Panel>
            </>
          )}
          {activeIndex === 1 && <PlanPackageSummary />}
        </div>
      </div>
    </>
  );
};

export default PBPConfiguration;
