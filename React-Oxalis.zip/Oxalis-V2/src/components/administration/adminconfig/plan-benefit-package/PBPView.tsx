import { useNavigate } from "react-router-dom";
import ViewForm from "../../../../controls/ViewForm";
import BenefitComponents from "../benefits/BenefitsComponents";
import BenefitViewList from "../benefits/BenefitViewList";

const PBPView = () => {
  const navigate = useNavigate();

  const headerRecord = [
    { label: "Code", value: "Benefit 20" },
    { label: "Name", value: "Benefit 20" },
    { label: "Effective Date", value: "9/5/2024" },
    { label: "Age", value: "From 0 years to 150 years" },
    { label: "Plan", value: "N/A" },
    { label: "Gender", value: "Both" },
    { label: "Claim Type", value: "HCFA" },
    { label: "Benifit Category", value: "Mental Health Services" },
    { label: "Remit Reason", value: "N/A" },
    { label: "EOB Reason", value: "N/A" },
    { label: "Network", value: "N/A" },
  ];

  const planBenefitRecord = [
    { label: "Plan Code", value: "H0001 - 015" },
    { label: "Plan Name", value: "AZ-Dialysis Complete" },
    { label: "Effective Date", value: "9/5/2024" },
    { label: "Company", value: "HPS AaNeel" },
    { label: "Sub company", value: "HPS AaNeel" },
    { label: "LOB", value: "medicare" },
    { label: "PBP Code", value: "015" },
    { label: "Product Type", value: "Medicare Advantage" },
    { label: "Plan Status", value: "Approved" },
    { label: "Approved Date", value: "08/01/2024" },
    { label: "State", value: "AZ" },
    { label: "County", value: "Graham" },
  ];
  const handleNavigate = () => {
    navigate("/administration/configuration/pbp-list");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Benefit Information
      </h2>
      <ViewForm header="Benefit Information" data={headerRecord} />
      <BenefitViewList />
      <ViewForm header="Plan Benefit Package Information" data={planBenefitRecord} />
      <BenefitComponents />
    </>
  );
};

export default PBPView;
