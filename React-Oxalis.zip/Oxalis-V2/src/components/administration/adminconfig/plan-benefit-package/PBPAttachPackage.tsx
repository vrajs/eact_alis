import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "../../../../controls/Button";
import { SelectButton } from "primereact/selectbutton";
import BenefitsAddEdit from "../benefits/BenefitAddEdit";

const PBPAttachPackage = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [showBenefitPlanPackage, setShowBenefitPlanPackage] = useState(false); // State to show/hide BenefitPlanPackage
  const navigate = useNavigate();

  const handleCodeClick = () => {
    navigate(`/administration/configuration/pbp-view`);
  };
  const options = ["Active"];
  const [value, setValue] = useState(options[0]);

  const headerTemplate = () => {
    return (
      <div className="flex justify-content-between gap-3 items-center">
        <label>Attach Benefit(s) to Package</label>
        <div className="flex gap-2">
          <SelectButton value={value} onChange={(e) => setValue(e.value)} options={options} />
          <Button outlined label="Create" onClick={() => setShowBenefitPlanPackage(true)} />
          <Button outlined label="Attach" />
          <Button outlined label="Cancel" />
        </div>
      </div>
    );
  };

  const codeData = [
    {
      codesID: 1,
      code: "Benefit 20",
      name: "Benefit 20",
      categoryName: "Mental Health Services",
      copay: "N/A",
      coinsurance: "N/A",
      effectiveDate: "1/1/2024",
      termDate: "9/19/2024",
    },
    {
      codesID: 2,
      code: "PCP 201",
      name: "Cpay 113",
      categoryName: "Mental Health Services",
      copay: "N/A",
      coinsurance: "N/A",
      effectiveDate: "1/1/2024",
      termDate: "9/19/2024",
    },
  ];

  return (
    <>
      {!showBenefitPlanPackage ? (
        <div className="pb-4">
          <DataTable
            paginator
            header={headerTemplate}
            className="p-datatable-gridlines"
            showGridlines
            rows={10}
            value={codeData} // Static data added here
            dataKey="codesID"
            emptyMessage="No records found."
            selection={selectedCustomer}
            onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
            selectionMode="single" // Single row selection
          >
            <Column
              field="code"
              header="Code"
              body={(rowData) => (
                <a className="underline" onClick={handleCodeClick}>
                  {rowData.code}
                </a>
              )}
              filter
              sortable
            />
            <Column field="name" header="Name" filter sortable />
            <Column field="categoryName" header="Category&nbsp;Name" filter sortable />
            <Column field="copay" header="Copay" filter sortable />
            <Column field="coinsurance" header="Coinsurance" filter sortable />
            <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
            <Column field="termDate" header="Term&nbsp;Date" filter sortable />
          </DataTable>
        </div>
      ) : (
        <BenefitsAddEdit />
      )}
    </>
  );
};

export default PBPAttachPackage;
