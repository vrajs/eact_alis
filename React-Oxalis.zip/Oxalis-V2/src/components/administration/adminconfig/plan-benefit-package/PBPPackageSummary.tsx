import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import Button from "../../../../controls/Button";
import { Sidebar } from "primereact/sidebar";
import { useNavigate } from "react-router-dom";
import PBPAttachPackage from "./PBPAttachPackage";

const PBPPackageSummary = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [visibleBottom, setVisibleBottom] = useState(false);
  const navigate = useNavigate();

  const headerTemplate = () => {
    return (
      <div className="flex justify-content-end gap-3 items-center">
        <Button outlined label="Terminate" />
        <Button outlined label="Add" onClick={() => setVisibleBottom(true)} />
      </div>
    );
  };
  const handleCodeClick = () => {
    navigate(`/administration/configuration/pbp-view`);
  };
  const codeData = [
    {
      codesID: 1,
      code: "Benefit 20",
      name: "Benefit 20",
      categoryName: "Mental Health Services",
      copay: "N/A",
      coinsurance: "N/A",
      effectiveDate: "1/1/2024",
      termDate: "9/19/2024",
    },
    {
      codesID: 2,
      code: "PCP 201",
      name: "Cpay 113",
      categoryName: "Mental Health Services",
      copay: "N/A",
      coinsurance: "N/A",
      effectiveDate: "1/1/2024",
      termDate: "9/19/2024",
    },
  ];
  return (
    <>
      <DataTable
        paginator
        header={headerTemplate}
        className="p-datatable-gridlines"
        showGridlines
        rows={10}
        value={codeData} // Static data added here
        dataKey="codesID"
        emptyMessage="No records found."
        selection={selectedCustomer}
        onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
        selectionMode="single" // Single row selection
      >
        <Column
          field="code"
          header="Code"
          body={(rowData) => (
            <a className="underline" onClick={handleCodeClick}>
              {rowData.code}
            </a>
          )}
          filter
          sortable
        />
        <Column field="name" header="Name" filter sortable />
        <Column field="categoryName" header="Category&nbsp;Name" filter sortable />
        <Column field="copay" header="Copay" filter sortable />
        <Column field="coinsurance" header="Coinsurance" filter sortable />
        <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
        <Column field="termDate" header="Term&nbsp;Date" filter sortable />
      </DataTable>
      <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-4/6 text-xl"
        header="Benefit Configuration"
      >
        <PBPAttachPackage />
      </Sidebar>
    </>
  );
};

export default PBPPackageSummary;
