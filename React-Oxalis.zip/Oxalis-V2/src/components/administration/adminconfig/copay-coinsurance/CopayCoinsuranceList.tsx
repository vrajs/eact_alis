import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "../../../../controls/Button";

const CopayCoinsuranceList = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const navigate = useNavigate();

  // Handle 'Add' button click
  const handleAddClick = () => {
    navigate("/administration/configuration/copay-coinsurance-add-edit");
  };

  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={handleAddClick} />
        </div>
      </div>
    );
  };
  const codeData = [
    {
      codesID: 1,
      code: "$20 Fixed",
      fixedCopay: "$20",
      maxCopay: "$0",
      coinsurance: "10%",
      maxPeriod: "N/A",
      maxCopayPerPeriod: "N/A",
      variableCopay: "No",
      par: "N/A",
      network: "In Network",
      noAuth: "No",
      effectiveDate: "9/19/2024",
      termDate: "9/19/2024",
    },
    {
      codesID: 2,
      code: "$50",
      fixedCopay: "$50",
      maxCopay: "N/A",
      coinsurance: "10%",
      maxPeriod: "N/A",
      maxCopayPerPeriod: "N/A",
      variableCopay: "No",
      par: "N/A",
      network: "In Network",
      noAuth: "No",
      effectiveDate: "9/19/2024",
      termDate: "9/19/2024",
    },
  ];
  return (
    <>
      <h2 className="pb-4">Copay Coinsurance</h2>
      <div className="pb-4">
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          value={codeData} // Static data added here
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column field="code" header="Code" filter sortable />
          <Column field="fixedCopay" header="Fixed&nbsp;Copay" filter sortable />
          <Column field="maxCopay" header="Max&nbsp;Copay" filter sortable />
          <Column field="coinsurance" header="Coinsurance" filter sortable />
          <Column field="maxPeriod" header="Max&nbsp;Period" filter sortable />
          <Column field="maxCopayPerPeriod" header="Max&nbsp;Copay&nbsp;Per&nbsp;Diem" filter sortable />
          <Column field="variableCopay" header="Variable&nbsp;Copay" filter sortable />
          <Column field="par" header="Par/NonPar" filter sortable />
          <Column field="network" header="Network" filter sortable />
          <Column field="noAuth" header="No&nbsp;Auth" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default CopayCoinsuranceList;
