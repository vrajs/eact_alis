import { Panel } from "primereact/panel";
import { useNavigate } from "react-router-dom";
import FormItem from "../../../../controls/FormItem";
import CustomForm from "../../../../controls/CustomForm";
import InputText from "../../../../controls/InputText";
import Button from "../../../../controls/Button";
import { DropdownChangeEvent } from "primereact/dropdown";
import { useState } from "react";
import Dropdown from "../../../../controls/Dropdown";
import Calendar from "../../../../controls/Calendar";
import Checkbox from "../../../../controls/CheckBox";

const CopayCoinsuranceAddEdit = () => {
  const navigate = useNavigate();
  const [checked, setChecked] = useState(false);
  const [isVariable, setVariableChecked] = useState(false);
  const [maxPeriod, setMaxPeriodList] = useState(null);
  const [maxCopayPerDiemPeriod, setMaxCopayPerDiemPeriodList] = useState(null);
  const [parNonPar, setParNonParList] = useState(null);
  const [network, setNetworkList] = useState(null);
  const networkList = [
    { key: "In Network", value: "1" },
    { key: "Out Of Area", value: "2" },
  ];
  const parNonParList = [
    { key: "Par", value: "1" },
    { key: "Non Par", value: "2" },
  ];
  const maxCopayPerDiemPeriodList = [
    { key: "1 Hour", value: "1" },
    { key: "5 Years", value: "2" },
  ];
  const maxPeriodList = [
    { key: "1 Hour", value: "1" },
    { key: "5 Years", value: "2" },
  ];

  const handleNavigate = () => {
    navigate("/administration/configuration/copay-coinsurance-list");
  };

  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>
        Copay Coinsurance Configuration
      </h2>
      <Panel header="Copay/Coinsurance Information" toggleable className="search-panel mb-4">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="copayCoinsuranceCode" label="copay Coinsurance Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="fixedCopay" label="Fixed Copay">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="maxCopay" label="Max Copay">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="maxPeriod" label="Max Period">
              <Dropdown
                id="maxPeriod"
                options={maxPeriodList}
                value={maxPeriod}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setMaxPeriodList(event.value)}
                showClear
                showHeader
                multiple
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="coinsurancePercentage" label="Coinsurance Percentage">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="maxCopayPerDiem" label="Max Copay Per Diem">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="maxCopayPerDiemPeriod" label="Max Copay Per Diem Period">
              <Dropdown
                id="maxCopayPerDiemPeriod"
                options={maxCopayPerDiemPeriodList}
                value={maxCopayPerDiemPeriod}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setMaxCopayPerDiemPeriodList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="parNonPar" label="Par/NonPar">
              <Dropdown
                id="parNonPar"
                options={parNonParList}
                value={parNonPar}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setParNonParList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="network" label="Network">
              <Dropdown
                id="network"
                options={networkList}
                value={network}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setNetworkList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <div className="flex gap-3 items-center">
              <Checkbox
                id="exclude-checkbox"
                type="checkbox"
                checked={checked}
                onChange={(e) => setChecked(e.target.checked)}
                className="p-checkbox"
                label="No Auth"
              />
              <Checkbox
                id="exclude-checkbox"
                type="checkbox"
                checked={isVariable}
                onChange={(e) => setVariableChecked(e.target.checked)}
                className="p-checkbox"
                label="Is Variable Copay Per Diem"
              />
            </div>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      </Panel>
    </>
  );
};

export default CopayCoinsuranceAddEdit;
