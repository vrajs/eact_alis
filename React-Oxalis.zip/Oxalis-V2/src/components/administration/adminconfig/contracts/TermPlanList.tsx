import { Panel } from "primereact/panel";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";

const TermPlanList = () => {
  // Sample data for the DataTable
  const termPlans = [
    {
      codesID: 1,
      termCode: "TC001",
      termName: "Basic Term Plan",
      remitReason: "Remit 1",
      eobReason: "EOB 1",
      gender: "All",
      ageFrom: 18,
      ageTo: 65,
      effectiveDate: "2024-01-01",
      termDate: "2024-12-31",
    },
    {
      codesID: 2,
      termCode: "TC002",
      termName: "Extended Term Plan",
      remitReason: "Remit 2",
      eobReason: "EOB 2",
      gender: "Female",
      ageFrom: 20,
      ageTo: 60,
      effectiveDate: "2024-02-01",
      termDate: "2024-11-30",
    },
  ];

  return (
    <Panel header="Term-Plan List" toggleable className="search-panel mb-4">
      <DataTable
        value={termPlans}
        paginator
        className="p-datatable-gridlines custom-table-header"
        showGridlines
        rows={10}
        dataKey="codesID"
        emptyMessage="No records found."
      >
        <Column field="termCode" header="Term&nbsp;Code" body={(rowData) => <a className="underline">{rowData.termCode}</a>} filter sortable />
        <Column field="termName" header="Term&nbsp;Name" filter sortable />
        <Column field="remitReason" header="Remit&nbsp;Reason" filter sortable />
        <Column field="eobReason" header="EOB&nbsp;Reason" filter sortable />
        <Column field="gender" header="Gender" filter sortable />
        <Column field="ageFrom" header="Age&nbsp;From" filter sortable />
        <Column field="ageTo" header="Age&nbsp;To" filter sortable />
        <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
        <Column field="termDate" header="Term&nbsp;Date" filter sortable />
      </DataTable>
    </Panel>
  );
};

export default TermPlanList;
