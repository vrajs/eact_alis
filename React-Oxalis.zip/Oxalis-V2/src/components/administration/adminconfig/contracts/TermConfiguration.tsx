import { Panel } from "primereact/panel";
import FormItem from "../../../../controls/FormItem";
import CustomForm from "../../../../controls/CustomForm";
import InputText from "../../../../controls/InputText";
import Button from "../../../../controls/Button";
import { DropdownChangeEvent } from "primereact/dropdown";
import { useState } from "react";
import Dropdown from "../../../../controls/Dropdown";
import Calendar from "../../../../controls/Calendar";
import InputNumber from "../../../../controls/InputNumber";
import InputTextarea from "../../../../controls/InputTextarea";
import Checkbox from "../../../../controls/CheckBox";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Sidebar } from "primereact/sidebar";
import TermList from "./TermList";

const TermConfiguration = () => {
  const [isFormVisible, setIsFormVisible] = useState(false); // Toggle for showing form or table
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [remitReason, setRemitReasonList] = useState(null);
  const [eobReason, setEobReasonList] = useState(null);
  const [providerSpeciality, setProviderSpecialityList] = useState(null);
  const [gender, setGenderList] = useState(null);
  const [checkboxStates, setCheckboxStates] = useState(
    Array(9).fill(false), // initialize each checkbox as unchecked
  );
  const [visibleBottom, setVisibleBottom] = useState(false);

  const genderList = [
    { key: "Male", value: "1" },
    { key: "Female", value: "2" },
  ];
  const providerSpecialityList = [
    { key: "Adult Day Care", value: "1" },
    { key: "Acupuncturist", value: "2" },
  ];
  const eobReasonList = [{ key: "Noncovered Service", value: "1" }];
  const remitReasonList = [{ key: "Resubmit To Argus", value: "1" }];
  const checkboxLabels = [
    "Emergency Room Only",
    "Members Assigned",
    "Capitated",
    "Is PCP",
    "Manual Review",
    "Ignore Case Rate",
    "Auth Required",
    "Auth Required when benefit requires Auth",
    "Documentation required",
  ];

  const handleCheckboxChange = (index) => {
    const newCheckboxStates = [...checkboxStates];
    newCheckboxStates[index] = !newCheckboxStates[index];
    setCheckboxStates(newCheckboxStates);
  };

  const handleAddClick = () => {
    setIsFormVisible(true); // Show the form when Add is clicked
  };

  const handleSaveClick = () => {
    // Perform any save logic here if needed
    setIsFormVisible(false); // Hide the form and show the table again
  };

  const headerTemplate = (options) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Term Information</div>
        <div className="flex gap-3">
          {!isFormVisible && <Button outlined label="Add Term" onClick={() => setVisibleBottom(true)} />}
          {!isFormVisible && <Button outlined label="Add" onClick={handleAddClick} />}
          <div className="flex align-items-center gap-2">{options.togglerElement}</div>
        </div>
      </div>
    );
  };

  return (
    <>
      <Panel headerTemplate={headerTemplate} toggleable className="search-panel mb-4">
        {isFormVisible ? (
          <CustomForm form={undefined}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="contractName" label="Contract Name">
                <InputText placeholder="Enter here" />
              </FormItem>
              <FormItem name="code" label="Code">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="termName" label="Term Name">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
              <FormItem name="remitReason" label="Remit Reason">
                <Dropdown
                  id="remitReason"
                  options={remitReasonList}
                  value={remitReason}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setRemitReasonList(event.value)}
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="eobReason" label="Eob Reason">
                <Dropdown
                  id="eobReason"
                  options={eobReasonList}
                  value={eobReason}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setEobReasonList(event.value)}
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="providerSpeciality" label="Provider Speciality">
                <Dropdown
                  id="providerSpeciality"
                  options={providerSpecialityList}
                  value={providerSpeciality}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setProviderSpecialityList(event.value)}
                  showClear
                  showHeader
                  multiple
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="gender" label="Gender">
                <Dropdown
                  id="gender"
                  options={genderList}
                  value={gender}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setGenderList(event.value)}
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="ageFrom" label="Age From">
                <InputNumber placeholder="Enter here" />
              </FormItem>
              <FormItem name="ageTo" label="Age To">
                <InputNumber placeholder="Enter here" />
              </FormItem>
              <div className="col-span-full">
                <FormItem name="desc" label="Description">
                  <InputTextarea rows={3} />
                </FormItem>
              </div>
              <div className="flex gap-3 flex-wrap col-span-full">
                {checkboxLabels.map((label, index) => (
                  <FormItem key={index} label="" name={label.toLowerCase().replace(" ", "")}>
                    <Checkbox
                      inputId={label.toLowerCase().replace(" ", "")}
                      label={label}
                      checked={checkboxStates[index]}
                      onChange={() => handleCheckboxChange(index)}
                    />
                  </FormItem>
                ))}
              </div>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={() => setIsFormVisible(false)} />
              <Button label="Save" raised onClick={handleSaveClick} />
            </div>
          </CustomForm>
        ) : (
          <DataTable
            paginator
            className="p-datatable-gridlines custom-table-header"
            showGridlines
            rows={10}
            dataKey="codesID"
            emptyMessage="No records found."
            selection={selectedCustomer}
            onSelectionChange={(e) => setSelectedCustomer(e.value)}
            selectionMode="single"
          >
            <Column field="termCode" header="Term&nbsp;Code" filter sortable />
            <Column field="termName" header="Term&nbsp;Name" filter sortable />
            <Column field="remitReason" header="Remit&nbsp;Reason" filter sortable />
            <Column field="eobReason" header="EOB&nbsp;Reason" filter sortable />
            <Column field="gender" header="Gender" filter sortable />
            <Column field="ageFrom" header="Age&nbsp;From" filter sortable />
            <Column field="ageTo" header="Age&nbsp;To" filter sortable />
            <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
            <Column field="termDate" header="Term&nbsp;Date" filter sortable />
          </DataTable>
        )}
      </Panel>
      <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-4/6 text-xl"
        header="Add Term List"
      >
        <TermList />
      </Sidebar>
    </>
  );
};

export default TermConfiguration;
