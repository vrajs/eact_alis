import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import Calendar from "../../../../controls/Calendar";
import CustomForm from "../../../../controls/CustomForm";
import Dropdown from "../../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import { useState } from "react";
import ViewForm from "../../../../controls/ViewForm";
import { Sidebar } from "primereact/sidebar";
import TermMasterVisit from "./TermMasterVisit";

const TermLimits = () => {
  const [visitCode, setVisitCodeList] = useState(null);
  const visitCodeList = [
    { key: "60 Add Days-IP", value: "1" },
    { key: "1V-PD", value: "2" },
  ];
  const [visibleBottom, setVisibleBottom] = useState(false);

  const headerRecord = [
    { label: "Code", value: "N/A" },
    { label: "Description", value: "N/A" },
    { label: "Visit Type", value: "N/A" },
    { label: "Max Amount", value: "N/A" },
    { label: "Max Unit", value: "N/A" },
    { label: "Time Period", value: "N/A" },
    { label: "SVCS outside US", value: "N/A" },
    { label: "Ben Max Unit", value: "N/A" },
  ];
  return (
    <>
      <div className="pt-3">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="visitCode" label="Claim Type">
              <Dropdown
                id="visitCode"
                options={visitCodeList}
                value={visitCode}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setVisitCodeList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
          </div>
          <ViewForm header="Details" data={headerRecord} />
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Create New Visit Code" outlined onClick={() => setVisibleBottom(true)} />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      </div>
      <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-4/6 text-xl"
        header="Master Visit"
      >
        <TermMasterVisit />
      </Sidebar>
    </>
  );
};

export default TermLimits;
