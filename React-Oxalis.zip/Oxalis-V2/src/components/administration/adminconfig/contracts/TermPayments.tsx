import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import Calendar from "../../../../controls/Calendar";
import CustomForm from "../../../../controls/CustomForm";
import Checkbox from "../../../../controls/CheckBox";
import Dropdown from "../../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import InputNumber from "../../../../controls/InputNumber";

const TermPayments = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [checked, setChecked] = useState(false);
  const [showForm, setShowForm] = useState(false); // State to toggle form display
  const [paymentType, setPaymentTypeList] = useState(null);
  const paymentTypeList = [
    { key: "Case Rate", value: "1" },
    { key: "Flat Rate", value: "2" },
  ];
  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={() => setShowForm(true)} />
        </div>
      </div>
    );
  };

  const handleSave = () => {
    setShowForm(false); // Show the data table after saving
    // Add save logic here if necessary
  };

  return (
    <>
      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pt-3">
        <FormItem name="paymentType" label="Paymeny Type">
          <Dropdown
            id="paymentType"
            options={paymentTypeList}
            value={paymentType}
            optionLabel="key"
            optionValue="value"
            onChange={(event: DropdownChangeEvent) => setPaymentTypeList(event.value)}
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
      </div>
      {showForm ? (
        <div className="pt-3">
          <CustomForm form={undefined}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="rate" label="Rate">
                <InputNumber placeholder="Enter here" />
              </FormItem>
              <FormItem name="payPercent" label="Pay Percent">
                <InputNumber placeholder="Enter here" />
              </FormItem>
              <FormItem name="maxReimbursement" label="Max Reimbursement">
                <InputNumber placeholder="Enter here" />
              </FormItem>
              <FormItem name="billedCharge" label="Billed Charge">
                <InputNumber placeholder="Enter here" />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <div className="flex gap-3 col-span-full">
                <Checkbox
                  id="exclude-checkbox"
                  type="checkbox"
                  checked={checked}
                  onChange={(e) => setChecked(e.target.checked)}
                  label="Ingored Billed Charges"
                />
                <Checkbox
                  id="prorate-checkbox"
                  type="checkbox"
                  checked={checked}
                  onChange={(e) => setChecked(e.target.checked)}
                  label="Prorate Days"
                />
              </div>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={() => setShowForm(false)} />
              <Button label="Save" raised onClick={handleSave} />
            </div>
          </CustomForm>
        </div>
      ) : (
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines mt-4"
          showGridlines
          rows={10}
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column field="ignoredBilled" header="Ignored&nbsp;Billed" filter sortable />
          <Column field="applyPerDay" header="Apply&nbsp;Per&nbsp;Day" filter sortable />
          <Column field="payPercent" header="Pay&nbsp;Percent" filter sortable />
          <Column field="maxReimbursment" header="Max&nbsp;Reimbursment" filter sortable />
          <Column field="rate" header="Rate" filter sortable />
          <Column field="prorateDays" header="Prorate&nbsp;Days" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      )}
    </>
  );
};

export default TermPayments;
