import { useNavigate } from "react-router-dom";
import ViewForm from "../../../../controls/ViewForm";
import TermPaymentView from "./TermPaymentView";
import TermPlanList from "./TermPlanList";

const ContractView = () => {
  const navigate = useNavigate();

  const headerRecord = [
    { label: "Claim Type", value: "N/A" },
    { label: "Contract Name", value: "contract" },
    { label: "Capitation", value: "N/A" },
    { label: "Anes Conversion Factor", value: "N/A" },
    { label: "Capitation", value: "N/A" },
    { label: "Effective Date", value: "10/05/2022" },
    { label: "Term Date", value: "12/31/9999" },
  ];

  const termRecord = [
    { label: "Age From", value: "From 0 years to 150 years" },
    { label: "Applied to", value: "Both" },
    { label: "Remit Reason", value: "N/A" },
    { label: "EOB Reason", value: "N/A" },
    { label: "Specialties", value: "N/A" },
  ];
  const handleNavigate = () => {
    navigate("/administration/configuration/contracts-list");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Contract Information
      </h2>
      <ViewForm header="Contract Information" data={headerRecord} />
      <ViewForm header="Term Information" data={termRecord} />
      <TermPlanList />
      <TermPaymentView />
    </>
  );
};

export default ContractView;
