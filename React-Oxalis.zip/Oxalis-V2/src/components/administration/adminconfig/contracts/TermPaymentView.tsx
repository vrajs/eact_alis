import { Panel } from "primereact/panel";
import { useState } from "react";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Dropdown, DropdownChangeEvent } from "primereact/dropdown";
import FormItem from "../../../../controls/FormItem";

const TermPaymentView = () => {
  const [paymentType, setPaymentTypeList] = useState(null);
  const paymentTypeList = [
    { key: "Case Rate", value: "1" },
    { key: "Flat Rate", value: "2" },
  ];
  return (
    <>
      <Panel header="Term Payment" toggleable className="search-panel mb-4">
        <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 mb-4">
          <FormItem name="paymentType" label="Payment Type">
            <Dropdown
              id="paymentType"
              options={paymentTypeList}
              value={paymentType}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setPaymentTypeList(event.value)}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
        </div>
        <DataTable
          paginator
          className="p-datatable-gridlines custom-table-header"
          showGridlines
          rows={10}
          dataKey="codesID"
          emptyMessage="No records found."
        >
          <Column field="ignoredBilled" header="Ignored&nbsp;Billed" filter sortable />
          <Column field="applyPerDay" header="Apply&nbsp;Per&nbsp;Day" filter sortable />
          <Column field="payPercent" header="Pay&nbsp;Percent" filter sortable />
          <Column field="maxReimbursment" header="Max&nbsp;Reimbursment" filter sortable />
          <Column field="rate" header="Rate" filter sortable />
          <Column field="prorateDays" header="Prorate&nbsp;Days" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      </Panel>
    </>
  );
};

export default TermPaymentView;
