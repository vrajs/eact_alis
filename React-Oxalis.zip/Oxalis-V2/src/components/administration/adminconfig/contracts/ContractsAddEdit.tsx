import { Panel } from "primereact/panel";
import { useNavigate } from "react-router-dom";
import FormItem from "../../../../controls/FormItem";
import CustomForm from "../../../../controls/CustomForm";
import InputText from "../../../../controls/InputText";
import Button from "../../../../controls/Button";
import { DropdownChangeEvent } from "primereact/dropdown";
import { useState } from "react";
import Dropdown from "../../../../controls/Dropdown";
import Calendar from "../../../../controls/Calendar";
import InputTextarea from "../../../../controls/InputTextarea";
import TermConfiguration from "./TermConfiguration";
import ConfigTermComponents from "./TermComponents";

const ContractsAddEdit = () => {
  const navigate = useNavigate();
  const [claimType, setClaimTypeList] = useState(null);
  const [capitationType, setCapitationTypeList] = useState(null);
  const [anesConversation, setAnesConversationList] = useState(null);
  const anesConversationList = [
    { key: "Medicare Factor", value: "1" },
    { key: "Medicare Only", value: "2" },
  ];
  const capitationTypeList = [
    { key: "Vision Cap", value: "1" },
    { key: "800M", value: "2" },
  ];
  const claimTypeList = [
    { key: "HCFA", value: "1" },
    { key: "UB04", value: "2" },
  ];

  const handleNavigate = () => {
    navigate("/administration/configuration/contracts-list");
  };

  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>
        Contract Configuration
      </h2>
      <Panel header="Contract Information" toggleable className="search-panel mb-4">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="contractCode" label="Contract Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="contractName" label="Contract Name">
              <InputText placeholder="Enter here" />
            </FormItem>
            <FormItem name="claimType" label="Claim Type">
              <Dropdown
                id="claimType"
                options={claimTypeList}
                value={claimType}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setClaimTypeList(event.value)}
                showClear
                showHeader
                multiple
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="capitationType" label="Capitation Type">
              <Dropdown
                id="capitationType"
                options={capitationTypeList}
                value={capitationType}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setCapitationTypeList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="anesConversation" label="Anes Conversation">
              <Dropdown
                id="anesConversation"
                options={anesConversationList}
                value={anesConversation}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setAnesConversationList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <div className="col-span-full">
              <FormItem name="desc" label="Description">
                <InputTextarea rows={3} />
              </FormItem>
            </div>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      </Panel>
      <TermConfiguration />
      <ConfigTermComponents />
    </>
  );
};

export default ContractsAddEdit;
