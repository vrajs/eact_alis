import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import { SelectButton } from "primereact/selectbutton";
import Button from "../../../../controls/Button";

const TermList = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row

  const options = ["Active"];
  const [value, setValue] = useState(options[0]);

  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Save & Create New Term" />
          <SelectButton value={value} onChange={(e) => setValue(e.value)} options={options} />
        </div>
      </div>
    );
  };
  const codeData = [
    {
      codesID: 1,
      contractCode: "Mr",
      termCode: "Physician Services",
      termName: "Physician Services",
      effectiveDate: "1/1/2024",
      termDate: "9/19/2024",
    },
  ];
  return (
    <>
      <div className="pb-4">
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          value={codeData} // Static data added here
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="multiple" // Single row selection
        >
          <Column selectionMode="multiple" />
          <Column field="contractCode" header="Contract&nbsp;Code" filter sortable />
          <Column field="termCode" header="Term&nbsp;Code" filter sortable />
          <Column field="termName" header="Term&nbsp;Name" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default TermList;
