import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "../../../../controls/Button";

const ContractsList = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const navigate = useNavigate();

  // Handle 'Add' button click
  const handleAddClick = () => {
    navigate("/administration/configuration/contracts-add-edit");
  };
  const handleCodeClick = () => {
    navigate(`/administration/configuration/contracts-view`);
  };
  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={handleAddClick} />
        </div>
      </div>
    );
  };
  const codeData = [
    {
      codesID: 1,
      contractCode: "Emergency",
      contractName: "Medicare Professional 100%",
      contractDescription: "N/A",
      claimType: "N/A",
      effectiveDate: "1/1/2024",
      termDate: "9/19/2024",
    },
    {
      codesID: 2,
      contractCode: "Code",
      contractName: "Contract",
      contractDescription: "N/A",
      claimType: "N/A",
      effectiveDate: "1/1/2024",
      termDate: "9/19/2024",
    },
  ];
  return (
    <>
      <h2 className="pb-4">Contract List</h2>
      <div className="pb-4">
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          value={codeData} // Static data added here
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column
            field="contractCode"
            header="Contract&nbsp;Code"
            body={(rowData) => (
              <a className="underline" onClick={handleCodeClick}>
                {rowData.contractCode}
              </a>
            )}
            filter
            sortable
          />
          <Column field="contractName" header="Contract&nbsp;Name" filter sortable />
          <Column field="contractDescription" header="Contract&nbsp;Description" filter sortable />
          <Column field="claimType" header="Claim&nbsp;Type" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default ContractsList;
