import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import InputText from "../../../../controls/InputText";
import Calendar from "../../../../controls/Calendar";
import CustomForm from "../../../../controls/CustomForm";
import Checkbox from "../../../../controls/CheckBox";
import Dropdown from "../../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import InputNumber from "../../../../controls/InputNumber";

const TermMasterVisit = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [checked, setChecked] = useState(false);
  const [showForm, setShowForm] = useState(false);
  const [visitType, setVisitTypeList] = useState(null);
  const [timePeriod, setTimePeriodList] = useState(null);
  const timePeriodList = [{ key: "Resubmit To Argus", value: "1" }];
  const visitTypeList = [
    { key: "Per Benefit", value: "1" },
    { key: "Per Lifetime", value: "2" },
  ];
  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={() => setShowForm(true)} />
        </div>
      </div>
    );
  };

  const handleSave = () => {
    setShowForm(false);
  };

  return (
    <>
      {showForm ? (
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="code" label="Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="description" label="Description">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="visitType" label="Visit Type">
              <Dropdown
                id="visitType"
                options={visitTypeList}
                value={visitType}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setVisitTypeList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="maxAmount" label="Max Amount">
              <InputNumber placeholder="Enter here" />
            </FormItem>
            <FormItem name="maxUnits" label="Max Units">
              <InputNumber placeholder="Enter here" />
            </FormItem>
            <FormItem name="timePeriod" label="Remit Reason">
              <Dropdown
                id="timePeriod"
                options={timePeriodList}
                value={timePeriod}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setTimePeriodList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="benMaxUnit" label="Ben Max Unit">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <div className="flex gap-3 items-center">
              <Checkbox
                id="exclude-checkbox"
                type="checkbox"
                checked={checked}
                onChange={(e) => setChecked(e.target.checked)}
                className="p-checkbox"
                label="SVCS Outside US"
              />
            </div>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={() => setShowForm(false)} />
            <Button label="Save" raised onClick={handleSave} />
          </div>
        </CustomForm>
      ) : (
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines mt-4"
          showGridlines
          rows={10}
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column field="code" header="Code" filter sortable />
          <Column field="description" header="Description" filter sortable />
          <Column field="visitType" header="Visit&nbsp;Type" filter sortable />
          <Column field="maxAmount" header="Max&nbsp;Amount" filter sortable />
          <Column field="maxUnits" header="Max&nbsp;Units" filter sortable />
          <Column field="timePeriod" header="Time&nbsp;Period" filter sortable />
          <Column field="svcsOutside" header="SVCS&nbsp;Outside" filter sortable />
          <Column field="benMaxUnit" header="Ben&nbsp;Max&nbsp;Unit" filter sortable />
          <Column field="benMaxUnitTimePeriod" header="Ben&nbsp;Max&nbsp;Unit&nbsp;Time&nbsp;Period" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      )}
    </>
  );
};

export default TermMasterVisit;
