import { Panel } from "primereact/panel";
import { TabView, TabPanel } from "primereact/tabview";
import TermCodes from "./TermCodes";
import TermServiceGroups from "./TermServiceGroups";
import TermModifiers from "./TermModifiers";
import TermLimits from "./TermLimits";
import TermPayments from "./TermPayments";

const ConfigTermComponents = () => {
  const tabs = [
    { header: "Codes", component: <TermCodes /> },
    { header: "Service Groups", component: <TermServiceGroups /> },
    { header: "Modifiers", component: <TermModifiers /> },
    { header: "Diagnosis", component: <TermModifiers /> },
    { header: "Place Of Service", component: <TermModifiers /> },
    { header: "Bill Types", component: <TermModifiers /> },
    { header: "Limits", component: <TermLimits /> },
    { header: "Payments", component: <TermPayments /> },
  ];

  return (
    <Panel header="Term Components" toggleable className="custom-tab-menu">
      <TabView>
        {tabs.map((tab, index) => (
          <TabPanel key={index} header={tab.header}>
            {tab.component}
          </TabPanel>
        ))}
      </TabView>
    </Panel>
  );
};

export default ConfigTermComponents;
