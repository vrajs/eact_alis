import { Panel } from "primereact/panel";
import Button from "../../../controls/Button";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import { useState } from "react";
import InputText from "../../../controls/InputText";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";

const TRCConfig = () => {
  const [trcCodes, setTrcCodesList] = useState(null);
  const [contractNumber, setcontractNumberList] = useState(null);
  const [pbpNumber, setpbpNumberList] = useState(null);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const codeData = [
    {
      codesID: 1,
      actions: "Tracking Id must match with Transacation and DTRR (Field 93)",
    },
    {
      codesID: 2,
      actions:
        "If the tracking Id does not match with TC 61 in system, then push the record in TRR fallout report and do not proceed with updating record in system",
    },
    {
      codesID: 3,
      actions:
        "Member Information to match with DTRR Information (Last Name 12 Char, First name 7 Char, DOB, Gender), if mismatch update System as per TRR, if the name in system exceeds beyond the characters received in TRR, do not update, provide a report",
    },
  ];
  const pbpNumberList = [
    { key: "AZ-Super Plus (HMO C-SNP) $0 per month", value: "1" },
    { key: "AZ-Dialysis Plus (HMO-POS C-SNP) $0 per month", value: "2" },
  ];
  const contractNumberList = [
    { key: "H0002", value: "1" },
    { key: "H0001", value: "2" },
  ];
  const trcCodesList = [
    { key: "011", value: "1" },
    { key: "012", value: "2" },
  ];

  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Advance Search (Filtered search values)</div>
        <div className="flex align-items-center gap-2">
          <Button outlined label="Save" />
          {options.togglerElement}
        </div>
      </div>
    );
  };
  return (
    <div className="layout-content">
      <h2 className="pb-4">TRC Configuration</h2>
      <Panel toggleable className="search-panel" headerTemplate={headerTemplate}>
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="trcCodes" label="TRC Codes">
              <Dropdown
                id="trcCodes"
                options={trcCodesList}
                value={trcCodes}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setTrcCodesList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="contractNumber" label="Contract Number">
              <Dropdown
                id="contractNumber"
                options={contractNumberList}
                value={contractNumber}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setcontractNumberList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="pbpNumber" label="PBP Number">
              <Dropdown
                id="pbpNumber"
                options={pbpNumberList}
                value={pbpNumber}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setpbpNumberList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="planAction" label="Plan Action">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="clear" text type="button" />
            <Button label="Apply" outlined type="submit" />
          </div>
        </CustomForm>
      </Panel>
      <div className="pb-4">
        <DataTable
          paginator
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          value={codeData}
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)}
          selectionMode="multiple"
        >
          <Column selectionMode="multiple" />
          <Column field="actions" header="Actions" filter sortable />
        </DataTable>
      </div>
    </div>
  );
};

export default TRCConfig;
