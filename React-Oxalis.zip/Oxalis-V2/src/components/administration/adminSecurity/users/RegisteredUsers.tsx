import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import Button from "../../../../controls/Button";
import CustomForm from "../../../../controls/CustomForm";
import FormItem from "../../../../controls/FormItem";
import InputText from "../../../../controls/InputText";
import Dropdown from "../../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import { Sidebar } from "primereact/sidebar";
import RolesAddEdit from "../roles/RolesAddEdit";

const RegisteredUsers = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const [showForm, setShowForm] = useState(false);
  const [select, setSelectList] = useState(null);
  const [preferenceType, setPreferenceTypeList] = useState(null);
  const [visibleBottom, setVisibleBottom] = useState(false);

  const preferenceTypeList = [
    { key: "By Company", value: "1" },
    { key: "By LOB", value: "2" },
  ];
  const selectList = [
    { key: "HPS Aaneel", value: "1" },
    { key: "Aaneel Infotech", value: "2" },
  ];
  const handleAddClick = () => {
    setShowForm(true);
  };

  const handleSaveClick = () => {
    setShowForm(false);
  };

  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={handleAddClick} />
        </div>
      </div>
    );
  };

  const codeData = [
    {
      codesID: 1,
      userName: "administrator",
      displayName: "Admin Name",
      email: "admin@aaneel.com",
      role: "Active",
    },
    {
      codesID: 2,
      userName: "user2",
      displayName: "User Two",
      email: "user2@example.com",
      role: "Inactive",
    },
  ];
  const roleData = [
    {
      codesID: 1,
      roleName: "Administrator",
      systemDefined: "No",
      description: "Default administrator Test",
    },
    {
      codesID: 2,
      roleName: "Billing Manager",
      systemDefined: "No",
      description: "Billing Manager",
    },
  ];
  // Custom body template for Status button
  const statusBodyTemplate = () => {
    return <Button label="Active" size="small" className="py-1 px-3" />;
  };

  // Custom body template for Reset Password button
  const resetPasswordBodyTemplate = () => {
    return <Button label="Reset Password" size="small" className="py-1 px-3" />;
  };

  return (
    <>
      {showForm ? (
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-4">
            <FormItem name="userName" label="User Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="displayName" label="Display Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="email" label="Email">
              <InputText type="email" placeholder="Enter here" />
            </FormItem>
          </div>
          <div className="pb-4">
            <h5 className="border-bottom-1 pb-3 mb-3">Assign Role(s)</h5>
            <DataTable
              className="p-datatable-gridlines border-bottom-1"
              showGridlines
              rows={10}
              value={roleData} // Static data added here
              dataKey="codesID"
              emptyMessage="No records found."
              selection={selectedCustomer}
              onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
              selectionMode="multiple" // Single row selection
            >
              <Column selectionMode="multiple" />
              <Column
                field="roleName"
                header="Role&nbsp;Name"
                body={(rowData) => (
                  <a className="underline" onClick={() => setVisibleBottom(true)}>
                    {rowData.roleName}
                  </a>
                )}
                filter
                sortable
              />
              <Column field="systemDefined" header="System&nbsp;Defined" filter sortable />
              <Column field="description" header="Description" filter sortable />
            </DataTable>
          </div>
          <div className="pb-3">
            <h5 className="border-bottom-1 pb-3 mb-3">Assign Data Preferences</h5>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-4">
              <FormItem name="preferenceType" label="Preference Type">
                <Dropdown
                  id="preferenceType"
                  options={preferenceTypeList}
                  value={preferenceType}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setPreferenceTypeList(event.value)}
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="select" label="Company">
                <Dropdown
                  id="select"
                  options={selectList}
                  value={select}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setSelectList(event.value)}
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
            </div>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={() => setShowForm(false)} />
            <Button label="Save" raised onClick={handleSaveClick} />
          </div>
        </CustomForm>
      ) : (
        <div className="pb-4">
          <DataTable
            paginator
            header={headerTemplate}
            className="p-datatable-gridlines"
            showGridlines
            rows={10}
            value={codeData} // Static data added here
            dataKey="codesID"
            emptyMessage="No records found."
            selection={selectedCustomer}
            onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
            selectionMode="single" // Single row selection
          >
            <Column field="userName" header="User&nbsp;Name" filter sortable />
            <Column field="displayName" header="Display&nbsp;Name" filter sortable />
            <Column field="email" header="Email" filter sortable />
            <Column field="role" header="Role" filter sortable />
            <Column body={statusBodyTemplate} header="Status" />
            <Column body={resetPasswordBodyTemplate} header="Reset&nbsp;Password" />
          </DataTable>
        </div>
      )}
      <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-4/6 text-xl"
        header="Role Information"
      >
        <RolesAddEdit />
      </Sidebar>
    </>
  );
};

export default RegisteredUsers;
