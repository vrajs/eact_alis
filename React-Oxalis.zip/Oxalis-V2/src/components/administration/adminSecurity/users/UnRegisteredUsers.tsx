import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import Button from "../../../../controls/Button";

const UnRegisteredUsers = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const codeData = [
    {
      codesID: 1,
      userName: "administrator",
      displayName: "Admin Name",
      email: "admin@aaneel.com",
      role: "Active",
    },
    {
      codesID: 2,
      userName: "user2",
      displayName: "User Two",
      email: "user2@example.com",
      role: "Inactive",
    },
  ];

  // Custom body template for Status button
  const statusBodyTemplate = () => {
    return <Button icon="cl_check_done " severity="success" rounded outlined />;
  };

  // Custom body template for Reset Password button
  const resetPasswordBodyTemplate = () => {
    return <Button icon="cl_close" severity="danger" rounded outlined />;
  };

  return (
    <>
      <div className="pb-4">
        <DataTable
          paginator
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          value={codeData} // Static data added here
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column field="userName" header="User&nbsp;Name" filter sortable />
          <Column field="email" header="Email" filter sortable />
          <Column field="role" header="Role" filter sortable />
          <Column body={statusBodyTemplate} header="Accept" />
          <Column body={resetPasswordBodyTemplate} header="Reject" />
        </DataTable>
      </div>
    </>
  );
};

export default UnRegisteredUsers;
