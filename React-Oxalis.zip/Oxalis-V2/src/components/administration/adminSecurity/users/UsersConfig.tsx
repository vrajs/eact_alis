import { TabView, TabPanel } from "primereact/tabview";
import ReqisteredUsers from "./RegisteredUsers";
import UnRegisteredUsers from "./UnRegisteredUsers";

const UsersConfig = () => {
  return (
    <>
      <h2 className="pb-4">User Configuration</h2>
      <TabView>
        <TabPanel header="Registered Users">
          <ReqisteredUsers />
        </TabPanel>
        <TabPanel header="Un-Registered Users">
          <UnRegisteredUsers />
        </TabPanel>
      </TabView>
    </>
  );
};

export default UsersConfig;
