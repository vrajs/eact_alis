import { Panel } from "primereact/panel";
import { useNavigate } from "react-router-dom";
import FormItem from "../../../../controls/FormItem";
import CustomForm from "../../../../controls/CustomForm";
import InputText from "../../../../controls/InputText";
import Button from "../../../../controls/Button";
import InputTextarea from "../../../../controls/InputTextarea";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Checkbox } from "primereact/checkbox";
import { useState } from "react";

const RolesAddEdit = () => {
  const navigate = useNavigate();
  const [accessRights, setAccessRights] = useState([
    { codesID: 1, menu: "Users", view: true, add: true }, // Only view and add for first record
    { codesID: 2, menu: "Roles", view: true, add: true, all: true, update: true, delete: true }, // Full permissions for second record
  ]);

  const handleNavigate = () => {
    navigate("/administration/security/roles");
  };

  const onAccessRightsChange = (e, rowData, field) => {
    const updatedRights = accessRights.map((item) => (item.codesID === rowData.codesID ? { ...item, [field]: e.checked } : item));
    setAccessRights(updatedRights);
  };

  const menuColumnTemplate = (rowData) => {
    return (
      <div className="flex items-center gap-2">
        <Checkbox
          checked={rowData.view && rowData.add}
          onChange={(e) => onAccessRightsChange(e, rowData, "view")} // Check/uncheck the "View" checkbox
        />
        <span>{rowData.menu}</span>
      </div>
    );
  };

  const accessRightsTemplate = (rowData) => {
    return (
      <div className="flex gap-3">
        {rowData.codesID === 1 && ( // Show only View and Add for first record
          <>
            <div className="flex items-center gap-1">
              <Checkbox inputId={`view-${rowData.codesID}`} checked={rowData.view} onChange={(e) => onAccessRightsChange(e, rowData, "view")} />
              <label htmlFor={`view-${rowData.codesID}`}>View</label>
            </div>
            <div className="flex items-center gap-1">
              <Checkbox inputId={`add-${rowData.codesID}`} checked={rowData.add} onChange={(e) => onAccessRightsChange(e, rowData, "add")} />
              <label htmlFor={`add-${rowData.codesID}`}>Add</label>
            </div>
          </>
        )}
        {rowData.codesID === 2 && ( // Show all for second record
          <>
            <div className="flex items-center gap-1">
              <Checkbox inputId={`view-${rowData.codesID}`} checked={rowData.view} onChange={(e) => onAccessRightsChange(e, rowData, "view")} />
              <label htmlFor={`view-${rowData.codesID}`}>View</label>
            </div>
            <div className="flex items-center gap-1">
              <Checkbox inputId={`add-${rowData.codesID}`} checked={rowData.add} onChange={(e) => onAccessRightsChange(e, rowData, "add")} />
              <label htmlFor={`add-${rowData.codesID}`}>Add</label>
            </div>
            <div className="flex items-center gap-1">
              <Checkbox inputId={`all-${rowData.codesID}`} checked={rowData.all} onChange={(e) => onAccessRightsChange(e, rowData, "all")} />
              <label htmlFor={`all-${rowData.codesID}`}>All</label>
            </div>
            <div className="flex items-center gap-1">
              <Checkbox inputId={`update-${rowData.codesID}`} checked={rowData.update} onChange={(e) => onAccessRightsChange(e, rowData, "update")} />
              <label htmlFor={`update-${rowData.codesID}`}>Update</label>
            </div>
            <div className="flex items-center gap-1">
              <Checkbox inputId={`delete-${rowData.codesID}`} checked={rowData.delete} onChange={(e) => onAccessRightsChange(e, rowData, "delete")} />
              <label htmlFor={`delete-${rowData.codesID}`}>Delete</label>
            </div>
          </>
        )}
      </div>
    );
  };

  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>
        Role Configuration
      </h2>
      <Panel header="Details" toggleable className="search-panel">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="roleName" label="Role Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <div className="col-span-3">
              <FormItem name="description" label="Description">
                <InputTextarea placeholder="Enter here" rows={1} />
              </FormItem>
            </div>
          </div>
          <h5 className="border-bottom-1 pb-3 mb-3 mt-0">Assign Feature(s)</h5>
          <DataTable
            className="p-datatable-gridlines"
            showGridlines
            rows={10}
            value={accessRights}
            dataKey="codesID"
            emptyMessage="No records found."
          >
            <Column field="menu" header="Menu" body={menuColumnTemplate} />
            <Column field="accessRights" header="Access Rights" body={accessRightsTemplate} />
          </DataTable>

          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleNavigate} />
            <Button label="Save" raised onClick={handleNavigate} />
          </div>
        </CustomForm>
      </Panel>
    </>
  );
};

export default RolesAddEdit;
