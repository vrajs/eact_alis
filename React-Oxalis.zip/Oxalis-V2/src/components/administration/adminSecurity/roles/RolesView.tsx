import { useNavigate } from "react-router-dom";
import ViewForm from "../../../../controls/ViewForm";

const RolesView = () => {
  const navigate = useNavigate();

  const headerRecord = [
    { label: "Role Name", value: "Administrator" },
    { label: "Role Description", value: "Default administrator Test" },
  ];
  const handleNavigate = () => {
    navigate("/administration/security/roles");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Role Configuration
      </h2>
      <ViewForm header="Details" data={headerRecord} />
    </>
  );
};

export default RolesView;
