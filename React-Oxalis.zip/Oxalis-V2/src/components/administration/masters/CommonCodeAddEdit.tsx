import { Panel } from "primereact/panel";
import { useState } from "react";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import InputText from "../../../controls/InputText";
import { useNavigate } from "react-router-dom";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import CustomForm from "../../../controls/CustomForm";
import Calendar from "../../../controls/Calendar";
import InputTextarea from "../../../controls/InputTextarea";

const CommonCodeAddEdit = () => {
  const navigate = useNavigate();
  const [facilityType, setFacilityTypeList] = useState(null);
  const facilityTypeList = [
    { key: "Facility", value: "1" },
    { key: "Non-Facility", value: "2" },
  ];
  const [codeType, setCodeTypeList] = useState(null);
  const codeTypeList = [
    { key: "HCPCS", value: "1" },
    { key: "POS", value: "2" },
  ];

  const handleNavigate = () => {
    navigate("/administration/masters/common-code");
  };

  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Codes
      </h2>
      <Panel header="Code Information" toggleable className="search-panel">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="codeType" label="Code Type">
              <Dropdown
                id="codeType"
                options={codeTypeList}
                value={codeType}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setCodeTypeList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="standardCode" label="Standard Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="shortName" label="Short Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="drgType" label="DRG Type">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="majorCategory" label="Major Category">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="facilityType" label="Facility/Non-Facility">
              <Dropdown
                id="facilityType"
                options={facilityTypeList}
                value={facilityType}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setFacilityTypeList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="dosageFrom" label="Dosage From">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="route" label="Route">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="strength" label="Strength">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="unit" label="Unit">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="ndcType" label="NDC Type">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <div className="col-span-full">
              <FormItem name="longDesc" label="Long Description">
                <InputTextarea rows={3} />
              </FormItem>
            </div>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text />
            <Button label="Save" raised onClick={handleNavigate} />
          </div>
        </CustomForm>
      </Panel>
    </>
  );
};

export default CommonCodeAddEdit;
