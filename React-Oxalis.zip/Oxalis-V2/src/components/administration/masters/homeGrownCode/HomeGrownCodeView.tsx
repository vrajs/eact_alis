import { useNavigate } from "react-router-dom";
import ViewForm from "../../../../controls/ViewForm";

const HomeGrownCodeView = () => {
  const navigate = useNavigate();

  const headerRecord = [
    { label: "Home Grown Code", value: "HOMETest_1" },
    { label: "Type", value: "631" },
    { label: "Short name", value: "HOMETest_1" },
    { label: "Standard Code", value: "11045" },
    { label: "Effective Date", value: "9/1/2022" },
    { label: "Term Date", value: "N/A" },
  ];
  const handleNavigate = () => {
    navigate("/administration/masters/home-grown-code-list");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Home Grown Code
      </h2>
      <ViewForm header="Code Information" data={headerRecord} />
    </>
  );
};

export default HomeGrownCodeView;
