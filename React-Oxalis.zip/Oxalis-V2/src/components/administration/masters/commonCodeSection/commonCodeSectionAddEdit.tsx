import { Panel } from "primereact/panel";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { DropdownChangeEvent } from "primereact/dropdown";
import FormItem from "../../../../controls/FormItem";
import InputText from "../../../../controls/InputText";
import Dropdown from "../../../../controls/Dropdown";
import CustomForm from "../../../../controls/CustomForm";
import Calendar from "../../../../controls/Calendar";
import InputTextarea from "../../../../controls/InputTextarea";
import Button from "../../../../controls/Button";
import InputNumber from "../../../../controls/InputNumber";
import { InputSwitch } from "primereact/inputswitch";

const CommonCodeSectionAddEdit = () => {
  const navigate = useNavigate();
  const [controlType, setControlTypeList] = useState(null);
  const [checked, setChecked] = useState(false);

  const controlTypeList = [
    { key: "Date", value: "1" },
    { key: "Number", value: "2" },
  ];
  const [codeType, setCodeTypeList] = useState(null);
  const codeTypeList = [
    { key: "HCPCS", value: "1" },
    { key: "POS", value: "2" },
  ];

  const handleNavigate = () => {
    navigate("/administration/masters/common-codesection-list");
  };

  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Region List</div>
        <div className="flex align-items-center gap-2">
          <label htmlFor="input-switch">Active</label>
          <InputSwitch id="input-switch" checked={checked} onChange={(e) => setChecked(e.value)} />
          {options.togglerElement}
        </div>
      </div>
    );
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Common Codes
      </h2>
      <Panel headerTemplate={headerTemplate} toggleable className="search-panel">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="codeType" label="Code Type">
              <Dropdown
                id="codeType"
                options={codeTypeList}
                value={codeType}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setCodeTypeList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="code" label="Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="shortName" label="Short Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="characterValue" label="Character Value">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="numericValue" label="Numeric Value">
              <InputNumber placeholder="Enter here" />
            </FormItem>
            <FormItem name="otherValue" label="Other Value">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="controlType" label="Control Type">
              <Dropdown
                id="controlType"
                options={controlTypeList}
                value={controlType}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setControlTypeList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <div className="col-span-full">
              <FormItem name="longDesc" label="Long Description">
                <InputTextarea rows={3} />
              </FormItem>
            </div>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text />
            <Button label="Save" raised onClick={handleNavigate} />
          </div>
        </CustomForm>
      </Panel>
    </>
  );
};

export default CommonCodeSectionAddEdit;
