import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "../../../../controls/Button";

const CommonCodeSectionList = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const navigate = useNavigate();

  // Handle 'Add' button click
  const handleAddClick = () => {
    navigate("/administration/masters/common-codesection-add-edit");
  };

  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={handleAddClick} />
        </div>
      </div>
    );
  };
  const codeData = [
    {
      codesID: 1,
      code: "H0004",
      shortName: "Test",
      longDesc: "N/A",
      codeType: "CMS Contract Code",
      charValue: "N/A",
      numericValue: "N/A",
      otherValue: "N/A",
      effectiveDate: "2023-01-01",
      termDate: "2023-12-31",
      displayOrder: "29",
    },
  ];
  return (
    <>
      <h2 className="pb-4">Common Code List</h2>
      <div className="pb-4">
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          value={codeData} // Static data added here
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          {/* Render 'code' as a hyperlink */}
          <Column field="code" header="Code" filter sortable />
          <Column field="shortName" header="Short&nbsp;Name" filter sortable />
          <Column field="longDesc" header="Long&nbsp;Description" filter sortable />
          <Column field="codeType" header="Code&nbsp;Type" filter sortable />
          <Column field="charValue" header="Char&nbsp;Value" filter sortable />
          <Column field="numericValue" header="Numeric&nbsp;Value" filter sortable />
          <Column field="otherValue" header="Other&nbsp;Value" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
          <Column field="displayOrder" header="Display&nbsp;Order" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default CommonCodeSectionList;
