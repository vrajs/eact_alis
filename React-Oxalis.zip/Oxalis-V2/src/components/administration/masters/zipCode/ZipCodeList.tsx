import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import Button from "../../../../controls/Button";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const ZIPCodeList = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const navigate = useNavigate();

  // Handle 'Add' button click
  const handleAddClick = () => {
    navigate("/administration/masters/zip-code-add-edit");
  };
  const handleCodeClick = () => {
    navigate(`/administration/masters/zip-code-view`);
  };
  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={handleAddClick} />
        </div>
      </div>
    );
  };
  const codeData = [
    {
      codesID: 1,
      code: "00501",
      areaCode: "631",
      state: "NY",
      city: "Holtsville",
      county: "Suffolk",
      country: "USA",
      effectiveDate: "N/A",
      termDate: "N/A",
    },
  ];
  return (
    <>
      <h2 className="pb-4">Zip Codes</h2>
      <div className="pb-4">
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          value={codeData} // Static data added here
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          {/* Render 'code' as a hyperlink */}
          <Column
            field="code"
            header="Code"
            body={(rowData) => (
              <a className="underline" onClick={handleCodeClick}>
                {rowData.code}
              </a>
            )}
            filter
            sortable
          />
          <Column field="areaCode" header="Area&nbsp;Code" filter sortable />
          <Column field="state" header="State" filter sortable />
          <Column field="city" header="City" filter sortable />
          <Column field="county" header="County" filter sortable />
          <Column field="country" header="Country" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default ZIPCodeList;
