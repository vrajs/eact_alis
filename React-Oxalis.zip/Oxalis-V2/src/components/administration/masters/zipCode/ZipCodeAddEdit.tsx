import { Panel } from "primereact/panel";
import { useState } from "react";
import Button from "../../../../controls/Button";
import FormItem from "../../../../controls/FormItem";
import InputText from "../../../../controls/InputText";
import { useNavigate } from "react-router-dom";
import Dropdown from "../../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import CustomForm from "../../../../controls/CustomForm";

import AutoComplete from "../../../../controls/AutoComplete";
import { InputSwitch } from "primereact/inputswitch";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import Calendar from "../../../../controls/Calendar";

const ZipCodeAddEdit = () => {
  const navigate = useNavigate();
  const [showForm, setShowForm] = useState(false);
  const [checked, setChecked] = useState(false);
  const [state, setStateList] = useState(null);
  const stateList = [
    { key: "AL", value: "1" },
    { key: "AZ", value: "2" },
  ];
  const [regionType, setRegionTypeList] = useState(null);
  const regionTypeList = [
    { key: "Eastern Region", value: "1" },
    { key: "Southern Region", value: "2" },
  ];
  const [productType, setProductTypeList] = useState(null);
  const productTypeList = [
    { key: "Medicare Advantage", value: "1" },
    { key: "Medicare Only", value: "2" },
  ];
  const handleNavigate = () => {
    navigate("/administration/masters/zip-code");
  };
  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Region List</div>
        <div className="flex align-items-center gap-2">
          {!showForm && <Button outlined label="Add" onClick={() => setShowForm(true)} />}
          {options.togglerElement}
        </div>
      </div>
    );
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Zip Code
      </h2>
      <Panel header="Code Information" toggleable className="search-panel mb-4">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="zipCode" label="Zip Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="areaCode" label="Area Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="state" label="State">
              <Dropdown
                id="state"
                options={stateList}
                value={state}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setStateList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="city" label="City">
              <AutoComplete id="city" field="key" placeholder="Enter city" readOnly minLength={2} />
            </FormItem>
            <FormItem name="county" label="County">
              <AutoComplete id="county" field="key" placeholder="Enter County" readOnly minLength={2} />
            </FormItem>
            <FormItem name="country" label="Country">
              <AutoComplete id="country" field="value" placeholder="Enter Country" readOnly minLength={2} />
            </FormItem>
            <FormItem name="isRural" label="is Rural ?">
              <InputSwitch id="input-switch" checked={checked} onChange={(e) => setChecked(e.value)} />
            </FormItem>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text />
            <Button label="Save" raised onClick={handleNavigate} />
          </div>
        </CustomForm>
      </Panel>
      <Panel headerTemplate={headerTemplate} toggleable className="search-panel">
        {!showForm ? (
          <DataTable
            paginator
            className="p-datatable-gridlines"
            showGridlines
            rows={10}
            dataKey="claimId"
            responsiveLayout="scroll"
            emptyMessage="No records found."
            selectionMode="single"
          >
            <Column field="productType" header="Product&nbsp;Type" filter sortable />
            <Column field="region" header="Region" filter sortable />
            <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
            <Column field="termDate" header="Term&nbsp;Date" filter sortable />
          </DataTable>
        ) : (
          <CustomForm form={undefined}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="productType" label="Product Type">
                <Dropdown
                  id="productType"
                  options={productTypeList}
                  value={productType}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setProductTypeList(event.value)}
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="regionType" label="Region Type">
                <Dropdown
                  id="regionType"
                  options={regionTypeList}
                  value={regionType}
                  optionLabel="key"
                  optionValue="value"
                  onChange={(event: DropdownChangeEvent) => setRegionTypeList(event.value)}
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={() => setShowForm(false)} /> {/* Hide form on Cancel */}
              <Button label="Save" raised />
            </div>
          </CustomForm>
        )}
      </Panel>
    </>
  );
};

export default ZipCodeAddEdit;
