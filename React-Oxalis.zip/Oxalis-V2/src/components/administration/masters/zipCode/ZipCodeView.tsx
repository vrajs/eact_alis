import { useNavigate } from "react-router-dom";
import ViewForm from "../../../../controls/ViewForm";

const ZipCodeView = () => {
  const navigate = useNavigate();

  const headerRecord = [
    { label: "Zip Code", value: "00501" },
    { label: "Area Code", value: "631" },
    { label: "State", value: "New York" },
    { label: "City", value: "Holtsville" },
    { label: "County", value: "Suffolk" },
    { label: "Country", value: "USA" },
  ];
  const handleNavigate = () => {
    navigate("/administration/masters/zip-code");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Zip Codes
      </h2>
      <ViewForm header="Code Information" data={headerRecord} />
    </>
  );
};

export default ZipCodeView;
