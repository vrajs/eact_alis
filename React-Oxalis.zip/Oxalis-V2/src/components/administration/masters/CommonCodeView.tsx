import { useNavigate } from "react-router-dom";
import ViewForm from "../../../controls/ViewForm";

const CommonCodeView = () => {
  const navigate = useNavigate();

  const headerRecord = [
    { label: "Code Type", value: "HCPCS Code" },
    { label: "Standard Code", value: "T2020" },
    { label: "Short Name", value: "Day habil waiver per diem" },
    { label: "Effective Date", value: "07/04/1928" },
    { label: "Term Date", value: "N/A" },
    { label: "Gender", value: "Both" },
    { label: "Long Description", value: "Day habilitation, waiver; per diem" },
  ];
  const handleNavigate = () => {
    navigate("/administration/masters/common-code");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Codes
      </h2>
      <ViewForm header="Code Information" data={headerRecord} />
    </>
  );
};

export default CommonCodeView;
