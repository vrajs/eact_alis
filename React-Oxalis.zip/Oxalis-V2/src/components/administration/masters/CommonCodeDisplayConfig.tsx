import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useEffect, useState } from "react";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";

const CommonCodeDisplayConfig = () => {
  const [customers1, setCustomers1] = useState<any>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [codeType, setCodeTypeList] = useState(null);
  const [page, setPageList] = useState(null);
  const pageList = [
    { key: "MEMBER_ADD_EDIT", value: "1" },
    { key: "BENEFIT_PAGE", value: "2" },
  ];
  const codeTypeList = [
    { key: "HCPCS", value: "1" },
    { key: "POS", value: "2" },
  ];
  // Simulate data fetching with a useEffect
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        setLoading(true);
        const customerData = [
          {
            code: "ICD9DX",
            shortName: "ICD-9-CM-DX",
            longDesc: "ICD Code",
            codeType: "Clinical Code Type",
            charValue: "ICD",
            numericValue: "2",
            otherValue: "N/A",
            effectiveDate: "1/1/2012",
            termDate: "12/31/9999",
            displayOrder: "0",
          },
          {
            code: "ICD10DX",
            shortName: "ICD-10-CM-DX",
            longDesc: "ICD Code",
            codeType: "Clinical Code Type",
            charValue: "ICD",
            numericValue: "1",
            otherValue: "N/A",
            effectiveDate: "1/1/2012",
            termDate: "12/31/9999",
            displayOrder: "0",
          },
        ];
        setCustomers1(customerData);
      } catch (error) {
        console.error("Error fetching customers:", error);
      } finally {
        setLoading(false);
      }
    };

    void fetchCustomers();
  }, []);

  return (
    <>
      <h2 className="pb-4">Common Code Display Configuration</h2>
      <Panel header="Advance Search" toggleable className="search-panel">
        <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
          <FormItem name="page" label="Page">
            <Dropdown
              id="page"
              options={pageList}
              value={page}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setPageList(event.value)}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
          <FormItem name="codeType" label="Code Type">
            <Dropdown
              id="codeType"
              options={codeTypeList}
              value={codeType}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setCodeTypeList(event.value)}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
        </div>
      </Panel>
      <div className="pb-4">
        <DataTable
          value={customers1}
          paginator
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          dataKey="claimId"
          responsiveLayout="scroll"
          emptyMessage="No records found."
          loading={loading}
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="multiple"
        >
          <Column selectionMode="multiple" />
          <Column field="code" header="Code" filter sortable body={(rowData) => <a className="underline">{rowData.code}</a>} />
          <Column field="shortName" header="Short&nbsp;Name" filter sortable />
          <Column field="longDesc" header="Long&nbsp;Description" filter sortable />
          <Column field="codeType" header="Code&nbsp;Type" filter sortable />
          <Column field="charValue" header="Char&nbsp;Value" filter sortable />
          <Column field="numericValue" header="Numeric&nbsp;Value" filter sortable />
          <Column field="otherValue" header="Other&nbsp;Value" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
          <Column field="displayOrder" header="Display&nbsp;Order" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default CommonCodeDisplayConfig;
