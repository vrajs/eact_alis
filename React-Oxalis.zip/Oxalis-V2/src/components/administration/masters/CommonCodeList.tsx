import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import Button from "../../../controls/Button";
import { useState } from "react";
import { useNavigate } from "react-router-dom";

const CommonCodeList = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const navigate = useNavigate();

  // Handle 'Add' button click
  const handleAddClick = () => {
    navigate("/administration/masters/common-code-add-edit");
  };
  const handleCodeClick = () => {
    navigate(`/administration/masters/common-code-view`);
  };
  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={handleAddClick} />
        </div>
      </div>
    );
  };
  const codeData = [
    {
      codesID: 1,
      code: "T2020",
      shortDesc: "Day habil waiver per diem",
      codeType: "HCPCS",
      drgType: "SURG",
      majorCategory: "PRE",
      gender: "Male",
      route: "N/A",
      strength: "N/A",
      dosageFrom: "N/A",
      unit: "N/A",
      ndcType: "N/A",
      effectiveDate: "2023-01-01",
      termDate: "2023-12-31",
    },
    {
      codesID: 2,
      code: "T2021",
      shortDesc: "Waiver service, nos",
      codeType: "HCPCS",
      drgType: "SURG",
      majorCategory: "PRE",
      gender: "Female",
      route: "N/A",
      strength: "N/A",
      dosageFrom: "N/A",
      unit: "N/A",
      ndcType: "N/A",
      effectiveDate: "2022-05-10",
      termDate: "2023-05-10",
    },
    {
      codesID: 3,
      code: "T2030",
      shortDesc: "Assist living waiver/diem",
      codeType: "HCPCS",
      majorCategory: "PRE",
      drgType: "SURG",
      gender: "Other",
      route: "N/A",
      strength: "N/A",
      dosageFrom: "N/A",
      unit: "N/A",
      ndcType: "N/A",
      effectiveDate: "2021-07-15",
      termDate: "2022-07-15",
    },
  ];
  return (
    <>
      <h2 className="pb-4">Common Codes</h2>
      <div className="pb-4">
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          value={codeData} // Static data added here
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          {/* Render 'code' as a hyperlink */}
          <Column
            field="code"
            header="Code"
            body={(rowData) => (
              <a className="underline" onClick={handleCodeClick}>
                {rowData.code}
              </a>
            )}
            filter
            sortable
          />
          <Column field="shortDesc" header="Short&nbsp;Description" filter sortable />
          <Column field="codeType" header="Code&nbsp;Type" filter sortable />
          <Column field="drgType" header="DRG&nbsp;Type" filter sortable />
          <Column field="majorCategory" header="Major&nbsp;Category" filter sortable />
          <Column field="gender" header="Gender" filter sortable />
          <Column field="dosageFrom" header="Dosage&nbsp;From" filter sortable />
          <Column field="route" header="Route" filter sortable />
          <Column field="strength" header="Strength" filter sortable />
          <Column field="unit" header="Unit" filter sortable />
          <Column field="ndcType" header="NDC&nbsp;Type" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default CommonCodeList;
