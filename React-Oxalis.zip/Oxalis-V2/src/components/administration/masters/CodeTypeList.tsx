import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";

const CommonTypeList = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const codeData = [
    {
      codesID: 1,
      code: "PTermReason",
      shortName: "Provider Term Reason",
      longDesc: "Provider Term Reason",
      effectiveDate: "2021-07-15",
      termDate: "2022-07-15",
    },
    {
      codesID: 2,
      code: "SpanSource",
      shortName: "Span Source",
      longDesc: "Span Source",
      effectiveDate: "2021-07-15",
      termDate: "2022-07-15",
    },
    {
      codesID: 3,
      code: "DenialReason",
      shortName: "Denial Reason",
      longDesc: "Denial Reason",
      effectiveDate: "2021-07-15",
      termDate: "2022-07-15",
    },
  ];
  return (
    <>
      <h2 className="pb-4">Code Type List</h2>
      <div className="pb-4">
        <DataTable
          paginator
          header="List Information"
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          value={codeData} // Static data added here
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column field="code" header="Code" filter sortable />
          <Column field="shortName" header="Short&nbsp;Description" filter sortable />
          <Column field="longDesc" header="Long&nbsp;Description" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default CommonTypeList;
