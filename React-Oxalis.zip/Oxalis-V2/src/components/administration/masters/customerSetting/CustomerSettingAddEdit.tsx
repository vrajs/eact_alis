import { Panel } from "primereact/panel";
import { useNavigate } from "react-router-dom";
import CustomForm from "../../../../controls/CustomForm";
import FormItem from "../../../../controls/FormItem";
import InputText from "../../../../controls/InputText";
import Calendar from "../../../../controls/Calendar";
import Button from "../../../../controls/Button";
import InputNumber from "../../../../controls/InputNumber";
import { InputSwitch } from "primereact/inputswitch";
import { useState } from "react";

const CustomerSettingAddEdit = () => {
  const navigate = useNavigate();
  const [checked, setChecked] = useState(false);
  const [bitChecked, setBitChecked] = useState(false);

  const handleNavigate = () => {
    navigate("/administration/masters/customer-setting-list");
  };

  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Customer Setting Code
      </h2>
      <Panel header="Code Information" toggleable className="search-panel">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="settingCode" label="Setting Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="description" label="Description">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="stringValue" label="String Value">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="numericValue" label="Numeric Value">
              <InputNumber placeholder="Enter here" />
            </FormItem>
            <FormItem name="dateValue" label="Date Value">
              <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" />
            </FormItem>
            <FormItem name="timeValue" label="Time Value">
              <Calendar placeholder="Enter Time" icon="cl_clock" iconPos="right" timeOnly />
            </FormItem>
            <div className="col-span-2 flex items-center">
              <div className="flex items-end gap-3">
                <label htmlFor="input-switch">Bit Value</label>
                <InputSwitch id="input-switch" checked={bitChecked} onChange={(e) => setBitChecked(e.value)} />
                <label htmlFor="input-switch">Portal Access</label>
                <InputSwitch id="input-switch" checked={checked} onChange={(e) => setChecked(e.value)} />
              </div>
            </div>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text />
            <Button label="Save" raised onClick={handleNavigate} />
          </div>
        </CustomForm>
      </Panel>
    </>
  );
};

export default CustomerSettingAddEdit;
