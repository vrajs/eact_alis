import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Button from "../../../../controls/Button";

const CustomerSettingList = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const navigate = useNavigate();

  // Handle 'Add' button click
  const handleAddClick = () => {
    navigate("/administration/masters/customer-setting-add-edit");
  };

  const headerTemplate = () => {
    return (
      <div>
        <div className="flex justify-content-end gap-3">
          <Button outlined label="Add" onClick={handleAddClick} />
        </div>
      </div>
    );
  };
  const codeData = [
    {
      codesID: 1,
      code: "MemSeqNo",
      description: "Member Sequqnce Number to Start for  MemberID",
      stringValue: "N/A",
      numericValue: "1000001",
      bitValue: "No",
      dateValue: "2023-12-31",
      timeValue: "",
      oneTime: "yes",
    },
    {
      codesID: 2,
      code: "ClaimSeqNo",
      description: "Claim Sequence Number to Start for ClaimNumber",
      stringValue: "N/A",
      numericValue: "1000001",
      bitValue: "No",
      dateValue: "2023-12-31",
      timeValue: "",
      oneTime: "yes",
    },
  ];
  return (
    <>
      <h2 className="pb-4">Customer Setting List</h2>
      <div className="pb-4">
        <DataTable
          paginator
          header={headerTemplate}
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          value={codeData} // Static data added here
          dataKey="codesID"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          {/* Render 'code' as a hyperlink */}
          <Column field="code" header="Setting&nbsp;Code" filter sortable />
          <Column field="description" header="Description" filter sortable />
          <Column field="stringValue" header="String&nbsp;Value" filter sortable />
          <Column field="numericValue" header="Numeric&nbsp;Value" filter sortable />
          <Column field="bitValue" header="Bit&nbsp;Value" filter sortable />
          <Column field="dateValue" header="Date&nbsp;Value" filter sortable />
          <Column field="timeValue" header="Time&nbsp;Value" filter sortable />
          <Column field="oneTime" header="Is&nbsp;One&nbsp;Time&nbsp;Value" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default CustomerSettingList;
