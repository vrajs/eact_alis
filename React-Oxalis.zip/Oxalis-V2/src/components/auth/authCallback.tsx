import { useEffect, useState } from "react";
import { useAuth } from "../../core/auth/provider/AuthProvider";
import useLocalStorage from "../../core/auth/hooks/useLocalStorage";
import AuthLoader from "../../core/components.ts/loaders/AuthLoader";

export const AuthCallBack = () => {
  const authContext = useAuth();
  const { getLocalStorageItem } = useLocalStorage();
  const [isLoggedIn, setIsLoggedIn] = useState(getLocalStorageItem("UserTokenInfo") ?? "");

  useEffect(() => {
    const handleSignIn = async () => {
      try {
        if (window.location.href.indexOf("auth-callback") <= -1 && !authContext.isAuthenticated()) {
          authContext.signinRedirect();
        } else if (window.location.href.indexOf("auth-callback") > -1) {
          await authContext.signinRedirectCallback();
          setIsLoggedIn(getLocalStorageItem("UserTokenInfo") ?? "");
        }
      } catch (error) {
        console.error("Error during sign-in callback:", error);
      }
    };
    handleSignIn();
  }, []);
  

  return (
    <>
      {isLoggedIn === "" ? (
        <div>
          <AuthLoader />
        </div>
      ) : null}
    </>
  );
};
