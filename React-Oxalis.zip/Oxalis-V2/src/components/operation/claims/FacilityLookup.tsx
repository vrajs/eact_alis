import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useEffect, useRef, useState } from "react";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import InputText from "../../../controls/InputText";
import { ProviderService } from "../../../services/ProviderService";
import { LazyTableState } from "../../../model/LazyTableState";
import { FormInstance, useForm } from "rc-field-form";
import { ProviderLookUpModel } from "../../../model/ProviderLookUpModel";
import CustomForm from "../../../controls/CustomForm";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import { useDispatch } from "react-redux";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import { FacilityLookUpModel, FacilitySearchModel } from "../../../model/FacilityLookUpModel";
import moment from "moment";
import { ClaimHeaderModel } from "../../../model/ClaimHeaderModel";
import InputNumber from "../../../controls/InputNumber";
import { AddFacilityData } from "../../../Redux/features/claimSlice";

interface FacilityLookupProps {
  form: FormInstance<ClaimHeaderModel>;
}

const FacilityLookup = ({ form }: FacilityLookupProps) => {
  const [selectedProvider, setSelectedProvider] = useState<ProviderLookUpModel | null>(null);
  const panel = useRef<Panel>(null);
  const [gridValues, setGridValues] = useState<FacilityLookUpModel[]>([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [searchForm] = useForm<FacilitySearchModel>();
  const dispatch = useDispatch();
  const { getFacilities } = ProviderService();

  const initialValues: FacilitySearchModel = {
    firstName: "",
    lastName: "",
    vendorName: "",
    npi: "",
    tin: "",
  }

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const lookup = async (query: string, formValue?: FacilitySearchModel) => {
    const dosFrom = moment(form.getFieldValue("dosFrom")).format("YYYY-MM-DD");
    const dosTo = moment(form.getFieldValue("dosTo")).format("YYYY-MM-DD");
    const facilityLookup = await getFacilities(dosFrom, dosTo, query, formValue);
    if (facilityLookup) {
      setGridValues(facilityLookup.data);
      setTotalRecords(facilityLookup.totalCount);
    }
  }

  const handleSave = () => {
    panel.current?.collapse(undefined);
    const formValue = searchForm.getFieldsValue(true) ?? null;
    const query = useQueryBuilder(lazyState);
    lookup(query, formValue ? formValue : null);
  }

  useEffect(() => {
    handleSave();
  }, [lazyState])

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedProvider(e.value)
    } else {
      setSelectedProvider(null)
    }
  }

  const handleFAcilitySelection = () => {
    dispatch(AddFacilityData(selectedProvider))
  }

  return (
    <>
      <Panel header="Advance Search" toggleable collapsed={true} className="search-panel" ref={panel}>
        <CustomForm form={searchForm} onFinish={handleSave} initialValues={initialValues}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="firstName" label="First Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="lastName" label="Last Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="npi" label="NPI">
              <InputNumber type="text" placeholder="Enter here" useGrouping={false} />
            </FormItem>
            <FormItem name="tin" label="TIN">
              <InputNumber type="text" placeholder="Enter here" useGrouping={false} />
            </FormItem>
            <FormItem name="vendor" label="Vendor">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="clear" text />
            <Button label="Apply" outlined />
          </div>
        </CustomForm>
      </Panel>
      <div className="pb-4">
        <DataTable
          paginator
          rowsPerPageOptions={paginatorConstants.pageOptions}
          className="p-datatable-gridlines"
          showGridlines
          rows={lazyState.rows}
          tableStyle={{ minWidth: '50rem' }}
          currentPageReportTemplate="{first} to {last} of {totalRecords}"
          dataKey="providerId"
          emptyMessage="No Group found."
          selectionMode="single"
          onPage={onPage}
          onSort={onSort}
          sortField={lazyState.sortField}
          onFilter={onFilter}
          value={gridValues}
          onSelectionChange={(e) => handleSelection(e)}
          totalRecords={totalRecords}
          first={lazyState.first}
        >
          <Column field="facilityCode" header="Facility&nbsp;Code" />
          <Column field="facilityName" header="Facility&nbsp;Name" />
          <Column field="facilityNPI" header="NPI" />
          <Column field="tin" header="TIN" />
          <Column field="vendorName" header="Vendor" />
        </DataTable>
        <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
          <Button label="Add Selected Facility" raised onClick={handleFAcilitySelection} />
        </div>
      </div>
    </>
  );
};

export default FacilityLookup;
