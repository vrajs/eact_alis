import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useEffect, useRef, useState } from "react";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import InputText from "../../../controls/InputText";
import { ProviderService } from "../../../services/ProviderService";
import { LazyTableState } from "../../../model/LazyTableState";
import { useForm } from "rc-field-form";
import { ProviderLookUpModel } from "../../../model/ProviderLookUpModel";
import CustomForm from "../../../controls/CustomForm";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import { useDispatch } from "react-redux";
import { AddProviderData } from "../../../Redux/features/claimSlice";
import { ClaimProviderSearchModel } from "../../../model/ClaimProviderSearchModel";
import useQueryBuilder from "../../../hooks/useQueryBuilder";

const ClaimProviderSearch = () => {
  const [selectedProvider, setSelectedProvider] = useState<ProviderLookUpModel | null>(null);
  const { getProviderLookup } = ProviderService();
  const panel = useRef<Panel>(null);
  const [gridValues, setGridValues] = useState<ProviderLookUpModel[]>([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [form] = useForm<ClaimProviderSearchModel>();
  const dispatch = useDispatch();

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const lookup = async (query: string) => {
    const providerLookup = await getProviderLookup(query);
    if (providerLookup) {
      setGridValues(providerLookup.data);
      setTotalRecords(providerLookup.totalCount);
    }
  }

  const handleSave = () => {
    console.log(form.getFieldsValue(true));
    panel.current?.collapse(undefined);
    const formValue = form.getFieldsValue(true);
    const keys = Object.keys(formValue);
    let query = useQueryBuilder(lazyState);

    keys.forEach((element: string) => {
      const value = formValue[element];

      if (value) {
        query += query ? `&${element}=${value}` : `?${element}=${value}`;
      }
    });

    lookup(query);
  }

  useEffect(() => {
    handleSave();
  }, [lazyState])

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedProvider(e.value)
    } else {
      setSelectedProvider(null)
    }
  }

  const handleProviderSelection = () => {
    dispatch(AddProviderData(selectedProvider))
  }

  return (
    <>
      <Panel header="Advance Search" toggleable collapsed={true} className="search-panel" ref={panel}>
        <CustomForm form={form} onFinish={handleSave} >
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="providerFirstName" label="First Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="providerLastName" label="Last Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="providerNPI" label="NPI">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="tin" label="TIN">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="vendor" label="Vendor">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="clear" text />
            <Button label="Apply" outlined />
          </div>
        </CustomForm>
      </Panel>
      <div className="pb-4">
      <DataTable
          paginator
          rowsPerPageOptions={paginatorConstants.pageOptions}
          className="p-datatable-gridlines"
          showGridlines
          rows={lazyState.rows}
          tableStyle={{ minWidth: '50rem' }}
          currentPageReportTemplate="{first} to {last} of {totalRecords}"
          dataKey="providerId"
          responsiveLayout="scroll"
          emptyMessage="No Group found."
          selectionMode="single"
          onPage={onPage}
          onSort={onSort}
          sortField={lazyState.sortField}
          onFilter={onFilter}
          value={gridValues}
          onSelectionChange={(e) => handleSelection(e)}
          totalRecords={totalRecords}
          first={lazyState.first}
        >
          <Column field="providerCode" header="Provider&nbsp;Code" sortable />
          <Column field="providerName" header="Provider&nbsp;Name" sortable />
          <Column field="providerNPI" header="NPI" sortable />
          <Column field="tin" header="TIN" sortable />
          <Column field="vendor" header="Vendor" sortable />
          <Column field="state" header="State" sortable />
          <Column field="city" header="City" sortable />
          <Column field="address1" header="Address" sortable />
          <Column field="zip" header="ZIP" sortable />
        </DataTable>
        <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
          <Button label="Add Selected Provider" raised onClick={handleProviderSelection}/>
        </div>
      </div>
    </>
  );
};

export default ClaimProviderSearch;
