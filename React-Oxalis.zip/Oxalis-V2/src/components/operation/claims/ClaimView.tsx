import { useNavigate } from "react-router-dom";
import ViewForm from "../../../controls/ViewForm";
import { useState, useEffect } from "react";
import PanelTable from "../../../controls/ViewTable";

const ClaimView = () => {
  const navigate = useNavigate();

  const data = [
    { label: "Claim", value: "24236E0003" },
    { label: "Claim Status", value: "Load" },
    { label: "Claim Type", value: "Professional" },
    { label: "Claim Source", value: "EDI" },
    { label: "DOS From", value: "01/02/2024" },
    { label: "DOS To", value: "01/02/2024" },
    { label: "Amount Billed", value: "$00.10" },
    { label: "Patient Account", value: "2024319CHA15908" },
    { label: "Date Entered", value: "08/23/2024" },
    { label: "Date Received", value: "08/23/2024" },
  ];

  const memberdata = [
    { label: "Member Id", value: "P00048115" },
    { label: "Member Name", value: "Gardner, Dennis" },
    { label: "Date of Birth", value: "01/23/1950" },
    { label: "LOB", value: "N/A" },
    { label: "PCP Id", value: "1011" },
    { label: "PCP Name", value: "Marta C Berio" },
    { label: "Effective Date", value: "01/01/1753" },
    { label: "Term Date", value: "01/01/1753" },
    { label: "Relationship", value: "Self" },
  ];

  const providerdata = [
    { label: "Provider Id", value: "PPR000053" },
    { label: "Provider Name", value: "Jeffrey S Grove" },
    { label: "Pay To", value: "N/A" },
    { label: "Contract", value: "N/A" },
    { label: "NPI", value: "1154313252" },
    { label: "TIN", value: "N/A" },
  ];
  const paymentdata = [
    { label: "Cheque Date", value: "N/A" },
    { label: "Cheque Number", value: "N/A" },
    { label: "Amount Paid", value: "N/A" },
    { label: "Amount of Cheque", value: "N/A" },
    { label: "Date Cleared", value: "N/A" },
  ];
  const alternatepayeedata = [
    { label: "Payee Name", value: "N/A" },
    { label: "Payee Address", value: "N/A" },
    { label: "Payee City State ZIP", value: "N/A" },
    { label: "Member Reimbursed", value: "N/A" },
    { label: "Provider Reimbursed", value: "N/A" },
    { label: "Reason", value: "N/A" },
  ];
  const claimdetails = [
    { label: "Date of Illness", value: "N/A" },
    { label: "Other Date", value: "N/A" },
    { label: "Employment", value: "No" },
    { label: "Auto", value: "No" },
    { label: "Provider Reimbursed", value: "No" },
    { label: "Other Accident", value: "No" },
    { label: "Referring Physician", value: "Wael Abdelghani" },
    { label: "Referring Phys NPI", value: "1508837915" },
    { label: "External Claim Id", value: "1959" },
    { label: "Prior Auth Number", value: "N/A" },
    { label: "Other Insurance Paid", value: "$00.00" },
    { label: "Accepts Assignment", value: "Yes" },
    { label: "Pay and Pursue", value: "No" },
    { label: "Corrected Claim", value: "No" },
    { label: "Patient Reimb", value: "No" },
    { label: "Encounter", value: "No" },
  ];
  const handleNavigate = () => {
    navigate("/claims/search");
  };

  const [customers1, setCustomers1] = useState<any[]>([]);
  const [diagnosisCode, setDiagnosisCode] = useState<any[]>([]);
  const [notes, setNotes] = useState<any[]>([]);

  const columns = [
    { field: "DOSFrom", header: "DOSFrom" },
    { field: "DOSTo", header: "DOSTo" },
    { field: "CPT", header: "CPT" },
    { field: "MOD", header: "MOD" },
    { field: "POS", header: "POS" },
    { field: "Units", header: "Units" },
    { field: "Billed", header: "Billed" },
    { field: "Allowed", header: "Allowed" },
    { field: "NonCovered", header: "NonCovered" },
    { field: "Deductible", header: "Deductible" },
    { field: "Copay", header: "Copay" },
    { field: "Coinsurance", header: "Coinsurance" },
    { field: "Payable", header: "Payable" },
    { field: "Interest", header: "Interest" },
    { field: "TotalPaid", header: "TotalPaid" },
  ];
  const diagnosiscolumns = [
    { field: "DiagPointer", header: "Diag Pointer" },
    { field: "Diagnosis", header: "Diagnosis" },
    { field: "DiagnosisDescription", header: "Diagnosis Description" },
    { field: "Qualifier", header: "Qualifier" },
  ];
  const notescolumns = [
    { field: "effectivedate", header: "Effective Date" },
    { field: "termdate", header: "Term Date" },
    { field: "shortdescription", header: "Short Description" },
    { field: "longdescription", header: "Long Description" },
    { field: "userinitials", header: "User Initials" },
    { field: "notedates", header: "Note Dates" },
  ];
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const customerData = [
          {
            DOSFrom: "GAN000012",
            DOSTo: "John Doe",
            CPT: "N/A",
            MOD: "N/A",
            POS: "N/A",
            Units: "0.00",
            Billed: "0",
            Allowed: "0",
            NonCovered: "0",
            Deductible: "0",
            Copay: "0",
            Coinsurance: "0",
            Payable: "0",
            Interest: "0",
            TotalPaid: "0",
            Code: "0",
          },
        ];
        const diagnosisCode = [
          {
            DiagPointer: "1",
            Diagnosis: "i10",
            DiagnosisDescription: "Essential (primary) hypertension",
            Qualifier: "0",
          },
        ];
        const notes = [
          {
            effectivedate: "N/A",
            termdate: "N/A",
            shortdescription: "N/A",
            longdescription: "N/A",
            userinitials: "N/A",
            notedates: "N/A",
          },
        ];
        setCustomers1(customerData);
        setDiagnosisCode(diagnosisCode);
        setNotes(notes);
      } catch (error) {
        console.error("Error fetching customers:", error);
      }
    };

    fetchCustomers();
  }, []);

  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>
        Claim Configuration
      </h2>
      <ViewForm header="Claim Information" data={data} />
      <ViewForm header="Member Information" data={memberdata} />
      <ViewForm header="Provider Information" data={providerdata} />
      <PanelTable panelHeader="Claim Summary" value={customers1} columns={columns} />
      <PanelTable panelHeader="Claim Diagnosis Code" value={diagnosisCode} columns={diagnosiscolumns} />
      <ViewForm header="Payment Information" data={paymentdata} />
      <ViewForm header="Alternate Payee/ Split Payment" data={alternatepayeedata} />
      <ViewForm header="Additional Claim Details" data={claimdetails} />
      <PanelTable panelHeader="Notes" value={notes} columns={notescolumns} />
    </>
  );
};

export default ClaimView;
