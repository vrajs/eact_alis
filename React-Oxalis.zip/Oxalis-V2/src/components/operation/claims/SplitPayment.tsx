import { Panel } from 'primereact/panel'
import React, { useEffect, useState } from 'react'
import CustomForm from '../../../controls/CustomForm'
import { useForm } from 'rc-field-form'
import { ClaimSplitPaymentModel } from '../../../model/ClaimSplitPaymentModel'
import FormItem from '../../../controls/FormItem'
import { InputText } from 'primereact/inputtext'
import InputNumber from '../../../controls/InputNumber'
import FormListItem from '../../../controls/FormListItem'
import Checkbox from '../../../controls/CheckBox'
import InputTextarea from '../../../controls/InputTextarea'
import Button from '../../../controls/Button'
import { useDispatch, useSelector } from 'react-redux'
import { AddSplitPayment } from '../../../Redux/features/claimSlice'
import { RootState } from '../../../Redux/app/store'
import ConfirmationDialog from '../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog'

const SplitPayment = () => {
  const [form] = useForm<ClaimSplitPaymentModel>();
  const [reimbursement, setReimbursement] = useState(false); 
  const {splitPayment} = useSelector((state: RootState) => state.claim);
  const [confirm, setConfirm] = useState<boolean>(false);
  const dispatch = useDispatch();

  useEffect(() => {
    if (splitPayment) {
      form.setFieldsValue({...splitPayment});
    }
  }, [splitPayment])

  const handleReimbursement = () => {
    setReimbursement((prevState) => !prevState)
  };

  const handleConfirm = () => {
    setConfirm(false);
  }

  const handleConfirmCancel = () => {
    setConfirm(false);
  }

  const handleCancel = () => {
    setConfirm(true);
    form.resetFields();
  };

  const handleSave = () => {
    const formValue = form.getFieldsValue(true);
    dispatch(AddSplitPayment(formValue))
  };

  return (
    <>
      {/* <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer"></i>Alter
      </h2> */}
      <Panel header="Split Payment Configuration" className="mb-4">
        <CustomForm form={form} onFinish={handleSave}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="payeeName" label="Member Reimbursement" rules={[{ required: true }]}>
              <InputNumber id='' placeholder='Enter here' useGrouping={false}/>
            </FormItem>

            {/* <FormItem label="" name="reimburseReminderToProvider"> */}
              <Checkbox
                inputId="reimburseReminderToProvider"
                label={"Reimburse reminder to provider"}
                checked={reimbursement}
                onChange={handleReimbursement} // Handle checkbox change
              />
            {/* </FormItem> */}

            <FormListItem name="reasonForSplitPayment" label="Reason for split payment" rules={[{ required: true, message: "Reason is required" }]}>
              <InputTextarea placeholder="Reason for split payment" />
            </FormListItem>

          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" outlined onClick={handleCancel} />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      </Panel>

      <ConfirmationDialog 
        visible={confirm} 
        onConfirm={handleConfirm} 
        onCancel={handleConfirmCancel}
        message={"Are you sure want to cancel it? Unsaved data will be lost"} 
        header={"Confirm"}/>
    </>
  )
}

export default SplitPayment