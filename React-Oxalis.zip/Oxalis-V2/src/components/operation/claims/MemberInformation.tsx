import React, { useEffect, useState } from "react";
import Button from "../../../controls/Button";
//import { Dialog } from "primereact/dialog";
import { Sidebar } from "primereact/sidebar";
import ClaimMemberSearch from "./ClaimMemberSearch";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import useFormattedDate from "../../../hooks/useFormattedDate";
import { MemberProviderDataModel } from "../../../model/MemberProviderDataModel";
import { FormInstance } from "rc-field-form";
import { ClaimHeaderModel } from "../../../model/ClaimHeaderModel";

interface MemberInformationProps {
  form: FormInstance<ClaimHeaderModel>;
}

const MemberInformation = ({ form }: MemberInformationProps) => {
  //const [displayBasic, setDisplayBasic] = useState(false);
  const [visibleBottom, setVisibleBottom] = useState(false);
  const [showDetails, setShowDetails] = useState<boolean>(false);
  const [memberCode, setMemberCode] = useState<string>("");
  const { memberInfo, claimHeaderID, claimData, claimNumber } = useSelector((state: RootState) => state.claim);
  const [data, setData] = useState<MemberProviderDataModel[]>([
    { label: "Gender ", value: null, name: "gender", format: false },
    { label: "Member Name", value: null, name: "memberName", format: false },
    { label: "DOB", value: null, name: "dob", format: true },
    { label: "Plan", value: null, name: "planName", format: false },
    { label: "PCP Name", value: null, name: "pcpName", format: false },
    { label: "Address ", value: null, name: "address1", format: false },
    { label: "Effective Date", value: null, name: "effectiveDate", format: true },
    { label: "Relationship ", value: null, name: "relationship", format: false },
  ]);

  useEffect(() => {
    if (claimHeaderID > 0 && claimData) {
      console.log("claimData claimData claimData", claimData)
      const bindData = data.map((memberData: MemberProviderDataModel) => {
        let value = claimData[memberData.name] ?? "N/A";
        console.log("claimData", claimData)
        if (value && memberData.format) {
          value = useFormattedDate(claimData, memberData.name);
          console.log("value value value", value)
          return { ...memberData, value };
        }
        value ? value : value = "N/A";
        return { ...memberData, value };
      })
      console.log("bindData", bindData)
      setData(bindData);
      setShowDetails(true);
      setMemberCode(claimData.memberCode);
    }
  }, [claimHeaderID, claimData])

  useEffect(() => {
    console.log("memberInfo memberInfo memberInfo", memberInfo)
    if (memberInfo) {
      setVisibleBottom(false);
      const resultData = data.map((eachData) => {
        let value = memberInfo[eachData.name];
        if (value && eachData.format) {
          value = useFormattedDate(memberInfo, eachData.name);
          console.log("value value value", value)
          return {...eachData, value};
        }
        value ? value : value = "N/A";
        return {...eachData, value};
      })
      console.log("resultData resultData", resultData)
      setData(resultData);
      setMemberCode(memberInfo.memberCode);
      console.log("memberInfo memberInfo", memberInfo)
      form.setFieldsValue({
        memberID: memberInfo.memberID, // 
        memberCode: memberInfo.memberCode, //
        plan: memberInfo.planName, // 
        gender: memberInfo.gender, //
        pcpName: memberInfo.pcpName, //
        pcpid: memberInfo.pcpid, // 
        memberName: memberInfo.memberName,
        relationship: memberInfo.relationship, // 
        relationshipID: memberInfo.relationshipID,
        memberEligibilityID: memberInfo.memberEligibilityID, // 
        memberPCPID: memberInfo.memberPCPID, //
        member837Address: memberInfo.address1, //
        dob: memberInfo.dob, //
        effectiveDate: memberInfo.effectiveDate, //
        planID: memberInfo.healthPlanID
      })
      setShowDetails(true);
    }
  }, [memberInfo])

  return (
    <>
      <h5 className="border-bottom-1 pb-3 mb-3 flex items-center gap-2 justify-between">
        Member Information {memberCode && `- ${memberCode}`}
        <Button type="button" icon="cl_search text-xl" outlined className="surface-border" onClick={() => setVisibleBottom(true)}></Button>
      </h5>
      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">
        {showDetails && data.map((item, index) => (
          <div key={index}>
            <div className="flex flex-nowrap justify-content-between align-items-center border-1 surface-border border-round px-3 py-2 cursor-pointer">
              <div className="flex align-items-center">
                <div className="flex-col">
                  <div className="block text-600 text-overflow-ellipsis overflow-hidden white-space-nowrap text-sm">{item.label}</div>
                  <div className="text-900 font-semibold block">{item.value}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      {/* <Dialog header="Dialog" visible={displayBasic} modal onHide={() => setDisplayBasic(false)} className="max-w-[80vw]">
        <ClaimMemberSearch />
      </Dialog> */}
      <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-4/6 text-xl"
        header="Member Search"
      >
        <ClaimMemberSearch />
      </Sidebar>
    </>
  );
};

export default MemberInformation;
