import { TabMenu } from "primereact/tabmenu";
import { useState } from "react";
import { Panel } from "primereact/panel";

// Import tab components
import ClaimServices from "../claims-components/claimServices";
import ClaimReference from "../claims-components/claimReference";
import ClaimOtherInsurance from "../claims-components/claimOtherInsurance";
import ClaimAudit from "../claims-components/claimAudit";
import ClaimEdits from "../claims-components/claimEdits";
import ClaimSummary from "../claims-components/claimSummary";
import ClaimProcessingSteps from "../claims-components/claimProcessingSteps";
import ClaimMessages from "../claims-components/claimMessages";
import ClaimNotes from "../claims-components/ClaimNotes";
import ClaimDiagnosis from "../claims-components/ClaimDiagnosis";
import { TabView, TabPanel } from "primereact/tabview";

interface ClaimDetailsProps {
  show: boolean;
}

const ClaimDetails = ({ show = false }: ClaimDetailsProps) => {
  const items = [
    { label: "Other Physicians", component: <ClaimDiagnosis />, show },
    { label: "UB Codes", component: <ClaimDiagnosis />, show },
    { label: "Diag and Diag Procedures", component: <ClaimDiagnosis />, show },
    { label: "Services", component: <ClaimServices />, show: true },
    { label: "Reference", component: <ClaimReference />, show: true },
    { label: "Other Insurance", component: <ClaimOtherInsurance />, show: true },
    { label: "Audit", component: <ClaimAudit />, show: true },
    { label: "Edits", component: <ClaimEdits />, show: true },
    { label: "Notes", component: <ClaimNotes />, show: true },
    { label: "Claim Summary", component: <ClaimSummary />, show: true },
    { label: "Processing Steps", component: <ClaimProcessingSteps />, show: true },
    { label: "EOB/EOP Messages", component: <ClaimMessages />, show: true },
  ];

  const [activeIndex, setActiveIndex] = useState(0);

  const handleTabChange = (e) => {
    setActiveIndex(e.index);
  };

  return (
    <div className="pb-4">
      <Panel header="Claim Components" toggleable className="custom-tab-menu">
        <TabView scrollable activeIndex={activeIndex} onTabChange={handleTabChange}>
          {items.map((item, index) => (
            <TabPanel key={index} header={item.label}>
              {item.component}
            </TabPanel>
          ))}
        </TabView>
      </Panel>
    </div>
  );
};

export default ClaimDetails;
