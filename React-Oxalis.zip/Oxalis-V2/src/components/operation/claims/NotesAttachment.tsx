import { useEffect, useRef, useState } from "react";
import Button from "../../../controls/Button";
import { Editor } from "primereact/editor";
import { FileUpload } from "primereact/fileupload";
import { Toast } from "primereact/toast";
import Dropdown from "../../../controls/Dropdown";
import FormItem from "../../../controls/FormItem";
import CommonCodeService from "../../../services/CommonCodeService";
import { CodeType } from "../../../data/constants/AppEnum";
import CustomForm from "../../../controls/CustomForm";
import { FormInstance, useForm } from "rc-field-form";
import { useDispatch } from "react-redux";
import { AddPreEnrollmentData } from "../../../Redux/features/preEnrollmentSlice";

const NotesAttachment = () => {
  const [attachmentOption, setAttachmentOptionList] = useState(null);
  const [text, setText] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const toast = useRef(null);
  const [form] = useForm<FormInstance>();
  const dispatch = useDispatch();
  const { getCommonCodeByCodeTypeId } = CommonCodeService();

  const onUpload = () => {
    toast.current.show({ severity: "info", summary: "Success", detail: "File Uploaded" });
  };

  const handleAttachClick = () => {
    const formValues = form.getFieldsValue(true);

    // Dispatch separate values to Redux
    dispatch(AddPreEnrollmentData({
      noteName: text,
      attachmentTypeId: formValues.attachmentTypeId,
      filePreEnroll: file
    }));

    toast.current.show({ severity: "success", summary: "Success", detail: "Data Attached" });
  };

  useEffect(() => {
    const fetchAttachmentTypes = async () => {
      const attachmentTypes = await getCommonCodeByCodeTypeId(CodeType.AttachmentType);
      setAttachmentOptionList(attachmentTypes);
    };

    fetchAttachmentTypes();
  }, []);

  return (
    <>
      <Editor
        value={text}
        onTextChange={(e) => setText(e.htmlValue)}
        style={{ height: "180px" }}
        className="pb-4"
        name="noteName"
      />
      <CustomForm form={form}>
        <div className="pb-3">
          <FormItem name="attachmentTypeId" label="Attachment Type">
            <Dropdown
              id="language"
              options={attachmentOption}
              optionLabel="key"
              optionValue="value"
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
        </div>
        <div className="pb-3">
          <h5 className="border-bottom-1 pb-3 mb-3">Attachment</h5>
          <Toast ref={toast}></Toast>
          <FileUpload
            mode="basic"
            name="filePreEnroll"
            accept="*/*"
            maxFileSize={1000000}
            customUpload
            auto={false}
            onSelect={(e) => setFile(e.files[0])}
            onUpload={onUpload}
          />
        </div>
        <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
          <Button label="Cancel" text />
          <Button label="Attach" outlined onClick={handleAttachClick} />
        </div>
      </CustomForm>
    </>
  );
};

export default NotesAttachment;
