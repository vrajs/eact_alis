import React, { useEffect, useState } from 'react'
import CustomForm from '../../../controls/CustomForm'
import { useForm } from 'rc-field-form'
import FormItem from '../../../controls/FormItem';
import Dropdown from '../../../controls/Dropdown';
import AutoComplete from '../../../controls/AutoComplete';
import FormListItem from '../../../controls/FormListItem';
import { REGEX_CONSTANTS } from '../../../data/constants/RegexConstants';
import { ZipCodeModel } from '../../../model/ZipCodeModel';
import { KeyValueModel } from '../../../model/KeyValueModel';
import ZipCodeService from '../../../services/ZipCodeService';
import { CityModel } from '../../../model/CityModel';
import Button from '../../../controls/Button';
import InputTextarea from '../../../controls/InputTextarea';
import { Panel } from 'primereact/panel';
import { useDispatch, useSelector } from 'react-redux';
import { AddAlternatePayee } from '../../../Redux/features/claimSlice';
import { AlternatePayeeModel } from '../../../model/AlternatePayeeModel';
import InputText from '../../../controls/InputText';
import { RootState } from '../../../Redux/app/store';

const AlternatePayeeInformation: React.FC = () => {
  const [zipCodes, setZipCodes] = useState<ZipCodeModel[]>([]);
  const [zipCodeOptions, setZipCodeOptions] = useState<KeyValueModel[]>([]);
  const [stateOptions, setStateOptions] = useState<KeyValueModel[]>([]);
  const { getZipCodeState, get, getCities } = ZipCodeService();
  const [cities, setCities] = useState<CityModel[]>([]);
  const {alternatePayee} = useSelector((state: RootState) => state.claim);
  const [countyOptions, setCountyOptions] = useState<KeyValueModel[]>([]);
  const [cityOptions, setCityOptions] = useState<KeyValueModel[]>([]);
  const dispatch = useDispatch();
  const [form] = useForm<AlternatePayeeModel>();

  const handleCancel = () => {
    // const formValue = form.getFieldsValue(true);
    // dispatch(AddAlternatePayee(null));
    form.resetFields();
  }

  const validateZipCode = (rule, value, callback) => {
    const regexValid = REGEX_CONSTANTS.ZIP_CODE.test(value);
    return new Promise((resolve, reject) => {
      if (!regexValid) {
        resolve(undefined);
        return;
      }
      if (regexValid) {
        const zipCodeExists = zipCodeOptions.some(zipCode => zipCode.key === value);
        if (!zipCodeExists) {
          reject(new Error("Zip code does not match"))
          return;
        }
      }
      resolve(undefined);
      return;
    });
  }

  useEffect(() => {
    form.setFieldsValue({...alternatePayee})
  }, [alternatePayee])

  useEffect(() => {
    const zipKeyValues = zipCodes.map((zip: ZipCodeModel) => {
      return { key: zip.code, value: zip.code };
    });
    setZipCodeOptions(zipKeyValues);
  }, [zipCodes])

  useEffect(() => {
    const statesRequest = getZipCodeState();
    const zipCodes = get();
    const cities = getCities();

    Promise.all([statesRequest, zipCodes, cities]).then(result => {
      setStateOptions(result[0]);
      setZipCodes(result[1]);
      setCities(result[2]);
    })
  }, [])

  const handleZipCodeChange = (event) => {
    const zipCode = zipCodes.find(zip => zip.code === event);
    if (zipCode) {
      form.setFieldValue("payeeCity", zipCode.city);
      form.setFieldValue("payeeState", zipCode.state);
    }
  }

  const handleSave = () => {
    const formValue = form.getFieldsValue(true);
    console.log(formValue)
    dispatch(AddAlternatePayee(formValue));
  }

  return (
    <>
      {/* <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer"></i>Alter
      </h2> */}
      <Panel header="Alternate Payee Configuration" className="mb-4">
        <CustomForm form={form} onFinish={handleSave}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="payeeName" label="Payee Name" rules={[{ required: true }]}>
              <InputText type="text" placeholder="Enter here" />
            </FormItem>

            <FormItem name="payeeAddress1" label="Payee Address 1" rules={[{ required: true }]}>
              <InputText type="text" placeholder="Enter here" />
            </FormItem>

            <FormItem name="payeeAddress2" label="Payee Address 2">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>

            <FormListItem name="payeeZip" label="Zip Code" rules={[
              { required: true, message: "Zip code is required" },
              { pattern: REGEX_CONSTANTS.ZIP_CODE, message: "Zip code is invalid" },
              { validator: validateZipCode, message: "Zip code does not match" }
            ]}>
              <AutoComplete id="zipcode" placeholder="Enter Zip code" field="value" suggestions={zipCodeOptions} minLength={2} onChange={handleZipCodeChange} />
            </FormListItem>

            <FormItem name="payeeCity" label="City" rules={[
              { required: true, message: "Zip code is required" },
            ]}>
              <AutoComplete id="city" field="value" placeholder="Enter City" disabled suggestions={cityOptions} minLength={2} />
            </FormItem>

            <FormItem name="payeeState" label="State" rules={[
              { required: true, message: "Zip code is required" },
            ]}>
              <Dropdown
                id="state"
                filter
                options={stateOptions}
                optionLabel="value"
                optionValue="key"
                placeholder="Select"
                showClear
                className="w-full"
                disabled
              />
            </FormItem>

            <FormItem name="payeeTin" label="Payee TIN">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>

            <FormListItem name="paymentRedirectReason" label="Reason" rules={[{ required: true, message: "Reason is required" }]}>
              <InputTextarea placeholder="Reason for redirect of payment" />
            </FormListItem>

          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" outlined onClick={handleCancel} />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      </Panel>
    </>
  )
}

export default AlternatePayeeInformation