import React, { useEffect, useState } from 'react'
import FormItem from '../../../controls/FormItem'
import Dropdown from '../../../controls/Dropdown'
import { InputSwitch } from 'primereact/inputswitch'
import { SwitchModel } from '../../../model/SwitchModel'
import { KeyValueModel } from '../../../model/KeyValueModel'
import { ContractViewModel } from '../../../model/ContractViewModel'
import ContractService from '../../../services/ContractService'
import { Field, FormInstance } from 'rc-field-form'
import { ClaimHeaderModel } from '../../../model/ClaimHeaderModel'
import { Sidebar } from 'primereact/sidebar'
import AlternatePayeeInformation from './AlternatePayeeInformation'
import SplitPayment from './SplitPayment'
import { useSelector } from 'react-redux'
import { RootState } from '../../../Redux/app/store'

interface OtherInformationProps {
  form: FormInstance<ClaimHeaderModel>;
}

const OtherInformation = ({ form }: OtherInformationProps) => {

  const [altFeeSchedule, setAltFeeSchedule] = useState<ContractViewModel[]>([]);
  const [feeScheduleOptions, setFeeScheduleOptions] = useState<KeyValueModel[]>([]);
  const [visibleBottom, setVisibleBottom] = useState(false);
  const [switchDetail, setSwitchDetail] = useState<SwitchModel | null>(null);
  const { alternatePayee, splitPayment, claimData, claimHeaderID } = useSelector((state: RootState) => state.claim);
  const [otherInfoSwitches, setOtherInfoSwitches] = useState<SwitchModel[]>([
    { label: "Accepts Assignment", id: "accept", value: false, name: "isAcceptsAssignment", show: true },
    { label: "Pay & Pursue", id: "pay", value: false, name: "isPayAndPursue", show: true },
    { label: "Corrected Claim", id: "corrected", value: false, name: "isCorrectedClaim", show: true },
    { label: "Patient Reimbursement", id: "patientReimbursement", value: false, name: "isPatientReimbursement", show: true },
    { label: "Refund Request", id: "refundRequest", value: false, name: "isRefundRequest", show: false },
    { label: "Encounter", id: "encounter", value: false, name: "isEncounter", show: true },
    { label: "Claim Not Clean", id: "claimNotClean", value: false, name: "isCleanClaim", show: true },
    { label: "Alternate Payee", id: "alternatePayee", value: false, name: "isAlternatePayee", showPopup: true, templateTitle: "Alternate Payee", template: <AlternatePayeeInformation />, disabled: false, dependencies: "isSplitPayment", show: true },
    { label: "Split Payment", id: "splitPayment", value: false, name: "isSplitPayment", showPopup: true, templateTitle: "Split Payment", template: <SplitPayment />, disabled: false, dependencies: "isAlternatePayee", show: true },
  ]);
  const { getContracts } = ContractService();

  const handleOtherInfoSwitchChange = (event, index: number, switchData: SwitchModel) => {
    setOtherInfoSwitches((prevState) => {
      prevState[index].value = event.value;
      if (prevState[index]?.dependencies) {
        const dependencyIndex = prevState.findIndex(state => state.name === prevState[index].dependencies);
        if (event.value) {
          prevState[dependencyIndex].value = false;
          prevState[dependencyIndex].disabled = true;
        } else {
          prevState[dependencyIndex].disabled = false;
        }
        
      }
      return [...prevState];
    })

    if (event.value && switchData.showPopup) {
      setVisibleBottom(true);
      setSwitchDetail(switchData);
    }
  }

  useEffect(() => {
    if (claimData) {
      const accidentData = otherInfoSwitches.map((eachData: SwitchModel) => {
        const value = claimData[eachData.name] ?? false;
        return { ...eachData, value, show: true };
      })
      setOtherInfoSwitches(accidentData);
    }
  }, [claimData])

  useEffect(() => {
    if (splitPayment) {
      console.log(splitPayment);
      setVisibleBottom(false);
      form.setFieldsValue({
        reimburseAmount: splitPayment?.reimburseAmount,
        reasonForSplitPayment: splitPayment?.reasonForSplitPayment,
        reimburseReminderToProvider: splitPayment?.reimburseReminderToProvider
      })
    }
  }, [splitPayment])

  useEffect(() => {
    if (alternatePayee) {
      setVisibleBottom(false)
      form.setFieldsValue({
        payeeAddress1: alternatePayee?.payeeAddress1,
        payeeAddress2: alternatePayee?.payeeAddress2,
        payeeCity: alternatePayee?.payeeCity,
        payeeName: alternatePayee?.payeeName,
        payeeZip: alternatePayee?.payeeZip,
        payeeTin: alternatePayee?.payeeTin,
        paymentRedirectReason: alternatePayee?.paymentRedirectReason,
        payeeState: alternatePayee?.payeeState
      })
    }
  }, [alternatePayee])

  useEffect(() => {
    const altFeeSchedule = getContracts();

    Promise.all([altFeeSchedule]).then(result => {
      setAltFeeSchedule(result[0])
    })
  }, [])

  useEffect(() => {
    if (altFeeSchedule.length > 0) {
      const feeSchedule = altFeeSchedule.map(contract => {
        return { key: contract.contractCode, value: contract.contractHeaderID };
      })
      setFeeScheduleOptions(feeSchedule);
    }

  }, [altFeeSchedule])

  return (
    <>
      <div className="pb-4">
        <h5 className="border-bottom-1 pb-3 mb-3 flex items-center gap-2">Other Information</h5>
        <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-4">
          <FormItem name="altFeeScheduleID" label="Alt Fee Schedule">
            <Dropdown
              id="fee"
              optionLabel="key"
              optionValue='value'
              placeholder="Select"
              options={feeScheduleOptions}
              showClear
              className="w-full"
            />
          </FormItem>
        </div>
        <div className="flex flex-wrap gap-4">
          {otherInfoSwitches.map((switchItem, index) => (
            <div key={index} className="flex align-items-center gap-2">
              <label htmlFor={switchItem.id}>{switchItem.label}</label>
              <Field name={switchItem.name}>
                <InputSwitch id={switchItem.id} checked={switchItem.value} name={switchItem.name} disabled={switchItem?.disabled} onChange={(event) => handleOtherInfoSwitchChange(event, index, switchItem)} />
              </Field>
            </div>
          ))}
        </div>
      </div>
      {switchDetail && <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-4/6 text-xl"
        header={switchDetail.templateTitle}
      >
        {switchDetail.template}
      </Sidebar>}
    </>
  )
}

export default OtherInformation;