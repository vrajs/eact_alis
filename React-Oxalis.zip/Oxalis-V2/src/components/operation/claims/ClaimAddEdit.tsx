import { Panel } from "primereact/panel";
import InputText from "../../../controls/InputText";
import Button from "../../../controls/Button";
import { useNavigate, useParams } from "react-router-dom";
import Calendar from "../../../controls/Calendar";
import { SetStateAction, useEffect, useState } from "react";
import Dropdown from "../../../controls/Dropdown";
import InputNumber from "../../../controls/InputNumber";
import { Dialog } from "primereact/dialog";
import ClaimAlertInfo from "../claims-components/ClaimAlertInfo";
import FormItem from "../../../controls/FormItem";
import { DropdownChangeEvent } from "primereact/dropdown";
import CommonCodeService from "../../../services/CommonCodeService";
import { ClaimSource, ClaimStatus, ClaimType, CodeType, CommonCodeFetchingType } from "../../../data/constants/AppEnum";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import { KeyValueModel } from "../../../model/KeyValueModel";
import { CommonCodeModel } from "../../../model/CommonCodeModel";
import CustomForm from "../../../controls/CustomForm";
import { ProviderService } from "../../../services/ProviderService";
import { ProviderViewModel } from "../../../model/ProviderViewModel";
import FormListItem from "../../../controls/FormListItem";
import { useForm } from "rc-field-form";
import ClaimService from "../../../services/ClaimService";
import { AddAlternatePayee, AddClaimData, AddSplitPayment, ClearClaimDetails } from "../../../Redux/features/claimSlice";
import { useDispatch } from "react-redux";
import moment from "moment";
import MemberInformation from "./MemberInformation";
import ProviderInformation from "./ProviderInformation";
import AdmitInformation from "./AdmitInformation";
import AccidentInformation from "./AccidentInformation";
import OtherInformation from "./OtherInformation";
import { ClaimHeaderModel } from "../../../model/ClaimHeaderModel";
import { ClaimHeaderViewModel } from "../../../model/ClaimHeaderViewModel";
import { MultipleValueRequestModel } from "../../../model/MultipleValueRequestModel";
import ClaimDetails from "./ClaimDetails";
import { useToaster } from "../../../layout/context/toastContext";
import useErrorHandler from "../../../hooks/useErrorHandler";
import FacilityInformation from "./FacilityInformation";

const ClaimAddEdit = () => {
  const navigate = useNavigate();
  const { claimId } = useParams<string>();
  const [displayBasic, setDisplayBasic] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState<boolean>(false);
  const [showClaimDetail, setShowClaimDetail] = useState<boolean>(false);
  const handleNavigate = () => {
    navigate("/claims/search");
  };

  const { getClaimsType } = CommonCodeService()
  const claimSourceOptions: KeyValueModel[] = useCommonCodeSubCategory(CodeType.ClaimSource, CommonCodeFetchingType.Default);
  const initialValues: ClaimHeaderViewModel = {
    claimHeaderID: 0,
    claimNumber: "",
    receivedDate: "",
    formTypeID: 0,
    enteredDate: "",
    dosFrom: "",
    dosTo: "",
    billedAmount: 0,
    paidAmount: 0,
    paidDate: "",
    otherInsurancePaid: 0,
    patientAccountNumber: "",
    externalClaimID: "",
    priorAuthNumber: "",
    claimStatusID: 0,
    claimStatusReason: "",
    claimSourceID: 0,
    isFinal: false,
    memberID: 0,
    providerID: 0,
    providerTypeID: 0,
    vendorName: "",
    provider837Address: "",
    member837Address: "",
    isCorrectedClaim: false,
    isPatientReimbursement: false,
    isRefundRequest: false,
    isCleanClaim: false,
    isEncounter: false,
    isAlternatePayee: false,
    isSplitPayment: false,
    isSuppressEOB: false,
    isPayAndPursue: false,
    altFeeScheduleID: 0,
    isEmployment: false,
    isAuto: false,
    isOtherAccident: false,
    illnessDate: "",
    otherDate: "",
    physicianName: "",
    physicianNPI: "",
    isAcceptsAssignment: false,
    billTypeID: 0,
    admitDate: "",
    admitHour: undefined,
    admitTypeID: 0,
    admitSourceID: 0,
    dischargeHour: undefined,
    dischargeStatusID: 0,
    billedDRGCode: undefined,
    revisedDRGCode: undefined,
    isPreDetermiantion: undefined,
    isEPSDTTitleXIX: undefined,
    serviceRendered: "",
    serviceRenderedName: "",
    claimAge: 0,
    url: undefined,
    memberCode: "",
    memberName: "",
    gender: "",
    memberEligibilityID: 0,
    plan: "",
    memberPCPID: 0,
    relationship: "",
    providerCode: "",
    providerName: "",
    providerNPI: "",
    providerGroupTIN: "",
    effectiveDate: "",
    reimburseAmount: 0,
    reimburseReminderToProvider: false,
    reasonForSplitPayment: "",
    payeeName: "",
    payeeAddress1: "",
    payeeAddress2: "",
    payeeCity: "",
    payeeState: "",
    payeeZip: "",
    payeeTin: "",
    paymentRedirectReason: "",
    vendorID: 0,
    accidentStateOrProvince: "",
    addedSource: "",
    providerStatus: "",
    providerSpecialtyID: 0,
    providerStatusID: 0,    
    checkNumber: 0,
    checkAmount: 0,
    checkClearDate: "",
    checkDate: "",
    dcn: "",
    memberInfo: undefined,
    providerInfo: undefined,
    referingPhysician: undefined,
    facilityInfo: undefined,
    altFreeScheduleInfo: undefined,
    claimStatus: "",
    dOB: "",
    pCPID: 0,
    lOBID: 0,
    pcpName: "",
    alternatePayeeZipCodeInfo: undefined,
    recordStatus: 0
  }
  const [claimTypes, setClaimTypes] = useState<CommonCodeModel[]>([]);
  const [referringProviders, setReferringProviders] = useState<ProviderViewModel[]>([]);
  const [referringProviderOptions, setReferringProviderOptions] = useState<KeyValueModel[]>([]);
  const [claimTypesOptions, setClaimTypesOptions] = useState<KeyValueModel[]>();
  const { getReferringProviders } = ProviderService();
  const { generateClaimNumber, getClaimByClaimNumber, createClaim, updateClaim } = ClaimService();
  const [dosFrom, setDosFrom] = useState<Date | null>(null);
  const [enteredDate, setEnteredDate] = useState<Date | null>(null);
  const dispatch = useDispatch();
  const [form] = useForm<ClaimHeaderModel>();
  const [formType, setFormType] = useState<undefined | null | number>(null);
  const { showToast } = useToaster();

  useEffect(() => {
    dispatch(ClearClaimDetails())
    const reqPaMulCodeType: MultipleValueRequestModel = {
      codeTypeIds: [CodeType.ClaimFormType],
      fetchingTypeId: CommonCodeFetchingType.ByDisplayOrder
    }
    const claimTypeRequest = getClaimsType(reqPaMulCodeType);
    const referringProviderRequest = getReferringProviders();

    Promise.all([claimTypeRequest, referringProviderRequest]).then(result => {
      setClaimTypes(result[0])
      setReferringProviders(result[1]);
    }).catch(error => {
      if (error[0] instanceof Error || error[1]) {
        setIsSubmitting(false);
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    })

    return () => {
      dispatch(ClearClaimDetails())
    }
  }, [])

  useEffect(() => {
    if (claimSourceOptions?.length > 0) {
      form.setFieldValue("claimSourceID", ClaimSource.Paper)
    }
  }, [claimSourceOptions])

  const getClaim = async () => {
    const claimHeader: ClaimHeaderViewModel = await getClaimByClaimNumber(claimId);
    console.log("claimHeader claimHeader", claimHeader)
    const claimHeaderData = {
      ...claimHeader,
      dosFrom: claimHeader.dosFrom ? moment(claimHeader.dosFrom).toDate() : null,
      dosTo: claimHeader.dosTo ? moment(claimHeader.dosTo).toDate() : null,
      receivedDate: claimHeader.receivedDate ? moment(claimHeader.receivedDate).toDate() : null,
      paidDate: claimHeader.paidDate ? moment(claimHeader.paidDate).toDate() : null,
      illnessDate: claimHeader.illnessDate ? moment(claimHeader.illnessDate).toDate() : null,
      otherDate: claimHeader.otherDate ? moment(claimHeader.otherDate).toDate() : null,
      admitDate: claimHeader.admitDate ? moment(claimHeader.admitDate).toDate() : null,
      effectiveDate: claimHeader.effectiveDate ? moment(claimHeader.effectiveDate).toDate() : null,
      enteredDate: claimHeader.enteredDate ? moment(claimHeader.enteredDate).toDate() : null,
    }
    form.setFieldsValue({ ...claimHeaderData });
    setDosFrom(claimHeaderData.dosFrom)
    const { payeeName, payeeAddress1, payeeAddress2, payeeZip, payeeCity, payeeState, payeeTin, paymentRedirectReason } = claimHeader;
    const { reimburseAmount, reasonForSplitPayment, reimburseReminderToProvider } = claimHeader;
    setShowClaimDetail(true);
    dispatch(AddClaimData(claimHeaderData));
    dispatch(AddAlternatePayee({ payeeName, payeeAddress1, payeeAddress2, payeeZip, payeeCity, payeeState, payeeTin, paymentRedirectReason }))
    dispatch(AddSplitPayment({ reimburseAmount, reasonForSplitPayment, reimburseReminderToProvider }));
  }

  useEffect(() => {
    if (claimId) {
      dispatch(ClearClaimDetails());
      getClaim();
    }
  }, [claimId])

  useEffect(() => {
    if (referringProviders.length > 0) {
      const referring = referringProviders.map(provider => {
        const { npi, providerCode, fullName } = provider
        return { key: `NPI: ${npi} | Code: ${providerCode} | Name: ${fullName}`, value: npi };
      })
      setReferringProviderOptions(referring);
    }
  }, [referringProviders])

  useEffect(() => {
    if (claimTypes.length > 0) {
      const claims = claimTypes.map((claim: CommonCodeModel) => {
        return { key: claim.shortName, value: claim.commonCodeID }
      })
      setClaimTypesOptions(claims);
    }
  }, [claimTypes])

  const handleReferringProviderChange = (event: DropdownChangeEvent) => {
    if (event.value) {
      const provider = referringProviders.find(provider => provider.npi == event.value);
      form.setFieldValue("physicianName", provider.fullName)
    } else {
      form.setFieldValue("physicianName", "");
    }
  }

  const handleServiceRenderedChange = (event: DropdownChangeEvent) => {
    if (event.value) {
      const provider = referringProviders.find(provider => provider.npi == event.value);
      form.setFieldValue("serviceRenderedName", provider.fullName);
    } else {
      form.setFieldValue("serviceRendered", "");
      form.setFieldValue("serviceRenderedName", "");
    }

  }

  const claimNumberResponse = async (receivedDate: Date) => {
    const formattedDate = moment(receivedDate).format("YYYY-MM-DD");
    const claimSourceId = form.getFieldValue("claimSourceID");

    const claimNumber = await generateClaimNumber(formattedDate, claimSourceId)
    // setClaimNumber(claimNumber);
    form.setFieldValue("claimNumber", claimNumber)
  }

  const handleReceivedDateChange = (event) => {
    if (!form.getFieldValue("claimNumber") && event) {
      claimNumberResponse(event);
    }
  }

  const handleCancel = () => {
    navigate("/claims/search");
    form.resetFields();
  }

  const handleDosFromDate = (event: Date) => {
    form.setFieldValue("dosTo", null);
    setDosFrom(event);
  }

  const handleEnteredDate = (event: Date) => {
    form.setFieldValue("dosFrom", null);
    form.setFieldValue("dosTo", null);
    setEnteredDate(event);
  }

  const dataMapper = async (value: ClaimHeaderViewModel) => {
    const dateFields = ["effectiveDate", "dob", "admitDate", "otherDate", "illnessDate", "paidDate", "dosTo", "dosFrom", "enteredDate", "receivedDate", "paidDate"]

    dateFields.forEach((field: string) => {
      value[field] ? value[field] = moment(value[field]).format("YYYY-MM-DD") : value[field] = null;
    })
    console.log("value value value value value", value)
    return await value;
  }

  const handleFormTypeChange = (event: DropdownChangeEvent) => {
    if (event) {
      setFormType(event.value)
    } else {
      setFormType(null)
    }
  }

  const handleSave = async () => {
    console.log(form.getFieldsValue(true));
    const memberCode = form.getFieldValue("memberCode");
    const providerCode = form.getFieldValue("providerCode");
    if (!memberCode) {
      return showToast({ severity: 'info', summary: 'Info', detail: "Please select a member" });
    }
    else if (!providerCode) {
      return showToast({ severity: 'info', summary: 'Info', detail: "Please select a provider" });
    }
    if (!claimId) {
      form.setFieldValue("claimStatusID", ClaimStatus.Open);
      form.setFieldValue("claimStatusReason", ClaimStatus[ClaimStatus.Open]);
    }
    const formValues = form.getFieldsValue(true);
    const formattedValues: ClaimHeaderViewModel = await dataMapper(formValues);

    setIsSubmitting(true)
    try {
      const claimResponse = claimId ? await updateClaim(formattedValues) : await createClaim(formattedValues);
      if (claimResponse) {
        form.resetFields();
        showToast({ severity: 'success', summary: 'Success', detail: "Claim saved successfully" });
        navigate("/claims/search");
      }
    }
    catch (error) {
      console.log(error)
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
    finally {
      setIsSubmitting(false);
    }
  }

  return (
    <>
      <h2 className="pb-4 flex-col md:flex md:flex-row align-center md:justify-between">
        <div className="flex items-center">
          <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Claim Configuration
        </div>
        <div className="flex flex-wrap gap-2">
          <Button icon="cl_user_fill text-xl" outlined onClick={() => setDisplayBasic(true)} />
          <Button icon="cl_doctor text-xl" outlined onClick={() => setDisplayBasic(true)} />
          <Button icon="cl_info_fill text-xl" outlined onClick={() => setDisplayBasic(true)} />
          <Button icon="cl_check_decagram text-xl" outlined onClick={() => setDisplayBasic(true)} />
          <Button label="Claim History" outlined onClick={() => setDisplayBasic(true)} />
        </div>
      </h2>
      <Panel header="Claim Information" toggleable className="mb-4">
        <CustomForm form={form} onFinish={handleSave} initialValues={initialValues}>
          <div className="pb-4">
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">
              <FormItem name="claimNumber" label="Claim Id(Auto Generated)">
                <InputText type="text" placeholder="Enter here" readOnly />
              </FormItem>

              <FormItem name="receivedDate" label="Date Received" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  maxDate={new Date()}
                  onChange={(event) => handleReceivedDateChange(event)}
                />
              </FormItem>

              <FormItem name="formTypeID" label="Form Type" rules={[{ required: true }]}>
                <Dropdown
                  id="formtype"
                  options={claimTypesOptions}
                  optionValue="value"
                  optionLabel="key"
                  placeholder="Select"
                  showClear
                  onChange={handleFormTypeChange}
                  className="w-full"
                  disabled={claimId ? true : false}
                />
              </FormItem>
              <FormItem name="enteredDate" label="Date Entered" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  maxDate={new Date()}
                  onChange={(event) => handleEnteredDate(event as Date)}
                />
              </FormItem>

              <FormItem name="dosFrom" label="Date Of Service From" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  maxDate={enteredDate ?? null}
                  disabled={!enteredDate}
                  onChange={(event) => handleDosFromDate(event as Date)}
                />
              </FormItem>

              <FormItem name="dosTo" label="Date Of Service To" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={dosFrom ? dosFrom : null}
                  maxDate={moment().toDate()}
                  disabled={!dosFrom}
                />
              </FormItem>
              <FormItem name="billedAmount" label="Billed Amount" rules={[{ required: true }]}>
                <InputNumber placeholder="Enter here" useGrouping={false} min={0} />
              </FormItem>
              <FormItem name="paidAmount" label="Amount Paid">
                <InputNumber placeholder="Enter here" useGrouping={false} />
              </FormItem>
              <FormItem name="otherInsurancePaid" label="Other Insurance Paid">
                <InputNumber placeholder="Enter here" useGrouping={false} min={0} />
              </FormItem>
              <FormItem name="patientAccountNumber" label="Patient Account Number">
                <InputText type="text" placeholder="Enter here" maxLength={32} />
              </FormItem>
              <FormItem name="externalClaimID" label="External Claim Id">
                <InputText type="text" placeholder="Enter here" maxLength={32} />
              </FormItem>
              <FormItem name="dcn" label="DCN">
                <InputText type="text" placeholder="Enter here" maxLength={16} />
              </FormItem>
              <FormItem name="priorAuthNumber" label="Prior Auth Number">
                <InputText type="text" placeholder="Enter here" maxLength={32} />
              </FormItem>
              <FormItem name="claimSourceID" label="Claim Source" rules={[{ required: true }]}>
                <Dropdown
                  id="claimSource"
                  options={claimSourceOptions}
                  optionValue="key"
                  optionLabel="value"
                  placeholder="Select"
                  showClear
                  className="w-full"
                  disabled={true}
                />
              </FormItem>
            </div>
          </div>
          <div className="pb-4">
            <MemberInformation form={form} />
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6"></div>
          </div>
          {formType === ClaimType.Professional && <div className="pb-4">
            <ProviderInformation form={form} />
          </div>}
          {formType === ClaimType.Institutional && <div className="pb-4">
            <FacilityInformation form={form} />
          </div>}
          {formType != ClaimType.Institutional && <div className="pb-4">
            <h5 className="border-bottom-1 pb-3 mb-3 flex items-center gap-2">Referring Provider Information</h5>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">
              <FormItem name="physicianNPI" label="Referring Provider NPI" rules={[{
                required: true
              }]}>
                <Dropdown
                  id="npi"
                  optionLabel="key"
                  options={referringProviderOptions}
                  onChange={handleReferringProviderChange}
                  optionValue="value"
                  placeholder="Select"
                  showClear
                  className="w-full"
                />
              </FormItem>
              <FormItem name="physicianName" label="Referring Provider" rules={[{
                required: true
              }]}>
                <InputText type="text" placeholder="Enter here" disabled />
              </FormItem>
              <FormListItem name="serviceRendered" label="Service Provider NPI" >
                {/* <InputText type="text" placeholder="Enter here" /> */}
                <Dropdown
                  id="npi"
                  optionLabel="key"
                  options={referringProviderOptions}
                  onChange={handleServiceRenderedChange}
                  optionValue="value"
                  placeholder="Select"
                  showClear
                  className="w-full"
                />
              </FormListItem>
              <FormItem name="serviceRenderedName" label="Service Provider Name">
                <InputText type="text" placeholder="Enter here" disabled />
              </FormItem>
              <FormItem name="serviceRenderedSpecialty" label="Provider Specialty">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
            </div>
          </div>}

          {formType === ClaimType.Institutional && <AdmitInformation />}
          <AccidentInformation form={form} />
          <OtherInformation form={form} />
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancel} type="button" />
            <Button label="Save" raised type="submit" disabled={isSubmitting} />
          </div>
        </CustomForm>
      </Panel>
      {claimId && showClaimDetail && <ClaimDetails show={formType === ClaimType.Institutional ? true : false} />}
      <Dialog header="Dynamic Header" visible={displayBasic} modal onHide={() => setDisplayBasic(false)}>
        <ClaimAlertInfo />
      </Dialog>
    </>
  );
};

export default ClaimAddEdit;
