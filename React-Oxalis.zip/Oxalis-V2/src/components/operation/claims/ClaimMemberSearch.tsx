import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useEffect, useRef, useState } from "react";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import Calendar from "../../../controls/Calendar";
import InputText from "../../../controls/InputText";
import PlanService from "../../../services/PlanService";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import { CodeType, CommonCodeFetchingType } from "../../../data/constants/AppEnum";
import { PlanViewModel } from "../../../model/PlanViewModel";
import { KeyValueModel } from "../../../model/KeyValueModel";
import CustomForm from "../../../controls/CustomForm";
import { useForm } from "rc-field-form";
import moment from "moment";
import { LazyTableState } from "../../../model/LazyTableState";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import MemberService from "../../../services/MemberService";
import { MemberLookUpModel } from "../../../model/MemberLookUpModel";
import { MemberLookupSearchModel } from "../../../model/MemberLookupSearchModel";
import { useDispatch } from "react-redux";
import { AddMemberData } from "../../../Redux/features/claimSlice";
import useFormattedDate from "../../../hooks/useFormattedDate";

const ClaimMemberSearch = () => {
  const { getActivePlans } = PlanService();
  const [plans, setPlans] = useState<PlanViewModel[]>([]);
  const [planOptions, setPlanOptions] = useState<KeyValueModel[]>([]);
  const relationShipOptions = useCommonCodeSubCategory(CodeType.MemberRelationship, CommonCodeFetchingType.Default);
  const [gridValues, setGridValues] = useState<MemberLookUpModel[]>([]);
  const [selectedMember, setSelectedMember] = useState<MemberLookUpModel | null>(null);
  const [totalRecords, setTotalRecords] = useState(0);
  const [form] = useForm<MemberLookupSearchModel>();
  const { memberLookup } = MemberService();
  const panel = useRef<Panel>(null);
  const dispatch = useDispatch();

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  useEffect(() => {
    handleSave();
  }, [lazyState])

  useEffect(() => {
    if (plans.length > 0) {
      const activePlans: KeyValueModel[] = plans.map(plan => {
        return { key: plan.healthPlanID, value: plan.planName };
      })
      setPlanOptions(activePlans);
    }
  }, [plans])

  useEffect(() => {
    const activePlans = async () => {
      const plans = await getActivePlans();
      setPlans(plans);
    }
    activePlans();
  }, [])

  const lookup = async (query: string) => {
    const memLookup = await memberLookup(query);
    console.log(memLookup);
    if (memLookup) {
      setGridValues(memLookup.data);
      setTotalRecords(memLookup.totalCount);
    }
  }

  const handleSave = () => {
    console.log(form.getFieldsValue(true));
    panel.current?.collapse(undefined);
    const formValue = form.getFieldsValue(true);
    const keys = Object.keys(formValue);
    let query = "";

    keys.forEach((element: string) => {
      let value = formValue[element];

      if (value && (element === 'dob' || element === 'effectiveDate')) {
        value = moment(value).format("YYYY-MM-DD");
      }

      if (value) {
        query += query ? `&${element}=${value}` : `?${element}=${value}`;
      }
    });

    query += query ? `&skip=${lazyState.first}` : `?skip=${lazyState.first}`;

    query += query ? `&take=${lazyState.rows}` : `?take=${lazyState.rows}`;

    lookup(query);
  }

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const termDateFormatTemplate = (value) => {
    const termDate = value.termDate;
    if (termDate) {
      return moment(termDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const effectiveDateFormatTemplate = (value) => {
    const effectiveDate = value.effectiveDate;
    if (effectiveDate) {
      return moment(effectiveDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const dobTemplate = (value) => {
    const effectiveDate = value.dob;
    if (effectiveDate) {
      return moment(effectiveDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const handleMemberSelection = () => {
    dispatch(AddMemberData(selectedMember))
  }

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedMember(e.value)
    } else {
      setSelectedMember(null)
    }
  }

  return (
    <>
      <Panel header="Advance Search" ref={panel} toggleable collapsed={false} className="search-panel">
        <CustomForm form={form} onFinish={handleSave} >
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="memberCode" label="Member Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="firstName" label="First Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="lastName" label="Last Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="dob" label="Date Of Birth">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="pcpName" label="PCP Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="planID" label="Plan">
              <Dropdown
                id="planID"
                options={planOptions}
                optionLabel="value"
                optionValue="key"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="relationshipID" label="Relationship">
              <Dropdown
                id="relationship"
                options={relationShipOptions}
                optionLabel="value"
                optionValue="key"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="mediCareMediCaidID" label="Medicare/Medicaid ID">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="clear" text />
            <Button label="Apply" outlined />
          </div>
        </CustomForm>
      </Panel>
      <div className="pb-4">

        <DataTable
          paginator
          rowsPerPageOptions={paginatorConstants.pageOptions}
          className="p-datatable-gridlines"
          showGridlines
          rows={lazyState.rows}
          tableStyle={{ minWidth: '50rem' }}
          paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
          currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
          dataKey="memberID"
          emptyMessage={paginatorConstants.emptyMessage}
          selectionMode="single"
          lazy onPage={onPage}
          onSort={onSort}
          sortOrder={lazyState.sortOrder}
          sortField={lazyState.sortField}
          onFilter={onFilter}
          value={gridValues}
          onSelectionChange={(e) => handleSelection(e)}
          totalRecords={totalRecords}
          first={lazyState.first}
        >
          <Column field="memberCode" header="Member&nbsp;Id" sortable />
          <Column field="medicaidID" header="Medicare/Medicaid&nbsp;Id" sortable />
          <Column field="memberName" header="Member&nbsp;Name" sortable />
          <Column field="dob" header="DOB" sortable body={dobTemplate}/>
          <Column field="coverageType" header="Coverage&nbsp;Type" sortable />
          <Column field="state" header="State" sortable />
          <Column field="city" header="City" sortable />
          <Column field="address1" header="Address" sortable />
          <Column field="zip" header="ZIP" sortable />
          <Column field="homePhone" header="Home&nbsp;Phone" sortable />
          <Column field="coverageType" header="Coverage&nbsp;Type" sortable />
          <Column field="planName" header="Plan&nbsp;&&nbsp;LOB" sortable />
          <Column field="pcpName" header="PCP&nbsp;Name" sortable />
          <Column field="relationship" header="Relationship" sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" body={effectiveDateFormatTemplate} sortable />
          <Column field="termDate" header="Term&nbsp;Date" body={termDateFormatTemplate} sortable />
          {/* <Column field="relationship" header="Term&nbsp;Date" filter sortable />
          <Column field="formattedEffectiveDate" header="Term&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
          <Column field="formattedEffectiveDate" header="Term&nbsp;Date" filter sortable />
          <Column field="formattedTermDate" header="Term&nbsp;Date" filter sortable />
          <Column field="providerId" header="Term&nbsp;Date" filter sortable /> */}
        </DataTable>
        <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
          <Button label="Add Selected Member" raised onClick={handleMemberSelection} />
        </div>
      </div>
    </>
  );
};

export default ClaimMemberSearch;
