import React, { useEffect, useState } from 'react'
import FormItem from '../../../controls/FormItem'
import Dropdown from '../../../controls/Dropdown'
import Calendar from '../../../controls/Calendar'
import { SwitchModel } from '../../../model/SwitchModel'
import { InputSwitch, InputSwitchChangeEvent } from 'primereact/inputswitch'
import { KeyValueModel } from '../../../model/KeyValueModel'
import ZipCodeService from '../../../services/ZipCodeService'
import { Field, FormInstance } from 'rc-field-form'
import { ClaimHeaderModel } from '../../../model/ClaimHeaderModel'
import { useSelector } from 'react-redux'
import { RootState } from '../../../Redux/app/store'

interface AccidentInformationProps {
  form: FormInstance<ClaimHeaderModel>;
}

const AccidentInformation = ({ form }: AccidentInformationProps) => {

  const [stateOptions, setStateOptions] = useState<KeyValueModel[]>([]);
  const { getZipCodeState } = ZipCodeService();
  const { claimData } = useSelector((state: RootState) => state.claim)

  const [accidentSwitch, setAccidentSwitch] = useState<SwitchModel[]>([
    { label: "Employment", id: "employment", name: "isEmployment", value: false, show: true },
    { label: "Auto", id: "auto", name: "isAuto", value: false, show: true },
    { label: "Other Accident", id: "otherAccident", name: "isOtherAccident", value: false, show: true },
  ])

  const handleAccidentSwitch = (event: InputSwitchChangeEvent, index: number) => {
    setAccidentSwitch((prevState) => {
      prevState[index].value = event.value;
      return [...prevState];
    })
  }

  useEffect(() => {
    if (claimData) {
      const accidentData = accidentSwitch.map((eachData: SwitchModel) => {
        const value = claimData[eachData.name] ?? false;
        return { ...eachData, value };
      })
      setAccidentSwitch(accidentData);
    }
  }, [claimData])

  useEffect(() => {
    const stateRequest = getZipCodeState();

    Promise.all([stateRequest]).then(result => {
      setStateOptions(result[0]);
    })
  }, [])

  return (
    <div className="pb-4">
      <h5 className="border-bottom-1 pb-3 mb-3 flex items-center gap-2">Accident Information</h5>
      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-4">
        <FormItem name="accidentStateOrProvince" label="State">
          <Dropdown
            id="state"
            optionLabel="value"
            optionValue='key'
            placeholder="Select"
            options={stateOptions}
            showClear
            className="w-full"
          />
        </FormItem>

        <FormItem name="illnessDate" label="Date Of Illness">
          <Calendar
            placeholder="Enter Date"
            selectionMode="single"
            icon="cl_calendar_today_line"
            iconPos="right"
            dateFormat="mm/dd/yy"
            maxDate={new Date()}
          />
        </FormItem>
        <FormItem name="otherDate" label="Other Date">
          <Calendar
            placeholder="Enter Date"
            selectionMode="single"
            icon="cl_calendar_today_line"
            iconPos="right"
            dateFormat="mm/dd/yy"
            maxDate={new Date()}
          />
        </FormItem>
      </div>
      <div className="flex flex-wrap gap-4">
        {accidentSwitch.map((accidentSwitch, index: number) => {
          return (<div className="flex align-items-center gap-2" key={index}>
            <label htmlFor={accidentSwitch.id}>{accidentSwitch.label}</label>
            <Field name={accidentSwitch.name} >
              <InputSwitch id={accidentSwitch.id} checked={accidentSwitch.value} onChange={(event) => handleAccidentSwitch(event, index)} />
            </Field>
            {/* <label htmlFor={accidentSwitch.id}>{accidentSwitch.label}</label>
            <InputSwitch id={accidentSwitch.id} name={accidentSwitch.name} checked={accidentSwitch.value} onChange={(event) => handleAccidentSwitch(event, index)} /> */}
          </div>)
        })}
      </div>
    </div>
  )
}

export default AccidentInformation