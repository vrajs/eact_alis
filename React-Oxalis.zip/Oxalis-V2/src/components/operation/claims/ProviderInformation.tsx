import { Sidebar } from "primereact/sidebar";
import React, { useEffect, useState } from "react";
import ClaimProviderSearch from "./ClaimProviderSearch";
import Button from "../../../controls/Button";
import { MemberProviderDataModel } from "../../../model/MemberProviderDataModel";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { FormInstance } from "rc-field-form";
import { ClaimHeaderModel } from "../../../model/ClaimHeaderModel";

interface ProviderInformationProps {
  form: FormInstance<ClaimHeaderModel>;
}

const ProviderInformation = ({form}: ProviderInformationProps) => {
  const [visibleBottom, setVisibleBottom] = useState(false);
  const {providerInfo, claimHeaderID, claimData} = useSelector((state: RootState) => state.claim);
  const [showDetails, setShowDetails] = useState<boolean>(false);
  const [providerCode, setProviderCode] = useState<string>("");
  const [providerData, setProviderData] = useState<MemberProviderDataModel[]>([
    { label: "Provider Name", value: null, name: "providerName" },
    { label: "NPI ", value: null, name: "providerNPI" },
    { label: "TIN ", value: null, name: "tin" },
    { label: "Vender ", value: null, name: "vendor" },
    { label: "Address ", value: null, name: "address1" },
  ]);

  useEffect(() => {
    if (claimHeaderID > 0 && claimData) {
      console.log("claimData claimData claimData", claimData)
      const bindData = providerData.map((memberData: MemberProviderDataModel) => {
        const value = claimData[memberData.name] ?? "N/A";
        return {...memberData, value};
      })
      setProviderData(bindData);
      setShowDetails(true);
      setProviderCode(claimData.providerCode);
    }
  }, [claimHeaderID])

  useEffect(() => {
    if (providerInfo) {
      console.log("providerInfo providerInfo providerInfo ",  providerInfo)
      const resultData = providerData.map((eachData) => {
        let value = providerInfo[eachData.name];
        value ? value : value = "N/A";
        return {...eachData, value};
      })
      setProviderData(resultData);
      setVisibleBottom(false)
      setProviderCode(providerInfo.providerCode);

      form.setFieldsValue({
        providerCode: providerInfo.providerCode,
        providerName: providerInfo.providerName,
        providerNPI: providerInfo.providerNPI,
        vendorName: providerInfo.vendor,
        vendorID: providerInfo.vendorID,
        providerID: providerInfo.providerID,
        providerStatus: !claimHeaderID ?  "" : "",
        providerStatusID: !claimHeaderID ? null : 0,
      })
      setShowDetails(true);
    }
  }, [providerInfo])

  return (
    <>
      <h5 className="border-bottom-1 pb-3 mb-3 flex justify-between">
        Billing Provider Information { providerCode && `- ${providerCode}`}
        <Button type="button" icon="cl_search text-xl" outlined className="surface-border" onClick={() => setVisibleBottom(true)}></Button>
      </h5>
      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">
        {showDetails && providerData.map((eachProvider, index) => (
          <div key={index}>
            <div className="flex flex-nowrap justify-content-between align-items-center border-1 surface-border border-round px-3 py-2  cursor-pointer">
              <div className="flex align-items-center">
                {/* <div className="relative md:mr-3">
                    <i className="cl_dot_big text-xxl"></i>
                  </div> */}
                <div className="flex-col">
                  <div className="block text-600 text-overflow-ellipsis overflow-hidden white-space-nowrap text-sm">{eachProvider.label}</div>
                  <div className="text-900 font-semibold block">{eachProvider.value}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-4/6 text-xl"
        header="Provider Search"
      >
        <ClaimProviderSearch />
      </Sidebar>
    </>
  );
};

export default ProviderInformation;
