import React, { useEffect, useState } from 'react'
import FormItem from '../../../controls/FormItem'
import Dropdown from '../../../controls/Dropdown'
import Calendar from '../../../controls/Calendar'
import useCommonCodeSubCategory from '../../../hooks/useCommonCodeSubCategory'
import { CodeType, CommonCodeFetchingType } from '../../../data/constants/AppEnum'
import DRGCodeService from '../../../services/DRGCodeService'
import { KeyValueModel } from '../../../model/KeyValueModel'
import { DRGCodeModel } from '../../../model/DRGCodeModel'

const AdmitInformation = () => {
  const { getAllCodes } = DRGCodeService();
  const [drgCodes, setDrgCodes] = useState<DRGCodeModel[]>([]);
  const [drgOptions, setDrgOptions] = useState<KeyValueModel[]>([]);
  const admitTypeOptions = useCommonCodeSubCategory(CodeType.AdmitType, CommonCodeFetchingType.Default);
  const admitSourceOptions = useCommonCodeSubCategory(CodeType.AdmitSource, CommonCodeFetchingType.Default);
  const dischargeStatusOptions = useCommonCodeSubCategory(CodeType.DischargeType, CommonCodeFetchingType.Default);
  const hoursOptions = [{ key: 1, value: "01" }, { key: 2, value: "02" }, { key: 3, value: "03" }, { key: 4, value: "04" }, { key: 5, value: "05" }, { key: 6, value: "06" }, { key: 7, value: "07" }, { key: 8, value: "08" }, { key: 9, value: "09" }, { key: 10, value: "10" }, { key: 11, value: "11" }, { key: 12, value: "12" }, { key: 13, value: "13" }, { key: 14, value: "14" }, { key: 15, value: "15" }, { key: 16, value: "16" }, { key: 17, value: "17" }, { key: 18, value: "18" }, { key: 19, value: "19" }, { key: 20, value: "20" }, { key: 21, value: "21" }, { key: 22, value: "22" }, { key: 23, value: "23" }, { key: 24, value: "24" }];

  useEffect(() => {
    const getDrgCodes = async () => {
      const drgCodes: DRGCodeModel[] = await getAllCodes();
      setDrgCodes(drgCodes);
    }
    getDrgCodes();
  }, [])

  useEffect(() => {
    if (drgCodes.length > 0) {
      const drgMapped: KeyValueModel[] = drgCodes.map((drg) => {
        return { key: drg.code, value: drg.code };
      })
      setDrgOptions(drgMapped);
    }
  }, [drgCodes])

  return (
    <div className="pb-4">
      <h5 className="border-bottom-1 pb-3 mb-3 flex items-center gap-2">Admit/Discharge Information</h5>
      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">
        <FormItem name="admitDate" label="Admit Date">
          <Calendar
            placeholder="Enter Date"
            selectionMode="single"
            icon="cl_calendar_today_line"
            iconPos="right"
            dateFormat="mm/dd/yy"
            maxDate={new Date()}
          />
        </FormItem>
        {/* <FormItem name="admitHour" label="Admit Hour">
          <Calendar id={`admit-hour`} placeholder="Admit" icon="cl_clock" iconPos="right" timeOnly />
        </FormItem> */}
        <FormItem name="admitHour" label="Admit Hour">
          <Dropdown
            id="admitHour"
            options={hoursOptions}
            optionLabel="value"
            optionValue="key"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="admitTypeID" label="Admit Type">
          <Dropdown
            id="admitType"
            options={admitTypeOptions}
            optionLabel="value"
            optionValue="key"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="admitSourceID" label="Admit Source">
          <Dropdown
            id="admitSource"
            options={admitSourceOptions}
            optionLabel="value"
            optionValue="key"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        {/* <FormItem name="dischargeHour" label="Discharge Hour">
          <Calendar id={`admit-hour`} placeholder="Discharge" icon="cl_clock" iconPos="right" timeOnly />
        </FormItem> */}
        <FormItem name="dischargeHour" label="Discharge Hour">
          <Dropdown
            id="dischargeHour"
            options={hoursOptions}
            optionLabel="value"
            optionValue="key"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="dischargeStatusID" label="Discharge Status">
          <Dropdown
            id="dischargeStatus"
            options={dischargeStatusOptions}
            optionLabel="value"
            optionValue="key"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="billedDRGCode" label="Billed DRG">
          <Dropdown
            id="billedDRG"
            options={drgOptions}
            optionLabel="key"
            optionValue="value"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="revisedDRGCode" label="Revised DRG">
          <Dropdown
            id="revisedDRG"
            options={drgOptions}
            optionLabel="key"
            optionValue="value"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
      </div>
    </div>
  )
}

export default AdmitInformation