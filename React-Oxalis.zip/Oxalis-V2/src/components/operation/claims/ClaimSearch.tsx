import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useEffect, useRef, useState } from "react";
import Button from "../../../controls/Button";
import Dropdown from "../../../controls/Dropdown";
import InputText from "../../../controls/InputText";
import { useNavigate } from "react-router-dom";
import { SplitButton } from "primereact/splitbutton";
import Calendar from "../../../controls/Calendar";
import { InputSwitch } from "primereact/inputswitch";
import ClaimService from "../../../services/ClaimService";
import { ClaimGridModel } from "../../../model/ClaimGridModel";
import { LazyTableState } from "../../../model/LazyTableState";
import moment from "moment";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import useFormattedDate from "../../../hooks/useFormattedDate";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { ClearKey } from "../../../Redux/features/keyboardShortcutSlice";
import * as XLSX from "xlsx";
import { useToaster } from "../../../layout/context/toastContext";

const ClaimSearch = () => {
  const navigate = useNavigate();
  const [checked, setChecked] = useState(false);
  const [selectedClaimNumber, setselectedClaimNumber] = useState(null);
  const [selectedMemberName, setselectedMemberName] = useState(null);
  const [selectedClaimType, setselectedClaimType] = useState(null);
  const { getClaimsGrid, exportClaims } = ClaimService();
  const [gridValues, setGridValues] = useState<ClaimGridModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [selectedClaim, setSelectedClaim] = useState<ClaimGridModel | null>(null);
  const ref = useRef<Panel>(null);
  const dispatch = useDispatch();
  const { isEdit, isAdd, isExport, isSearch } = useSelector((state: RootState) => state.keyboardShortCut);
  const { showToast } = useToaster();
  const items = [
    {
      label: "HCFA",
    },
    {
      label: "UB04",
    },
  ];
  const handleEdit = () => {
    if (selectedClaim) {
      navigate(`/claims/claims-add-edit/${selectedClaim.claimNumber}`)
    }
  }

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    ref.current?.collapse(undefined)
    const claimsViewList = await getClaimsGrid(query);
    console.log("claimsViewList", getClaimsGrid)
    if (claimsViewList) {
      setGridValues(claimsViewList.data);
      setTotalRecords(claimsViewList.totalCount);
    }
  };

  const handleExport = async () => {
    const claims: ClaimGridModel[] = await exportClaims();

    const claimsData = claims.map((claim: ClaimGridModel) => {
      const { claimNumber, formType, claimStatusCode, receivedDate, memberCode, memberName, providerName, vendorName, dosFrom, dosTo, paidAmount } = claim;
      return { "Claim Number": claimNumber, "Form Type": formType, "Claim Status": claimStatusCode, "Received Date": receivedDate, "Member Id": memberCode, "Member Name": memberName, "Provider Name": providerName, "Vendor Name": vendorName, "DOS From": dosFrom ? moment(dosFrom).toDate() : "", "DOS To": dosTo ? moment(dosTo).toDate() : "", "Paid Amount": paidAmount }
    })
    // console.log(groupData);
    const ws = XLSX.utils.json_to_sheet(claimsData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Group List");
    XLSX.writeFile(wb, "Claims.xlsx");
    showToast({ severity: 'success', summary: 'Success', detail: "File downloaded successfully" });
  }

  useEffect(() => {
    if (isSearch) {
      ref.current.expand(undefined);
    }
    dispatch(ClearKey());
  }, [isSearch])

  useEffect(() => {
    if (isExport) {
      handleExport();
    }
    dispatch(ClearKey());
  }, [isExport])

  useEffect(() => {
    if (isEdit && selectedClaim) {
      handleEdit();
    }
    dispatch(ClearKey());
  }, [isEdit])

  useEffect(() => {
    if (isAdd) {
      handleNavigate();
    }
    dispatch(ClearKey());
  }, [isAdd])

  useEffect(() => {
    loadLazyData();
  }, [lazyState]);

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedClaim(e.value)
    } else {
      setSelectedClaim(null);
    }
  }

  const receivedDateFormatTemplate = (value) => {
    return useFormattedDate(value, "receivedDate");
  }

  const dateFromFormatTemplate = (value) => {
    return useFormattedDate(value, "dosFrom")
  }

  const handleNavigate = () => {
    navigate("/claims/claims-add-edit");
  };
  const handleView = () => {
    navigate("/claims/claims-view");
  };

  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Advance Search</div>
        <div className="flex align-items-center gap-2">
          <label htmlFor="input-switch">Include Deleted</label>
          <InputSwitch id="input-switch" checked={checked} onChange={(e) => setChecked(e.value)} />
          <Dropdown optionLabel="name" placeholder="Saved Search (0)" filter className="w-full" />
          <SplitButton label="Add" model={items} onClick={handleNavigate}></SplitButton>
          {selectedClaim && <Button outlined label="Edit" onClick={handleEdit} />}
          <Button label="Export" outlined onClick={handleExport} tooltip="Alt + X" />
          {options.togglerElement}
        </div>
      </div>
    );
  };
  return (
    <>
      <h2 className="pb-4">Claim Search</h2>
      <Panel headerTemplate={headerTemplate} toggleable className="m-0 search-panel" ref={ref} collapsed>
        <div className="!grid xl:grid-cols-3 lg:grid-cols-2 sm:grid-cols-1 !gap-6 pb-3">
          <div className="!grid grid-cols-2 !gap-4">
            <h5 className="border-bottom-1 pb-3 col-span-2">Claim Details</h5>
            <div>
              <label htmlFor="dropdown">Claim Number</label>
              <Dropdown
                id="dropdown"
                value={selectedClaimNumber}
                onChange={(e) => setselectedClaimNumber(e.value)}
                options={[]}
                optionLabel="name"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </div>
            <div>
              <label htmlFor="GroupId">Claim Number</label>
              <InputText type="text" placeholder="Enter here" />
            </div>
            <div>
              <label htmlFor="claimtype">Claim Type</label>
              <Dropdown
                id="claimtype"
                value={selectedClaimType}
                onChange={(e) => setselectedClaimType(e.value)}
                options={[]}
                optionLabel="name"
                multiple
                showHeader
                showClear
                placeholder="Select"
                className="w-full"
              />
            </div>
            <div>
              <label htmlFor="GroupId">Claim Status</label>
              <InputText type="text" placeholder="Enter here" />
            </div>
            <div>
              <label htmlFor="date">Date Of Service From</label>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}

              />
            </div>
            <div>
              <label htmlFor="date">Date Of Service To</label>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}

              />
            </div>
            <div>
              <label htmlFor="date">Received Date From</label>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}

              />
            </div>
            <div>
              <label htmlFor="date">Received Date To</label>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}

              />
            </div>
          </div>
          <div className="!grid grid-cols-2 !gap-4">
            <h5 className="border-bottom-1 pb-3 col-span-2">Member & Provider Info</h5>
            <div>
              <label htmlFor="membername">Member Name</label>
              <Dropdown
                id="membername"
                value={selectedMemberName}
                onChange={(e) => setselectedMemberName(e.value)}
                options={[]}
                optionLabel="name"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </div>
            <div>
              <label htmlFor="membername">Member Name</label>
              <InputText type="text" placeholder="Enter here" />
            </div>
            <div>
              <label htmlFor="memberId">Member ID</label>
              <Dropdown
                id="memberId"
                value={selectedMemberName}
                onChange={(e) => setselectedMemberName(e.value)}
                options={[]}
                optionLabel="name"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </div>
            <div>
              <label htmlFor="memberId">Member Id</label>
              <InputText type="text" placeholder="Enter here" />
            </div>
            <div>
              <label htmlFor="providername">Provider Name</label>
              <Dropdown
                id="providername"
                value={selectedMemberName}
                onChange={(e) => setselectedMemberName(e.value)}
                options={[]}
                optionLabel="name"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </div>
            <div>
              <label htmlFor="providername">Provider Name</label>
              <InputText type="text" placeholder="Enter here" />
            </div>
            <div>
              <label htmlFor="providerId">Provider Id</label>
              <Dropdown
                id="providerId"
                value={selectedMemberName}
                onChange={(e) => setselectedMemberName(e.value)}
                options={[]}
                optionLabel="name"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </div>
            <div>
              <label htmlFor="providerId">Provider Id</label>
              <InputText type="text" placeholder="Enter here" />
            </div>
          </div>
          <div className="!grid grid-cols-2 !gap-4 content-start lg:col-span-2 xl:col-span-1">
            <h5 className="border-bottom-1 pb-3 col-span-2">Payment Info</h5>
            <div>
              <label htmlFor="authnumber">Authorization Number</label>
              <Dropdown
                id="authnumber"
                value={selectedMemberName}
                onChange={(e) => setselectedMemberName(e.value)}
                options={[]}
                optionLabel="name"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </div>
            <div>
              <label htmlFor="authnumber">Authorization Number</label>
              <InputText type="text" placeholder="Enter here" />
            </div>
            <div>
              <label htmlFor="checknumber">Check Number</label>
              <Dropdown
                id="checknumber"
                value={selectedMemberName}
                onChange={(e) => setselectedMemberName(e.value)}
                options={[]}
                optionLabel="name"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </div>
            <div>
              <label htmlFor="checknumber">Check Number</label>
              <InputText type="text" placeholder="Enter here" />
            </div>
            <div>
              <label htmlFor="date">Paid Date From</label>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}

              />
            </div>
            <div>
              <label htmlFor="date">Paid Date To</label>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}

              />
            </div>
          </div>
        </div>
        <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
          <Button label="clear" text />
          <Button label="Apply" outlined />
          <Button label="Apply & Save" raised />
        </div>
      </Panel>
      <div className="pb-4">
        <DataTable
          paginator
          rowsPerPageOptions={paginatorConstants.pageOptions}
          className="p-datatable-gridlines"
          showGridlines
          rows={lazyState.rows}
          tableStyle={{ minWidth: '50rem' }}
          paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
          currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
          dataKey="claimHeaderID"
          emptyMessage="No Group found."
          selectionMode="single"
          lazy onPage={onPage}
          onSort={onSort}
          sortField={lazyState.sortField}
          sortOrder={lazyState.sortOrder}
          onFilter={onFilter}
          value={gridValues}
          onSelectionChange={(e) => handleSelection(e)}
          totalRecords={totalRecords}
          first={lazyState.first}
        >
          <Column
            field="claimNumber"
            header="Claim&nbsp;Id"
            body={(rowData) => (
              <a onClick={handleView} className="underline">
                {rowData.claimNumber}
              </a>
            )}
          />
          <Column field="claimStatusCode" header="Status" sortable />
          <Column field="formType" header="Claim&nbsp;Type" sortable />
          <Column field="receivedDate" header="Received&nbsp;Date" sortable body={receivedDateFormatTemplate} />
          <Column field="memberCode" header="Member&nbsp;Id" sortable />
          <Column field="memberName" header="Member&nbsp;Name" sortable />
          <Column field="providerName" header="Provider&nbsp;Name" sortable />
          <Column field="vendorName" header="Vendor&nbsp;Name" sortable />
          <Column field="dosFrom" header="DOS" sortable body={dateFromFormatTemplate} />
          <Column field="paidAmount" header="Paid" sortable />
          <Column field="datePaid" header="Date&nbsp;Paid" sortable />
          <Column field="checkNumber" header="Check&nbsp;Number" sortable />
        </DataTable>
      </div>
    </>
  );
};

export default ClaimSearch;
