import { Sidebar } from "primereact/sidebar";
import React, { useEffect, useState } from "react";
import ClaimProviderSearch from "./ClaimProviderSearch";
import Button from "../../../controls/Button";
import { MemberProviderDataModel } from "../../../model/MemberProviderDataModel";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { FormInstance } from "rc-field-form";
import { ClaimHeaderModel } from "../../../model/ClaimHeaderModel";
import FacilityLookup from "./FacilityLookup";
import { useToaster } from "../../../layout/context/toastContext";

interface FacilityInformationProps {
  form: FormInstance<ClaimHeaderModel>;
}

const FacilityInformation = ({ form }: FacilityInformationProps) => {
  const [visibleBottom, setVisibleBottom] = useState(false);
  const { claimHeaderID, claimData, facility } = useSelector((state: RootState) => state.claim);
  const [showDetails, setShowDetails] = useState<boolean>(false);
  const [providerCode, setProviderCode] = useState<string>("");
  const { showToast } = useToaster();
  const [facilityData, setFacilityData] = useState<MemberProviderDataModel[]>([
    { label: "Provider Name", value: null, name: "facilityName" },
    { label: "NPI ", value: null, name: "facilityNPI" },
    { label: "TIN ", value: null, name: "tin" },
    { label: "Vendor ", value: null, name: "vendorName" },
  ]);

  const facilitySearch = () => {
    const dosFrom = form.getFieldValue("dosFrom");
    const dosTo = form.getFieldValue("dosTo");

    if (!dosTo || !dosFrom) {
      return showToast({ severity: 'info', summary: 'Info', detail: 'Please select DOS From and DOS To date' })
    }
    setVisibleBottom(true);
  }

  useEffect(() => {
    if (claimHeaderID > 0 && claimData) {
      console.log("claimData claimData claimData", claimData)
      const bindData = facilityData.map((memberData: MemberProviderDataModel) => {
        const value = claimData[memberData.name] ?? "N/A";
        return { ...memberData, value };
      })
      setFacilityData(bindData);
      setShowDetails(true);
      setProviderCode(claimData.providerCode);
    }
  }, [claimHeaderID])

  useEffect(() => {
    if (facility) {
      console.log("facility providerInfo providerInfo ", facility)
      const resultData = facilityData.map((eachData) => {
        let value = facility[eachData.name];
        value ? value : value = "N/A";
        return { ...eachData, value };
      })
      setFacilityData(resultData);
      setVisibleBottom(false)
      setProviderCode(facility.facilityCode);

      form.setFieldsValue({
        providerCode: facility.facilityCode,
        providerName: facility.facilityName,
        providerNPI: facility.facilityNPI,
        vendorName: facility.vendorName,
        vendorID: facility.vendorID,
        providerID: facility.facilityID,
        providerStatus: !claimHeaderID ? "" : "",
        providerStatusID: !claimHeaderID ? null : 0,
      });
      setShowDetails(true);
      setVisibleBottom(false);
    }
  }, [facility])

  return (
    <>
      <h5 className="border-bottom-1 pb-3 mb-3 flex justify-between items-center">
        Facility Information {providerCode && `- ${providerCode}`}
        <Button type="button" icon="cl_search text-xl" outlined className="surface-border" onClick={facilitySearch}></Button>
      </h5>
      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">
        {showDetails && facilityData.map((eachFacility, index) => (
          <div key={index}>
            <div className="flex flex-nowrap justify-content-between align-items-center border-1 surface-border border-round px-3 py-2  cursor-pointer">
              <div className="flex align-items-center">
                {/* <div className="relative md:mr-3">
                    <i className="cl_dot_big text-xxl"></i>
                  </div> */}
                <div className="flex-col">
                  <div className="block text-600 text-overflow-ellipsis overflow-hidden white-space-nowrap text-sm">{eachFacility.label}</div>
                  <div className="text-900 font-semibold block">{eachFacility.value}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-4/6 text-xl"
        header="Facility Search"
      >
        <FacilityLookup form={form} />
      </Sidebar>
    </>
  );
};

export default FacilityInformation;
