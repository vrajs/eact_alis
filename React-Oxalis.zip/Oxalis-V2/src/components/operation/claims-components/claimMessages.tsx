import EOPList from "./EOPList";
import EOBList from "./EOBList";
import EOBUser from "./EOBUser";

const ClaimMessages = () => {
  return (
    <>
      <EOPList />
      <EOBList />
      <EOBUser />
    </>
  );
};

export default ClaimMessages;
