import { Column } from 'primereact/column';
import { DataTable } from 'primereact/datatable';
import React, { useEffect, useState } from 'react'
import { paginatorConstants } from '../../../data/constants/PaginatorConstants';
import { LazyTableState } from '../../../model/LazyTableState';
import { RootState } from '../../../Redux/app/store';
import { useSelector } from 'react-redux';
import ClaimEobService from '../../../services/ClaimEobService';
import { EOBEOPType } from '../../../data/constants/AppEnum';
import { ClaimEOBEOPViewModel } from '../../../model/ClaimEOBEOPViewModel';

const EOBList = () => {
  const { getGridData } = ClaimEobService();
  const { claimHeaderID } = useSelector((state: RootState) => state.claim);
  const [gridValues, setGridValues] = useState<ClaimEOBEOPViewModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const loadLazyData = async () => {
    const claimEobResponse = await getGridData(claimHeaderID, EOBEOPType.EOB, lazyState.first, lazyState.rows);
    console.log("claimEobResponse", claimEobResponse)
    if (claimEobResponse) {
      setGridValues(claimEobResponse.data);
      setTotalRecords(claimEobResponse.totalCount);
    }
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState]);

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };


  return (
    <>
      <DataTable
        paginator
        rowsPerPageOptions={paginatorConstants.pageOptions}
        className="p-datatable-gridlines"
        showGridlines
        rows={lazyState.rows}
        tableStyle={{ minWidth: '50rem' }}
        currentPageReportTemplate="{first} to {last} of {totalRecords}"
        dataKey="claimServiceID"
        responsiveLayout="scroll"
        emptyMessage="No Group found."
        selectionMode="single"
        lazy onPage={onPage}
        onSort={onSort}
        sortField={lazyState.sortField}
        onFilter={onFilter}
        value={gridValues}
        totalRecords={totalRecords}
        first={lazyState.first}
      >
        <Column field="lineNumber" header="Line&nbsp;Number" filter sortable />
        <Column field="code" header="Code" filter sortable />
        <Column field="description" header="Description" filter sortable />
      </DataTable>
    </>
  );

}

export default EOBList