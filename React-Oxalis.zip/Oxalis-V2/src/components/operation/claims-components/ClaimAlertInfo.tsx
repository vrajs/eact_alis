import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";

const ClaimAlertInfo = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  return (
    <>
      <DataTable
        paginator
        className="p-datatable-gridlines"
        showGridlines
        rows={10}
        dataKey="claimId"
        emptyMessage="No records found."
        selection={selectedCustomer}
        onSelectionChange={(e) => setSelectedCustomer(e.value)}
        selectionMode="single"
      >
        <Column field="spanValue" header="Span&nbsp;Value" sortable />
        <Column field="planID" header="Plan&nbsp;ID" sortable />
        <Column field="alertName" header="Alert&nbsp;Name" sortable />
        <Column field="effectiveDate" header="Effective&nbsp;Date" sortable />
        <Column field="termDate" header="Term&nbsp;Date" sortable />
        <Column field="pcp" header="PCP" sortable />
      </DataTable>
    </>
  );
};

export default ClaimAlertInfo;
