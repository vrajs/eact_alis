import React from 'react'

const DiagCodes = () => {
  return (
    <div>DiagCodes</div>
  )
}

export default DiagCodes