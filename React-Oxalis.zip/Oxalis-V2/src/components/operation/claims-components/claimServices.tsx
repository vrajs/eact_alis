import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import CustomForm from "../../../controls/CustomForm";
import InputNumber from "../../../controls/InputNumber";
import Calendar from "../../../controls/Calendar";
import { Field, useForm } from "rc-field-form";
import { ClaimServiceViewModel } from "../../../services/ClaimServiceViewModel";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { ClaimType, ClinicalCodeType, CodeType, CommonCodeFetchingType } from "../../../data/constants/AppEnum";
import Checkbox from "../../../controls/CheckBox";
import PosCodeService from "../../../services/PosCodeService";
import CPTCodeService from "../../../services/CPTCodeService";
import NDCService from "../../../services/NDCservice";
import ClaimDiagnosisService from "../../../services/ClaimDiagnosisService";
import BillTypeCodeService from "../../../services/BillTypeCodeService";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import CommonCodeService from "../../../services/CommonCodeService";
import { PosCodeModel } from "../../../model/PosCodeModel";
import { CPTCodeModel } from "../../../model/CPTCodeModel";
import { NDCCodeModel } from "../../../model/NDCCodeModel";
import { ClaimDiagnosisViewModel } from "../../../model/ClaimDiagnosisViewModel";
import { BillTypeCodeModel } from "../../../model/BillTypeCodeModel";
import { CommonCodeModel } from "../../../model/CommonCodeModel";
import DRGCodeService from "../../../services/DRGCodeService";
import { DRGCodeModel } from "../../../model/DRGCodeModel";
import { ProviderService } from "../../../services/ProviderService";
import { ProviderViewModel } from "../../../model/ProviderViewModel";
import { KeyValueModel } from "../../../model/KeyValueModel";
import FormListItem from "../../../controls/FormListItem";
import moment from "moment";
import ClinicalCodeService from "../../../services/ClinicalCodeService";
import ClaimServiceServices from "../../../services/ClaimServiceServices";
import ClaimAdjudicationService from "../../../services/ClaimAdjudicationService";
import { LazyTableState } from "../../../model/LazyTableState";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import useFormattedDate from "../../../hooks/useFormattedDate";
import { MultipleValueRequestModel } from "../../../model/MultipleValueRequestModel";
import ClaimEditService from "../../../services/ClaimEditService";
import useErrorHandler from "../../../hooks/useErrorHandler";
import useToast from "../../../hooks/useToast";
import { useToaster } from "../../../layout/context/toastContext";

const ClaimServices = () => {
  const [showTable, setShowTable] = useState<boolean>(true);
  const [form] = useForm<ClaimServiceViewModel>();
  const { formTypeID, claimHeaderID, claimData } = useSelector((state: RootState) => state.claim);
  const epsdtOptions = useCommonCodeSubCategory(CodeType.EPSDT, CommonCodeFetchingType.ByCode)
  const [isEmg, setIsEmg] = useState<boolean>(false);
  const { getPosCodes } = PosCodeService();
  const { updateClaimService, createClaimService, claimServiceGrid, getById } = ClaimServiceServices();
  const { editsProcessing } = ClaimEditService();
  const { getCPTCodes } = CPTCodeService();
  const { getNDCCodes } = NDCService();
  const { getByClaimHeader, getAdmitList } = ClaimDiagnosisService();
  const { getBillTypeCodes } = BillTypeCodeService();
  const { getClaimsType } = CommonCodeService();
  const { getAllCodes } = DRGCodeService();
  const { getReferringProviders } = ProviderService();
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const { adjudicateClaim, serviceClaimSave } = ClaimAdjudicationService();
  const { showToast } = useToaster();
  const { effectiveClinicalCode } = ClinicalCodeService();
  const reqPaMulCodeType: MultipleValueRequestModel = {
    codeTypeIds: [CodeType.ClaimPend, CodeType.ClaimDeny],
    fetchingTypeId: CodeType.ClaimPend,
  };
  const [posCodes, setPosCodes] = useState<PosCodeModel[]>([]);
  const [cptCodes, setCptCodes] = useState<CPTCodeModel[]>([]);
  const [cptCodeOptions, setCptCodeOptions] = useState<KeyValueModel[]>([]);
  const [ndcCodes, setNdcCodes] = useState<NDCCodeModel[]>([]);
  const [ndcCodeOptions, setNdcCodeOptions] = useState<KeyValueModel[]>([]);
  const [diagnosis, setDiagnosis] = useState<ClaimDiagnosisViewModel[]>([]);
  const [diagnosisOptions, setDiagnosisOptions] = useState<KeyValueModel[]>([]);
  const [billTypes, setBillTypes] = useState<BillTypeCodeModel[]>([]);
  const [billTypeOptions, setBillTypeOptions] = useState<KeyValueModel[]>([]);
  const [pendDeny, setPendDeny] = useState<CommonCodeModel[]>([]);
  const [pendDenyOptions, setPendDenyOptions] = useState<KeyValueModel[]>([]);
  const [admits, setAdmits] = useState<ClaimDiagnosisViewModel[]>([]);
  const [admitOptions, setAdmitOptions] = useState<KeyValueModel[]>([]);
  const [drgCodes, setDrgCodes] = useState<DRGCodeModel[]>([]);
  const [drgCodeOptions, setDrgCodeOptions] = useState<KeyValueModel[]>([]);
  const [renderingProviders, setRenderingProviders] = useState<ProviderViewModel[]>([]);
  const [renderingProviderOptions, setRenderingProviderOptions] = useState<KeyValueModel[]>([]);
  const [benefitOptions, setBenefitOptions] = useState<KeyValueModel[]>([]);
  const [dosFrom, setDosFrom] = useState<Date | string>("");
  const [dosTo, setDosTo] = useState<Date | string>("");
  const [gridValues, setGridValues] = useState<ClaimServiceViewModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [selectedService, setSelectedService] = useState<ClaimServiceViewModel | null>(null);


  useEffect(() => {
    if (claimHeaderID > 0) {
      const posCodeReq = getPosCodes();
      const cptCodeReq = getCPTCodes();
      const ndcReq = getNDCCodes();
      const diagnosisReq = getByClaimHeader(claimHeaderID);
      const billTypeReq = getBillTypeCodes();
      const pendDenyReq = getClaimsType(reqPaMulCodeType);
      const admitReq = getAdmitList(claimHeaderID);
      const drgCodesReq = getAllCodes();
      const renderingProviderReq = getReferringProviders();
      Promise.all([posCodeReq, cptCodeReq, ndcReq, diagnosisReq, billTypeReq, pendDenyReq, admitReq, drgCodesReq, renderingProviderReq]).then(result => {
        setPosCodes(result[0]);
        setCptCodes(result[1]);
        setNdcCodes(result[2]);
        setDiagnosis(result[3]);
        setBillTypes(result[4]);
        setPendDeny(result[5]);
        setAdmits(result[6]);
        setDrgCodes(result[7]);
        setRenderingProviders(result[8]);
      })
    }
  }, [claimHeaderID]);

  useEffect(() => {
    if (claimData && !showTable) {

      const { dosFrom, dosTo, serviceRendered, serviceRenderedName } = claimData;
      setDosFrom(moment(dosFrom).format("YYYY-MM-DD"));
      setDosTo(moment(dosTo).format("YYYY-MM-DD"));
      console.log("form dos", { dosFrom, dosTo, serviceRendered, serviceRenderedName })
      console.log(renderingProviderOptions[0])
      const renderingProvider = renderingProviders.find(a => a.npi === serviceRendered);
      if (renderingProvider) {
        const renderingProviderName = renderingProvider.fullName;
        form.setFieldValue("renderingProviderName", renderingProviderName)
        form.setFieldValue("procedureCode", "")
      }

      form.setFieldsValue({ dosFrom: moment(dosFrom).toDate(), dosTo: moment(dosTo).toDate(), renderingProviderNPI: serviceRendered, })
    }
  }, [showTable, claimData])

  useEffect(() => {
    if (cptCodes.length > 0) {
      const codes = cptCodes.map((code: CPTCodeModel) => {
        return { key: `${code.code} - ${code.shortDescription}`, value: code.code }
      })
      setCptCodeOptions(codes);
    }
  }, [cptCodes])

  useEffect(() => {
    if (ndcCodes.length > 0) {
      const ndcs = ndcCodes.map((code: NDCCodeModel) => {
        return { key: code.code, value: code.code }
      })
      setNdcCodeOptions(ndcs);
    }
  }, [ndcCodes])

  useEffect(() => {
    if (diagnosis.length > 0) {
      const diagnosisOpt = diagnosis.map((diag: ClaimDiagnosisViewModel) => {
        return { key: `${diag.diagnosisPointer} - ${diag.diagnosisCode}`, value: diag.diagnosisPointerStr }
      })
      setDiagnosisOptions(diagnosisOpt);
    }
  }, [diagnosis])

  useEffect(() => {
    if (admits.length > 0) {
      const admitOpt = admits.map((admit: ClaimDiagnosisViewModel) => {
        return { key: `${admit.diagnosisPointer} - ${admit.diagnosisCode}`, value: admit.diagnosisPointerStr }
      })
      setAdmitOptions(admitOpt);
    }
  }, [admits])

  useEffect(() => {
    if (billTypes.length > 0) {
      const billTypeOpt = billTypes.map((bill: BillTypeCodeModel) => {
        return { key: bill.code, value: bill.billTypeCodeID }
      })
      setBillTypeOptions(billTypeOpt);
    }
  }, [billTypes])

  useEffect(() => {
    if (drgCodes.length > 0) {
      const drugCode = drgCodes.map((drg: DRGCodeModel) => {
        return { key: drg.code, value: drg.code }
      })
      setDrgCodeOptions(drugCode);
    }
  }, [drgCodes])

  useEffect(() => {
    if (renderingProviders.length > 0) {
      const renderingProvider = renderingProviders.map((provider: ProviderViewModel) => {
        const { npi, providerCode, fullName } = provider
        return { key: `NPI: ${npi} | Code: ${providerCode} | Name: ${fullName}`, value: npi };
      })
      setRenderingProviderOptions(renderingProvider);
    }
  }, [renderingProviders])


  useEffect(() => {
    if (pendDeny.length > 0) {
      const pend = pendDeny.map((pend: CommonCodeModel) => {
        return { key: pend.longDescription, value: pend.commonCodeID };
      })
      setPendDenyOptions(pend);
    }
  }, [pendDeny])

  const handleModChange = async (rule, value) => {
    // console.log(event.value);
    // if (event.value.length > 4) {
    //   event.preventDefault();
    // }
    if (value && value.length > 4) {
      return Promise.reject("Modifiers cannot be more than 4");
    }
    return Promise.resolve();
  }

  const handlePendChange = (event: DropdownChangeEvent) => {
    console.log(event.value);
    const pend = pendDeny.find((pend: CommonCodeModel) => pend.commonCodeID === event.value);
    form.setFieldValue("code", pend.code);
  }

  const validatePOSCode = async (rule, value) => {
    const isEffective = await effectiveClinicalCode(ClinicalCodeType.POS, value, dosFrom, dosTo);
    if (!isEffective) {
      return Promise.reject("POS code is invalid");
    }
    return Promise.resolve();
  }

  const dataMapper = (formValue: ClaimServiceViewModel) => {
    const { memberID, claimHeaderID } = claimData;
    console.log(formValue);
    const { modifiers: mod, diagnosisPointer: diagPointer } = formValue;
    const modifiers: string = mod.length > 0 && Array.isArray(mod) ? mod.join(";") : "";
    const diagnosisPointer: string = diagPointer.length > 0 && Array.isArray(diagPointer) ? diagPointer.join(";") : "";

    const claimService: ClaimServiceViewModel = { ...formValue, modifiers, diagnosisPointer, claimHeaderID, memberID };
    console.log(claimService);
    return claimService;
  }

  const handleSave = async () => {
    console.log(form.getFieldsError());
    console.log(form.getFieldsValue(true));
    const claimService: ClaimServiceViewModel = dataMapper(form.getFieldsValue(true));
    const claimServiceResponse = selectedService ? await updateClaimService(claimService) : await createClaimService(claimService)
    if (claimServiceResponse) {
      setShowTable(true);
      form.resetFields();
      loadLazyData();
      setSelectedService(null);
    }
  }

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const loadLazyData = async () => {
    const claimServicesGrid = await claimServiceGrid(claimHeaderID, lazyState.first, lazyState.rows);
    console.log("claimServicesGrid", claimServicesGrid)
    if (claimServicesGrid) {
      setGridValues(claimServicesGrid.data);
      setTotalRecords(claimServicesGrid.totalCount);
    }
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState]);

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedService(e.value);
    } else {
      setSelectedService(null);
    }
  }


  const handleEMGChange = () => {
    setIsEmg((prevState) => !prevState)
  };
  const handleAddClick = () => {
    setShowTable(false);
    setSelectedService(null);
  };
  const processEdits = async () => {
    try {
      await editsProcessing(claimHeaderID);
    }
    catch (error) {
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
    finally {
      setIsProcessing(false)
    }
  };
  const handleCancel = () => {
    setShowTable(true);
    setSelectedService(null);
    form.resetFields();
  };
  const dosToTemplate = (data: ClaimServiceViewModel) => {
    return useFormattedDate(data, "dosTo")
  }
  const dosFromTemplate = (data: ClaimServiceViewModel) => {
    return useFormattedDate(data, "dosFrom")
  }
  const handleEdit = async () => {
    console.log("selectedServiceselectedService", selectedService)
    if (selectedService) {
      const claimService = await getById(selectedService.claimServiceID);
      if (claimService) {
        setShowTable(false);
        const { modifiers: mods, diagnosisPointer: diags } = claimService;
        const modifiers = mods && typeof (mods) === 'string' ? mods.split(";") : [];
        const diagnosisPointer = diags && typeof (diags) === 'string' ? diags.split(";") : [];
        form.setFieldsValue({ ...claimService });
        form.setFieldValue("diagnosisPointer", diagnosisPointer);
        form.setFieldValue("modifiers", modifiers);
        form.setFieldValue("lineNumber", selectedService.lineNumber);
      }
    }
  }

  const header = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedService && <Button outlined label="Edit" onClick={handleEdit} />}
          <Button outlined label="Add" onClick={handleAddClick} />
          <Button outlined label="Process Edits" disabled={isProcessing} onClick={processEdits} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            rowsPerPageOptions={paginatorConstants.pageOptions}
            className="p-datatable-gridlines"
            header={header}
            showGridlines
            rows={lazyState.rows}
            tableStyle={{ minWidth: '50rem' }}
            currentPageReportTemplate="{first} to {last} of {totalRecords}"
            dataKey="claimServiceID"
            responsiveLayout="scroll"
            emptyMessage="No Group found."
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >
            {/* <Column field="line" header="Line" filter sortable /> */}
            <Column header="Line" headerStyle={{ width: '3rem' }} body={(data, options) => (lazyState.first + options.rowIndex + 1)}></Column>
            <Column field="dosFrom" body={dosFromTemplate} header="DOS&nbsp;From" filter sortable />
            <Column field="dosTo" body={dosToTemplate} header="Dos&nbsp;To" filter sortable />
            <Column field="posCode" header="POS" filter sortable />
            <Column field="procedureCode" header="procedure&nbsp;Code" filter sortable />
            <Column field="modifiers" header="MOD" filter sortable />
            <Column field="ndc" header="NDC" filter sortable />
            <Column field="emg" header="EMG" filter sortable />
            <Column field="diagnosisPointer" header="Diag&nbsp;Pointer" filter sortable />
            <Column field="benefit" header="Benefit" filter sortable />
            <Column field="epsdt" header="EPSDT" filter sortable />
            <Column field="referralAuthNumber" header="Auth&nbsp;Number" filter sortable />
            <Column field="billedAmount" header="Billed" filter sortable />
            <Column field="unitsOrMinutes" header="Units" filter sortable />
            <Column field="allowedUnitsOrMinutes" header="Allowed&nbsp;Units" filter sortable />
            <Column field="allowedAmount" header="Allowed" filter sortable />
            <Column field="differenceAmount" header="Difference" filter sortable />
            <Column field="nonCoveredAmount" header="Non&nbsp;Covered" filter sortable />
            <Column field="deductibleAmount" header="Deductible&nbsp;Amount" filter sortable />
            <Column field="copayAmount" header="Copay&nbsp;Amount" filter sortable />
            <Column field="coinsuranceAmount" header="Coinsurance" filter sortable />
            <Column field="payableAmount" header="Payable&nbsp;Amount" filter sortable />
            <Column field="interestAmount" header="Interest" filter sortable />
            <Column field="totalPaidAmount" header="Total&nbsp;Paid" filter sortable />
            <Column field="renderingProviderNPI" header="Rendering&nbsp;Provider&nbsp;NPI" filter sortable />
            <Column field="renderingProviderName" header="Rendering&nbsp;Provider" filter sortable />
            <Column field="isClean" header="Clean" filter sortable />
            <Column field="service" header="Service" filter sortable />
            <Column field="isOverride" header="Override" filter sortable />
            <Column field="contract" header="Contract" filter sortable />
            <Column field="contractTerm" header="Contract&nbsp;Term" filter sortable />
            <Column field="feeScheduleCode" header="Fee&nbsp;Schedule" filter sortable />
            <Column field="pending" header="Pending/Deny" filter sortable />
            <Column field="code" header="Code" filter sortable />
          </DataTable>
        </>
      ) : (
        <CustomForm form={form} onFinish={handleSave}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            {/* <FormItem name="lineNumber" label="Line Item">
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem> */}
            <FormItem name="dosFrom" label="Dos From" rules={[{ required: true }]}>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                disabled
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="dosTo" label="Dos To" rules={[{ required: true }]}>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                disabled
                maxDate={new Date()}
              />
            </FormItem>
            {formTypeID != ClaimType.Institutional && <FormItem name="posCode" label="POS" rules={[{ required: true }, { validator: validatePOSCode }]}>
              <InputText type="text" placeholder="Enter here" />
            </FormItem>}
            {formTypeID != ClaimType.Professional && <FormItem name="revenueCode" label="Revenue Code" rules={[{ required: true }]}>
              <InputText type="text" placeholder="Enter here" />
            </FormItem>}
            {(formTypeID != ClaimType.Institutional && formTypeID != ClaimType.Professional) && <FormItem name="rugsCode" label="RUGS Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>}
            {(formTypeID != ClaimType.Institutional && formTypeID != ClaimType.Professional) && <FormItem name="procedureCode" label="Procedure Code">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>}
            {formTypeID != ClaimType.Institutional && <FormListItem name="modifiers" label="MOD" rules={[{ validator: handleModChange }]}>
              <Dropdown
                id="mod"
                options={cptCodeOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                multiple
                showHeader
                // onChange={(event) => handleCptChange(event)}
                placeholder="Select"
                className="w-full"
              />
            </FormListItem>}
            {formTypeID != ClaimType.Institutional && <FormItem name="ndcCode" label="NDC">
              <Dropdown
                id="ndc"
                options={ndcCodeOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>}
            {formTypeID != ClaimType.Institutional && <FormItem name="diagnosisPointer" label="Diag Code" rules={[{ required: true }]}>
              <Dropdown
                id="diagCode"
                options={diagnosisOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                multiple
                showHeader
                placeholder="Select"
                className="w-full"
              />
            </FormItem>}

            {formTypeID == ClaimType.Institutional && <FormItem name="diagnosisPointer" label="Pricing Diagnosis" rules={[{ required: true }]}>
              <Dropdown
                id="diagCode"
                options={diagnosisOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                multiple
                showHeader
                placeholder="Select"
                className="w-full"
              />
            </FormItem>}

            {formTypeID == ClaimType.Institutional && <FormItem name="admitDiagnosis" label="Admit Diagnosis">
              <Dropdown
                id="diagCode"
                options={admitOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                multiple
                showHeader
                placeholder="Select"
                className="w-full"
              />
            </FormItem>}

            {formTypeID == ClaimType.Institutional && <FormItem name="billTypeId" label="Bill Type">
              <Dropdown
                id="emg"
                options={billTypeOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>}

            {formTypeID == ClaimType.Institutional && <FormItem name="billedDrgCode" label="Billed DRG">
              <Dropdown
                id="emg"
                options={drgCodeOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>}

            <FormItem name="benefitCombo" label="Benefit">
              <Dropdown
                id="benefit"
                options={benefitOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="epsdt" label="EPSDT">
              <Dropdown
                id="epsdt"
                options={epsdtOptions}
                optionLabel="value"
                optionValue="value"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="referralAuthNumber" label="Auth Number">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="billedAmount" label="Billed" rules={[{ required: true }]}>
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="unitsOrMinutes" label="Units" rules={[{ required: true }]}>
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="allowedUnitsOrMinutes" label="Allowed Units or Minutes" rules={[{ required: true }]}>
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="allowedAmount" label="Allowed">
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="differenceAmount" label="Write Off">
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="nonCoveredAmount" label="Non Convered">
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="deductibleAmount" label="Deductible Amount">
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="copayAmount" label="Copay Amount" rules={[{ required: true }]}>
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="coinsuranceAmount" label="Co Insurance">
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="payableAmount" label="Payable Amount">
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="interestAmount" label="Interest">
              <InputNumber type="text" placeholder="Enter here" disabled />
            </FormItem>
            <FormItem name="totalPaidAmount" label="Total Paid">
              <InputNumber type="text" placeholder="Enter here" disabled />
            </FormItem>
            {formTypeID != ClaimType.Institutional && <FormItem name="renderingProviderNPI" label="Rendering Provider NPI">
              {/* <InputText type="text" placeholder="Enter here" /> */}
              <Dropdown
                id="rendering"
                options={renderingProviderOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                placeholder="Select"
                className="w-full"
                disabled
              />
            </FormItem>}
            {formTypeID != ClaimType.Institutional && <FormItem name="renderingProviderName" label="Rendering Provider">
              <InputText type="text" placeholder="Enter here" disabled />
            </FormItem>}
            <FormItem name="providerContract" label="Contract">
              <InputText type="text" placeholder="Enter here" disabled />
            </FormItem>
            <FormItem name="contractTerm" label="Contract Term">
              <InputText type="text" placeholder="Enter here" disabled />
            </FormItem>
            <FormItem name="feeScheduleCode" label="Fee Schedule">
              <InputText type="text" placeholder="Enter here" disabled />
            </FormItem>
            <FormItem name="serviceStatus" label="Line Status">
              <InputText type="text" placeholder="Enter here" disabled />
            </FormItem>
            <FormItem name="serviceLineStatusId" label="Pending/Deny">
              <Dropdown
                id="deny"
                options={pendDenyOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                onChange={handlePendChange}
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="code" label="Code">
              <InputText type="text" placeholder="Enter here" disabled />
            </FormItem>
            {formTypeID == ClaimType.Institutional && <FormItem name="revisedDrgCode" label="Revised DRG">
              <Dropdown
                id="emg"
                options={drgCodeOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>}
            {formTypeID != ClaimType.Institutional && <Field name="isEmg" >
              <Checkbox
                inputId="isEMg"
                label={"EMG"}
                checked={isEmg}
                onChange={handleEMGChange} // Handle checkbox change
              />
            </Field>}
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancel} />
            <Button label="Save" raised />
            {/* onClick={handleSave} */}
          </div>
        </CustomForm>
      )}
    </>
  );
};

export default ClaimServices;
