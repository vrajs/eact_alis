import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import CustomForm from "../../../controls/CustomForm";
import Calendar from "../../../controls/Calendar";
import InputNumber from "../../../controls/InputNumber";
import ClaimOtherInsuranceService from "../../../services/ClaimOtherInsuranceService";
import { useForm } from "rc-field-form";
import { ClaimOtherInsuranceViewModel } from "../../../model/ClaimOtherInsuranceViewModel";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import { ClaimType, COBType, CodeType, CommonCodeFetchingType } from "../../../data/constants/AppEnum";
import { KeyValueModel } from "../../../model/KeyValueModel";
import CPTCodeService from "../../../services/CPTCodeService";
import { CPTCodeModel } from "../../../model/CPTCodeModel";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import moment from "moment";
import ClaimServiceServices from "../../../services/ClaimServiceServices";
import { ClaimServiceViewModel } from "../../../services/ClaimServiceViewModel";
import PosCodeService from "../../../services/PosCodeService";
import { PosCodeModel } from "../../../model/PosCodeModel";

const ClaimOtherInsurance = () => {
  const [showTable, setShowTable] = useState<boolean>(true);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [customers1, setCustomers1] = useState<any>([]);
  const [form] = useForm<ClaimOtherInsuranceViewModel>();
  const [cptCodes, setCptCodes] = useState<CPTCodeModel[]>([]);
  const [posCodes, setPosCodes] = useState<PosCodeModel[]>([]);
  const [cptCodesOptions, setCptCodesOptions] = useState<KeyValueModel[]>([]);
  const { getCPTCodes } = CPTCodeService();
  const { getPosCodes } = PosCodeService();
  const cobOptions: KeyValueModel[] = useCommonCodeSubCategory(CodeType.COBType, CommonCodeFetchingType.Default)
  const [dosFrom, setDosFrom] = useState<Date | null | string>(null);
  const [dosTo, setDosTo] = useState<Date | null | string>(null);
  const { claimData, claimHeaderID, formTypeID } = useSelector((state: RootState) => state.claim);
  const { claimServices } = ClaimServiceServices();
  const [services, setServices] = useState<ClaimServiceViewModel[]>([]);
  const [serviceOptions, setServiceOptions] = useState<KeyValueModel[]>([]);
  const [disable, setDisable] = useState<boolean>(false);
  const { getById, createOtherInsurance, updateOtherInsurance, deleteOtherInsurance, getByClaimHeaderID } = ClaimOtherInsuranceService();
  const [lh, setLH] = useState(null);
  const lhList = [
    { key: "Line", value: "Line" },
    { key: "Header", value: "Header" },
  ];
  const [line, setLine] = useState(null);
  const lineList = [
    { key: "Line", value: "Line" },
    { key: "Header", value: "Header" },
  ];
  const [mod, setMOD] = useState(null);
  const modList = [
    { key: "A1", value: "A1" },
    { key: "A2", value: "A2" },
  ];

  useEffect(() => {
    if (claimData) {
      const { dosFrom, dosTo, billedAmount } = claimData;
      setDosFrom(moment(dosFrom).toDate());
      setDosTo(moment(dosTo).toDate());
      form.setFieldsValue({
        dosFrom: moment(dosFrom).toDate(),
        dosTo: moment(dosTo).toDate(),
        billedAmount,
      })
    }
  }, [claimData])

  useEffect(() => {
    const cptCodes = getCPTCodes();
    const posCodes = getPosCodes();
    Promise.all([cptCodes, posCodes]).then(result => {
      setCptCodes(result[0]);
      setPosCodes(result[1]);
    })
  }, [])

  useEffect(() => {
    if (cptCodes.length > 0) {
      const cpts = cptCodes.map((cpt: CPTCodeModel) => {
        return { key: `${cpt.code} - ${cpt.shortDescription}`, value: cpt.code };
      })
      setCptCodesOptions(cpts);
    }
  }, [cptCodes]);

  const getClaimService = async () => {
    const services = await claimServices(claimHeaderID);
    if (services.length > 0) {
      setServices(services);
    }
  }

  useEffect(() => {
    if (services.length > 0) {
      const service = services.map((serve: ClaimServiceViewModel, index: number) => {
        console.log("serve serve serve serve", serve)
        return { key: index + 1, value: index + 1 };
      })
      setServiceOptions(service);
    }
  }, [services])

  const handleServiceLineChange = (event: DropdownChangeEvent) => {
    if (event.value) {
      const service = services.find((service: ClaimServiceViewModel) => service.serviceLineStatusID === event.value);
      const { posCode, procedureCode, billedAmount } = service;
      form.setFieldsValue({ posCode, procedureCode, billedAmount })
    }
  }

  const handleCobChange = (event: DropdownChangeEvent) => {
    if (event.value == COBType.Header) {
      const setValues = {
        "serviceLineNumber": 0,
        "posCode": "",
        "revenueCode": "",
        "procedureCode": "",
      }
      setDisable(true);
      form.setFieldValue("isLineLevel", false);

      //     this.getClaimOtherInsuranceFormControls.modifiers.disable();
      //     this.getClaimOtherInsuranceFormControls.modifiers.removeValidators(Validators.required);
      //     this.getClaimOtherInsuranceFormControls.procedureCode.removeValidators(Validators.required);
      //     this.getClaimOtherInsuranceFormControls.revenueCode.removeValidators(Validators.required);
      //     this.getClaimOtherInsuranceFormControls.posCode.removeValidators(Validators.required);

      //     this.getClaimOtherInsuranceFormControls.modifiers.updateValueAndValidity();
      //     this.getClaimOtherInsuranceFormControls.procedureCode.updateValueAndValidity();
      //     this.getClaimOtherInsuranceFormControls.revenueCode.updateValueAndValidity();
      //     this.getClaimOtherInsuranceFormControls.posCode.updateValueAndValidity();
    } else if (event.value == COBType.Line) {
      setDisable(false);
      getClaimService();
      form.setFieldValue("isLineLevel", true);
      // this.claimService.getClaimServiceData(this.claimHeaderId, null, null).subscribe(data => {
      //     this.claimServiceList = data.dataList;
      // });

      if (formTypeID != ClaimType.Institutional) {
        // this.getClaimOtherInsuranceFormControls.posCode.setValidators(Validators.required);
        // this.getClaimOtherInsuranceFormControls.procedureCode.setValidators(Validators.required);
      }

      if (formTypeID != ClaimType.Professional) {
        //  this.getClaimOtherInsuranceFormControls.revenueCode.setValidators(Validators.required);
      }
    }

  }

  const handleAddClick = () => {
    setShowTable(false);
  };

  const handleSave = async () => {
    console.log(form.getFieldsValue(true))
    const formValue = form.getFieldsValue(true);
    const { memberID, claimHeaderID } = claimData;;
    const otherInsurance: ClaimOtherInsuranceViewModel = { ...formValue, memberID, claimHeaderID };
    console.log(otherInsurance);
    const otherInsuranceResponse = await createOtherInsurance(otherInsurance);
    if (otherInsuranceResponse) {
      setShowTable(true);
    }
  };

  const handleCancel = () => {
    setShowTable(true);
  };
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        const customerData = [
          {
            line: "1",
            dosFrom: "1-02-2024",
            dosto: "1-02-2024",
            pos: "11",
            procedureCode: "99213",
            billed: "N/A",
            units: "N/A",
            deductibleAmount: "0",
            copayAmount: "0",
            allowed: "N/A",
            coinsurance: "0",
            netAllowed: "0",
            totalPaid: "0",
          },
        ];
        setCustomers1(customerData);
      } catch (error) {
        console.error("Error fetching customers:", error);
      }
    };

    fetchCustomers();
  }, []);
  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            value={customers1}
            paginator
            className="p-datatable-gridlines"
            showGridlines
            rows={10}
            dataKey="claimId"
            responsiveLayout="scroll"
            emptyMessage="No records found."
            header={header1}
            selection={selectedCustomer}
            onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
            selectionMode="single" // Single row selection
          >
            <Column field="line" header="Line" filter sortable />
            <Column field="dosFrom" header="DOS&nbsp;From" filter sortable />
            <Column field="dosto" header="Dos&nbsp;To" filter sortable />
            <Column field="pos" header="POS" filter sortable />
            <Column field="procedureCode" header="procedure&nbsp;Code" filter sortable />
            <Column field="mod" header="MOD" filter sortable />
            <Column field="billed" header="Billed" filter sortable />
            <Column field="units" header="Units" filter sortable />
            <Column field="allowed" header="Allowed" filter sortable />
            <Column field="deductibleAmount" header="Deductible&nbsp;Amount" filter sortable />
            <Column field="copayAmount" header="Copay&nbsp;Amount" filter sortable />
            <Column field="coinsurance" header="Coinsurance" filter sortable />
            <Column field="netAllowed" header="Net&nbsp;Allowed" filter sortable />
            <Column field="totalPaid" header="Total&nbsp;Paid" filter sortable />
          </DataTable>
        </>
      ) : (
        <CustomForm form={form} onFinish={handleSave}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="lineOrHeaderCalc" label="Line/Header" rules={[{ required: true }]}>
              <Dropdown
                id="lh"
                options={cobOptions}
                optionLabel="value"
                optionValue="key"
                showClear
                placeholder="Select"
                onChange={handleCobChange}
                className="w-full"
              />
            </FormItem>

            <FormItem name="serviceLineNumber" label="Line" rules={disable ? [] : [{ required: true }]}>
              <Dropdown
                id="line"
                options={serviceOptions}
                optionLabel="key"
                optionValue="key"
                showClear
                placeholder="Select"
                className="w-full"
                disabled={disable}
              />
            </FormItem>

            <FormItem name="dosFrom" label="DOS From" rules={[{ required: true }]}>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                disabled
              />
            </FormItem>
            <FormItem name="dosTo" label="Dos To" rules={[{ required: true }]}>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                disabled
              />
            </FormItem>
            {formTypeID != ClaimType.Institutional && <FormItem name="posCode" label="POS" rules={[]}>
              <InputText type="text" placeholder="Enter here" disabled={disable} />
            </FormItem>}
            {formTypeID != ClaimType.Institutional && <FormItem name="procedureCode" label="Procedure Code">
              <InputText type="text" placeholder="Enter here" disabled={disable} />
            </FormItem>}
            {formTypeID != ClaimType.Professional && <FormItem name="revenueCode" label="Revenue Code">
              <InputText type="text" placeholder="Enter here" disabled={disable} />
            </FormItem>}
            <FormItem name="modifiers" label="MOD">
              <Dropdown
                id="mod"
                options={cptCodesOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                multiple
                showHeader
                placeholder="Select"
                className="w-full"
                disabled={disable}
              />
            </FormItem>
            <FormItem name="billedAmount" label="Billed">
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="units" label="Units" rules={[{ required: true }]}>
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="eobDate" label="EOB" rules={[{ required: true }]}>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="allowedAmount" label="Allowed" rules={[{ required: true }]}>
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="deductibleAmount" label="Deductible Amount">
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="copayAmount" label="Copay Amount">
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="coinsuranceAmount" label="Co Insurance">
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="netAllowedAmount" label="Net Allowed" rules={[{ required: true }]}>
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="totalPaidAmount" label="Total Paid" rules={[{ required: true }]}>
              <InputNumber type="text" placeholder="Enter here" />
            </FormItem>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancel} />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      )}
    </>
  );
};

export default ClaimOtherInsurance;
