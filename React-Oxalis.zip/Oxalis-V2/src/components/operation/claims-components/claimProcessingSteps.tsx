import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import ClaimProcessingStepsService from "../../../services/ClaimProcessingStepsService";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import { LazyTableState } from "../../../model/LazyTableState";
import { ClaimProcessingStepsViewModel } from "../../../model/ClaimProcessingStepsViewModel";

const ClaimProcessingSteps = () => {
  const { getByClaimHeaderID } = ClaimProcessingStepsService();
  const { claimHeaderID } = useSelector((state: RootState) => state.claim);
  const [gridValues, setGridValues] = useState<ClaimProcessingStepsViewModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const loadLazyData = async () => {
    const processingSteps = await getByClaimHeaderID(claimHeaderID, lazyState.first, lazyState.rows);
    console.log("processingSteps", processingSteps)
    if (processingSteps) {
      setGridValues(processingSteps.data);
      setTotalRecords(processingSteps.totalCount);
    }
  };


  useEffect(() => {
    if (claimHeaderID > 0) {
      loadLazyData();
    }
  }, [claimHeaderID, lazyState])
  return (
    <>
      <DataTable
        paginator
        rowsPerPageOptions={paginatorConstants.pageOptions}
        className="p-datatable-gridlines"
        showGridlines
        rows={lazyState.rows}
        tableStyle={{ minWidth: '50rem' }}
        currentPageReportTemplate="{first} to {last} of {totalRecords}"
        dataKey="claimHeaderID"
        responsiveLayout="scroll"
        emptyMessage="No Group found."
        selectionMode="single"
        lazy onPage={onPage}
        onSort={onSort}
        sortField={lazyState.sortField}
        onFilter={onFilter}
        value={gridValues}
        totalRecords={totalRecords}
        first={lazyState.first}
      >
        <Column field="processDate" header="process&nbsp;Date" filter sortable />
        <Column field="processStep" header="process&nbsp;Step" filter sortable />
        <Column field="processValue" header="process&nbsp;Value" filter sortable />
      </DataTable>
    </>
  );
};

export default ClaimProcessingSteps;
