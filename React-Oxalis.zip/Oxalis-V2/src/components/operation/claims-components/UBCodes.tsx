import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import CustomForm from "../../../controls/CustomForm";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { useForm } from "rc-field-form";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import { LazyTableState } from "../../../model/LazyTableState";
import { ClinicalCodeType, CodeType, CommonCodeFetchingType, ControlType } from "../../../data/constants/AppEnum";
import moment from "moment";
import { GridModel } from "../../../model/GridModel";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import { ClaimUBCodesViewModel } from "../../../model/ClaimUBCodesViewModel";
import Calendar from "../../../controls/Calendar";
import InputNumber from "../../../controls/InputNumber";
import ClaimUbCodeService from "../../../services/ClaimUbCodeService";
import ClinicalCodeService from "../../../services/ClinicalCodeService";
import FormListItem from "../../../controls/FormListItem";
import { RuleObject } from "rc-field-form/es/interface";

const UBCodes = () => {
  const [showTable, setShowTable] = useState<boolean>(true);
  const [selectedUbCode, setSelectedUbCode] = useState<ClaimUBCodesViewModel>(null);
  const { claimHeaderID } = useSelector((state: RootState) => state.claim);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [gridValues, setGridValues] = useState<ClaimUBCodesViewModel[]>([]);
  const { createClaimUbCode, updateClaimUb, getById, deleteClaimUb, getByClaimHeaderID } = ClaimUbCodeService();
  const [form] = useForm<ClaimUBCodesViewModel>();
  const { claimData } = useSelector((state: RootState) => state.claim);
  // other physician
  const ubCodeType = useCommonCodeSubCategory(CodeType.ClaimUBCodeType, CommonCodeFetchingType.Default);

  // UB codes
  const [fromDate, setFromDate] = useState<Date | null>(null);
  const { effectiveClinicalCode } = ClinicalCodeService();

  const handleAddClick = () => {
    setShowTable(false);
    setSelectedUbCode(null);
  };
  const handleCancel = () => {
    setShowTable(true);
    form.resetFields();
    setSelectedUbCode(null);
  };

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const loadLazyData = async () => {
    if (claimHeaderID > 0) {
      const claimPhysicianResp: GridModel<ClaimUBCodesViewModel> = await getByClaimHeaderID(claimHeaderID, lazyState.first, lazyState.rows);
      console.log("claimPhysicianResp", claimPhysicianResp)
      if (claimPhysicianResp) {
        setGridValues(claimPhysicianResp.data);
        setTotalRecords(claimPhysicianResp.totalCount);
      }
    }
  };

  const validateDiagnosis = async (rule: RuleObject, value: string) => {
    if (value) {
      const { dosFrom, dosTo } = claimData;
      const code = form.getFieldValue("typeID");
      if (!code) {
        return Promise.reject("Invalid code");
      }
      const dosFromFormatted = dosFrom ? moment(dosFrom).format("YYYY-MM-DD") : null;
      const dosToFormatted = dosFrom ? moment(dosTo).format("YYYY-MM-DD") : null;
      const clinicalCodeService = await effectiveClinicalCode(code, value.toUpperCase(), dosFromFormatted, dosToFormatted);
      if (clinicalCodeService) {
        form.setFieldValue("description", clinicalCodeService?.shortDescription);
      } else {
        return Promise.reject("Diagnosis code is invalid");
      }
    }
  }

  useEffect(() => {
    loadLazyData();
  }, [lazyState]);

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedUbCode(e.value)
    } else {
      setSelectedUbCode(null);
    }
  }

  const handleFromDateChange = (event: Date) => {
    if (event) {
      setFromDate(event);
    } else {
      setFromDate(null);
    }
  }

  const handleEdit = async () => {
    if (selectedUbCode.claimUBCodesID) {
      const claimUbData = await getById(selectedUbCode.claimUBCodesID);
      const { fromDate: effectiveDate, toDate: termDate } = claimUbData;
      const fromDate = effectiveDate ? moment(effectiveDate).toDate() : null;
      const toDate = termDate ? moment(termDate).toDate() : null;
      const bindValue = { ...claimUbData, toDate, fromDate };
      form.setFieldsValue({ ...bindValue });
      setShowTable(false);
    }
  }

  const initialValues: ClaimUBCodesViewModel = {
    claimUBCodesID: 0,
    claimHeaderID: 0,
    typeID: 0,
    ubCode: "",
    description: "",
    fromDate: "",
    toDate: "",
    amount: 0,
    addedSource: "",
    url: ""
  }

  const handleSave = async () => {
    console.log(form.getFieldsValue(true));
    let formValue = form.getFieldsValue(true)

    const claimUbCode: ClaimUBCodesViewModel = { ...formValue, claimHeaderID }
    const claimPhysicianResponse = selectedUbCode ? await updateClaimUb(claimUbCode) : await createClaimUbCode(claimUbCode);
    if (claimPhysicianResponse) {
      setShowTable(true);
      loadLazyData();
      setSelectedUbCode(null);
      form.resetFields();
    }
  }

  const header = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedUbCode && <Button outlined label="Edit" onClick={handleEdit} />}
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            rowsPerPageOptions={paginatorConstants.pageOptions}
            className="p-datatable-gridlines"
            showGridlines
            header={header}
            rows={lazyState.rows}
            tableStyle={{ minWidth: '50rem' }}
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
            dataKey="claimUBCodesID"
            emptyMessage={paginatorConstants.emptyMessage}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >
            <Column field="codeTypeID" header="Type" sortable />
            <Column field="codeValue" header="Ref&nbsp;Value" sortable />
            <Column field="effectiveDate" header="Effective&nbsp;Date" sortable />
            <Column field="termDate" header="Term&nbsp;Date" sortable />
          </DataTable>
        </>
      ) : (
        <CustomForm form={form} onFinish={handleSave} initialValues={initialValues}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="typeID" label="Type" rules={[{ required: true }]}>
              <Dropdown
                id="codeTypeId"
                optionLabel="value"
                optionValue="key"
                options={ubCodeType}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>

            <FormListItem name="ubCode" label="Code" rules={[{ required: true, message: "Code is required" }, { validator: validateDiagnosis, message: "Code is invalid" }]}>
              <InputText type="text" placeholder="Enter here" />
            </FormListItem>

            <FormItem name="description" label="Description" rules={[{ required: true }]}>
              <InputText type="text" placeholder="Enter here" />
            </FormItem>

            <FormItem name="fromDate" label="From Date" rules={[{ required: true }]}>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                onChange={(event) => handleFromDateChange(event as Date)}
              />
            </FormItem>

            <FormItem name="toDate" label="To Date" rules={[{ required: true }]}>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                minDate={fromDate}
                disabled={!fromDate}
              />
            </FormItem>

            <FormItem name="amount" label="Amount" rules={[{ required: true }]}>
              <InputNumber placeholder="Enter here" useGrouping={false} />
            </FormItem>

          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancel} type="button" />
            <Button label="Save" raised type="submit" />
          </div>
        </CustomForm>
      )}
    </>
  );
};

export default UBCodes;
