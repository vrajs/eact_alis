import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import Calendar from "../../../controls/Calendar";
import Button from "../../../controls/Button";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { FormInstance, useForm } from "rc-field-form";
import { LazyTableState } from "../../../model/LazyTableState";
import { GridModel } from "../../../model/GridModel";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import { ClaimNotesViewModel } from "../../../model/ClaimNotesViewModel";
import ClaimNotesService from "../../../services/ClaimNotesService";
import useFormattedDate from "../../../hooks/useFormattedDate";

const ClaimNotes = () => {
  const [showTable, setShowTable] = useState<boolean>(true);
  const [selectedNotes, setSelectedNotes] = useState<ClaimNotesViewModel>();
  const { create, update, del, getByClaimHeaderID, getById } = ClaimNotesService();
  const { claimHeaderID, claimData } = useSelector((state: RootState) => state.claim);
  const [gridValues, setGridValues] = useState<ClaimNotesViewModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [form] = useForm<ClaimNotesViewModel>();


  const handleAddClick = () => {
    setShowTable(false);
    form.setFieldValue("noteDate", new Date())
  };

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  useEffect(() => {
    if (claimHeaderID > 0) {
      loadLazyData();
    }
  }, [lazyState, claimHeaderID]);

  const loadLazyData = async () => {
    if (claimHeaderID > 0) {
      const claimNoteResponse: GridModel<ClaimNotesViewModel> = await getByClaimHeaderID(claimHeaderID, lazyState.first, lazyState.rows);
      if (claimNoteResponse) {
        setGridValues(claimNoteResponse.data);
        setTotalRecords(claimNoteResponse.totalCount);
      }
    }
  };

  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true)
    const { memberID } = claimData;

    console.log("formValues formValues", formValues)

    const claimNotes: ClaimNotesViewModel = { ...formValues, memberID, claimHeaderID };
    const claimNoteResponse = await create(claimNotes);
    if (claimNoteResponse) {
      setShowTable(true);
      loadLazyData();
    }
    // const providerNotes = await dataMapper(formValues);
    // console.log(providerNotes)
    // const notesResponse = selectedNotesId > 0 ? await update(providerNotes) : await create(providerNotes);
    // setSelectedNotesId(0);
    // setShowTable(true);
    // setLazyState((prevState) => {
    //   return { ...prevState, first: 0 }
    // })
    // form.resetFields();
  };

  const termDateFormatTemplate = (value: ClaimNotesViewModel) => {
    return useFormattedDate(value, "termDate")
  }

  const effectiveDateFormatTemplate = (value: ClaimNotesViewModel) => {
    return useFormattedDate(value, "effectiveDate")
  }

  const noteDateTemplate = (value: ClaimNotesViewModel) => {
    return useFormattedDate(value, "noteDate")
  }

  const handleCancel = () => {
    setShowTable(true);
    setLazyState((prevState) => {
      return { ...prevState, first: 0 }
    })
  }

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedNotes(e.value);
    } else {
      setSelectedNotes(null);
    }
  }

  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          <Button outlined label="Add" onClick={handleAddClick} />
        </>

      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            className="p-datatable-gridlines mt-4"
            showGridlines
            rows={10}
            dataKey="claimNotesID"
            responsiveLayout="scroll"
            emptyMessage="No records found."
            header={header1}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            // sortOrder={lazyState.sortOrder}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >
            <Column field="shortDesc" header="Short&nbsp;Description" filter sortable />
            <Column field="longDesc" header="Long&nbsp;Description" filter sortable />
            <Column field="noteDate" body={noteDateTemplate} header="Note&nbsp;Date" filter sortable />
            <Column field="effectiveDate" body={effectiveDateFormatTemplate} header="Effective&nbsp;Date" filter sortable />
            <Column field="termDate" body={termDateFormatTemplate} header="Term&nbsp;Date" filter sortable />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="effectiveDate" label="Effective Date" rules={[
                { required: true }
              ]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="termDate" label="Term Date" >
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>
              <FormItem name="shortDesc" label="Short Description" rules={[
                { required: true }
              ]}>
                <InputText type="text" placeholder="Enter here" />
              </FormItem>

              <FormItem name="longDesc" label="Long Description" rules={[
                { required: true }
              ]}>
                <InputText type="text" placeholder="Enter here" />
              </FormItem>

              <FormItem name="noteDate" label="Add Date" >
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  disabled
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={handleCancel} />
              <Button label="Save" raised />
            </div>
          </CustomForm>
        </div>
      )}
    </>
  );
};

export default ClaimNotes;
