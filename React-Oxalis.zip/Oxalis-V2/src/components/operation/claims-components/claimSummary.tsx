import { useState, useEffect } from "react";
import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import ClaimServiceServices from "../../../services/ClaimServiceServices";
import { LazyTableState } from "../../../model/LazyTableState";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { ClaimServiceViewModel } from "../../../services/ClaimServiceViewModel";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import useFormattedDate from "../../../hooks/useFormattedDate";
import ClaimAdjudication from "./ClaimAdjudication";

const ClaimSummary = () => {
  const { claimServiceGrid } = ClaimServiceServices();
  const { claimHeaderID } = useSelector((state: RootState) => state.claim);
  const [gridValues, setGridValues] = useState<ClaimServiceViewModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const loadLazyData = async () => {
    const claimServicesGrid = await claimServiceGrid(claimHeaderID, lazyState.first, lazyState.rows);
    console.log("claimServicesGrid", claimServicesGrid)
    if (claimServicesGrid) {
      setGridValues(claimServicesGrid.data);
      setTotalRecords(claimServicesGrid.totalCount);
    }
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState]);

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const dosToTemplate = (data: ClaimServiceViewModel) => {
    return useFormattedDate(data, "dosTo")
  }

  const dosFromTemplate = (data: ClaimServiceViewModel) => {
    return useFormattedDate(data, "dosFrom")
  }

  const header = (
    <ClaimAdjudication />
  );

  return (
    <>
      <DataTable
        paginator
        header={header}
        rowsPerPageOptions={paginatorConstants.pageOptions}
        className="p-datatable-gridlines"
        showGridlines
        rows={lazyState.rows}
        tableStyle={{ minWidth: '50rem' }}
        currentPageReportTemplate="{first} to {last} of {totalRecords}"
        dataKey="claimServiceID"
        responsiveLayout="scroll"
        emptyMessage="No Group found."
        selectionMode="single"
        lazy onPage={onPage}
        onSort={onSort}
        sortField={lazyState.sortField}
        onFilter={onFilter}
        value={gridValues}
        totalRecords={totalRecords}
        first={lazyState.first}
      >
        <Column field="dosFrom" body={dosFromTemplate} header="DOS&nbsp;From" filter sortable />
        <Column field="dosTo" body={dosToTemplate} header="DOS&nbsp;To" filter sortable />
        <Column field="CPT" header="CPT" filter sortable />
        <Column field="modifiers" header="MOD" filter sortable />
        <Column field="posCode" header="POS" filter sortable />
        <Column field="unitsOrMinutes" header="Units" filter sortable />
        <Column field="billedAmount" header="Billed" filter sortable />
        <Column field="allowedAmount" header="Allowed" filter sortable />
        <Column field="nonCoveredAmount" header="NonCovered" filter sortable />
        <Column field="deductibleAmount" header="Deductible" filter sortable />
        <Column field="copayAmount" header="Copay" filter sortable />
        <Column field="coinsuranceAmount" header="Coinsurance" filter sortable />
        <Column field="payableAmount" header="Payable" filter sortable />
        <Column field="interestAmount" header="Interest" filter sortable />
        <Column field="totalPaidAmount" header="TotalPaid" filter sortable />
      </DataTable>
    </>
  );
};

export default ClaimSummary;
