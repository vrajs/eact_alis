import { Column } from 'primereact/column';
import { DataTable } from 'primereact/datatable';
import React, { useEffect, useState } from 'react'
import { paginatorConstants } from '../../../data/constants/PaginatorConstants';
import { LazyTableState } from '../../../model/LazyTableState';
import { RootState } from '../../../Redux/app/store';
import { useSelector } from 'react-redux';
import ClaimEobService from '../../../services/ClaimEobService';
import { EOBEOPType } from '../../../data/constants/AppEnum';
import { ClaimEOBEOPViewModel } from '../../../model/ClaimEOBEOPViewModel';
import Button from '../../../controls/Button';
import { Panel } from 'primereact/panel';
import CustomForm from '../../../controls/CustomForm';
import { useForm } from 'rc-field-form';
import FormItem from '../../../controls/FormItem';
import Dropdown from '../../../controls/Dropdown';
import { InputText } from 'primereact/inputtext';

const EOBUser = () => {
  const { getGridData } = ClaimEobService();
  const { claimHeaderID } = useSelector((state: RootState) => state.claim);
  const [gridValues, setGridValues] = useState<ClaimEOBEOPViewModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [showTable, setShowTable] = useState<boolean>(true);
  const [form] = useForm();

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const handleAdd = () => {
    setShowTable(false);
  }

  const handleCancel = () => {
    setShowTable(true);
    loadLazyData();
  }

  const header = (
    <div>
      <div className="flex justify-content-end gap-3">
        <Button outlined label="Add" onClick={handleAdd} />
      </div>
    </div>
  );

  const loadLazyData = async () => {
    const claimEobResponse = await getGridData(claimHeaderID, EOBEOPType.USER, lazyState.first, lazyState.rows);
    console.log("claimEobResponse", claimEobResponse)
    if (claimEobResponse) {
      setGridValues(claimEobResponse.data);
      setTotalRecords(claimEobResponse.totalCount);
    }
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState]);

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const handleSave = () => {
    console.log(form.getFieldsValue(true));
  }

  return (
    <>
      {showTable ? <DataTable
        paginator
        header={header}
        rowsPerPageOptions={paginatorConstants.pageOptions}
        className="p-datatable-gridlines"
        showGridlines
        rows={lazyState.rows}
        tableStyle={{ minWidth: '50rem' }}
        currentPageReportTemplate="{first} to {last} of {totalRecords}"
        dataKey="claimServiceID"
        responsiveLayout="scroll"
        emptyMessage="No Group found."
        selectionMode="single"
        lazy onPage={onPage}
        onSort={onSort}
        sortField={lazyState.sortField}
        onFilter={onFilter}
        value={gridValues}
        totalRecords={totalRecords}
        first={lazyState.first}
      >
        <Column field="lineNumber" header="Line&nbsp;Number" filter sortable />
        <Column field="code" header="Code" filter sortable />
        <Column field="description" header="Description" filter sortable />
      </DataTable>
        :
        <>
          <h2 className="pb-4 flex align-center">
            User Information
          </h2>
          <Panel header="Location Information" toggleable className="mb-4">
            <CustomForm form={form} onFinish={handleSave}>
              <div className="pb-4">
                <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">
                  <FormItem name="locationTypeID" label="Line Number" rules={[
                    { required: true }
                  ]}>
                    <Dropdown
                      id="addresstype"
                      optionLabel="value"
                      optionValue="key"
                      placeholder="Select"
                      showClear
                      className="w-full"
                    />
                  </FormItem>

                  <FormItem name="locationName" label="Office Name" rules={[
                    { required: true }
                  ]}>
                    <InputText type="text" placeholder="Enter here" />
                  </FormItem>

                  <FormItem name="address1" label="Address 1" rules={[
                    { required: true }
                  ]}>
                    <InputText type="text" placeholder="Enter here" />
                  </FormItem>
                </div>
                <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
                  <Button label="Cancel" text onChange={handleCancel} />
                  <Button label="Save" raised />
                </div>
              </div>
            </CustomForm>
          </Panel>
        </>}
    </>
  );

}

export default EOBUser