import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import CustomForm from "../../../controls/CustomForm";
import Checkbox from "../../../controls/CheckBox";
import ClaimDiagnosisService from "../../../services/ClaimDiagnosisService";
import { useForm } from "rc-field-form";
import { ClaimDiagnosisViewModel } from "../../../model/ClaimDiagnosisViewModel";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import { LazyTableState } from "../../../model/LazyTableState";
import { ClaimType, ClinicalCodeType, CodeType, CommonCodeFetchingType } from "../../../data/constants/AppEnum";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import InputTextarea from "../../../controls/InputTextarea";
import { DropdownChangeEvent } from "primereact/dropdown";
import FormListItem from "../../../controls/FormListItem";
import { RuleObject } from "rc-field-form/es/interface";
import ClinicalCodeService from "../../../services/ClinicalCodeService";
import moment from "moment";
import useErrorHandler from "../../../hooks/useErrorHandler";
import { useToaster } from "../../../layout/context/toastContext";
import useQueryBuilder from "../../../hooks/useQueryBuilder";

const ClaimDiagnosis = () => {
  const [showTable, setShowTable] = useState<boolean>(true);
  const { createDiagnosis, updateDiagnosis, getClaimDiags } = ClaimDiagnosisService();
  const [form] = useForm<ClaimDiagnosisViewModel>();
  const [selectedDiagnosis, setSelectedDiagnosis] = useState<ClaimDiagnosisViewModel | null>(null);
  const { claimData, claimHeaderID, formTypeID } = useSelector((state: RootState) => state.claim);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [gridValues, setGridValues] = useState<ClaimDiagnosisViewModel[]>([]);
  const qualifierOptions = useCommonCodeSubCategory(CodeType.Qualifier, CommonCodeFetchingType.Default);
  const { effectiveClinicalCode } = ClinicalCodeService();
  const { showToast } = useToaster();

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: "",
    sortOrder: 0,
    filters: {}
  });

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (claimHeaderID > 0) {
      const claimDiagResponse = await getClaimDiags(claimHeaderID, query);
      if (claimDiagResponse) {
        setGridValues(claimDiagResponse.data);
        setTotalRecords(claimDiagResponse.totalCount);
      }
    }
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState, claimHeaderID]);

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedDiagnosis(e.value)
    } else {
      setSelectedDiagnosis(null);
    }
  }

  const handleAddClick = () => {
    setShowTable(false);
    setSelectedDiagnosis(null);
  };

  const handleClear = () => {
    setShowTable(true);
    setSelectedDiagnosis(null);
    form.resetFields();
    loadLazyData();
  }

  const handleCancel = () => {
    handleClear();
  };

  const handleQualifierChange = (event: DropdownChangeEvent) => {
    console.log(event)
  }

  const handleEdit = () => {
    if (selectedDiagnosis) {
      setShowTable(false);
      form.setFieldsValue({ ...selectedDiagnosis })
    }
  }

  const validateDiagnosis = async (rule: RuleObject, value: string, callback) => {
    if (value) {
      const { dosFrom, dosTo } = claimData;
      const dosFromFormatted = dosFrom ? moment(dosFrom).format("YYYY-MM-DD") : null;
      const dosToFormatted = dosFrom ? moment(dosTo).format("YYYY-MM-DD") : null;
      const clinicalCodeService = await effectiveClinicalCode(ClinicalCodeType.ICD10CMPCS, value.toUpperCase(), dosFromFormatted, dosToFormatted);
      if (clinicalCodeService) {
        form.setFieldValue("diagnosisDescription", clinicalCodeService?.shortDescription);
      } else {
        callback("Diagnosis code is invalid");
      }
    }
  }

  const handleSave = async () => {
    console.log(form.getFieldsValue(true));
    const formValue = form.getFieldsValue(true);
    const { dosFrom, dosTo, memberID, claimHeaderID } = claimData;
    const claimDiagnosisValue: ClaimDiagnosisViewModel = { ...formValue, claimHeaderID, dosFrom: dosFrom ? moment(dosFrom).format("YYYY-MM-DD") : null, dosTo: dosTo ? moment(dosTo).format("YYYY-MM-DD") : null, memberID, diagnosisCode: formValue.diagnosisCode.toUpperCase() };
    try {
      const claimDiagResponse = claimDiagnosisValue.claimDiagnosisID > 0 ? await updateDiagnosis(claimDiagnosisValue) : await createDiagnosis(claimDiagnosisValue);
      setShowTable(true);
      if (claimDiagResponse) {
        handleClear();
        showToast({ severity: 'success', summary: 'Success', detail: "Diagnosis saved successfully" });
      }
    }
    catch (error) {
      console.log(error)
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
  }

  const header = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedDiagnosis && <Button outlined label="Edit" onClick={handleEdit} />}
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            rowsPerPageOptions={paginatorConstants.pageOptions}
            className="p-datatable-gridlines"
            showGridlines
            header={header}
            rows={lazyState.rows}
            tableStyle={{ minWidth: '50rem' }}
            currentPageReportTemplate="{first} to {last} of {totalRecords}"
            dataKey="claimDiagnosisID"
            emptyMessage={paginatorConstants.emptyMessage}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            onFilter={onFilter}
            sortOrder={lazyState.sortOrder}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >
            <Column field="diagnosisPointerStr" header="Diag&nbsp;Pointer" />
            <Column field="diagnosisCode" header="Diagnosis" sortable />
            <Column field="diagnosisDescription" header="Diagnosis&nbsp;description" sortable />
            <Column field="qualifier" header="Qualifier" sortable />
          </DataTable>
        </>
      ) : (
        <CustomForm form={form} onFinish={handleSave}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            {formTypeID != ClaimType.Professional && <FormItem name="diagnosisTypeId" label="Diagnosis Type" rules={[{ required: true }]}>
              <Dropdown
                id="diagnosisTypeId"
                placeholder="Select"
                showClear
                className="w-full"
              />
            </FormItem>}
            <FormItem name="qualifier" label="Qualifier" rules={[{ required: true }]}>
              <Dropdown
                id="qualifier"
                optionLabel="value"
                optionValue="value"
                options={qualifierOptions}
                showClear
                onChange={(event) => handleQualifierChange(event)}
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormListItem name="diagnosisCode" label="Diagnosis" validateDebounce={400} rules={[{ required: true, message: "Diagnosis is required" },
            { validator: validateDiagnosis, message: "Diagnosis code is invalid" }
            ]}>
              <InputText type="text" placeholder="Enter here" />
            </FormListItem>
            <FormItem name="diagnosisDescription" label="Diagnosis Description" rules={[{ required: true }]}>
              <InputTextarea disabled />
            </FormItem>

            {formTypeID != ClaimType.Professional && <Checkbox inputId="isPoa" label={"POA"} checked={false} />}
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancel} />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      )}
    </>
  );
};

export default ClaimDiagnosis;
