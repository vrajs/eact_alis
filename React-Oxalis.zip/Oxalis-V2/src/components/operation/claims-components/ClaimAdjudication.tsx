import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux';
import { RootState } from '../../../Redux/app/store';
import { ClaimType } from '../../../data/constants/AppEnum';
import Button from '../../../controls/Button';
import ClaimServiceServices from '../../../services/ClaimServiceServices';
import ClaimService from '../../../services/ClaimService';
import ClaimEditService from '../../../services/ClaimEditService';
import { ClaimHeaderModel } from '../../../model/ClaimHeaderModel';
import ClaimAdjudicationService from '../../../services/ClaimAdjudicationService';
import usePermissionExists from '../../../hooks/usePermissionExists';
import { Permission } from '../../../data/constants/PermissionConstants';
import { useNavigate } from 'react-router';

const ClaimAdjudication = () => {
  const { claimHeaderID, claimData, formTypeID } = useSelector((state: RootState) => state.claim);
  const { getClaimStatusWithNoDenialCode } = ClaimServiceServices();
  const { checkClaimHasRequireInfoForAdjudication } = ClaimService();
  const { adjudicateClaim } = ClaimAdjudicationService();
  const { checkClaimEditStatusByHeaderId } = ClaimEditService();
  const navigate = useNavigate();

  const [hasDenied, setHasDenied] = useState<boolean>(false);
  const [hasInfo, setHasInfo] = useState<boolean>(false);
  const [noDenial, setNoDenial] = useState<boolean>(false);

  useEffect(() => {
    if (claimHeaderID > 0) {
      const claimStatusReq = getClaimStatusWithNoDenialCode(claimHeaderID);
      const claimReqInfoReq = checkClaimHasRequireInfoForAdjudication(claimHeaderID);
      const claimEditStatusReq = checkClaimEditStatusByHeaderId(claimHeaderID);
      Promise.all([claimStatusReq, claimReqInfoReq, claimEditStatusReq]).then(result => {
        setNoDenial(result[0]);
        setHasInfo(result[1]);
        setHasDenied(result[2]);
      })
    }
  }, [claimHeaderID])

  const handleAutoAdjudicate = async () => {
    if (hasDenied) {
      console.log("denied", hasDenied)
      // show dialog
    }
    else if ((formTypeID == ClaimType.Institutional && usePermissionExists(Permission.permission_to_update_professional_claims)) || (formTypeID == ClaimType.Professional && usePermissionExists(Permission.permission_to_update_institutional_claims))) {
      // this.notificationService.showMessage(AlertMessageType.Error, "Unauthorized");
      return;
    }

    console.log({ noDenial, hasInfo });

    const claimHeader: ClaimHeaderModel = {
      ...claimData,
      isFinal: false
    }

    const claimAdjudicationResponse = await adjudicateClaim(claimHeader);

    if (claimAdjudicationResponse) {
      navigate("/claims/search")
    }
  }

  return (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          <Button outlined label="Auto Adjudicate" onClick={handleAutoAdjudicate} />
        </>
      </div>
    </div>
  )
}

export default ClaimAdjudication