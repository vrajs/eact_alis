import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import CustomForm from "../../../controls/CustomForm";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { useForm } from "rc-field-form";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import { LazyTableState } from "../../../model/LazyTableState";
import { CodeType, CommonCodeFetchingType, ControlType } from "../../../data/constants/AppEnum";
import moment from "moment";
import { GridModel } from "../../../model/GridModel";
import { ClaimOtherPhysicianViewModel } from "../../../model/ClaimOtherPhysicianViewModel";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import ClaimOtherPhysicianService from "../../../services/ClaimOtherPhysicianService";

const OtherPhysicians = () => {
  const [showTable, setShowTable] = useState<boolean>(true);
  const [selectedPhysician, setSelectedPhysician] = useState<ClaimOtherPhysicianViewModel>(null);
  
  
  
  // other physician
  const { claimHeaderID } = useSelector((state: RootState) => state.claim);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const physicianTypeOptions = useCommonCodeSubCategory(CodeType.UBPhysType, CommonCodeFetchingType.Default);
  const qualifierTypeOptions = useCommonCodeSubCategory(CodeType.ANSIqualifier, CommonCodeFetchingType.Default);
  const { createOtherPhysician, updateOtherPhysician, getByClaimHeaderID, getById } = ClaimOtherPhysicianService();
  const [form] = useForm<ClaimOtherPhysicianViewModel>();
  const [gridValues, setGridValues] = useState<ClaimOtherPhysicianViewModel[]>([]);

  const handleAddClick = () => {
    setShowTable(false);
    setSelectedPhysician(null);
  };
  const handleCancel = () => {
    setShowTable(true);
    form.resetFields();
    setSelectedPhysician(null);
  };

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const loadLazyData = async () => {
    if (claimHeaderID > 0) {
      const claimPhysicianResp: GridModel<ClaimOtherPhysicianViewModel> = await getByClaimHeaderID(claimHeaderID, lazyState.first, lazyState.rows);
      console.log("claimPhysicianResp", claimPhysicianResp)
      if (claimPhysicianResp) {
        setGridValues(claimPhysicianResp.data);
        setTotalRecords(claimPhysicianResp.totalCount);
      }
    }
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState]);

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedPhysician(e.value)
    } else {
      setSelectedPhysician(null);
    }
  }

  const handleEdit = async () => {
    if (selectedPhysician.claimOtherPhysicianID) {
      const claimPhysician = await getById(selectedPhysician.claimOtherPhysicianID);      
      form.setFieldsValue({ ...claimPhysician });
      setShowTable(false);
    }
  }

  const initialValues: ClaimOtherPhysicianViewModel = {
    claimOtherPhysicianID: 0,
    claimHeaderID: 0,
    physicianTypeID: 0,
    physicianCode: "",
    qualifierID: 0,
    lastName: "",
    firstName: "",
    addedSource: "",
    url: ""
  }

  const handleSave = async () => {
    console.log(form.getFieldsValue(true));
    let formValue = form.getFieldsValue(true)

    const claimPhysician: ClaimOtherPhysicianViewModel = { ...formValue, claimHeaderID }
    const claimPhysicianResponse = selectedPhysician ? await updateOtherPhysician(claimPhysician) : await createOtherPhysician(claimPhysician);
    if (claimPhysicianResponse) {
      setShowTable(true);
      loadLazyData();
      setSelectedPhysician(null);
      form.resetFields();
    }
  }

  const header = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedPhysician && <Button outlined label="Edit" onClick={handleEdit} />}
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            rowsPerPageOptions={paginatorConstants.pageOptions}
            className="p-datatable-gridlines"
            showGridlines
            header={header}
            rows={lazyState.rows}
            tableStyle={{ minWidth: '50rem' }}
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
            dataKey="claimOtherPhysicianID"
            emptyMessage="No Claim Diagnosis found."
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >
            <Column field="codeTypeID" header="Type" sortable />
            <Column field="codeValue" header="Ref&nbsp;Value" sortable />
            <Column field="effectiveDate" header="Effective&nbsp;Date" sortable />
            <Column field="termDate" header="Term&nbsp;Date" sortable />
          </DataTable>
        </>
      ) : (
        <CustomForm form={form} onFinish={handleSave} initialValues={initialValues}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="physicianTypeID" label="Physician Type" rules={[{ required: true }]}>
              <Dropdown
                id="codeTypeId"
                optionLabel="value"
                optionValue="key"
                options={physicianTypeOptions}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>

            <FormItem name="physicianCode" label="Value" rules={[{ required: true }]}>
              <InputText type="text" placeholder="Enter here" />
            </FormItem>

            <FormItem name="qualifierID" label="Qualifier" rules={[{ required: true }]}>
              <Dropdown
                id="codeTypeId"
                optionLabel="value"
                optionValue="key"
                options={qualifierTypeOptions}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>

            <FormItem name="lastName" label="Last Name" rules={[{ required: true }]}>
              <InputText type="text" placeholder="Enter here" />
            </FormItem>

            <FormItem name="firstName" label="First Name" rules={[{ required: true }]}>
              <InputText type="text" placeholder="Enter here" />
            </FormItem>

          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancel} type="button" />
            <Button label="Save" raised type="submit" />
          </div>
        </CustomForm>
      )}
    </>
  );
};

export default OtherPhysicians;
