import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import CustomForm from "../../../controls/CustomForm";
import Calendar from "../../../controls/Calendar";
import ClaimReferenceService from "../../../services/ClaimReferenceService";
import { ClaimReferenceViewModel } from "../../../model/ClaimReferenceViewModel";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { useForm } from "rc-field-form";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import { LazyTableState } from "../../../model/LazyTableState";
import { KeyValueModel } from "../../../model/KeyValueModel";
import { CodeType, CommonCodeFetchingType, ControlType } from "../../../data/constants/AppEnum";
import CommonCodeService from "../../../services/CommonCodeService";
import { CommonCodeModel } from "../../../model/CommonCodeModel";
import InputNumber from "../../../controls/InputNumber";
import moment from "moment";
import { GridModel } from "../../../model/GridModel";
import useFormattedDate from "../../../hooks/useFormattedDate";
import { MultipleValueRequestModel } from "../../../model/MultipleValueRequestModel";

const ClaimReference = () => {
  const [showTable, setShowTable] = useState<boolean>(true);
  const [selectedReference, setSelectedReference] = useState<ClaimReferenceViewModel>(null); 
  const { createReference, updateReference, deleteReference, getByClaimHeaderID, getById } = ClaimReferenceService();
  const { claimNumber, claimData, claimHeaderID } = useSelector((state: RootState) => state.claim);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [gridValues, setGridValues] = useState<ClaimReferenceViewModel[]>([]);
  const [effectiveDate, setEffectiveDate] = useState<Date | string | null>(null);
  const [form] = useForm<ClaimReferenceViewModel>();
  const { getClaimsType } = CommonCodeService();
  const [types, setTypes] = useState<CommonCodeModel[]>([]);
  const [typeOptions, setTypeOptions] = useState<KeyValueModel[]>([]);
  const [controlTypeID, setControlTypeID] = useState<number>(7701);

  useEffect(() => {
    const reqPaMulCodeType: MultipleValueRequestModel = {
      codeTypeIds: [CodeType.RefValueType],
      fetchingTypeId: CommonCodeFetchingType.ByLongDescription
    }
    const claimTypeRequest = getClaimsType(reqPaMulCodeType);

    Promise.all([claimTypeRequest]).then(result => {
      setTypes(result[0])
    })
  }, [])

  const effectiveDateTemplate = (data: ClaimReferenceViewModel) => {
    return useFormattedDate(data, "effectiveDate")
  }

  const codeValueFormat = (data: ClaimReferenceViewModel) => {
    if (data.controlTypeID === ControlType.Date) {
      return useFormattedDate(data, "codeValue");
    } else if (data.controlTypeID === ControlType.Text || data.controlTypeID === ControlType.Number) {
      const { codeValue } = data;
      return String(codeValue);
    }
  }

  const termDateTemplate = (data: ClaimReferenceViewModel) => {
    return useFormattedDate(data, "termDate")
  }

  useEffect(() => {
    if (types.length > 0) {
      const type = types.map((type: CommonCodeModel) => {
        return { key: type.shortName, value: type.commonCodeID };
      })
      setTypeOptions(type);
    }
  }, [types]);

  const handleTypeChange = (event: DropdownChangeEvent) => {
    if (event.value) {
      const type = types.find((type: CommonCodeModel) => type.commonCodeID === event.value);
      form.setFieldValue("codeValue", null);
      if (type) {
        if (type.controlTypeID === ControlType.Text) {
          setControlTypeID(ControlType.Text);
        } else if (type.controlTypeID === ControlType.Number) {
          setControlTypeID(ControlType.Number);
        } else if (type.controlTypeID === ControlType.Date) {
          setControlTypeID(ControlType.Date);
        }
      }
    }
  }

  const handleEffectiveDate = (event: string) => {
    if (event) {
      setEffectiveDate(event)
    } else {
      setEffectiveDate(null);
    }
  }

  const handleAddClick = () => {
    setShowTable(false);
    setSelectedReference(null);
  };
  const handleCancel = () => {
    setShowTable(true);
    form.resetFields();
    setSelectedReference(null);
  };

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const loadLazyData = async () => {
    if (claimHeaderID > 0) {
      const claimReference: GridModel<ClaimReferenceViewModel> = await getByClaimHeaderID(claimHeaderID, lazyState.first, lazyState.rows);
      console.log("claimReference", claimReference)
      if (claimReference) {
        setGridValues(claimReference.data);
        setTotalRecords(claimReference.totalCount);
      }
    }
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState]);

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedReference(e.value)
    } else {
      setSelectedReference(null);
    }
  }

  const handleEdit = async () => {
    if (selectedReference.claimReferenceID) {
      const claimData = await getById(selectedReference.claimReferenceID);
      let { controlTypeID, codeValue, effectiveDate, termDate } = claimData;
      if (codeValue && controlTypeID === ControlType.Date) {
        codeValue = moment(codeValue).toDate()
      }
      if (effectiveDate) {
        effectiveDate = moment(effectiveDate).toDate();
      }
      if (termDate) {
        termDate = moment(termDate).toDate()
      }
      const bindValue = { ...claimData, termDate, effectiveDate, codeValue, controlTypeID };
      form.setFieldsValue({ ...bindValue });
      setShowTable(false);
    }
  }

  const handleSave = async () => {
    console.log(form.getFieldsValue(true));
    let formValue = form.getFieldsValue(true)
    if (controlTypeID == ControlType.Number) {
      const { codeValue } = formValue;
      formValue = { ...formValue, codeValue: String(codeValue) }
    } else if (controlTypeID == ControlType.Date) {
      const { codeValue } = formValue;
      formValue = { ...formValue, codeValue: moment(codeValue).format("YYYY-MM-DD") }
    }
    const claimReference: ClaimReferenceViewModel = { ...formValue, claimHeaderID, controlTypeID }
    const claimReferenceResponse = selectedReference ? await updateReference(claimReference) : await createReference(claimReference);
    if (claimReferenceResponse) {
      setShowTable(true);
      loadLazyData();
      setSelectedReference(null);
      form.resetFields();
    }
  }

  const header = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedReference && <Button outlined label="Edit" onClick={handleEdit} />}
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            rowsPerPageOptions={paginatorConstants.pageOptions}
            className="p-datatable-gridlines"
            showGridlines
            header={header}
            rows={lazyState.rows}
            tableStyle={{ minWidth: '50rem' }}
            currentPageReportTemplate="{first} to {last} of {totalRecords}"
            dataKey="claimReferenceID"
            responsiveLayout="scroll"
            emptyMessage="No Claim Diagnosis found."
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >
            <Column field="codeTypeID" header="Type" filter sortable />
            <Column field="codeValue" body={codeValueFormat} header="Ref&nbsp;Value" filter sortable />
            <Column field="effectiveDate" body={effectiveDateTemplate} header="Effective&nbsp;Date" filter sortable />
            <Column field="termDate" body={termDateTemplate} header="Term&nbsp;Date" filter sortable />
          </DataTable>
        </>
      ) : (
        <CustomForm form={form} onFinish={handleSave}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="codeTypeID" label="Type" rules={[{ required: true }]}>
              <Dropdown
                id="codeTypeId"
                optionLabel="key"
                optionValue="value"
                options={typeOptions}
                showClear
                onChange={(event) => handleTypeChange(event)}
                placeholder="Select"
                className="w-full"
              />
            </FormItem>

            {controlTypeID === ControlType.Text && <FormItem name="codeValue" label="Ref Value" rules={[{ required: true }]}>
              <InputText type="text" placeholder="Enter here" />
            </FormItem>}
            {controlTypeID === ControlType.Number && <FormItem name="codeValue" label="Ref Value" rules={[{ required: true }]}>
              <InputNumber placeholder="Enter here" useGrouping={false} />
            </FormItem>}

            {controlTypeID === ControlType.Date && <FormItem name="codeValue" label="Ref Value" rules={[{ required: true }]}>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>}
            <FormItem name="effectiveDate" label="Effective Date" rules={[{ required: true }]}>
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                onChange={(event) => handleEffectiveDate(event)}
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                minDate={form.getFieldValue("effectiveDate") ? new Date(form.getFieldValue("effectiveDate")) : null}
                disabled={!form.getFieldValue("effectiveDate")}
              />
            </FormItem>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancel} />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      )}
    </>
  );
};

export default ClaimReference;
