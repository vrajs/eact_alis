import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import ClaimAuditService from "../../../services/ClaimAuditService";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import { LazyTableState } from "../../../model/LazyTableState";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { ClaimAuditViewModel } from "../../../model/ClaimAuditViewModel";
import useFormattedDate from "../../../hooks/useFormattedDate";

const ClaimAudit = () => {
  const { getByClaimHeaderID } = ClaimAuditService();
  const {claimHeaderID} = useSelector((state: RootState) => state.claim);
  const [gridValues, setGridValues] = useState<ClaimAuditViewModel[]>([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: "",
    sortOrder: 1,
    filters: {}
  });

  const loadLazyData = async () => {
    const auditResponse = await getByClaimHeaderID(claimHeaderID, lazyState.first, lazyState.rows);
    console.log("auditResponse", auditResponse)
    if (auditResponse) {
      setGridValues(auditResponse.data);
      setTotalRecords(auditResponse.totalCount);
    }
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState]);

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    console.log("event event", event)
    event['first'] = 0;
    setLazyState(event);
  };

  const dateFormatTemplate = (data: ClaimAuditViewModel) => {
    return useFormattedDate(data, "createdDate");
  }
  
  return (
    <>
      <DataTable
        paginator
        rowsPerPageOptions={paginatorConstants.pageOptions}
        className="p-datatable-gridlines"
        showGridlines
        rows={lazyState.rows}
        tableStyle={{ minWidth: '50rem' }}
        currentPageReportTemplate={`${lazyState.rows + 1} to ${totalRecords} of ${totalRecords}`}
        dataKey="claimAuditID"
        responsiveLayout="scroll"
        emptyMessage="No Group found."
        selectionMode="single"
        lazy onPage={onPage}
        onSort={onSort}
        sortField={lazyState.sortField}
        // sortOrder={lazyState.sortOrder}
        onFilter={onFilter}
        value={gridValues}      
        totalRecords={totalRecords}
        first={lazyState.first}
      >
        <Column field="actionDescription" header="Action" filter sortable />
        <Column field="userInitials" header="User" filter sortable />
        <Column field="createdDate" body={dateFormatTemplate} header="Created&nbsp;Date" filter sortable />
      </DataTable>
    </>
  );
};

export default ClaimAudit;
