import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import CustomForm from "../../../controls/CustomForm";
import InputText from "../../../controls/InputText";
import Checkbox from "../../../controls/CheckBox";
import ClaimServiceServices from "../../../services/ClaimServiceServices";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { KeyValueModel } from "../../../model/KeyValueModel";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import { CodeType, CommonCodeFetchingType } from "../../../data/constants/AppEnum";
import EditCodeService from "../../../services/EditCodeService";
import { EditCodeModel } from "../../../model/EditCodeModel";
import { ClaimServiceViewModel } from "../../../services/ClaimServiceViewModel";
import CommonCodeService from "../../../services/CommonCodeService";
import { CommonCodeModel } from "../../../model/CommonCodeModel";
import { useForm } from "rc-field-form";
import { ClaimEditViewModel } from "../../../model/ClaimEditViewModel";
import ClaimEditService from "../../../services/ClaimEditService";
import { LazyTableState } from "../../../model/LazyTableState";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import useFormattedDate from "../../../hooks/useFormattedDate";
import { MultipleValueRequestModel } from "../../../model/MultipleValueRequestModel";

const ClaimEdits = () => {
  const [showTable, setShowTable] = useState<boolean>(true);
  const [isOverRide, setIsOverRide] = useState(false); // Checkbox state
  const { claimServices } = ClaimServiceServices();
  const { claimHeaderID } = useSelector((state: RootState) => state.claim);
  const editStatus = useCommonCodeSubCategory(CodeType.EditReason, CommonCodeFetchingType.Default);
  const { getEditCodes } = EditCodeService();
  const [editCodes, setEditCodes] = useState<EditCodeModel[]>([]);
  const [editCodeOptions, setEditCodeOptions] = useState<KeyValueModel[]>([]);
  const [services, setServices] = useState<ClaimServiceViewModel[]>([]);
  const [serviceOptions, setServiceOptions] = useState<KeyValueModel[]>([]);
  const [outcomeReasons, setOutComeReason] = useState<CommonCodeModel[]>([]);
  const [outcomeReasonsOptions, setOutComeReasonOptions] = useState<KeyValueModel[]>([]);
  const { getById, createEdit, updateEdit, claimEditGrid } = ClaimEditService();
  const { getClaimsType } = CommonCodeService();
  const [form] = useForm<ClaimEditViewModel>();
  const [gridValues, setGridValues] = useState<ClaimEditViewModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [selectedClaimEdit, setSelectedClaimEdit] = useState<ClaimEditViewModel | null>(null);
  const initialValues: ClaimEditViewModel = {
    claimEditsID: 0,
    claimHeaderID: 0,
    claimLineID: 0,
    editCode: "",
    editDescription: "",
    outComeID: 0,
    outComeCodeID: 0,
    comments: "",
    editCodeID: 0,
    isOverride: false,
    lastUpdatedDate: "",
    lastUpdatedBy: "",
    addedSource: "",
    url: "",
    outCome: "",
    outComeCode: "",
    lineNumber: 0,
    recordDisplayOrder: 0,
    isFreezedEditCode: 0
  }

  useEffect(() => {
    if (claimHeaderID > 0) {
      const claimService = claimServices(claimHeaderID);
      const editCodes = getEditCodes();
      const reqPaMulCodeType: MultipleValueRequestModel = {
        codeTypeIds: [CodeType.ClaimPend, CodeType.ClaimDeny],
        fetchingTypeId: CodeType.ClaimPend,
      }
      const claimTypeRequest = getClaimsType(reqPaMulCodeType);

      Promise.all([claimService, editCodes, claimTypeRequest]).then(result => {
        setServices(result[0]);
        setEditCodes(result[1]);
        setOutComeReason(result[2]);
      })
    }
  }, [claimHeaderID])

  useEffect(() => {
    if (editCodes.length > 0) {
      const codes = editCodes.map(editCode => {
        const { code: key, code: value, codeName: description } = editCode;
        return { key: editCode.code, value: `${editCode.code} - ${editCode.codeName}` };
      })
      setEditCodeOptions(codes);
    }
  }, [editCodes])

  useEffect(() => {
    if (services.length > 0) {
      const serviceMap = services.map((service: ClaimServiceViewModel, index: number) => {
        return { key: index + 1, value: service.claimServiceID };
      })
      setServiceOptions(serviceMap);
    }
  }, [services]);

  useEffect(() => {
    if (outcomeReasons.length > 0) {
      const reasons = outcomeReasons.map((commonCode: CommonCodeModel, index: number) => {
        return { key: commonCode.shortName, value: commonCode.commonCodeID };
      })
      setOutComeReasonOptions(reasons);
    }
  }, [outcomeReasons])

  const handleCodeChange = (event: DropdownChangeEvent) => {
    console.log(event.value);
    console.log(editCodes[0])
    const editCode = editCodes.find(editCode => editCode.code == event.value);
    form.setFieldValue("editDescription", editCode.codeName);
    form.setFieldValue("editCodeID", event.value);
  }

  const handleOutComeChange = (event: DropdownChangeEvent) => {
    console.log(event);
    console.log(outcomeReasons[0]);
    // const outCome = outcomeReasons.find(reason => reason.)
  }

  const handleSave = async () => {
    console.log(form.getFieldsValue(true));
    const formValue = form.getFieldsValue(true);
    const claimEditValue: ClaimEditViewModel = { ...formValue, claimHeaderID, claimLineID: formValue.lineNumber }
    const claimEditResponse = selectedClaimEdit ? await updateEdit(claimEditValue) : await createEdit(claimEditValue);
    if (claimEditResponse) {
      setShowTable(true);
      form.resetFields();
      loadLazyData();
      setSelectedClaimEdit(null);
      setIsOverRide(false);
    }
  }

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const loadLazyData = async () => {
    const claimEditResponse = await claimEditGrid(claimHeaderID, lazyState.first, lazyState.rows);
    console.log("claimEditResponse", claimEditResponse)
    if (claimEditResponse) {
      setGridValues(claimEditResponse.data);
      setTotalRecords(claimEditResponse.totalCount);
    }
  };

  useEffect(() => {
    if (claimHeaderID > 0) {
      loadLazyData();
    }
  }, [lazyState, claimHeaderID]);

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedClaimEdit(e.value)
    } else {
      setSelectedClaimEdit(null);
    }
  }

  const dateFormat = (data: ClaimEditViewModel) => {
    return useFormattedDate(data, "lastUpdatedDate");
  }

  const handleEdit = async () => {
    if (selectedClaimEdit) {
      const claimEditData = await getById(selectedClaimEdit.claimEditsID);
      if (claimEditData) {
        const { isOverride } = claimEditData;
        setIsOverRide(isOverride)
        form.setFieldsValue({ ...claimEditData });
        setShowTable(false);
      }
    }
  }

  const handleAddClick = () => {
    setShowTable(false);
    setSelectedClaimEdit(null);
  };

  const handleCancel = () => {
    setShowTable(true);
    setSelectedClaimEdit(null);
    form.resetFields();
    setIsOverRide(false);
  };

  const handleCheckboxChange = () => {
    setIsOverRide((prev) => !prev); // Toggle the checked state
  };

  const header = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedClaimEdit && <Button outlined label="Edit" onClick={handleEdit} />}
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            rowsPerPageOptions={paginatorConstants.pageOptions}
            className="p-datatable-gridlines"
            showGridlines
            header={header}
            rows={lazyState.rows}
            tableStyle={{ minWidth: '50rem' }}
            currentPageReportTemplate="{first} to {last} of {totalRecords}"
            dataKey="claimEditsID"
            responsiveLayout="scroll"
            emptyMessage="No Group found."
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >
            <Column field="lineNumber" header="Line&nbsp;Number" filter sortable />
            <Column field="editCode" header="Edit&nbsp;Code" filter sortable />
            <Column field="editDescription" header="Edit&nbsp;Description" filter sortable />
            <Column field="outCome" header="Edit&nbsp;Status" filter sortable />
            <Column field="outComeCode" header="Outcome&nbsp;Reason" filter sortable />
            <Column field="comments" header="Comments" filter sortable />
            <Column field="lastUpdatedDate" body={dateFormat} header="Date" filter sortable />
            <Column field="lastUpdatedBy" header="Updated&nbsp;By" filter sortable />
          </DataTable>
        </>
      ) : (
        <CustomForm form={form} onFinish={handleSave} initialValues={initialValues}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3 items-center">
            <FormItem name="lineNumber" label="Line Number" rules={[{ required: true }]}>
              <Dropdown
                id="line"
                options={serviceOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="editCode" label="Edit Code" rules={[{ required: true }]}>
              <Dropdown
                id="editCode"
                options={editCodeOptions}
                optionLabel="value"
                optionValue="key"
                showClear
                placeholder="Select"
                className="w-full"
                onChange={handleCodeChange}
              />
            </FormItem>
            <FormItem name="editDescription" label="Description">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="outComeID" label="Status" rules={[{ required: true }]}>
              <Dropdown
                id="status"
                options={editStatus}
                optionLabel="value"
                optionValue="key"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="outComeCodeID" label="Outcome Reason">
              <Dropdown
                id="reason"
                options={outcomeReasonsOptions}
                optionLabel="key"
                optionValue="value"
                showClear
                placeholder="Select"
                className="w-full"
                onChange={handleOutComeChange}
              />
            </FormItem>
            <FormItem name="comments" label="Comments">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem label="" name="isOverride">
              <Checkbox
                inputId="isOverride"
                label={"Is Override"}
                checked={isOverRide}
                onChange={handleCheckboxChange} // Handle checkbox change
              />
            </FormItem>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancel} />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      )}
    </>
  );
};

export default ClaimEdits;
