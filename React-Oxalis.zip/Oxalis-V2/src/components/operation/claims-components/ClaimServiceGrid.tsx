import React from 'react'

const ClaimServiceGrid = () => {
  return (
    <div>ClaimServiceGrid</div>
  )
}

export default ClaimServiceGrid