import { Panel } from "primereact/panel";
import { useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import Dropdown from "../../../controls/Dropdown";
import InputNumber from "../../../controls/InputNumber";
import InputMask from "../../../controls/InputMask";
import Calendar from "../../../controls/Calendar";
import Button from "../../../controls/Button";
import { useNavigate, useParams } from "react-router-dom";
import CustomForm from "../../../controls/CustomForm";
import { Field, useForm } from "rc-field-form";
import FormItem from "../../../controls/FormItem";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import { CodeType, CommonCodeFetchingType, Country, Page } from "../../../data/constants/AppEnum";
import useCommonCodeConfiguration from "../../../hooks/useCommonCodeConfiguration";
import ZipCodeService from "../../../services/ZipCodeService";
import { KeyValueModel } from "../../../model/KeyValueModel";
import { ZipCodeModel } from "../../../model/ZipCodeModel";
import AutoComplete from "../../../controls/AutoComplete";
import { CityModel } from "../../../model/CityModel";
import { CountyModel } from "../../../model/CountyModel";
import LocationService from "../../../services/LocationService";
import moment from "moment";
import { InputSwitch, InputSwitchChangeEvent } from "primereact/inputswitch";
import { REGEX_CONSTANTS } from "../../../data/constants/RegexConstants";
import { LocationModel, LocationTimeForm } from "../../../model/LocationModel";
import FormListItem from "../../../controls/FormListItem";
import { SwitchModel } from "../../../model/SwitchModel";
import { useToaster } from "../../../layout/context/toastContext";
import { useDispatch, useSelector } from "react-redux";
import { AppDispatch, RootState } from "../../../Redux/app/store";
import { ClearKey } from "../../../Redux/features/keyboardShortcutSlice";
import { Dialog } from "primereact/dialog";
import { DropdownChangeEvent } from "primereact/dropdown";
import { getCities, getCounties, getStates, getZipCodes } from "../../../Redux/features/locationSlice";
import useErrorHandler from "../../../hooks/useErrorHandler";

interface OfficeTimings {
  day: string;
  fromName: string;
  toName: string;
  isWeekDay: boolean;
}

const LocationAddEdit = () => {
  const navigate = useNavigate();
  const days: OfficeTimings[] = [
    { day: "Monday", fromName: "mondayFromHour", toName: "mondayToHour", isWeekDay: true },
    { day: "Tuesday", fromName: "tuesdayFromHour", toName: "tuesdayToHour", isWeekDay: true },
    { day: "Wednesday", fromName: "wednesdayFromHour", toName: "wednesdayToHour", isWeekDay: true },
    { day: "Thursday", fromName: "thursdayFromHour", toName: "thursdayToHour", isWeekDay: true },
    { day: "Friday", fromName: "fridayFromHour", toName: "fridayToHour", isWeekDay: true },
    { day: "Saturday", fromName: "saturdayFromHour", toName: "saturdayToHour", isWeekDay: false },
    { day: "Sunday", fromName: "sundayFromHour", toName: "sundayToHour", isWeekDay: false },
  ];
  const [showTimer, setShowTimer] = useState<boolean>(false);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const { zipCodes, cities, counties, states } = useSelector((state: RootState) => state.location);
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const [form] = useForm();
  const [timingForm] = useForm<LocationTimeForm>();
  const addressTypeOptions = useCommonCodeSubCategory(CodeType.AddressType, CommonCodeFetchingType.Default);
  const afterHoursOptions = useCommonCodeSubCategory(CodeType.AfterHoursCoverage, CommonCodeFetchingType.Default);
  const genderOptions = useCommonCodeConfiguration(Page.MEMBER_ADD_EDIT, CodeType.Gender);
  const { getZipCodeCountry } = ZipCodeService();
  const [countryOptions, setCountryOptions] = useState<KeyValueModel[]>([]);
  // const [states, setStates] = useState<KeyValueModel[]>([]);
  const [zipCodeOptions, setZipCodeOptions] = useState<KeyValueModel[]>([]);
  const [cityOptions, setCityOptions] = useState<KeyValueModel[]>([]);
  // const [counties, setCounties] = useState<CountyModel[]>([]);
  const [countyOptions, setCountyOptions] = useState<KeyValueModel[]>([]);
  // const [cities, setCities] = useState<CityModel[]>([]);
  const { locationId } = useParams();
  const { createLocation, updateLocation, getById } = LocationService();
  const { isSave, isAdd } = useSelector((state: RootState) => state.keyboardShortCut);
  const { showToast } = useToaster();
  const dispatch = useDispatch<AppDispatch>();
  const [isUpdate, setIsUpdate] = useState<boolean>(false);
  const validateZipCode = (rule, value) => {
    const regexValid = REGEX_CONSTANTS.ZIP_CODE.test(value);
    return new Promise((resolve, reject) => {
      if (!regexValid) {
        resolve(undefined);
        return;
      }
      if (regexValid) {
        const zipCodeExists = zipCodeOptions.some(zipCode => zipCode.key === value);
        if (!zipCodeExists) {
          reject(new Error("Zip code does not match"))
          return;
        }
      }
      resolve(undefined);
      return;
    });
  }

  const minAgeValidator = async (rule, value) => {
    const maxAge = form.getFieldValue("maximumAge");
    if (!maxAge) {
      return Promise.resolve(null);
    }
    if (value > maxAge) {
      return Promise.reject("Min age is invalid");
    }
  }

  const maxAgeValidator = async (rule, value) => {
    const minAge = form.getFieldValue("minimumAge");
    if (!minAge) {
      return Promise.resolve(null);
    }
    if (value < minAge) {
      return Promise.reject("Max age is invalid");
    }
  }

  const setWeekDayTime = () => {
    setShowTimer(true);
  }

  const emailValidator = async (rule, value) => {
    if (!value) {
      return Promise.resolve(null);
    }
    const isValid: boolean = REGEX_CONSTANTS.EMAIL.test(value);
    if (!isValid) {
      return Promise.reject("Email is invalid");
    }
    return Promise.resolve(null);
  }

  const handleHide = () => {
    setShowTimer(false);
    timingForm.resetFields();
  }

  useEffect(() => {
    dispatch(ClearKey());
  }, [isAdd])

  const handleSave = async () => {
    const formValues = form.getFieldsValue(true);
    const locationModel: LocationModel = { ...formValues }
    days.forEach(day => {
      locationModel[day.fromName] = form.getFieldValue(`${day.fromName}`) ? moment(form.getFieldValue(`${day.fromName}`)).format("HH:mm:ss") : "";
      locationModel[day.toName] = form.getFieldValue(`${day.toName}`) ? moment(form.getFieldValue(`${day.toName}`)).format("HH:mm:ss") : "";
    })
    setIsSubmitting(true);
    try {
      const locationResponse = Number(locationId) > 0 ? await updateLocation(locationModel) : await createLocation(locationModel);

      if (locationResponse) {
        if (!locationId) {
          navigate("/location");
        } else {
          setIsUpdate((prevState) => !prevState);
        }
        form.resetFields();
        showToast({ severity: 'success', summary: 'Success', detail: "Location data saved successfully" });
      }
    }
    catch (error) {
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    } finally {
      setIsSubmitting(false);
    }

  }

  useEffect(() => {
    if (isSave) {
      handleSave();
      dispatch(ClearKey());
    }
  }, [isSave])

  const handleZipCodeChange = (event) => {
    const zipCode = zipCodes.find(zip => zip.code === event);
    if (zipCode) {
      // form.setFieldValue("country", zipCode.country);
      form.setFieldValue("country", Country.USA);
      form.setFieldValue("city", zipCode.city);
      form.setFieldValue("county", zipCode.county);
      form.setFieldValue("state", zipCode.state);
      form.setFieldValue("stateFullName", zipCode.stateFullName);
    }
  }

  const handleEffectiveDateChange = (event: Date) => {
    setEffectiveDate(event);
  }

  const handleCancel = () => {
    navigate("/location");
  }

  const handleTimeSave = () => {
    const fromTime = timingForm.getFieldValue("from") ? moment(timingForm.getFieldValue("from")).toDate() : null;
    const toTime = timingForm.getFieldValue("to") ? moment(form.getFieldValue(`${timingForm.getFieldValue("to")}`)).toDate() : "";
    days.forEach((day: OfficeTimings) => {
      if (day.isWeekDay) {
        form.setFieldValue(day.fromName, fromTime);
        form.setFieldValue(day.toName, toTime);
      }
    })
    setShowTimer(false);
    timingForm.resetFields();
  }

  const [switches, setSwitches] = useState<SwitchModel[]>([
    { label: "PCP", name: "isPCP", id: "pcp", value: false, show: true },
    { label: "Handicap Accessible", name: "isHandicapAccessible", id: "handicap", value: false, show: true },
    { label: "Accepting New Patient", name: "isAcceptingNewPatient", id: "accepting", value: false, show: true },
    { label: "Include In Provider Directory", name: "isIncludeInProviderDirectory", id: "include", value: false, show: true },
  ]);

  const handleSwitchChange = (event: InputSwitchChangeEvent, index) => {
    setSwitches((prevState) => {
      prevState[index].value = event.value
      return [...prevState]
    })
  }

  const getLocation = async () => {
    const locationResponse = await getById(Number(locationId));

    days.forEach(day => {
      if (locationResponse[day.fromName]) {
        const [hour, minute, second] = locationResponse[day.fromName].split(":");
        locationResponse[day.fromName] = moment().hour(hour).minute(minute).second(second).toDate();
      }

      if (locationResponse[day.toName]) {
        const [hour, minute, second] = locationResponse[day.toName].split(":");
        locationResponse[day.toName] = moment().hour(hour).minute(minute).second(second).toDate();
      }
    })

    switches.forEach((eachSwitch: SwitchModel, index: number) => {
      const { name } = eachSwitch;
      if (locationResponse[name]) {
        setSwitches((prevState) => {
          prevState[index].value = locationResponse[name]
          return [...prevState]
        })
      }
    })

    console.log("locationResponse", locationResponse)
    form.setFieldsValue({ ...locationResponse, effectiveDate: moment(locationResponse.effectiveDate).toDate(), termDate: locationResponse.termDate ? moment(locationResponse.termDate).toDate() : null })

  };

  useEffect(() => {
    const countryRequest = getZipCodeCountry();
    Promise.all([countryRequest]).then(result => {
      setCountryOptions(result[0]);
    })
    dispatch(getCities());
    dispatch(getStates());
    dispatch(getCounties());
  }, [])

  useEffect(() => {
    if (Number(locationId) > 0) {
      getLocation();
    }
  }, [locationId, isUpdate])

  useEffect(() => {
    if (zipCodes?.length == 0) {
      dispatch(getZipCodes());
    }
  }, [zipCodes])

  useEffect(() => {
    const zipKeyValues = zipCodes.map((zip: ZipCodeModel) => {
      return { key: zip.code, value: zip.code };
    });
    setZipCodeOptions(zipKeyValues);
  }, [zipCodes])

  useEffect(() => {
    const city = cities.map((zip: CityModel) => {
      return { key: zip.city, value: zip.city };
    });
    setCityOptions(city);
  }, [cities])

  useEffect(() => {
    const county = counties.map((county: CountyModel) => {
      return { key: county.county, value: county.county };
    });
    setCountyOptions(county);
  }, [counties])

  const handleNavigate = () => {
    navigate("/location");
  };

  // const initialValues = {
  //   genderRestriction: null,
  //   afterHoursCoverage: null,
  //   effectiveDate: null,
  //   termDate: null
  // }
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Location Configuration
      </h2>
      <Panel header="Location Information" toggleable className="mb-4">
        <CustomForm form={form} onFinish={handleSave}>
          <div className="pb-4">
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">
              <FormItem name="locationTypeID" label="Address Type" rules={[
                { required: true }
              ]}>
                <Dropdown
                  id="addresstype"
                  options={addressTypeOptions}
                  optionLabel="value"
                  optionValue="key"
                  placeholder="Select"
                  showClear
                  className="w-full"
                />
              </FormItem>

              <FormItem name="locationName" label="Office Name" rules={[
                { required: true }
              ]}>
                <InputText type="text" placeholder="Enter here" />
              </FormItem>

              <FormItem name="address1" label="Address 1" rules={[
                { required: true }
              ]}>
                <InputText type="text" placeholder="Enter here" />
              </FormItem>

              <FormItem name="address2" label="Address 2">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>

              <FormListItem name="zip" label="Zip Code" rules={[
                { required: true, message: "Zip code is required" },
                { pattern: REGEX_CONSTANTS.ZIP_CODE, message: "Zip code is invalid" },
                { validator: validateZipCode, message: "Zip code does not match" }
              ]}>
                <AutoComplete id="zipcode" placeholder="Enter Zip code" field="value" suggestions={zipCodeOptions} minLength={2} onChange={handleZipCodeChange} />
              </FormListItem>

              <FormItem name="city" label="City" rules={[
                { required: true },
              ]}>
                {/* <Dropdown
                  id="City"
                  options={cityOptions}
                  optionLabel="value"
                  optionValue="key"
                  showClear
                  placeholder="Select"
                  className="w-full"
                /> */}
                <AutoComplete id="city" field="value" placeholder="Enter City" disabled suggestions={cityOptions} minLength={2} />
              </FormItem>

              <FormItem name="state" label="State" rules={[
                { required: true },
              ]}>
                <Dropdown
                  id="state"
                  filter
                  options={states}
                  optionLabel="value"
                  optionValue="key"
                  placeholder="Select"
                  showClear
                  className="w-full"
                  disabled
                />
                {/* <AutoComplete id="state" field="value" placeholder="Enter City" suggestions={stateOptions} minLength={2} itemTemplate={stateTemplate} /> */}
              </FormItem>

              <FormItem name="county" label="County" rules={[
                { required: true },
              ]}>
                {/* <Dropdown
                  id="county"
                  options={countyOptions}
                  optionValue="key"
                  optionLabel="value"
                  placeholder="Select"
                  showClear
                  className="w-full"
                  readOnly
                /> */}
                <AutoComplete id="state" field="key" placeholder="Enter County" readOnly suggestions={countyOptions} minLength={2} disabled />
              </FormItem>

              <FormItem name="country" label="Country">
                {/* <Dropdown
                  id="country"
                  options={countryOptions}
                  optionLabel="key"
                  optionValue="value"
                  placeholder="Select"
                  showClear
                  className="w-full"
                /> */}
                <AutoComplete id="country" field="value" placeholder="Enter Country" readOnly suggestions={countryOptions} minLength={2} disabled />
              </FormItem>
            </div>
          </div>
          <div className="pb-4">
            <h5 className="border-bottom-1 pb-3 mb-3">Other Details</h5>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">
              <FormItem name="phone" label="Phone">
                <InputMask mask="(999) 999-9999" inputClassName="w-full" placeholder="Enter here" unmask={true} />
              </FormItem>
              <FormItem name="fax" label="Fax">
                <InputMask mask="999-999-9999" inputClassName="w-full" placeholder="Enter here" unmask={true} />
              </FormItem>
              <FormItem name="emergencyPhone" label="Emergency Phone">
                <InputMask mask="(999) 999-9999" inputClassName="w-full" placeholder="Enter here" unmask={true} />
              </FormItem>
              <FormItem name="secondaryPhone" label="Secondary Phone">
                <InputMask mask="(999) 999-9999" inputClassName="w-full" placeholder="Enter here" unmask={true} />
              </FormItem>
              <FormListItem
                name="primaryEmail"
                label="Primary Email"
                rules={[{ validator: emailValidator, message: "Email is invalid" }]}
              >
                <InputText type="email" placeholder="Enter here" />
              </FormListItem>
              <FormListItem
                name="secondaryEmail"
                label="Secondary Email"
                rules={[{ validator: emailValidator, message: "Email is invalid" }]}
              >
                <InputText type="email" placeholder="Enter here" />
              </FormListItem>
              <FormItem name="afterHoursCoverage" label="After Hours Coverage" rules={[{ required: true }]}>
                <Dropdown
                  id="afterhours"
                  options={afterHoursOptions}
                  optionLabel="value"
                  optionValue="value"
                  placeholder="Select"
                  onChange={(event: DropdownChangeEvent) => form.setFieldValue("afterHoursCoverage", event.value)}
                  showClear
                  className="w-full"
                />
              </FormItem>
              <FormListItem name="minimumAge" label="Age From" rules={[{ required: true, message: "Age From is required" }, {validator: minAgeValidator, message: "Min age is invalid"}]}>
                <InputNumber type="text" placeholder="Enter here" min={0} useGrouping={false} max={120} />
              </FormListItem>
              <FormListItem name="maximumAge" label="Age To" rules={[{ required: true, message: "Age To is required" }, {validator: maxAgeValidator, message: "Max age is invalid"}]}>
                <InputNumber type="text" placeholder="Enter here" min={0} useGrouping={false} max={120}/>
              </FormListItem>
              <FormItem name="genderRestriction" label="Gender Restrictions" rules={[{ required: true }]}>
                <Dropdown
                  id="gender"
                  options={genderOptions}
                  optionLabel="value"
                  optionValue="key"
                  placeholder="Select"
                  showClear
                  className="w-full"
                  onChange={(event: DropdownChangeEvent) => form.setFieldValue("genderRestriction", event.value)}
                />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  onChange={(event) => handleEffectiveDateChange(event as Date)}
                  dateFormat="mm/dd/yy"
                />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={form.getFieldValue("effectiveDate") ? form.getFieldValue("effectiveDate") : null}
                  disabled={!form.getFieldValue("effectiveDate")}
                />
              </FormItem>
            </div>
          </div>
          <div className="pb-4">
            <div className="flex flex-row justify-between items-center border-bottom-1 pb-3 mb-3">
              <h5 >Office Timings</h5>
              <Button label="Set Weekday Timing" type="button" onClick={setWeekDayTime} />
            </div>
            <div className="!grid xl:grid-cols-7 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 !gap-6">
              {days.map((officeTiming: OfficeTimings, index) => (
                <div key={index} className="border-1 surface-border border-round p-fluid text-center">
                  <span className="text-900 font-bold block border-bottom-1 surface-border p-3">{officeTiming.day}</span>
                  <div className="p-3 flex flex-col gap-3">
                    <div>
                      <Field name={officeTiming.fromName} >
                        <Calendar id={`calendar-from-${index}`} placeholder="From" icon="cl_clock" iconPos="right" timeOnly />
                      </Field>
                    </div>
                    <div>
                      <Field name={officeTiming.toName} >
                        <Calendar id={`calendar-to-${index}`} placeholder="To" icon="cl_clock" iconPos="right" timeOnly />
                      </Field>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="pb-4">
            <div className="flex flex-wrap gap-4">
              {switches.map((switchItem: SwitchModel, index: number) => (
                <div key={index} className="flex align-items-center gap-2">
                  <label className="font-medium font-base" htmlFor={switchItem.id}>{switchItem.label}</label>
                  <Field name={switchItem.name} >
                    <InputSwitch id={switchItem.id} checked={switchItem.value} onChange={(event) => handleSwitchChange(event, index)} />
                  </Field>
                </div>
              ))}
            </div>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancel} type="button" />
            <Button label="Save" raised disabled={isSubmitting} type="submit" />
          </div>
        </CustomForm>
      </Panel>

      <Dialog header="Select Weekday timing" visible={showTimer} modal onHide={handleHide} draggable={false}>
        <CustomForm form={timingForm} onFinish={handleTimeSave}>
          <div className="pb-4 flex flex-row gap-3">
            <div>
              <FormListItem name="from" rules={[{ required: true, message: "From time is required" }]} label={""}>
                <Calendar id="weekday-from" placeholder="From" icon="cl_clock" iconPos="right" timeOnly />
              </FormListItem>
            </div>
            <div>
              <Field name="to" >
                <Calendar id="weekday-to" placeholder="To" icon="cl_clock" iconPos="right" timeOnly />
              </Field>
            </div>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={() => setShowTimer(false)} type="button" />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      </Dialog>
    </>
  );
};

export default LocationAddEdit;
