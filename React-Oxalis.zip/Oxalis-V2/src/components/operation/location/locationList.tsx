import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import Button from "../../../controls/Button";
import { useEffect, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { LazyTableState } from "../../../model/LazyTableState";
import { LocationModel } from "../../../model/LocationModel";
import LocationService from "../../../services/LocationService";
import moment from "moment";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import { TableColumnModel } from "../../../model/TableColumnModel";
import { Panel } from "primereact/panel";
import * as XLSX from 'xlsx';
import CustomForm from "../../../controls/CustomForm";
import { useForm } from "rc-field-form";
import { useToaster } from "../../../layout/context/toastContext";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import { CodeType, CommonCodeFetchingType } from "../../../data/constants/AppEnum";
import InputText from "../../../controls/InputText";
import { LocationSearchModel } from "../../../model/LocationSearchModel";
import ZipCodeService from "../../../services/ZipCodeService";
import { useDispatch, useSelector } from "react-redux";
import { AddCities, AddCounties, AddStates, AddZipCodes, getCities, getCounties, getStates, getZipCodes } from "../../../Redux/features/locationSlice";
import { AppDispatch, RootState } from "../../../Redux/app/store";
import { ClearKey } from "../../../Redux/features/keyboardShortcutSlice";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";
import useErrorHandler from "../../../hooks/useErrorHandler";
import useLocalStorage from "../../../core/auth/hooks/useLocalStorage";

const LocationList = () => {
  const navigate = useNavigate();
  const [gridValues, setGridValues] = useState<LocationModel[]>([]);
  const [selectedLocation, setSelectedLocation] = useState<LocationModel | null>(null);
  const [totalRecords, setTotalRecords] = useState(0);
  const { locationGrid, exportLocation, deleteLocation } = LocationService();  
  const ref = useRef<Panel>(null);
  const [form] = useForm<LocationSearchModel>();
  const { showToast } = useToaster();
  const dispatch = useDispatch<AppDispatch>();
  const addressTypeOptions = useCommonCodeSubCategory(CodeType.AddressType, CommonCodeFetchingType.Default);
  const { zipCodes, cities, counties, states } = useSelector((state: RootState) => state.location);
  const { isEdit, isAdd, isExport, isSearch, isDelete } = useSelector((state: RootState) => state.keyboardShortCut);
  const [showConfirm, setShowConfirm] = useState<boolean>(false);  

  const handleView = () => {
    navigate("/location/location-view");
  };
  const handleAdd = () => {
    navigate("/location/location-add-edit");
  };
  const handleEdit = () => {
    if (selectedLocation) {
      navigate(`/location/location-add-edit/${selectedLocation.locationID}`);
    }
  }

  useEffect(() => {
    if (isSearch) {
      ref.current.expand(undefined);
    }
    dispatch(ClearKey());
  }, [isSearch])

  useEffect(() => {
    if (isExport) {
      handleExport();
    }
    dispatch(ClearKey());
  }, [isExport])

  useEffect(() => {
    if (isDelete) {
      handleDelete();
    }
    dispatch(ClearKey());
  }, [isDelete])

  useEffect(() => {
    if (isEdit && selectedLocation) {
      handleEdit();
    }
    dispatch(ClearKey());
  }, [isEdit])

  useEffect(() => {
    if (isAdd) {
      handleAdd();
    }
    dispatch(ClearKey());
  }, [isAdd])

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: "",
    sortOrder: 0,
    filters: {}
  });

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedLocation) {
      try {
        const deleteResponse = await deleteLocation(selectedLocation.locationID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "Group deleted successfully" });
          form.resetFields();
          loadLazyData();
          setSelectedLocation(null);
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setSelectedLocation(null);
  }

  const handleDelete = () => {
    if (selectedLocation) {
      setShowConfirm(true);
    }
  }

  useEffect(() => {
    if (zipCodes?.length == 0) {
      dispatch(getZipCodes());
    }
  }, [zipCodes])

  useEffect(() => {
    dispatch(getCities());
    dispatch(getStates());
    dispatch(getCounties());
  }, [])

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    ref.current.collapse(undefined)
    const searchForm: LocationSearchModel = form.getFieldsValue(true);

    const locationGridResponse = await locationGrid(searchForm?.officeName ?? "", searchForm?.addressType ?? null, query);
    if (locationGrid) {
      setGridValues(locationGridResponse.data);
      setTotalRecords(locationGridResponse.totalCount);
    }
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState]);

  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    console.log("event event", event)
    event['first'] = 0;
    setLazyState(event);
  };

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedLocation(e.value)
    } else {
      setSelectedLocation(null);
    }
  }

  const termDateFormatTemplate = (value) => {
    const termDate = value.termDate;
    if (termDate) {
      return moment(termDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const effectiveDateFormatTemplate = (value) => {
    const effectiveDate = value.effectiveDate;
    if (effectiveDate) {
      return moment(effectiveDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const handleCancel = () => {
    form.resetFields();
    ref.current.collapse(undefined);
    loadLazyData();
  }

  const handleExport = async () => {
    const locationData = await exportLocation();

    const locations = locationData.map((a: LocationModel) => {
      const { locationID: ID, locationName, address1, phone: Phone, primaryEmail, effectiveDate, termDate } = a;
      return { ID, 'Office Name': locationName, 'Address': address1, Phone, 'Primary Email': primaryEmail, 'Effective Date': moment(effectiveDate).toDate(), 'Term Date': termDate ? moment(termDate).toDate() : null }
    })
    const ws = XLSX.utils.json_to_sheet(locations);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Location List");
    XLSX.writeFile(wb, "Location.xlsx");
    showToast({ severity: 'success', summary: 'Success', detail: "File downloaded successfully" });
  }

  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;

    return (
      <div className={className}>
        <div className="font-bold">Advance Search</div>
        <div className="flex align-items-center gap-2">
          <Button outlined label="Add" onClick={handleAdd} tooltip="Alt + A" />
          {selectedLocation && <Button outlined label="Edit" onClick={handleEdit} tooltip="Alt + E" />}
          {selectedLocation && <Button outlined label="Delete" onClick={handleDelete} tooltip="Alt + D"/>}
          <Button label="Export" outlined onClick={handleExport} tooltip="Alt + X" />
          {options.togglerElement}
        </div>
      </div>
    );
  };

  return (
    <>
      <h2 className="pb-4">Location</h2>
      <Panel toggleable className="m-0 search-panel" headerTemplate={headerTemplate} ref={ref} collapsed>
        <CustomForm form={form} onFinish={loadLazyData}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="addressType" label="Address Type">
              <Dropdown
                id="dropdown"
                options={addressTypeOptions}
                optionLabel="value"
                optionValue="key"
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>

            <FormItem name="officeName" label="Office Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>

          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="clear" text onClick={handleCancel} type="button" />
            <Button label="Apply" outlined type="submit" />
            {/* <Button label="Apply & Save" raised onClick={handleFilterSave} /> */}
          </div>
        </CustomForm>
      </Panel>
      <DataTable
        paginator
        rowsPerPageOptions={paginatorConstants.pageOptions}
        className="p-datatable-gridlines"
        showGridlines
        rows={lazyState.rows}
        // header={header1}
        tableStyle={{ minWidth: '50rem' }}
        paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
        currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
        dataKey="providerID"
        emptyMessage={paginatorConstants.emptyMessage}
        selectionMode="single"
        lazy onPage={onPage}
        onSort={onSort}
        sortField={lazyState.sortField}
        sortOrder={lazyState.sortOrder}
        onFilter={onFilter}
        value={gridValues}
        onSelectionChange={(e) => handleSelection(e)}
        totalRecords={totalRecords}
        first={lazyState.first}
      >
        <Column
          field="locationName"
          header="Office&nbsp;Name"
          sortable
          body={(rowData) => (
            <a onClick={handleView} className="underline">
              {rowData.locationName}
            </a>
          )}
        />
        <Column field="address1" header="Address" sortable />
        <Column field="phone" header="Phone" sortable />
        <Column field="primaryEmail" header="Email" sortable />
        <Column field="effectiveDate" header="Effective&nbsp;Date" body={effectiveDateFormatTemplate} sortable />
        <Column field="termDate" header="Term&nbsp;Date" body={termDateFormatTemplate} sortable />
      </DataTable>

      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </>
  );
};

export default LocationList;
