import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useNavigate } from "react-router-dom";
import ViewForm from "../../../controls/ViewForm";

const LocationView = () => {
  const navigate = useNavigate();
  const data = [
    { label: "Office Name", value: "SSM Office : Billing" },
    { label: "Location", value: "Mg Road" },
  ];
  const otherdata = [
    { label: "After hours Coverage", value: "N/A" },
    { label: "Age Range", value: "1 To 100" },
    { label: "Gender Restriction", value: "Female" },
    { label: "Handicap accessible", value: "No" },
    { label: "PCP", value: "No" },
    { label: "Accepting New Patient", value: "No" },
    { label: "nclude In Provider Directory", value: "No" },
  ];
  const secondarydata = [
    { label: "Phone Number", value: "N/A" },
    { label: "Emergency Number", value: "N/A" },
    { label: "Secondary Number", value: "N/A" },
    { label: "Fax", value: "N/A" },
    { label: "Primary Mail", value: "N/A" },
    { label: "Secondary Mail", value: "N/A" },
  ];
  const handleNavigate = () => {
    navigate("/location");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Location Information
      </h2>
      <ViewForm header="PPR000304 - Kesaven - Provider" data={data} />
      <ViewForm header="Secondary Details" data={otherdata} />
      <ViewForm header="Other Details" data={secondarydata} />
      <Panel header="Office Hours" toggleable className="mb-4">
        <DataTable className="p-datatable-gridlines" showGridlines emptyMessage="No records found.">
          <Column field="Day" header="Day" filter sortable />
          <Column field="Time" header="Time" filter sortable />
        </DataTable>
      </Panel>
    </>
  );
};

export default LocationView;
