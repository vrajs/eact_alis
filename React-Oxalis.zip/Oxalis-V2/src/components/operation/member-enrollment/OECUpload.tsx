import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useRef, useState } from "react";
import Button from "../../../controls/Button";
import { FileUpload } from "primereact/fileupload";
import { Toast } from "primereact/toast";
import { useNavigate } from "react-router-dom";

const OECUpload = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const toast = useRef(null);
  const navigate = useNavigate();

  const onUpload = () => {
    toast.current.show({ severity: "info", summary: "Success", detail: "File Uploaded" });
  };
  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">New File Information</div>
        <div className="flex align-items-center gap-2">
          <Button outlined label="Export" />
          {options.togglerElement}
        </div>
      </div>
    );
  };
  const handleNavigate = () => {
    navigate("/member/oec-search");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>OEC Files View Information
      </h2>
      <Panel headerTemplate={headerTemplate} toggleable className="search-panel">
        <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
          <Toast ref={toast}></Toast>
          <FileUpload mode="basic" name="demo[]" url="/api/upload" accept="image/*" maxFileSize={1000000} onUpload={onUpload} />
        </div>
        <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
          <Button label="View" outlined />
          <Button label="Upload" raised />
        </div>
      </Panel>
      <div className="pb-4">
        <DataTable
          paginator
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          dataKey="claimId"
          responsiveLayout="scroll"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single" // Single row selection
        >
          <Column field="mbi" header="MBI" filter sortable />
          <Column field="lastName" header="Last&nbsp;Name" filter sortable />
          <Column field="firstName" header="First&nbsp;Name" filter sortable />
          <Column field="status" header="Status" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default OECUpload;
