import FormItem from "../../../controls/FormItem";
import CustomForm from "../../../controls/CustomForm";
import { useState } from "react";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import InputMask from "../../../controls/InputMask";
import InputText from "../../../controls/InputText";
import { AccordianProps } from "./EnrollmentMemberInfo";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { NextTab } from "../../../Redux/features/enrollmentSlice";
import Button from "../../../controls/Button";

const EnrollmentAuthorization = ({ form }: AccordianProps) => {
  const [repRelationship, setrepRelationship] = useState(null);
  const repRelationshipList = [
    { key: "Yes", value: "1" },
    { key: "No", value: "2" },
  ];
  const dispatch = useDispatch();
  const [hasError, setHasError] = useState<boolean>(true);

  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])
  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  return (
    <>

      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3 items-center">
        <FormItem name="authorisedName" label="Authorised Rep Name">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="authorisedAddress" label="Authorised Rep Address">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="repRelationship" label="Authorised Rep Relationship">
          <Dropdown
            id="repRelationship"
            options={repRelationshipList}
            value={repRelationship}
            optionLabel="key"
            optionValue="value"
            onChange={(event: DropdownChangeEvent) => setrepRelationship(event.value)}
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="contactNumber" label="Authorised Rep Contact Number">
          <InputMask mask="(999) 999-9999" placeholder="Enter here" />
        </FormItem>
      </div>
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentAuthorization;
