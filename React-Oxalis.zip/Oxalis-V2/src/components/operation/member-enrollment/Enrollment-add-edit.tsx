import { useEffect, useState } from "react";
import { Panel } from "primereact/panel";
import Button from "../../../controls/Button";
import { Accordion, AccordionTab } from "primereact/accordion";
import { InputSwitch } from "primereact/inputswitch";
import EnrollmentMemberInfo from "./EnrollmentMemberInfo";
import EnrollmentContactDetails from "./EnrollmentContactDetails";
import EnrollmentEligibilityDetails from "./EnrollmentEligibilityDetails";
import EnrollmentSales from "./EnrollmentSales";
import EnrollmentOtherCoverage from "./EnrollmentOtherCoverage";
import EnrollmentAuthorization from "./EnrollmentAuthorization";
import EnrollmentPriorData from "./EnrollmentPriorData";
import EnrollmentRXDetails from "./EnrollmentRXDetails";
import EnrollmentPCP from "./EnrollmentPCP";
import EnrollmentPremiumDetails from "./EnrollmentPremiumDetails";
import EnrollmentPlanEligibility from "./EnrollmentPlanEligibility";
import EnrollmentBEQDetails from "./EnrollmentBEQDetails";
import EnrollmentAuditHistory from "./EnrollmentAuditHistory";
import EnrollmentAttachmentList from "./EnrollmentAttachmentList";
import EnrollmentNotes from "./EnrollmentNotes";
import EnrollmentTRRDetails from "./EnrollmentTRRDetails";
import EnrollmentTransactionDetails from "./EnrollmentTransactionDetails";
import EnrollmentCorrespondence from "./EnrollmentCorrespondence";
import EnrollmentSpans from "./EnrollmentSpans";
import { useNavigate, useParams } from "react-router-dom";
import { EnrollmentService } from "../../../services/EnrollmentService";
import { MemberAndPlanInfoModel } from "../../../model/MemberAndPlanInfoModel";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { CancelNextTab, CancelPreviousTab } from "../../../Redux/features/enrollmentSlice";
import { useForm } from "rc-field-form"; // Import useForm for creating the form instance
import CustomForm from "../../../controls/CustomForm";





const EnrollmentAddEdit = () => {
  const navigate = useNavigate();
  const [activeIndex, setActiveIndex] = useState<any>(0);
  const [checked, setChecked] = useState(false);
  const { memberEditId } = useParams();
  const [memberId, setMemberId] = useState<number>(0);
  const { memberDetailsView } = EnrollmentService();
  const [memberData, setMemberData] = useState<MemberAndPlanInfoModel | null>(null);
  const { next } = useSelector((state: RootState) => state.enrollment);
  const { previous } = useSelector((state: RootState) => state.enrollment);
  const dispatch = useDispatch();
  const [form] = useForm<MemberAndPlanInfoModel>();

  const accordionTabs = [
    { header: "Member Information", component: <EnrollmentMemberInfo form={form} /> },
    { header: "Contact Details", component: <EnrollmentContactDetails form={form} /> },
    { header: "Eligibility Details", component: <EnrollmentEligibilityDetails form={form} /> },
    { header: "Sales", component: <EnrollmentSales form={form} /> },
    { header: "Other Coverage", component: <EnrollmentOtherCoverage form={form} /> },
    { header: "Authorization", component: <EnrollmentAuthorization form={form} /> },
    { header: "Prior Enrollment Data", component: <EnrollmentPriorData form={form} /> },
    { header: "RX Details", component: <EnrollmentRXDetails form={form} /> },
    { header: "PCP", component: <EnrollmentPCP form={form} /> },
    { header: "Transaction Details", component: <EnrollmentTransactionDetails form={form} /> },
    { header: "Premium Details", component: <EnrollmentPremiumDetails form={form} /> },
    { header: "Spans", component: <EnrollmentSpans form={form} /> },
    { header: "Plan Eligibility Spans", component: <EnrollmentPlanEligibility form={form} /> },
    { header: "TRR Details", component: <EnrollmentTRRDetails form={form} /> },
    { header: "BEQ Details", component: <EnrollmentBEQDetails form={form} /> },
    { header: "Correspondence", component: <EnrollmentCorrespondence form={form} /> },
    { header: "Attachment List", component: <EnrollmentAttachmentList form={form} /> },
    { header: "Notes", component: <EnrollmentNotes form={form} /> },
    { header: "Audit History", component: <EnrollmentAuditHistory form={form} /> },
  ];

  const handleNext = () => {
    if (activeIndex < accordionTabs.length - 1) {
      setActiveIndex(activeIndex + 1);
    }
  };

  useEffect(() => {
    if (next) {
      handleNext();
    }
    if (previous) {
      handlePrevious();
    }
    dispatch(CancelNextTab());
    dispatch(CancelPreviousTab());
  }, [next, previous]);

  const handlePrevious = () => {
    if (activeIndex > 0) {
      setActiveIndex(activeIndex - 1);
    }
  };

  useEffect(() => {
    const fetchMemberData = async () => {
      if (Number(memberEditId) > 0) {
        try {
          const data = await memberDetailsView(Number(memberEditId));
          setMemberData(data);
          form.setFieldsValue({ ...data });
        } catch (error) {
          console.error("Error fetching member data:", error);
        }
      } else {
        setMemberData(null);
      }
      setMemberId(Number(memberEditId));
    };
    fetchMemberData();
  }, [memberEditId]);

  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Member Detail</div>
        <div className="flex align-items-center gap-2">
          <Button icon="cl_user_fill text-2xl" text />
          <Button icon="cl_doctor text-2xl" text />
          <Button icon="cl_info_fill text-2xl" text />
          <label htmlFor="input-switch">Portal Access</label>
          <InputSwitch id="input-switch" checked={checked} onChange={(e) => setChecked(e.value)} />
        </div>
      </div>
    );
  };

  const handleNavigate = () => {
    navigate("/operation/member/enrollment");
  };

  const handleSubmit = async () => {
    const allFormValues = form.getFieldsValue(true); // Retrieve all form values
    console.log("All Form Values:", allFormValues);
    // Handle final submission logic here
  };

  return (
    <CustomForm onFinish={handleSubmit} form={form}> {/* Wrap in CustomForm */}
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Enrollment Information
      </h2>
      <Panel headerTemplate={headerTemplate} toggleable className="search-panel mb-2">
        <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">
          {/* Add mapped data here if needed */}
        </div>
      </Panel>

      <Accordion activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)} multiple={false}>
        {accordionTabs.map((tab, index) => (
          <AccordionTab key={index} header={tab.header}>
            {tab.component}
            <div className="flex justify-end mt-4 border-top-1 pt-3 !gap-3">
              {/* You can add Next/Previous buttons if needed */}
            </div>
          </AccordionTab>
        ))}
      </Accordion>
      <button onClick={handleSubmit} type="submit">Submit</button>
    </CustomForm>
  );
};

export default EnrollmentAddEdit;

