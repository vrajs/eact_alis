import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useEffect, useRef, useState } from "react";
import Button from "../../../controls/Button";
import Dropdown from "../../../controls/Dropdown";
import InputText from "../../../controls/InputText";
import InputNumber from "../../../controls/InputNumber";
import { useNavigate } from "react-router-dom";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import { LazyTableState } from "../../../model/LazyTableState";
import { FormInstance, useForm } from "rc-field-form";
import { GridModel } from "../../../model/GridModel";
import { ProviderViewModel } from "../../../model/ProviderViewModel";
import SpecialtyService from "../../../services/SpecialtyService";
import { ProviderDataModel } from "../../../model/ProviderDataModel";
import { ProviderService } from "../../../services/ProviderService";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import { CodeType, CommonCodeFetchingType } from "../../../data/constants/AppEnum";
import { KeyValueModel } from "../../../model/KeyValueModel";
import FormItem from "../../../controls/FormItem";
import CustomForm from "../../../controls/CustomForm";
import { REGEX_CONSTANTS } from "../../../data/constants/RegexConstants";
import { Calendar } from "primereact/calendar";
import { FileTemplateListView } from "../../../model/FileTemplateListViewModel";
import OECFileService from "../../../services/OECFileService";

const OECSearch = () => {
  const navigate = useNavigate();

  const [selectedProviderType, setselectedProviderType] = useState(null);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null);
  const groupTypes = useCommonCodeSubCategory(CodeType.ProviderType, CommonCodeFetchingType.Default);
  const [specialityList, setspecialityList] = useState([]);
  const [languageList, setLanguageList] = useState([]);
  const [specialtyList, setSpecialityList] = useState<KeyValueModel[]>([]);
  const [selectedLanguage, setselectedLanguage] = useState(null);
  const language = [{ name: "language 1" }, { name: "language 2" }];
  const [customers1, setCustomers1] = useState<any>([]);
  const [loading, setLoading] = useState(true);

  const [gridValues, setGridValues] = useState([]);
  const [form] = useForm<FormInstance>();
  const { getFileTemplateDetails } = OECFileService();
  const [totalRecords, setTotalRecords] = useState(0);
  const [selectedProvider, setSelectedProvider] = useState<ProviderViewModel | null>();

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });
  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };
  const ref = useRef<Panel>(null);
  useEffect(() => {
    loadLazyData();
  }, [lazyState]);

  const handleFormError = () => {
    console.log(form.getFieldsError());
  }
  // Simulate data fetching with a useEffect
  const loadLazyData = async () => {
    const searchForm = form.getFieldsValue(true);
    // ref.current.collapse(undefined)
    setLoading(true);
    searchForm.skip = lazyState.first;
    searchForm.take = lazyState.rows;
    const oecData: FileTemplateListView = await getFileTemplateDetails(searchForm, "OEC");
    if (oecData) {
      setGridValues(oecData.fileTemplateList);
      setTotalRecords(oecData.totalRecords);
      setLoading(false);
    }
  };
  const handleSelection = (e) => {
    if (e.value) {
      setSelectedProvider(e.value)
    } else {
      setSelectedProvider(null);
    }
  }
  const handleNavigate = () => {
    navigate("/member/oec-upload");
  };
  const handleView = () => {
    navigate("/provider/provider-view");
  };
  const handleEdit = () => {
    const providerid: number = selectedProvider.providerID;
    navigate(`/provider/provider-add-edit/${providerid}`);
  }
  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Advance Search</div>
        <div className="flex align-items-center gap-2">
          <Dropdown optionLabel="name" placeholder="Saved Search (0)" filter className="w-full" />
          <Button outlined label="Add" onClick={handleNavigate} />
          {selectedProvider && <Button outlined label="Edit" onClick={handleEdit} />}
          <Button label="Export" outlined />
          {options.togglerElement}
        </div>
      </div>
    );
  };
  return (
    <>
      <h2 className="pb-4">OEC Files View Information</h2>
      <Panel header="Advance Search" headerTemplate={headerTemplate} ref={ref} toggleable className="search-panel">
        <CustomForm form={form} onFinish={loadLazyData} onFinishFailed={handleFormError}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="fileName" label="File Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="fileDateFrom" label="From Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="fileDateTo" label="To Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="clear" text />
            <Button label="Apply" outlined />
            <Button label="Upload" raised onClick={handleNavigate} />
          </div>
        </CustomForm>
      </Panel>
      <div className="pb-4">
        <DataTable
          paginator
          rowsPerPageOptions={paginatorConstants.pageOptions}
          className="p-datatable-gridlines"
          showGridlines
          rows={lazyState.rows}
          tableStyle={{ minWidth: '50rem' }}
          currentPageReportTemplate="{first} to {last} of {totalRecords}"
          dataKey="providerID"
          responsiveLayout="scroll"
          emptyMessage="No Group found."
          selectionMode="single"
          lazy onPage={onPage}
          onSort={onSort}
          sortField={lazyState.sortField}
          onFilter={onFilter}
          value={gridValues}
          onSelectionChange={(e) => handleSelection(e)}
          totalRecords={totalRecords}
          first={lazyState.first}
        >
          <Column field="fileName" header="File&nbsp;Name" filter sortable body={(rowData) => <a className="underline">{rowData.fileName}</a>} />
          <Column field="createdBy" header="File&nbsp;Uploaded&nbsp;By" filter sortable />
          <Column field="fileDate" header="File&nbsp;Uploaded&nbsp;Date" filter sortable />
          <Column field="records" header="No&nbsp;Of&nbsp;Records" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default OECSearch;
