import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { AccordianProps } from "./EnrollmentMemberInfo";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { NextTab } from "../../../Redux/features/enrollmentSlice";
import Button from "../../../controls/Button";

const EnrollmentPlanEligibilty  = ({ form }: AccordianProps) => {
  const dispatch = useDispatch();
  const [hasError, setHasError] = useState<boolean>(true);

  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])

  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  return (
    <>
      <DataTable
        paginator
        className="p-datatable-gridlines"
        showGridlines
        rows={10}
        dataKey="claimId"
        emptyMessage="No records found."
        selectionMode="single"
      >
        <Column field="planID" header="plan&nbsp;ID" filter sortable />
        <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
        <Column field="termDate" header="Term&nbsp;Date" filter sortable />
        <Column field="pcp" header="PCP" filter sortable />
        <Column field="createdBy" header="Created&nbsp;By" filter sortable />
        <Column field="createdDate" header="Created&nbsp;Date" filter sortable />
      </DataTable>
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentPlanEligibilty;
