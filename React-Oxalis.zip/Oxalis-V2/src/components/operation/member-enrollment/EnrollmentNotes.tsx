import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import FormItem from "../../../controls/FormItem";
import InputNumber from "../../../controls/InputNumber";
import { Editor } from "primereact/editor";
import { useState } from "react";
import { AccordianProps } from "./EnrollmentMemberInfo";
import { useEffect } from "react";
 import { useDispatch } from "react-redux";
import { NextTab } from "../../../Redux/features/enrollmentSlice";
import Button from "../../../controls/Button";

const EnrollmentNotes  = ({ form }: AccordianProps) => {
  const [text, setText] = useState("");
  const dispatch = useDispatch();
  const [hasError, setHasError] = useState<boolean>(true);

  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])

  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  return (
    <>
      <DataTable
        paginator
        className="p-datatable-gridlines mb-4"
        showGridlines
        rows={10}
        dataKey="claimId"
        emptyMessage="No records found."
        selectionMode="single"
      >
        <Column field="notes" header="Notes" filter sortable />
        <Column field="createdBy" header="Created&nbsp;By" filter sortable />
        <Column field="createdDate" header="Created&nbsp;Date" filter sortable />
        <Column field="delete" header="Delete" filter sortable />
      </DataTable>
      <Editor value={text} onTextChange={(e) => setText(e.htmlValue)} className="mb-4" placeholder="Enter here" />
      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3 items-end">
        <FormItem name="confirmNumber" label="Confirmation Number">
          <InputNumber placeholder="Enter here" />
        </FormItem>
      </div>
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentNotes;
