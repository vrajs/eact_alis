import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Dropdown, DropdownChangeEvent } from "primereact/dropdown";
import FormItem from "../../../controls/FormItem";
import { useState } from "react";
import CustomForm from "../../../controls/CustomForm";
import Calendar from "../../../controls/Calendar";

import InputText from "../../../controls/InputText";
import { AccordianProps } from "./EnrollmentMemberInfo";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { NextTab } from "../../../Redux/features/enrollmentSlice";
import Button from "../../../controls/Button";

const EnrollmentSpans = ({ form }: AccordianProps) => {
  const [isAdding, setIsAdding] = useState(false); // To manage add mode
  const [spanType, setSpanTypeList] = useState(null);
  const [spanSource, setSpanSourceList] = useState(null);
  const spanSourceList = [
    { key: "CMS", value: "1" },
    { key: "BEQ", value: "2" },
  ];
  const spanTypeList = [
    { key: "LIS", value: "51" },
    { key: "PCP", value: "61" },
  ];
  const handleAddClick = () => {
    setIsAdding(true); // Show form
  };

  const handleSaveClick = () => {
    setIsAdding(false); // Go back to the table
    // You can also handle saving logic here
  };
  const dispatch = useDispatch();
  const [hasError, setHasError] = useState<boolean>(true);

  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])

  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  const handleCancelClick = () => {
    setIsAdding(false); // Go back to the table on cancel
  };

  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <Button outlined label="Add" onClick={handleAddClick} />
      </div>
    </div>
  );

  return (
    <>
      {/* Show either the table or the form based on isAdding state */}
      {isAdding ? (
        <>

          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="spanType" label="Span Type">
              <Dropdown
                id="spanType"
                options={spanTypeList}
                value={spanType}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setSpanTypeList(event.value)}
                showClear
                multiple
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="endDate" label="End Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="spanValue" label="Span Value">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="spanSource" label="Span Source">
              <Dropdown
                id="spanSource"
                options={spanSourceList}
                value={spanSource}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setSpanSourceList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <div className="col-span-3">
              <FormItem name="comments" label="Comments">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
            </div>
          </div>
          <div className="flex justify-content-center border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancelClick} />
            <Button label="Save" outlined onClick={handleSaveClick} />
          </div>

        </>
      ) : (
        <DataTable
          paginator
          className="p-datatable-gridlines"
          showGridlines
          header={header1}
          rows={10}
          dataKey="claimId"
          emptyMessage="No records found."
          selectionMode="single"
        >
          <Column field="spanId" header="Span&nbsp;Id" filter sortable />
          <Column field="spanType" header="Span&nbsp;Type" filter sortable />
          <Column field="spanEffectiveDate" header="Span&nbsp;Effective&nbsp;Date" filter sortable />
          <Column field="spanEndDate" header="Span&nbsp;End&nbsp;Date" filter sortable />
          <Column field="value" header="Value" filter sortable />
          <Column field="source" header="Source" filter sortable />
          <Column field="comments" header="Comments" filter sortable />
        </DataTable>
      )}
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentSpans;
