import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import Button from "../../../controls/Button";
import { Dropdown, DropdownChangeEvent } from "primereact/dropdown";
import FormItem from "../../../controls/FormItem";
import { useState } from "react";
import CustomForm from "../../../controls/CustomForm";
import InputText from "../../../controls/InputText";
import Calendar from "../../../controls/Calendar";
import { AccordianProps } from "./EnrollmentMemberInfo";
import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { NextTab } from "../../../Redux/features/enrollmentSlice";

const EnrollmentTransactionDetails = ({ form }: AccordianProps) => {
  const [contractID, setContractID] = useState(null);
  const [pbpID, setPBPID] = useState(null);
  const [isAdding, setIsAdding] = useState(false); // To manage add mode
  const [transactionType, setTransactionTypeList] = useState(null);
  const [subGroupID, setSubGroupIDList] = useState(null);
  const [subGroupName, setSubGroupNameList] = useState(null);
  const [electionType, setElectionTypeList] = useState(null);
  const [optOut, setOptOutList] = useState(null);
  const [premiumWithhold, setpremiumWithholdList] = useState(null);
  const [employerSubsidy, setemployerSubsidyList] = useState(null);
  const [transactionStatus, setTransactionStatusList] = useState(null);
  const [pendingReason, setPendingReasonList] = useState(null);
  const [incompleteReason, setIncompleteReasonList] = useState(null);
  const [denialFlag, setDenialFlagList] = useState(null);
  const denialFlagList = [
    { key: "Yes", value: "1" },
    { key: "No", value: "2" },
  ];
  const incompleteReasonList = [
    { key: "Proof of Medicare Coverage", value: "1" },
    { key: "Special Exceptions", value: "2" },
  ];
  const pendingReasonList = [
    { key: "Other", value: "1" },
    { key: "Incomplete", value: "2" },
  ];
  const transactionStatusList = [
    { key: "New", value: "1" },
    { key: "Exception", value: "2" },
  ];
  const employerSubsidyList = [
    { key: "Yes", value: "1" },
    { key: "No", value: "2" },
  ];
  const premiumWithholdList = [
    { key: "Deduct from SSA benefits", value: "1" },
    { key: "Direct self-pay", value: "2" },
  ];
  const optOutList = [
    { key: "Yes", value: "1" },
    { key: "No", value: "2" },
  ];
  const electionTypeList = [
    { key: "Annual Election Period", value: "1" },
    { key: "Plan submitted Rollover", value: "2" },
  ];
  const subGroupNameList = [
    { key: "DKA", value: "1" },
    { key: "Others", value: "2" },
  ];
  const subGroupIDList = [
    { key: "000001", value: "1" },
    { key: "000002", value: "2" },
  ];
  const contractIDList = [
    { key: "H0001", value: "H0001" },
    { key: "H0002", value: "H0002" },
  ];

  const pbpIDList = [
    { key: "012", value: "012" },
    { key: "013", value: "013" },
  ];
  const transactionTypeList = [
    { key: "51", value: "51" },
    { key: "61", value: "61" },
  ];
  const handleAddClick = () => {
    setIsAdding(true); // Show form
  };
  const dispatch = useDispatch();
  const [hasError, setHasError] = useState<boolean>(true);

  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])

  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  const handleSaveClick = () => {
    setIsAdding(false); // Go back to the table
    // You can also handle saving logic here
  };

  const handleCancelClick = () => {
    setIsAdding(false); // Go back to the table on cancel
  };

  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <Button outlined label="Add" onClick={handleAddClick} />
      </div>
    </div>
  );

  return (
    <>
      {/* Show either the table or the form based on isAdding state */}
      {isAdding ? (
        <>

          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="transactionType" label="Transaction Type">
              <Dropdown
                id="transactionType"
                options={transactionTypeList}
                value={transactionType}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setTransactionTypeList(event.value)}
                showClear
                multiple
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="contractID" label="Contract ID">
              <Dropdown
                id="contractID"
                options={contractIDList}
                value={contractID}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setContractID(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="pbpID" label="PBP ID">
              <Dropdown
                id="pbpID"
                options={pbpIDList}
                value={pbpID}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setPBPID(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="subGroupID" label="Sub Group ID">
              <Dropdown
                id="subGroupID"
                options={subGroupIDList}
                value={subGroupID}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setSubGroupIDList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="subGroupName" label="Sub Group Name">
              <Dropdown
                id="subGroupName"
                options={subGroupNameList}
                value={subGroupName}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setSubGroupNameList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="electionType" label="Election Type">
              <Dropdown
                id="electionType"
                options={electionTypeList}
                value={electionType}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setElectionTypeList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <div className="col-span-2">
              <FormItem name="sepReason" label="SEP Reason">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
            </div>
            <FormItem name="sepReasonDate" label="SEP Reason Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="signatureDate" label="Signature Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="receiptDate" label="Receipt Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="termDate" label="Term Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="optOut" label="Part D Opt-out">
              <Dropdown
                id="optOut"
                options={optOutList}
                value={optOut}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setOptOutList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="premiumWithhold" label="premium Withold Option">
              <Dropdown
                id="premiumWithhold"
                options={premiumWithholdList}
                value={premiumWithhold}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setpremiumWithholdList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="employerSubsidy" label="Employer Subsidy Override">
              <Dropdown
                id="employerSubsidy"
                options={employerSubsidyList}
                value={employerSubsidy}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setemployerSubsidyList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="requestedDate" label="RFI Requested Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="dueDate" label="RFI Due Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="responseDate" label="RFI Response Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="transactionStatus" label="Transaction Status">
              <Dropdown
                id="transactionStatus"
                options={transactionStatusList}
                value={transactionStatus}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setTransactionStatusList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="pendingReason" label="Pending Reason">
              <Dropdown
                id="pendingReason"
                options={pendingReasonList}
                value={pendingReason}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setPendingReasonList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="incompleteReason" label="Incomplete Reason">
              <Dropdown
                id="incompleteReason"
                options={incompleteReasonList}
                value={incompleteReason}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setIncompleteReasonList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="denialFlag" label="Denial Flag">
              <Dropdown
                id="denialFlag"
                options={denialFlagList}
                value={denialFlag}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setDenialFlagList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
          </div>
          <div className="flex justify-content-center border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancelClick} />
            <Button label="Save" outlined onClick={handleSaveClick} />
          </div>

        </>
      ) : (
        <DataTable
          paginator
          className="p-datatable-gridlines"
          showGridlines
          header={header1}
          rows={10}
          dataKey="claimId"
          emptyMessage="No records found."
          selectionMode="single"
        >
          <Column field="transID" header="Trans&nbsp;ID" filter sortable />
          <Column field="transType" header="Trans&nbsp;Type" filter sortable />
          <Column field="transStatus" header="Trans&nbsp;Status" filter sortable />
          <Column field="contractID" header="Contract&nbsp;ID" filter sortable />
          <Column field="pbp" header="PBP" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="termDate" header="Term&nbsp;Date" filter sortable />
          <Column field="electionType" header="Election&nbsp;Type" filter sortable />
        </DataTable>
      )}
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentTransactionDetails;
