import ViewForm from "../../../controls/ViewForm";

const EnrollmentTRRView = () => {
  const headerRecord = [
    { label: "Beneficiary ID", value: "3N79M19FM95" },
    { label: "Surname", value: "SARAH" },
    { label: "First Name", value: "ZANOTK" },
    { label: "Date of Birth", value: "07/04/1928" },
    { label: "Contract Number", value: "H0001" },
    { label: "State Code", value: "10" },
    { label: "County Code", value: "001" },
    { label: "Effective Date", value: "01/01/2024" },
    { label: "Transaction Reply Code", value: "011" },
    { label: "SEP Reason Code", value: "37" },
    { label: "Source ID", value: "H0001" },
    { label: "Secondary Rx ID", value: "N/A" },
    { label: "Part D Rx Group", value: "RXGROUP12345678" },
    { label: "Plan Benefit Package ID", value: "008" },
    { label: "ESRD Indicator", value: "0" },
    { label: "TRC Short Name", value: "N/A" },
    { label: "Plan Assigned Transaction Tracking ID", value: "000000000000445" },
  ];

  return (
    <>
      <ViewForm header="Detail Record" data={headerRecord} />
    </>
  );
};

export default EnrollmentTRRView;
