import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Sidebar } from "primereact/sidebar";
import { useState } from "react";
import EnrollmentBEQView from "./EnrollmentBEQView";
import EnrollmentTRRView from "./EnrollmentTRRView";
import { AccordianProps } from "./EnrollmentMemberInfo";
 import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { NextTab } from "../../../Redux/features/enrollmentSlice";
import Button from "../../../controls/Button";

const EnrollmentTRRDetails  = ({ form }: AccordianProps) => {
  const dispatch = useDispatch();
  const [hasError, setHasError] = useState<boolean>(true);

  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])

  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  const [visibleBottom, setVisibleBottom] = useState(false);
  const mockData = [
    {
      claimId: "1001",
      pbp: "001",
      transTypeCode: "A01",
      transReplayCode: "R01",
      transEffectiveDate: "2024-01-01",
      trrDate: "2024-01-05",
      transStatus: "Completed",
    },
    {
      claimId: "1002",
      pbp: "002",
      transTypeCode: "A02",
      transReplayCode: "R02",
      transEffectiveDate: "2024-01-02",
      trrDate: "2024-01-06",
      transStatus: "Pending",
    },
    {
      claimId: "1003",
      pbp: "003",
      transTypeCode: "A03",
      transReplayCode: "R03",
      transEffectiveDate: "2024-01-03",
      trrDate: "2024-01-07",
      transStatus: "Failed",
    },
    // Add more data as needed
  ];

  return (
    <>
      <DataTable
        value={mockData}
        paginator
        className="p-datatable-gridlines"
        showGridlines
        rows={10}
        dataKey="claimId"
        emptyMessage="No records found."
        selectionMode="single"
      >
        <Column
          field="pbp"
          header="PBP"
          filter
          sortable
          body={(rowData) => (
            <a className="underline" onClick={() => setVisibleBottom(true)}>
              {rowData.pbp}
            </a>
          )}
        />
        <Column field="transTypeCode" header="Trans&nbsp;Type&nbsp;Code" filter sortable />
        <Column field="transReplayCode" header="Trans&nbsp;Replay&nbsp;Code" filter sortable />
        <Column field="transEffectiveDate" header="Trans&nbsp;Effective&nbsp;Date" filter sortable />
        <Column field="trrDate" header="TRR&nbsp;Date" filter sortable />
        <Column field="transStatus" header="Trans&nbsp;Status" filter sortable />
      </DataTable>
      <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-full text-xl"
        header="TRR Information"
      >
        <EnrollmentTRRView />
      </Sidebar>
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentTRRDetails;
