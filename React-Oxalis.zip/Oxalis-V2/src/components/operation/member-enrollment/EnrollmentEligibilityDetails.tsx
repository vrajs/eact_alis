import FormItem from "../../../controls/FormItem";
import CustomForm from "../../../controls/CustomForm";
import { useEffect, useState } from "react";
import Dropdown from "../../../controls/Dropdown";
import Calendar from "../../../controls/Calendar";
import { MemberAndPlanInfoModel } from "../../../model/MemberAndPlanInfoModel";
import { FormInstance, useForm } from "rc-field-form";
import { useDispatch, useSelector } from "react-redux";
import { NextTab, PreviousTab, selectDob } from "../../../Redux/features/enrollmentSlice";
import moment from "moment";
import { AccordianProps } from "./EnrollmentMemberInfo";
import Button from "../../../controls/Button";

const EnrollmentEligibilityDetails = ({ form }: AccordianProps) => {

  const [isMedicarePartAEffDateValid, setIsMedicarePartAEffDateValid] = useState(true);
  const [isMedicarePartBEffDateValid, setIsMedicarePartBEffDateValid] = useState(true);
  const [hasError, setHasError] = useState<boolean>(true);
  const esrdFlagList = [
    { key: "Yes", value: "1" },
    { key: "No", value: "0" },
  ];
  const employedStatusList = [
    { key: "Yes", value: "1" },
    { key: "No", value: "0" },
  ];
  const spouseEmployedStatusList = [
    { key: "Yes", value: "1" },
    { key: "No", value: "0" },
  ];

  const dob = useSelector(selectDob);
  const dispatch = useDispatch();
  useEffect(() => {

  }, [form]);
  const handlePrevious = async () => {
    dispatch(PreviousTab())
  }
  const handleMedicarePartAChange = (selectedDate) => {
    const firstDateOfMonth = new Date(selectedDate).getDate();
    const threeMonthsFromNow = new Date();
    threeMonthsFromNow.setMonth(threeMonthsFromNow.getMonth() + 3);

    const formattedDob = moment(dob).format("YYYY-MM-DD");
    const formattedSelectedDate = moment(selectedDate).format("YYYY-MM-DD");

    if (formattedSelectedDate < formattedDob || firstDateOfMonth !== 1) {
      setIsMedicarePartAEffDateValid(false);
    } else if (selectedDate > threeMonthsFromNow) {
      alert("Confirm Medicare Part A Date"); // Replace with custom confirmation logic
    } else {
      setIsMedicarePartAEffDateValid(true);
    }
  };
  const handleMedicarePartBChange = (selectedDate) => {
    const firstDateOfMonth = new Date(selectedDate).getDate();
    const threeMonthsFromNow = new Date();
    threeMonthsFromNow.setMonth(threeMonthsFromNow.getMonth() + 3);

    const formattedDob = moment(dob).format("YYYY-MM-DD");
    const formattedSelectedDate = moment(selectedDate).format("YYYY-MM-DD");

    if (formattedSelectedDate < formattedDob || firstDateOfMonth !== 1) {
      setIsMedicarePartBEffDateValid(false);
    } else if (selectedDate > threeMonthsFromNow) {
      alert("Confirm Medicare Part B Date"); // Replace with custom confirmation logic
    } else {
      setIsMedicarePartBEffDateValid(true);
    }
  };
  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])
  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }
  }

  return (
    <>
      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3 items-center">
        <FormItem
          name="medicarePartAEffectiveDate"
          label="Medicare Part A Eff Date"
          rules={[{ required: true, message: "This field is required" }]}
        >
          <Calendar
            placeholder="Enter Date"
            selectionMode="single"
            icon="cl_calendar_today_line"
            iconPos="right"
            dateFormat="mm/dd/yy"
            maxDate={new Date()}
            onChange={handleMedicarePartAChange}
          />
        </FormItem>
        {!isMedicarePartAEffDateValid && (
          <span style={{ color: "red", fontSize: "small" }}>
            Date must be the first of the month and not before DOB
          </span>
        )}
        <FormItem name="medicarePartBEffectiveDate" label="Medicare Part B Eff Date" rules={[{ required: true }]}>
          <Calendar
            placeholder="Enter Date"
            selectionMode="single"
            icon="cl_calendar_today_line"
            iconPos="right"
            dateFormat="mm/dd/yy"
            maxDate={new Date()}
            onChange={handleMedicarePartBChange}
          />
        </FormItem>
        {!isMedicarePartBEffDateValid && (
          <span style={{ color: "red", fontSize: "small" }}>
            Date must be the first of the month and not before DOB
          </span>
        )}
        <FormItem name="dateOfDeath" label="Date Of Death">
          <Calendar
            placeholder="Enter Date"
            selectionMode="single"
            icon="cl_calendar_today_line"
            iconPos="right"
            dateFormat="mm/dd/yy"
            maxDate={new Date()}
          />
        </FormItem>
        <FormItem name="incarceratedDate" label="Incarcerated Date">
          <Calendar
            placeholder="Enter Date"
            selectionMode="single"
            icon="cl_calendar_today_line"
            iconPos="right"
            dateFormat="mm/dd/yy"
            maxDate={new Date()}
          />
        </FormItem>
        <FormItem name="medicarePartDEffectiveDate" label="Medicare Part D Eff Date">
          <Calendar
            placeholder="Enter Date"
            selectionMode="single"
            icon="cl_calendar_today_line"
            iconPos="right"
            dateFormat="mm/dd/yy"
            maxDate={new Date()}
          />
        </FormItem>
        <FormItem name="isEsrd" label="ESRD Flag">
          <Dropdown
            id="esrdFlag"
            options={esrdFlagList}
            optionLabel="key"
            optionValue="value"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="isEmployed" label="Employed Status">
          <Dropdown
            id="employedStatus"
            options={employedStatusList}
            optionLabel="key"
            optionValue="value"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="spouseEmployedStatus" label="Spouse Employed Status">
          <Dropdown
            id="spouseEmployedStatus"
            options={spouseEmployedStatusList}
            optionLabel="key"
            optionValue="value"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
      </div>
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" onClick={handlePrevious} />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentEligibilityDetails;

