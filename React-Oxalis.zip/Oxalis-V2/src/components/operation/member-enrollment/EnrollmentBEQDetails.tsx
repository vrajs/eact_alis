import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Sidebar } from "primereact/sidebar";
import { useState } from "react";
import EnrollmentBEQView from "./EnrollmentBEQView";
import { AccordianProps } from "./EnrollmentMemberInfo";
import { useEffect } from "react";
 import { useDispatch } from "react-redux";
import { NextTab } from "../../../Redux/features/enrollmentSlice";
import Button from "../../../controls/Button";

const EnrollmentBEQDetails = ({ form }: AccordianProps) => {
  const dispatch = useDispatch();
  const [hasError, setHasError] = useState<boolean>(true);

  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])

  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  const [visibleBottom, setVisibleBottom] = useState(false);
  // Sample data for the grid
  const [enrollmentData] = useState([
    {
      contractID: "C123",
      pbp: "PBP001",
      beqSentData: "2024-09-01",
      beqProcessedData: "Processed",
      beqMatchStatus: "Matched",
    },
    {
      contractID: "C124",
      pbp: "PBP002",
      beqSentData: "2024-09-02",
      beqProcessedData: "Not Processed",
      beqMatchStatus: "Not Matched",
    },
    {
      contractID: "C125",
      pbp: "PBP003",
      beqSentData: "2024-09-03",
      beqProcessedData: "Processed",
      beqMatchStatus: "Matched",
    },
  ]);

  return (
    <>
      <DataTable
        value={enrollmentData}
        paginator
        className="p-datatable-gridlines"
        showGridlines
        rows={10}
        dataKey="contractID"
        emptyMessage="No records found."
        selectionMode="single"
      >
        <Column
          field="contractID"
          header="Contract&nbsp;ID"
          filter
          sortable
          body={(rowData) => (
            <a className="underline" onClick={() => setVisibleBottom(true)}>
              {rowData.contractID}
            </a>
          )}
        />
        <Column field="pbp" header="PBP" filter sortable />
        <Column field="beqSentData" header="BEQ&nbsp;Sent&nbsp;Date" filter sortable />
        <Column field="beqProcessedData" header="BEQ&nbsp;Processed&nbsp;Status" filter sortable />
        <Column field="beqMatchStatus" header="BEQ&nbsp;Match&nbsp;Status" filter sortable />
      </DataTable>
      <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-full text-xl"
        header="BEQ Information"
      >
        <EnrollmentBEQView />
      </Sidebar>
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentBEQDetails;
