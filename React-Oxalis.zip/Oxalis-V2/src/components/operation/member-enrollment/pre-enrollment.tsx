import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { ChangeEvent, useEffect, useState } from "react";
import Button from "../../../controls/Button";
import InputNumber from "../../../controls/InputNumber";
import Calendar from "../../../controls/Calendar";
import { RadioButton } from "primereact/radiobutton"; // Import RadioButton
import InputText from "../../../controls/InputText";
import Dropdown from "../../../controls/Dropdown";
import { Sidebar } from "primereact/sidebar";
import NotesAttachment from "../claims/NotesAttachment";
import CustomForm from "../../../controls/CustomForm";
import { FormInstance, useForm } from "rc-field-form";
import PreEnrollmentService from "../../../services/PreEnrollmentService";
import { MemberEnrollmentHeaderModel } from "../../../model/MemberEnrollmentHeaderModel";
import FormItem from "../../../controls/FormItem";
import LocalStorageService from "../../../services/localStorageService";
import { API_ENDPOINTS } from "../../../data/constants/AppConstants";
import { ApplicationStatus, UserEnum } from "../../../data/constants/AppEnum";
import { UserModel } from "../../../model/UserModel";
import { MemberBEQRequestModel, SaveMemberPreEnrollment } from "../../../model/MemberBEQRequestModel";
import { MemberBEQResponseModel } from "../../../model/MemberBEQResponseModel";
import { useSelector } from "react-redux";
import { AddPreEnrollmentData, selectPreEnrollmentData } from "../../../Redux/features/preEnrollmentSlice";
import { OtherNote } from "../../../model/OtherNoteModel";

const PreEnrollment = () => {
  const [visibleBottom, setVisibleBottom] = useState(false);
  
  const [customers1, setCustomers1] = useState<any>([]);
  const [showData, setShowData] = useState<boolean>(false);
  const [loading, setLoading] = useState(true);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const { getPreEnrollmentHeaderByMBI, getCMSResponseWorkArround, saveFinalValue, InsertNote, otherFileUpload } = PreEnrollmentService();

  const genderList = [
    { key: 'Both', value: 10001 },
    { key: 'Male', value: 10002 },
    { key: 'FeMale', value: 10003 },
    { key: 'UnKnown', value: 10004 }
  ];
  const yesNoList = [
    { key: 'Yes', value: 10005 },
    { key: 'No', value: 10006 }
  ];
  const [memberBEQRequestModel, setMemberBEQRequestModel] = useState<MemberBEQRequestModel>();

  const [memberEnrollmentHeaderModel, setMemberEnrollmentHeaderModel] = useState<MemberEnrollmentHeaderModel>();
  const [preEnrollmentvalues, setPreEnrollmentvalues] = useState<SaveMemberPreEnrollment>({
    memberPreEnrollmentId: 0,
    trackingId: '',
    applicationStatusID: null,
    contractId: null,
    mbi: '',
    dob: new Date(),
    genderId: null,
    firstName: '',
    lastName: '',
    middleInitial: '',
    permanentAddressCity: '',
    permanentAddressState: '',
    permanentAddressZip: '',
    permanentAddressCounty: '',
    medicarePartAEffectiveDate: '',
    medicarePartBEffectiveDate: '',
    isESRD: false,
    isEnrolledInStateMedicaid: false,
    isEGHP: false,
    receiptDate: '',
    memberPreEnrollmentSourceId: 0,
    memberId: 0,
    effectiveDate: '',
    termDate: '',
    addedSource: '',
    updatedSource: '',
    loadComment: '',
    createdBy: '',
    permanentStateAndCountyCode: '',
    documentList: [],
    attachmentTypeId: 0
  });

  const [finalValues, setFinalValues] = useState<{ [key: string]: string }>({}); // To track final values
  const preEnrollmentData = useSelector(selectPreEnrollmentData);


  const [otherNote, setOtherNote] = useState<OtherNote>({
    NoteId: 0,
    MemberID: 0,
    Name: '',
    IsDeleted: 0,
    UpdatedDate: new Date(), // You need to initialize the Date fields
    UpdatedBy: '',
    CreatedDate: new Date(),
    CreatedBy: '',
  });

  let isMisMatch = false;
  // Simulate data fetching with useEffect
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        setLoading(true);
        const customerData = [
          { id: "1", name: "Last Name", member: "", cms: "", finalvalue: "" },
          { id: "2", name: "First Name", member: "", cms: "", finalvalue: "" },
          { id: "3", name: "Middle Initial", member: "", cms: "", finalvalue: "" },
          { id: "4", name: "Gender", member: "", cms: "", finalvalue: "" },
          { id: "5", name: "Permanent Address Zip", member: "", cms: "", finalvalue: "" },
          { id: "6", name: "Permanent Address City", member: "", cms: "", finalvalue: "" },
          { id: "7", name: "Permanent Address State", member: "", cms: "", finalvalue: "" },
          { id: "8", name: "Permanent County Code", member: "", cms: "", finalvalue: "" },
          { id: "9", name: "Medicare part A effective Date", member: "", cms: "", finalvalue: "" },
          { id: "10", name: "Medicare Part B Effective Date", member: "", cms: "", finalvalue: "" },
          { id: "11", name: "ESRD Flag", member: "", cms: "", finalvalue: "" },
          { id: "12", name: "Enrolled in State Medicaid", member: "", cms: "", finalvalue: "" },
          { id: "13", name: "EGHP", member: "", cms: "", finalvalue: "" },
        ];
        setCustomers1(customerData);
      } catch (error) {
        console.error("Error fetching customers:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCustomers();
  }, []);
  const [form] = useForm<FormInstance>();

  const [selectedRowData, setSelectedRowData] = useState<any>({});

  // Template to render a radio button in the Phone column
  const clearForm = () => {
    form.resetFields(); // This will reset all the form fields to their initial values
  };

  const getPreEnrollmentHeaderByMBIFun = () => {
    !form.getFieldsError().some(fieldError => fieldError)

    const formValues = form.getFieldsValue(true);
    if (formValues.beneficiaryIdentifier == null || formValues.beneficiaryIdentifier == undefined) {
      return;
    }
    setMemberEnrollmentHeaderModel({
      ...memberEnrollmentHeaderModel, // Spread the previous values to avoid overwriting
      genderId: formValues.gender ?? 0, // Set the desired property
    });

    const checkMemberAlreadyExist = async () => {
      const res = await getPreEnrollmentHeaderByMBI(formValues.beneficiaryIdentifier);
      if (res.result > 0) {
        // this.isRedirectToEnrollmentScreen(res.result);
      }
      else {
        setMemberEnrollmentHeaderModel({
          ...memberEnrollmentHeaderModel, // Spread the previous values to avoid overwriting
          enrollmentHeaderAttachment: [], // Set the desired property
        });
      }
      console.log(res)
    };
    checkMemberAlreadyExist();
  };
  const requestBEQWorkArround = async () => {
    const formValues = form.getFieldsValue(true);
    // Clear data if needed

    let user: UserModel = LocalStorageService.getDataObject(UserEnum.Current_User);

    if (formValues.beneficiaryBirthDate != null || formValues.beneficiaryBirthDate != undefined || formValues.beneficiaryBirthDate != '') {
      // setMemberBEQRequestModel(formValues);
      setMemberBEQRequestModel((prevState) => ({
        ...prevState, // Spread the previous state to avoid overwriting existing properties
        ...formValues, // Add the form values
        userId: user?.id ?? "", // Set the userId
      }));

      const res = await getCMSResponseWorkArround({
        ...formValues,
        userId: user?.id ?? '',
      });
      if (res == '') {
        // this.isRedirectToEnrollmentScreen(res.result);
      }
      else {

        setMemberEnrollmentHeaderModel({
          ...memberEnrollmentHeaderModel, // Spread the previous values to avoid overwriting
          enrollmentHeaderAttachment: [], // Set the desired property
        });
      }
      console.log(res)
      await bindCMSData(res);
    }
    else {
      // form.setFields([
      //   {
      //     name: 'beneficiaryBirthDate',
      //     touched: true, // Mark the field as touched
      //     errors: form.getFieldValue('beneficiaryBirthDate') ? [] : ['This field is required'], // Custom validation errors
      //   },
      // ]);

      // Optionally trigger validation across the form
      form.validateFields(['beneficiaryBirthDate']);
    }
  };
  const cancelForm = async () => {
    form.resetFields();
    setShowData(false)
  }
  const enrollMember = async () => {
    const formValues = form.getFieldsValue(true);
    console.log(finalValues)
    // console.log(preEnrollmentData.filePreEnroll)
    // console.log(preEnrollmentData.noteName.slice(3, -4))
    // console.log(preEnrollmentData.attachmentTypeId)
    preEnrollmentvalues.lastName = finalValues[1] ?? ""
    preEnrollmentvalues.firstName = finalValues[2] ?? ""
    preEnrollmentvalues.middleInitial = finalValues[3] ?? ""
    preEnrollmentvalues.genderId = genderList.find((item) => item.key === finalValues[4])?.value
    preEnrollmentvalues.permanentAddressZip = finalValues[5]
    preEnrollmentvalues.permanentAddressCity = finalValues[6]
    preEnrollmentvalues.permanentAddressState = finalValues[7]
    preEnrollmentvalues.permanentAddressCounty = finalValues[8]
    preEnrollmentvalues.medicarePartAEffectiveDate = finalValues[9]
    preEnrollmentvalues.medicarePartBEffectiveDate = finalValues[10]
    preEnrollmentvalues.isESRD = yesNoList.find((item) => item.key === finalValues[11])?.value == 10005 ? true : false
    preEnrollmentvalues.isEnrolledInStateMedicaid = yesNoList.find((item) => item.key === finalValues[12])?.value == 10005 ? true : false
    preEnrollmentvalues.isEGHP = yesNoList.find((item) => item.key === finalValues[13])?.value == 10005 ? true : false
    preEnrollmentvalues.mbi = formValues.beneficiaryIdentifier;
    preEnrollmentvalues.dob = formValues.beneficiaryBirthDate;
    preEnrollmentvalues.attachmentTypeId = preEnrollmentData.attachmentTypeId;
    preEnrollmentvalues.permanentStateAndCountyCode = finalValues[8]
    preEnrollmentvalues.effectiveDate = finalValues[9]
    preEnrollmentvalues.termDate = finalValues[10]

    preEnrollmentvalues.applicationStatusID = ApplicationStatus.EPreEenrollReady;
    
    preEnrollmentvalues.applicationStatusID = formValues.receiptDate

    if (isMisMatch) {
      preEnrollmentvalues.applicationStatusID = ApplicationStatus.EBEQMismatch;
    }
    const res = await saveFinalValue(preEnrollmentvalues);
    if (res && Number(res) > 0) {

      if (preEnrollmentData) {
        const formData = new FormData();

        if (preEnrollmentData.filePreEnroll) {
          formData.append("filePreEnroll", preEnrollmentData.filePreEnroll); // Append the file
        }
        // formData.append("noteName", preEnrollmentData.noteName); // Append the noteName
        formData.append("attachmentType", preEnrollmentData.attachmentTypeId.toString()); // Append attachmentTypeId as string

        // You may append additional data like memberId here
        formData.append("memberId", res); // Example of appending memberId

        try {
          const res = await otherFileUpload(formData);
          console.log("Upload successful:", res);
        } catch (error) {
          console.error("Error uploading:", error);
        }
      }
      // this.documentService.clearFormData();

      otherNote.Name = preEnrollmentData.noteName.slice(3, -4)
      otherNote.MemberID = Number(res)
      // if (this.othernote.MemberID == 0) {
      //   this.notificationService.showMessage(AlertMessageType.Error, AppConstant.wentWrong);
      //   return;
      // }
      otherNote.IsDeleted = 0;
      otherNote.UpdatedBy = "";
      // this.othernote.CreatedBy = authService.currentUser.userName;
      // this.othernote.UpdatedDate = Utils.formateDate(new Date());
      // this.othernote.CreatedDate = Utils.formateDate(new Date());

      const res3 = await InsertNote(
        otherNote);
      dispatch(AddPreEnrollmentData({
        noteName: '',
        attachmentTypeId: 0,
        filePreEnroll: null
      }));
      // this.isRedirectToEnrollmentScreen(res);
    }


  }

  const bindCMSData = async (responseCMS: string) => {
    if (responseCMS) {
      let response = await JSON.parse(responseCMS);
      const formValues = await form.getFieldsValue(true);

      setMemberEnrollmentHeaderModel((prevState) => ({
        ...prevState,
        ...response, // Merge with the CMS response
        mbi: formValues.beneficiaryIdentifier,
        dob: formValues.beneficiaryBirthDate,
        receiptDate: new Date(Date.now() - 86400000), // Setting to yesterday
        contactTypeId: 6406,
        enrollmentHeaderAttachment: [],
      }));
      const responseMapping = {
        "Last Name": response.LastName,
        "First Name": response.FirstName,
        "Middle Initial": response.MiddleInitial,
        "Gender": response.GenderID, // Assuming GenderID corresponds to the Gender column
        "Permanent Address Zip": response.PermanentAddressZip,
        "Permanent Address City": response.PermanentAddressCity,
        "Permanent Address State": response.PermanentAddressState,
        "Permanent County Code": response.PermanentStateAndCountyCode,
        "Medicare part A effective Date": response.MedicarePartAEffectiveDate,
        "Medicare Part B Effective Date": response.MedicarePartBEffectiveDate,
        "ESRD Flag": response.IsESRD,
        "Enrolled in State Medicaid": response.IsEnrolledInStateMedicaId,
        "EGHP": response.IsEGHP,
      };

      setCustomers1((prevCustomers) =>
        prevCustomers.map((customer) => {
          return {
            ...customer,
            cms: ((responseMapping[customer.name] == undefined) || (responseMapping[customer.name] == 0) || (responseMapping[customer.name] == null)) ? '' : responseMapping[customer.name], // Use mapped value or empty string
          };
        })
      );

      setShowData(true); // To display data based on condition
    }
  };


  const handleAlphabetInput = (event: any) => {
    const value = event;
    return value
  };
  const handleKeyPress = (event: React.KeyboardEvent<HTMLInputElement>) => {
    const charCode = event.charCode;

    // Allow only alphabets (A-Z, a-z) and control keys (backspace, tab, etc.)
    if (
      (charCode < 65 || charCode > 90) && // A-Z
      (charCode < 97 || charCode > 122) && // a-z
      charCode !== 8 && // Backspace
      charCode !== 9 // Tab
    ) {
      event.preventDefault();
    }
  };
  // Custom validation to allow only numbers
  const handleNumberInput = (event: any) => {
    const value = event;
    // Replace any non-numeric characters with an empty string
    return value
  };
  const phoneTemplate = (rowData: any) => {
    const { id, name } = rowData;
    const value = selectedRowData[id]?.member || rowData.member;
    const type = ["Gender"].includes(name) ? "Dropdown" : ["ESRD Flag", "Enrolled in State Medicaid", "EGHP"].includes(name) ? "YesNoDropdown" :
      ["First Name", "Middle Initial", "Last Name"].includes(name) ? "InputText" :
        ["Permanent Address Zip", "Permanent County Code"].includes(name) ? "InputNumber" :
          ["Medicare part A effective Date", "Medicare Part B Effective Date"].includes(name) ? "Calendar" :
            "InputText"; // default

    return (
      <>
        {renderInput(type, value, rowData, id)}
        <RadioButton
          value="member"
          checked={selectedRowData[id]?.selected === "member"}
          onChange={() => handleRadioChange(id, "member")}
        />
      </>
    );
  };
  const renderInput = (type: string, value: any, rowData: any, id: string) => {
    switch (type) {
      case "Dropdown":
        return (
          <Dropdown
            options={genderList}
            optionLabel="key"
            optionValue="value"
            placeholder="Select Gender"
            value={value}
            onChange={(e) => handleMemberChange(id, e.value)}
          />
        );
      case "YesNoDropdown":
        return (
          <Dropdown
            options={yesNoList}
            optionLabel="key"
            optionValue="value"
            placeholder="Select"
            value={value}
            onChange={(e) => handleMemberChange(id, e.value)}
          />
        );
      case "InputText":
        return (
          <InputText
            value={value}
            onChange={(e) => handleMemberChange(id, handleAlphabetInput(e))}
            onKeyPress={handleKeyPress}
          />
        );
      case "InputNumber":
        return (
          <InputNumber
            value={value}
            onChange={(e) => handleMemberChange(id, handleNumberInput(e))}
          />
        );
      case "Calendar":
        return (
          <Calendar
            value={value}
            onChange={(e) => handleMemberChange(id, e)}
            dateFormat="mm/dd/yy"
            placeholder="Select Date"
            showIcon
          />
        );
      default:
        return null;
    }
  };
  const CMSTemplate = (rowData: any) => {
    return (
      <div className="flex align-items-center gap-3">
        <div>{rowData.cms}</div>
        <RadioButton
          value="cms"
          checked={selectedRowData[rowData.id]?.selected === "cms"}
          onChange={() => handleRadioChange(rowData.id, "cms")}
        />
      </div>
    );
  };

  const FinalTemplate = (rowData: any) => {
    return <div>{finalValues[rowData.id]}</div>;
  };

  const handleMemberChange = (id: string, value: any) => {
    setSelectedRowData((prevState) => ({
      ...prevState,
      [id]: {
        ...prevState[id],
        member: value,
      },
    }));

    // Update the final value if "member" is selected
    if (selectedRowData[id]?.selected === "member") {
      setFinalValues((prevValues) => ({
        ...prevValues,
        [id]: value,
      }));
    }
  };

  const handleRadioChange = (id: string, selected: "member" | "cms") => {
    if (selected == "member") {
      isMisMatch = true;
    }
    setSelectedRowData((prevState) => ({
      ...prevState,
      [id]: {
        ...prevState[id],
        selected,
      },
    }));

    // Get the member or cms value based on the selected radio button
    const valueToSet = selected === "member"
      ? selectedRowData[id]?.member || customers1.find(c => c.id === id)?.member
      : customers1.find(c => c.id === id)?.cms;

    const getMappedValue = (value: any) => {
      const genderMatch = genderList.find((item) => item.value === value);
      const yesNoMatch = yesNoList.find((item) => item.value === value);
      if (genderMatch) return genderMatch.key;
      if (yesNoMatch) return yesNoMatch.key;
      return value; // Return the value if no match found
    };

    // Check if the valueToSet is a date and format it, or check for gender/yes-no list match
    const parsedValueToSet =
      valueToSet instanceof Date
        ? `${valueToSet.getMonth() + 1}/${valueToSet.getDate()}/${valueToSet.getFullYear()}`
        : getMappedValue(valueToSet); // Apply mapping logic for gender and yes/no

    setFinalValues((prevValues) => ({
      ...prevValues,
      [id]: parsedValueToSet,
    }));
  };

  return (
    <>
      <h2 className="pb-4">Pre-Enrollment Configuration</h2>
      <Panel toggleable className="m-0 search-panel" header="Information">
        <CustomForm form={form} >
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <div>
              <FormItem
                name="beneficiaryIdentifier"
                label="MBI Number">
                <InputText placeholder="Enter here" />
              </FormItem>
            </div>
            <div>
              <FormItem name="beneficiaryBirthDate" label="DOB">
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  maxDate={new Date()}
                />
              </FormItem>
            </div>
            <div>
              <FormItem
                name="gender"
                label="Gender"

              >
                <Dropdown
                  id="gender"
                  options={genderList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
            </div>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3 mb-4">
            <Button label="clear" text onClick={clearForm} />
            <Button
              label="View"
              outlined
              onClick={getPreEnrollmentHeaderByMBIFun}
            />
            <Button label="Request BEQ" raised onClick={requestBEQWorkArround} />
            {/* <Button label="Request BEQ" raised /> */}
          </div>

          {showData && (<div className="pb-4">
            <DataTable value={customers1} className="p-datatable-gridlines border-bottom-1" showGridlines rows={10} dataKey="id" emptyMessage="No records found" loading={loading} selection={selectedCustomer} onSelectionChange={(e) => setSelectedCustomer(e.value)}>
              <Column field="name" header="Field" style={{ width: '25%' }} />
              <Column field="member" header="Member" body={phoneTemplate} style={{ width: '25%' }} />
              <Column field="cms" header="CMS" body={CMSTemplate} style={{ width: '25%' }} />
              <Column field="finalvalue" header="Final Value" body={FinalTemplate} style={{ width: '25%' }} />

            </DataTable>
          </div>)}
          {showData && (<div className="pb-4">
            <h5 className="border-bottom-1 pb-3 mb-3">Other Details</h5>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">
              <div>
              <FormItem name="receiptDate" label="Receipt Date">
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  maxDate={new Date()}
                />
              </FormItem>
              </div>
              <div>
                <Button outlined type="button" label="Notes & Attachment" className="mt-3" onClick={() => setVisibleBottom(true)} />
              </div>
            </div>

          </div>
          )}
          {showData && (<div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={cancelForm} />
            <Button label="Enroll" raised onClick={enrollMember} />
          </div>)}
        </CustomForm>
      </Panel>
      {showData && (<Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-4/6 text-xl"
        header="Notes"
      >
        <NotesAttachment />
      </Sidebar>)}

    </>
  );
};

export default PreEnrollment;
function dispatch(arg0: any) {
  throw new Error("Function not implemented.");
}

