import FormItem from "../../../controls/FormItem";
import InputText from "../../../controls/InputText";
import CustomForm from "../../../controls/CustomForm";
import { useEffect, useState } from "react";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import InputMask from "../../../controls/InputMask";
import { MemberAndPlanInfoModel } from "../../../model/MemberAndPlanInfoModel";
import { FormInstance, useForm } from "rc-field-form";
import CommonCodeService from "../../../services/CommonCodeService";
import { CodeType, HIPAACommunication } from "../../../data/constants/AppEnum";
import { ProviderService } from "../../../services/ProviderService";
import { EnrollmentService } from "../../../services/EnrollmentService";
import { AccordianProps } from "./EnrollmentMemberInfo";
import Button from "../../../controls/Button";
import { CancelNextTab, NextTab, PreviousTab } from "../../../Redux/features/enrollmentSlice";
import { useDispatch } from "react-redux";

const EnrollmentContactDetails = ({ form }: AccordianProps) => {

  const [languageList, setlanguageList] = useState(null);
  const [accessibiltyList, setAccessibiltyList] = useState(null);

  const { getCommonCodeByCodeTypeIdRace } = CommonCodeService();
  const { getPerAddresInfo } = EnrollmentService();
  const { getCommonCodeByCodeTypeIdAll, getMemberCount } = ProviderService();
  const [contactPreferenceList, setContactPreferenceList] = useState(null);
  const [isEmailRequired, setIsEmailRequired] = useState(false);
 
  const [hasError, setHasError] = useState<boolean>(true);
  const dispatch = useDispatch();
  const handleZipChange = async (e) => {
    const zipCode = e;
    form.setFieldValue("permanentAddressZip", zipCode);

    if (zipCode) {
      try {
        const res = await getPerAddresInfo(zipCode);
        form.setFieldsValue({
          permanentAddressCity: res.city,
          permanentAddressState: res.state,
          permanentAddressCounty: res.county,
          permanentStateandCountyCode: res.countyCode,
        });
      } catch (error) {
        console.error("Error fetching address info:", error);
      }
    }
  };

  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }

  }, [hasError])
  const handleMailZipChange = async (e) => {
    const zipCode = e;
    form.setFieldValue("mailingAddressZip", zipCode);

    if (zipCode) {
      try {
        const res = await getPerAddresInfo(zipCode);
        form.setFieldsValue({
          mailingAddressCity: res.city,
          mailingAddressState: res.state
        });
      } catch (error) {
        console.error("Error fetching address info:", error);
      }
    }
  };
  const handleContactPreferenceChange = (e) => {
    const selectedValue = e.value;
    form.setFieldValue("contactPreference", selectedValue);

    // Check if the selected value is "mail" to conditionally set email as required
    if (selectedValue === HIPAACommunication.Email) {
      setIsEmailRequired(true);
      form.validateFields(["email"]); // Validate email if it's required
    } else {
      setIsEmailRequired(false);
      form.resetFields(["email"]); // Clear email validation errors if not required
    }
  };
  useEffect(() => {
    const language = getCommonCodeByCodeTypeIdAll(CodeType.Language);
    const accessibilty = getCommonCodeByCodeTypeIdRace(CodeType.AccessibilityFormat);
    const contactPreference = getCommonCodeByCodeTypeIdRace(CodeType.HIPAACommunication);


    Promise.all([language, accessibilty, contactPreference]).then(result => {
      setlanguageList(result[0]);
      setAccessibiltyList(result[1]);
      setContactPreferenceList(result[2]);

    })

  }, [form]);
  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }
  }
  const handlePrevious = async () => {
    dispatch(PreviousTab())
  }
  return (
    <>

      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3 items-center">
        <FormItem name="primaryLanguageID" label="Language" rules={[
          { required: true }
        ]}>
          <Dropdown
            id="language"
            options={languageList}
            optionLabel="key"
            optionValue="value"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="accessibilityFormatID" label="Accessibility" rules={[
          { required: true }
        ]}>
          <Dropdown
            id="accessibility"
            options={accessibiltyList}
            optionLabel="key"
            optionValue="value"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <div className="col-span-2">
          <FormItem name="permanentAddressLine1" label="Permanent Address" rules={[
            { required: true }
          ]}>
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
        </div>
        <FormItem name="permanentAddressZip" label="Permanent Address Zip" rules={[
          { required: true }, { pattern: /^[0-9]*$/, message: 'Permanent Address Zip can only contain numbers' }]}>
          <InputText type="text" placeholder="Enter here" onChange={handleZipChange} />

        </FormItem>
        <FormItem name="permanentAddressCity" label="Permanent Address City" rules={[
          { required: true }, { pattern: /^[a-zA-Z]*$/, message: 'Permanent Address City can only contain alphabets' }
        ]}>
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="permanentAddressState" label="Permanent Address State" rules={[
          { required: true }, { pattern: /^[a-zA-Z]*$/, message: 'Permanent Address State can only contain alphabets' }, { max: 2, message: 'Permanent Address Statecannot be longer than 2 characters' }]}>
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="permanentAddressCounty" label="Permanent Address County" rules={[
          { required: true }]}>
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="permanentStateandCountyCode" label="Permanent State & County Code" rules={[
          { required: true }, { pattern: /^[0-9]*$/, message: 'Permanent State & County Code can only contain numbers' }]}>
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="phoneNumber" label="Phone">
          <InputMask mask="(999) 999-9999" placeholder="Enter here" />
        </FormItem>
        <FormItem name="altPhonenumber" label="Alternate Phone">
          <InputMask mask="(999) 999-9999" placeholder="Enter here" />
        </FormItem>
        <FormItem name="contactPreference" label="Contact Preference" rules={[
          { required: true }]}>
          <Dropdown
            id="contactPreference"
            options={contactPreferenceList}
            optionLabel="key"
            optionValue="value"
            onChange={handleContactPreferenceChange}
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem
          name="email"
          label="Email ID"
          rules={isEmailRequired ? [{ required: true, message: "Email is required when contact preference is mail" }] : []}
        >
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <div className="col-span-2">
          <FormItem name="mailingAddressLine1" label="Mailing Address">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
        </div>
        <FormItem name="mailingAddressZip" label="Mailing Address Zip" rules={[
          { pattern: /^[0-9]*$/, message: 'Permanent State & County Code can only contain numbers' }]}>
          <InputText type="text" placeholder="Enter here" onChange={handleMailZipChange} />
        </FormItem>
        <FormItem name="mailingAddressCity" label="Mailing Address City" rules={[
          { pattern: /^[a-zA-Z]*$/, message: 'Permanent Address City can only contain alphabets' }
        ]}>
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="mailingAddressState" label="Mailing Address State" rules={[
          { pattern: /^[a-zA-Z]*$/, message: 'Mailing Address State can only contain alphabets' }
        ]}>
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="emergencyContactName" label="Emergency Contact Name" rules={[
          { pattern: /^[a-zA-Z]*$/, message: 'Emergency Contact Name can only contain alphabets' }
        ]}>
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="emergencyContactPhone" label="Emergency Contact Phone">
          <InputMask mask="(999) 999-9999" placeholder="Enter here" />
        </FormItem>
      </div>
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" onClick={handlePrevious} />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentContactDetails;

