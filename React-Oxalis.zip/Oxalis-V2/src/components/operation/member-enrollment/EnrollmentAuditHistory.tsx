import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { AccordianProps } from "./EnrollmentMemberInfo";

const EnrollmentAuditHistory  = ({ form }: AccordianProps) => {
  return (
    <>
      <DataTable
        paginator
        className="p-datatable-gridlines"
        showGridlines
        rows={10}
        dataKey="claimId"
        emptyMessage="No records found."
        selectionMode="single"
      >
        <Column field="modifiedField" header="Modified&nbsp;Field" filter sortable />
        <Column field="mbi" header="MBI" filter sortable />
        <Column field="memberID" header="Member&nbsp;ID" filter sortable />
        <Column field="beforeValue" header="Before&nbsp;Value" filter sortable />
        <Column field="afterValue" header="After&nbsp;Value" filter sortable />
        <Column field="modifiedDate" header="Modified&nbsp;Date" filter sortable />
        <Column field="modifiedBy" header="Modified&nbsp;By" filter sortable />
        <Column field="source" header="Source" filter sortable />
      </DataTable>
    </>
  );
};

export default EnrollmentAuditHistory;
