import ViewForm from "../../../controls/ViewForm";

const EnrollmentBEQView = () => {
  const headerRecord = [
    { label: "File ID", value: "MMABEQRH" },
    { label: "Sending Entity", value: "H4869" },
    { label: "File", value: "GOLDKIDNEY.txt" },
    { label: "File Control", value: "000000193" },
  ];

  const detailRecord = [
    { label: "Record Type", value: "DTL01" },
    { label: "Beneficiary ID", value: "1N19M19GG77" },
    { label: "Date of Birth", value: "01/23/1950" },
    { label: "Gender Code", value: "Male" },
    { label: "Detail Record", value: "1" },
  ];

  const trailerRecord = [
    { label: "File ID Name", value: "MMABEQRT" },
    { label: "Sending Entity (CMS)", value: "H4869" },
    { label: "File Creation Date", value: "07/15/2024" },
    { label: "File Control Number", value: "000000193" },
    { label: "Record Count", value: "4" },
  ];
  const startRecord = [
    { label: "Record Type", value: "N/A" },
    { label: "Beneficiary ID", value: "1N19M19GG77" },
    { label: "Beneficiary's Date of Birth", value: "04/09/2024" },
    { label: "Beneficiary's Gender Code", value: "Male" },
    { label: "Detail Record Sequence Number", value: "B000001" },
  ];
  const endRecord = [
    { label: "Processed Flag", value: "Yes" },
    { label: "Beneficiary Match Flag", value: "Yes" },
    { label: "Medicare Part A Entitlement Start Date", value: "01/01/2010" },
    { label: "Medicare Part B Entitlement Start Date", value: "01/01/2010" },
    { label: "Medicaid Indicator", value: "0" },
    { label: "Part D Enrollment Effective Date", value: "01/01/2010" },
  ];

  return (
    <>
      <ViewForm header="BEQ Request File Header Record" data={headerRecord} />
      <ViewForm header="BEQ Request File Detail Record" data={detailRecord} />
      <ViewForm header="BEQ Request File Trailer Record" data={trailerRecord} />
      <ViewForm header="Start of Original Detail Record" data={startRecord} />
      <ViewForm header="End of Original Detail Record" data={endRecord} />
    </>
  );
};

export default EnrollmentBEQView;
