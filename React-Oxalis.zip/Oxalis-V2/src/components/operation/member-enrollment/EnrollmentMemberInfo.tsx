import FormItem from "../../../controls/FormItem";
import InputText from "../../../controls/InputText";
import CustomForm from "../../../controls/CustomForm";
import { useEffect, useState } from "react";
import Dropdown from "../../../controls/Dropdown";
import Calendar from "../../../controls/Calendar";
import InputNumber from "../../../controls/InputNumber";
import { FormInstance, useForm } from "rc-field-form";
import { MemberAndPlanInfoModel } from "../../../model/MemberAndPlanInfoModel";
import { CodeType, Page } from "../../../data/constants/AppEnum";
import CommonCodeService from "../../../services/CommonCodeService";
import { EnrollmentService } from "../../../services/EnrollmentService";
import { useDispatch, useSelector } from "react-redux";
import { AddDob, NextTab } from "../../../Redux/features/enrollmentSlice";
import Button from "../../../controls/Button";
import { RootState } from "../../../Redux/app/store";
import FormListItem from "../../../controls/FormListItem";
export interface AccordianProps {
  form: FormInstance<MemberAndPlanInfoModel>;
}
const EnrollmentMemberInfo = ({ form }: AccordianProps) => {
  const [memberStatusList, setMemberStatusList] = useState(null);
  const [ethnicityList, SetEthnicityList] = useState(null);
  const [raceList, setRaceList] = useState(null);
  const [prefixList, setPrefixList] = useState(null);
  const [genderList, setGenderList] = useState(null);
  const [selectedPrefix, setSelectedPrefix] = useState(null);
  const [selectedGender, setSelectedGender] = useState(null);
  const [prefixValidationMessage, setPrefixValidationMessage] = useState("");
  const [hasError, setHasError] = useState<boolean>(true);
  const [genderValidationMessage, setGenderValidationMessage] = useState("");
  const { getCommonCodeByCodeTypeId, getCommonCodeByCodeTypeIdRace, getCommonCodeConfigurationByCodeTypeId } = CommonCodeService();
  const dispatch = useDispatch();


  const [subGroup, setSubGroupList] = useState(null);


  const MBI_REGEXP = /\b[1-9][AC-HJKMNP-RT-Yac-hjkmnp-rt-y][AC-HJKMNP-RT-Yac-hjkmnp-rt-y0-9][0-9]-?[AC-HJKMNP-RT-Yac-hjkmnp-rt-y][AC-HJKMNP-RT-Yac-hjkmnp-rt-y0-9][0-9]-?[AC-HJKMNP-RT-Yac-hjkmnp-rt-y]{2}\d{2}\b/gm;

  const onFocusOutMbiEvent = (e) => {
    if (e.target.value && !MBI_REGEXP.test(e.target.value)) {
      // Display validation message
      console.log("MBI number is invalid");
    }
  };
  const [mbiValue, setMbiValue] = useState('');
  const [mbiValidationMessage, setMbiValidationMessage] = useState('');
  const handleMBIChange = async (rule, value) => {

    setMbiValue(value);

    // Check if MBI is valid
    if (!MBI_REGEXP.test(value)) {
      return Promise.reject("MBI must follow the correct format");

    } else {
      return Promise.resolve();
    }
  };
  const changeHandleMBIChange = async (e) => {
    form.setFieldValue("mbi" as any, e.value);
    await form.validateFields(["mbi"]);
  };
  const handleDateChange = (selectedDate) => {
    dispatch(AddDob(selectedDate));
  }; // Your additional logic here };

  // const handlePrefixChange = (e) => {
  //   const newPrefix = e.value;
  //   setSelectedPrefix(newPrefix);
  //   validatePrefixGender();
  // };

  // const handleGenderChange = (e) => {
  //   const newGender = e.value;
  //   setSelectedGender(newGender);
  //   validatePrefixGender();
  // };

  const validatePrefix = async () => {
    // Explicitly cast "gender" as any to bypass the TypeScript error
    let prefix = form.getFieldValue("prefix" as any);
    const gender = form.getFieldValue("gender" as any);

    if (gender === "M" && prefix !== 5202 && prefix != null && prefix != undefined) {
      return Promise.reject("If gender is Male, prefix must be Mr.");
    } else if (gender === "F" && ![5201, 5203].includes(prefix) && prefix != null && prefix != undefined) {
      return Promise.reject("If gender is Female, prefix must be Mrs or Miss.");
    } else {
      validateGender();
      return Promise.resolve();
    }

  };

  const validateGender = async () => {

    let gender = form.getFieldValue("gender" as any);
    let prefix = form.getFieldValue("prefix" as any);
    if (gender === "M" && prefix !== 5202 && gender != null && gender != undefined) {
      return Promise.reject("If gender is Male, prefix must be Mr.");
    } else if (gender === "F" && ![5201, 5203].includes(prefix) && gender != null && gender != undefined) {
      return Promise.reject("If gender is Female, prefix must be Mrs or Miss.");
    }
    else {
      validatePrefix();
      return Promise.resolve();
    }
  };
  const handlePrefixChange = async (e) => {
    form.setFieldValue("prefix" as any, e.value);
    await form.validateFields(["prefix", "gender"]);
  };

  const handleGenderChange = async (e) => {
    form.setFieldValue("gender" as any, e.value);
    await form.validateFields(["gender", "prefix"]);
  };
  useEffect(() => {
    const memberStatus = getCommonCodeByCodeTypeId(CodeType.MemberStatus);
    const ethnicity = getCommonCodeByCodeTypeIdRace(CodeType.Ethnicity);
    const race = getCommonCodeByCodeTypeIdRace(CodeType.Race);
    const prefix = getCommonCodeByCodeTypeId(CodeType.Prefix);
    const subGroup = getCommonCodeByCodeTypeId(CodeType.SubGroup);
    const genderList = getCommonCodeConfigurationByCodeTypeId(Page.ENROLLMENT_PAGE.toString(), CodeType.Gender);

    Promise.all([memberStatus, ethnicity, race, prefix, subGroup, genderList]).then(result => {
      setMemberStatusList(result[0]);
      SetEthnicityList(result[1]);
      setRaceList(result[2]);
      setPrefixList(result[3]);
      setSubGroupList(result[4]);
      setGenderList(result[5]);
    })
    dispatch(AddDob(form.getFieldValue("dob")));
  }, [form]);

  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])

  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  const handlePrevious = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  return (
    <>

      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3 items-center">
        <FormItem name="trackingID" label="Tracking ID">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="lobName" label="LOB Type">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="memberStatusID" label="Member Status" rules={[
          { required: true }
        ]}>
          <Dropdown
            id="memberStatus"
            options={memberStatusList}
            optionLabel="key"
            optionValue="value"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <div className="form-item-container">
          <FormListItem name="prefix" label="Prefix" rules={[{ validator: validatePrefix }]}>
            <Dropdown
              id="prefix"
              options={prefixList}
              optionLabel="key"
              optionValue="value"
              onChange={handlePrefixChange}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormListItem>

        </div>
        <FormItem
          name="firstName"
          label="First Name"
          rules={[
            { required: true, message: 'First Name is required' }, // Required validation
            { max: 20, message: 'First Name cannot be longer than 20 characters' }, // Max length validation
            { pattern: /^[a-zA-Z]*$/, message: 'First Name can only contain alphabets' } // Pattern validation
          ]}
        >
          <InputText placeholder="Enter First Name" />
        </FormItem>

        <FormItem
          name="lastName"
          label="Last Name"
          rules={[
            { required: true, message: 'Last Name is required' }, // Required validation
            { max: 20, message: 'Last Name cannot be longer than 20 characters' }, // Max length validation
            { pattern: /^[a-zA-Z]*$/, message: 'Last Name can only contain alphabets' } // Pattern validation
          ]}
        >
          <InputText placeholder="Enter Last Name" />
        </FormItem>
        <FormItem
          name="middleName"
          label="Middle Initial"
          rules={[
            { max: 1, message: 'Middle Initial cannot be longer than 1 character' }, // Max length validation
            { pattern: /^[a-zA-Z]*$/, message: 'Middle Initial can only contain alphabets' } // Pattern validation
          ]}
        >
          <InputText placeholder="Enter Middle Initial" />
        </FormItem>

        <FormItem name="raceID" label="Race">
          <Dropdown
            id="race"
            options={raceList}
            optionLabel="key"
            optionValue="value"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="ethnicityID" label="Ethnicity">
          <Dropdown
            id="ethnicity"
            options={ethnicityList}
            optionLabel="key"
            optionValue="value"
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="dob" label="Date Of Birth" rules={[{ required: true }]}>
          <Calendar
            placeholder="Enter Date"
            selectionMode="single"
            icon="cl_calendar_today_line"
            iconPos="right"
            dateFormat="mm/dd/yy"
            maxDate={new Date()}
            onChange={handleDateChange} // Call your function on date change
          />
        </FormItem>
        <div className="form-item-container">
          <FormListItem name="gender" label="Gender" rules={[{ validator: validateGender }]}>
            <Dropdown
              id="gender"
              options={genderList}
              optionLabel="value"
              optionValue="key"
              onChange={handleGenderChange}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormListItem>

        </div>
        <FormListItem
          name="ssn"
          label="SSN"
          rules={[
            { pattern: /^[0-9]*$/, message: 'SSN can only contain numbers' }
          ]}
        >
          <InputText placeholder="Enter SSN" />
        </FormListItem>

        <div className="form-item-container">
          <FormListItem name="mbi" label="MBI" rules={[
            { required: true, message: "MBI is required" },
            { validator: handleMBIChange, message: "MBI must follow the correct format" }
          ]}>
            <InputText
              placeholder="Enter MBI"
              value={mbiValue}
              onChange={changeHandleMBIChange}
              className="w-full"
            />
          </FormListItem>
          {/* <span style={{ color: 'red', fontSize: '12px', marginTop: '4px' }}>
            {mbiValidationMessage || '\u00A0'}
          </span> */}
        </div>

        <FormItem name="memberCode" label="Client Member ID">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
      </div>
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        {/* <Button label="Previous" text type="button" /> */}
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>

    </>
  );
};

export default EnrollmentMemberInfo;
