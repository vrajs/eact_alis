import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useEffect, useRef, useState } from "react";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import InputText from "../../../controls/InputText";
import { useNavigate } from "react-router-dom";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import CustomForm from "../../../controls/CustomForm";
import { MemberAndPlanInfoModel } from "../../../model/MemberAndPlanInfoModel";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import { LazyTableState } from "../../../model/LazyTableState";
import { FormInstance, useForm } from "rc-field-form";
import { GridModel } from "../../../model/GridModel";
import { vwMemberEnrollmentDetail } from "../../../model/vwMemberEnrollmentDetail";
import PreEnrollmentService from "../../../services/PreEnrollmentService";
import { EnrollmentService } from "../../../services/EnrollmentService";
import CommonCodeService from "../../../services/CommonCodeService";
import { CodeType } from "../../../data/constants/AppEnum";
import { KeyValueModel } from "../../../model/KeyValueModel";

const EnrollmentSearch = () => {
  const navigate = useNavigate();
  const [customers1, setCustomers1] = useState<any>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMember, setselectedMember] = useState<MemberAndPlanInfoModel | null>();
  const [contractNumber, setContractNumberList] = useState(null);

  const [PBPNumber, setPBPNumberList] = useState(null);

  const { getMemberGrid } = EnrollmentService();
  const [contractList, setContractList] = useState(null);
  const [pbpList, setPbpList] = useState(null);
  const [tranList, setTranList] = useState(null);

  const [gridValues, setGridValues] = useState([]);
  const ref = useRef<Panel>(null);
  const { getCommonCodeByCodeTypeId } = CommonCodeService();
  const [totalRecords, setTotalRecords] = useState(0);
  const [form] = useForm<FormInstance>();
  const [transactionStatus, setTransactionStatusList] = useState(null);
  const memberStatusArray: KeyValueModel[] = [
    { value: 51401, key: 'Active' },
    { value: 51402, key: 'Pending' },
    { value: 51403, key: 'Disenrolled' },
    { value: 51404, key: 'Cancelled' }
  ];
  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });
  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState]);
  // Simulate data fetching with a useEffect
  useEffect(() => {
    const contract = getCommonCodeByCodeTypeId(CodeType.CMSContractCode);
    const pbp = getCommonCodeByCodeTypeId(CodeType.CMSPBPCode);
    const tran = getCommonCodeByCodeTypeId(CodeType.ApplicationStatus);


    Promise.all([contract, pbp, tran]).then(result => {
      setContractList(result[0]);
      setPbpList(result[1]);
      setTranList(result[2]);

    })
  }, [])
  const loadLazyData = async () => {
    const searchForm = form.getFieldsValue(true);
    ref.current.collapse(undefined)
    setLoading(true);
    const groupGridData: GridModel<vwMemberEnrollmentDetail> = await getMemberGrid(searchForm, lazyState.first, lazyState.rows);
    if (groupGridData) {
      setGridValues(groupGridData.data);
      setTotalRecords(groupGridData.totalCount);
      setLoading(false);
    }
  };
  const handleSelection = (e) => {
    if (e.value) {
      setselectedMember(e.value)
    } else {
      setselectedMember(null);
    }
  }

  const handleNavigate = () => {
    navigate(`/operation/member/enrollment-add-edit/${0}`);
  };
  const handleEdit = () => {
    const memberId: number = selectedMember.memberID;
    navigate(`/operation/member/enrollment-add-edit/${memberId}`);
  }
  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Advance Search</div>
        <div className="flex align-items-center gap-2">
          <Dropdown optionLabel="name" placeholder="Saved Search (0)" filter className="w-full" />
          <Button outlined label="Add" onClick={handleNavigate} />
          {selectedMember && <Button outlined label="Edit" onClick={handleEdit} />}
          <Button label="Export" outlined />
          {options.togglerElement}
        </div>
      </div>
    );
  };
  return (
    <>
      <h2 className="pb-4">Enrollment Information</h2>
      <Panel headerTemplate={headerTemplate} ref={ref} toggleable className="search-panel">
        <CustomForm form={form} onFinish={loadLazyData}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="trackingID" label="Tracking ID">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="mbi" label="MBI">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="firstName" label="First Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="lastName" label="Last Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="memberID" label="Member ID">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="clientMemberID" label="Client Member ID">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="applicationStatusID" label="Trans Status">
              <Dropdown
                id="transaction"
                options={tranList}
                optionLabel="key"
                optionValue="value"
                showClear
                placeholder="Select"
                className="w-full"
                onChange={(e: DropdownChangeEvent) => form.setFieldsValue({ applicationStatusID: e.value || null } as Partial<typeof form>)}
              />
            </FormItem>
            <FormItem name="contractID" label="Contract Number">
              <Dropdown
                id="contract"
                options={contractList}
                optionLabel="key"
                optionValue="value"
                showClear
                placeholder="Select"
                className="w-full"
                onChange={(e: DropdownChangeEvent) => form.setFieldsValue({ contractID: e.value || null } as Partial<typeof form>)}
              />
            </FormItem>
            <FormItem name="pBPID" label="PBP Number">
              <Dropdown
                id="pbp"
                options={pbpList}
                optionLabel="key"
                optionValue="value"
                showClear
                placeholder="Select"
                className="w-full"
                onChange={(e: DropdownChangeEvent) => form.setFieldsValue({ pBPID: e.value || null } as Partial<typeof form>)}
              />
            </FormItem>
            <FormItem name="memberStatusID" label="Member Status">
              <Dropdown
                id="memberStatus"
                options={memberStatusArray}
                optionLabel="key"
                optionValue="value"
                showClear
                placeholder="Select"
                className="w-full"
                onChange={(e: DropdownChangeEvent) => form.setFieldsValue({ memberStatusID: e.value || null } as Partial<typeof form>)}  // Cast to Partial
              />
            </FormItem>


          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="clear" text />
            <Button label="Apply" outlined />
            <Button label="Apply & Save" raised onClick={handleNavigate} />
          </div>
        </CustomForm>
      </Panel>
      <div className="pb-4">
        <DataTable
          paginator
          rowsPerPageOptions={paginatorConstants.pageOptions}
          className="p-datatable-gridlines"
          showGridlines
          rows={lazyState.rows}
          tableStyle={{ minWidth: '50rem' }}
          paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
          currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
          dataKey="providerID"
          emptyMessage={paginatorConstants.emptyMessage}
          selectionMode="single"
          lazy onPage={onPage}
          onSort={onSort}
          sortField={lazyState.sortField}
          onFilter={onFilter}
          value={gridValues}
          onSelectionChange={(e) => handleSelection(e)}
          totalRecords={totalRecords}
          first={lazyState.first}
          sortOrder={lazyState.sortOrder}
        >
          <Column field="trackingID" header="Tracking&nbsp;Id" filter sortable />
          <Column field="mbi" header="Member&nbsp;Name" filter sortable />
          <Column field="firstName" header="First&nbsp;Name" filter sortable />
          <Column field="lastName" header="Last&nbsp;Name" filter sortable />
          <Column field="memberID" header="Member&nbsp;Id" filter sortable hidden />
          <Column field="clientMemberId" header="Client&nbsp;Member" filter sortable />
          <Column field="applicationStatus" header="Trans&nbsp;Status" filter sortable />
          <Column field="contractDescription" header="Contract" filter sortable />
          <Column field="pbpDescription" header="PBP" filter sortable />
          <Column field="memberStatus" header="Member&nbsp;Status" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default EnrollmentSearch;
