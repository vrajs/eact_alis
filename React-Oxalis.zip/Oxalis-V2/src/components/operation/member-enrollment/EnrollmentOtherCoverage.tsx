import FormItem from "../../../controls/FormItem";
import InputText from "../../../controls/InputText";
import CustomForm from "../../../controls/CustomForm";
import { useEffect, useState } from "react";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import InputMask from "../../../controls/InputMask";
import InputNumber from "../../../controls/InputNumber";
import { AccordianProps } from "./EnrollmentMemberInfo";
import { useDispatch } from "react-redux";
import { NextTab } from "../../../Redux/features/enrollmentSlice";
import Button from "../../../controls/Button";
import { CancelNextTab, PreviousTab } from "../../../Redux/features/enrollmentSlice";

const EnrollmentOtherCoverage = ({ form }: AccordianProps) => {
  const [medicaid, setMedicaidList] = useState(null);
  const medicaidList = [
    { key: "Yes", value: "1" },
    { key: "No", value: "2" },
  ];
  const [medicaidLevel, setMedicaidLevel] = useState(null);
  const medicaidLevelList = [
    { key: "QMB", value: "1" },
    { key: "SLMB", value: "2" },
  ];
  const [chronicCondition, setChronicCondition] = useState(null);
  const chronicConditionList = [
    { key: "Diabetes", value: "1" },
    { key: "Lung Disorder", value: "2" },
  ];
  const [selectedlongTerm, setSelectedLongTerm] = useState(null);
  const longTerm = [
    { key: "Yes", value: "1" },
    { key: "No", value: "2" },
  ];
  const [drugCoverage, setDrugCoverage] = useState(null);
  const drugCoverageList = [
    { key: "Yes", value: "1" },
    { key: "No", value: "2" },
  ];
  const dispatch = useDispatch();
  const [hasError, setHasError] = useState<boolean>(true);
  const handlePrevious = async () => {
    dispatch(PreviousTab())
  }
  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])
  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  return (
    <>

      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3 items-center">
        <FormItem name="medicaid" label="Enrolled in State Medicaid">
          <Dropdown
            id="medicaid"
            options={medicaidList}
            value={medicaid}
            optionLabel="key"
            optionValue="value"
            onChange={(event: DropdownChangeEvent) => setMedicaidList(event.value)}
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="medicaidNumber" label="Medicaid Number">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="medicaidLevel" label="Medicaid Level For SNP">
          <Dropdown
            id="medicaidLevel"
            options={medicaidLevelList}
            value={medicaidLevel}
            optionLabel="key"
            optionValue="value"
            onChange={(event: DropdownChangeEvent) => setMedicaidLevel(event.value)}
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="chronicCondition" label="Plan Specific Chronic Condition">
          <Dropdown
            id="chronicCondition"
            options={chronicConditionList}
            value={chronicCondition}
            optionLabel="key"
            optionValue="value"
            onChange={(event: DropdownChangeEvent) => setChronicCondition(event.value)}
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="providerOffice" label="Provider Office Name for Verification ">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>

        <FormItem name="officeAddress" label="Provider Office Address">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="officeCity" label="Provider Office City">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="officeState" label="Provider Office State">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="officeZip" label="Provider Office Zip">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="officeContact" label=" Provider Office Contact Phone ">
          <InputMask mask="(999) 999-9999" placeholder="Enter here" />
        </FormItem>
        <FormItem name="longTerm" label="Long Term Care">
          <Dropdown
            id="longTerm"
            options={longTerm}
            value={selectedlongTerm}
            optionLabel="key"
            optionValue="value"
            onChange={(event: DropdownChangeEvent) => setSelectedLongTerm(event.value)}
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="careName" label="Long Term Care Name">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="careAddress" label="Long Term Care Address">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="carePhone" label="Long Term Care Phone ">
          <InputMask mask="(999) 999-9999" placeholder="Enter here" />
        </FormItem>
        <FormItem name="groupNumber" label="Employer Group Number">
          <InputNumber placeholder="Enter here" />
        </FormItem>
        <FormItem name="groupName" label="Employer Group Name">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="drugCoverage" label="Other Prescription Drug Coverage">
          <Dropdown
            id="drugCoverage"
            options={drugCoverageList}
            value={drugCoverage}
            optionLabel="key"
            optionValue="value"
            onChange={(event: DropdownChangeEvent) => setDrugCoverage(event.value)}
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="otherCoverage" label="Name of Other Coverage">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="idCoverage" label="ID For This Coverage">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="groupCoverage" label="Group Number for this Coverage ">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="secondaryDrug" label="Secondary Drug BIN">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="secondaryDrugPCN" label="Secondary Drug PCN">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
      </div>
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" onClick={handlePrevious} />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentOtherCoverage;
