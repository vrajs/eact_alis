import FormItem from "../../../controls/FormItem";
import CustomForm from "../../../controls/CustomForm";
import { useEffect, useState } from "react";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import Calendar from "../../../controls/Calendar";
import { FormInstance } from "rc-field-form";
import { MemberAndPlanInfoModel } from "../../../model/MemberAndPlanInfoModel";
import { AccordianProps } from "./EnrollmentMemberInfo";
import { useDispatch } from "react-redux";
import { NextTab, PreviousTab } from "../../../Redux/features/enrollmentSlice";
import Button from "../../../controls/Button";

const EnrollmentSales = ({ form }: AccordianProps) => {
  const [enrollmentSource, setEnrollmentSourceList] = useState(null);
  const enrollmentSourceList = [
    { key: "Fax", value: "1" },
    { key: "OEC", value: "2" },
  ];
  const [enrollmentMechanism, setenrollmentMechanism] = useState(null);
  const enrollmentMechanismList = [
    { key: "Electronic", value: "1" },
    { key: "Others", value: "2" },
  ];
  const [salesAgent, setsalesAgent] = useState(null);
  const salesAgentList = [
    { key: "Test 1", value: "1" },
    { key: "Test 2", value: "2" },
  ];
  const dispatch = useDispatch();
  const [hasError, setHasError] = useState<boolean>(true);
  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])
  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  const handlePrevious = async () => {
    dispatch(PreviousTab())
  }
  return (
    <>

      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3 items-center">
        <FormItem name="enrollmentSource" label="Enrollment Source">
          <Dropdown
            id="enrollmentSource"
            options={enrollmentSourceList}
            value={enrollmentSource}
            optionLabel="key"
            optionValue="value"
            onChange={(event: DropdownChangeEvent) => setEnrollmentSourceList(event.value)}
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="enrollmentMechanism" label="Enrollment Mechanism">
          <Dropdown
            id="enrollmentMechanism"
            options={enrollmentMechanismList}
            value={enrollmentMechanism}
            optionLabel="key"
            optionValue="value"
            onChange={(event: DropdownChangeEvent) => setenrollmentMechanism(event.value)}
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="salesAgent" label="Sales Agent">
          <Dropdown
            id="salesAgent"
            options={salesAgentList}
            value={salesAgent}
            optionLabel="key"
            optionValue="value"
            onChange={(event: DropdownChangeEvent) => setsalesAgent(event.value)}
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FormItem name="saleDate" label="Sale Date">
          <Calendar
            placeholder="Enter Date"
            selectionMode="single"
            icon="cl_calendar_today_line"
            iconPos="right"
            dateFormat="mm/dd/yy"
            maxDate={new Date()}
          />
        </FormItem>
      </div>
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" onClick={handlePrevious} />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentSales;
