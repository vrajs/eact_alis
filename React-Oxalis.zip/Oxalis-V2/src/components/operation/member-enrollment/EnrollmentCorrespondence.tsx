import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import Button from "../../../controls/Button";
import { Dropdown, DropdownChangeEvent } from "primereact/dropdown";
import FormItem from "../../../controls/FormItem";
import { useState } from "react";
import CustomForm from "../../../controls/CustomForm";
import Calendar from "../../../controls/Calendar";
import InputTextarea from "../../../controls/InputTextarea";
import { AccordianProps } from "./EnrollmentMemberInfo";

import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { NextTab } from "../../../Redux/features/enrollmentSlice";


const EnrollmentCorrespondence = ({ form }: AccordianProps) => {
  const [isAdding, setIsAdding] = useState(false); // To manage add mode
  const [letterType, setLetterTypeList] = useState(null);

  const letterTypeList = [
    { key: "Enrollment-Request for Information", value: "51" },
    { key: "Disenrollment-Denial Letter", value: "61" },
  ];
  const handleAddClick = () => {
    setIsAdding(true); // Show form
  };
  const dispatch = useDispatch();
  const [hasError, setHasError] = useState<boolean>(true);

  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])

  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  const handleSaveClick = () => {
    setIsAdding(false); // Go back to the table
    // You can also handle saving logic here
  };

  const handleCancelClick = () => {
    setIsAdding(false); // Go back to the table on cancel
  };

  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <Button outlined label="Add" onClick={handleAddClick} />
      </div>
    </div>
  );

  return (
    <>
      {/* Show either the table or the form based on isAdding state */}
      {isAdding ? (
        <>

          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="letterType" label="Letter Type">
              <Dropdown
                id="letterType"
                options={letterTypeList}
                value={letterType}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setLetterTypeList(event.value)}
                showClear
                multiple
                placeholder="Select"
                className="w-full"
              />
            </FormItem>

            <FormItem name="letterGenDate" label="Letter Gen Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="signatureDate" label="Signature Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="receiptDate" label="Receipt Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <div className="col-span-4">
              <FormItem name="comments" label="Comments">
                <InputTextarea rows={3} />
              </FormItem>
            </div>
          </div>
          <div className="flex justify-content-center border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancelClick} />
            <Button label="Save" outlined onClick={handleSaveClick} />
          </div>

        </>
      ) : (
        <DataTable
          paginator
          className="p-datatable-gridlines"
          showGridlines
          header={header1}
          rows={10}
          dataKey="claimId"
          emptyMessage="No records found."
          selectionMode="single"
        >
          <Column field="letterType" header="Letter&nbsp;Type" filter sortable />
          <Column field="letterGenDate" header="Letter&nbsp;Gen&nbsp;Date" filter sortable />
          <Column field="letterMailDate" header="Letter&nbsp;Mail&nbsp;Date" filter sortable />
          <Column field="responseDueDate" header="Response&nbsp;Due&nbsp;Date" filter sortable />
        </DataTable>
      )}
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentCorrespondence;
