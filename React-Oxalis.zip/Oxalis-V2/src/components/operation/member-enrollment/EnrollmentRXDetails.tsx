import FormItem from "../../../controls/FormItem";
import CustomForm from "../../../controls/CustomForm";
import InputText from "../../../controls/InputText";
import { AccordianProps } from "./EnrollmentMemberInfo";
import { useEffect, useState } from "react";
import { useDispatch } from "react-redux";
import { NextTab } from "../../../Redux/features/enrollmentSlice";
import Button from "../../../controls/Button";
const EnrollmentRXDetails = ({ form }: AccordianProps) => {
  const dispatch = useDispatch();
  const [hasError, setHasError] = useState<boolean>(true);

  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])

  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  return (
    <>

      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3 items-center">
        <FormItem name="rxId" label="Primary Rx Id">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="rxGroup" label="Primary Rx Group">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="rxBin" label="Primary Rx BIN">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
        <FormItem name="rxPcn" label="Primary Rx PCN">
          <InputText type="text" placeholder="Enter here" />
        </FormItem>
      </div>
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentRXDetails;
