import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { FileUpload } from "primereact/fileupload";
import { useState } from "react";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import { AccordianProps } from "./EnrollmentMemberInfo";
import { useEffect } from "react";
 import { useDispatch } from "react-redux";
import { NextTab } from "../../../Redux/features/enrollmentSlice";
import Button from "../../../controls/Button";

const EnrollmentAttachmentList  = ({ form }: AccordianProps) => {
  const [attachmentType, setAttachmentType] = useState(null);
  const attachmentTypeList = [
    { key: "Enrollment", value: "1" },
    { key: "Others", value: "2" },
  ];
  const dispatch = useDispatch();
  const [hasError, setHasError] = useState<boolean>(true);

  useEffect(() => {
    if (!hasError) {
      console.log("hasError", hasError)
      dispatch(NextTab())
    }
  }, [hasError])

  const handleSubmit = async () => {
    console.log(form.getFieldsError())
    const formDetails = form.getFieldsError();

    for (let i = 0; i < formDetails.length; i++) {
      if (formDetails[i].errors.length) {
        setHasError(true);
        break;
      } else {
        setHasError(false);
      }
    }

  };
  return (
    <>
      <DataTable
        paginator
        className="p-datatable-gridlines mb-4"
        showGridlines
        rows={10}
        dataKey="claimId"
        emptyMessage="No records found."
        selectionMode="single"
      >
        <Column field="fileName" header="File&nbsp;Name" filter sortable />
        <Column field="attachmentType" header="Attachment&nbsp;Type" filter sortable />
        <Column field="createdBy" header="Created&nbsp;By" filter sortable />
        <Column field="createdDate" header="Created&nbsp;Date" filter sortable />
        <Column field="delete" header="Delete" filter sortable />
      </DataTable>
      <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3 items-end">
        <FormItem name="attachmentType" label="Attachment Type">
          <Dropdown
            id="attachmentType"
            options={attachmentTypeList}
            value={attachmentType}
            optionLabel="key"
            optionValue="value"
            onChange={(event: DropdownChangeEvent) => setAttachmentType(event.value)}
            showClear
            placeholder="Select"
            className="w-full"
          />
        </FormItem>
        <FileUpload mode="basic" name="demo[]" url="/api/upload" accept="image/*" maxFileSize={1000000} />
      </div>
      <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
        <Button label="Previous" text type="button" />
        <Button label="Next" raised type="submit" onClick={handleSubmit} />
      </div>
    </>
  );
};

export default EnrollmentAttachmentList;
