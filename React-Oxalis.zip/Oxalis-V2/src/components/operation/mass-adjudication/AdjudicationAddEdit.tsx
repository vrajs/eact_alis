// import React, { useRef, useState } from "react";
// import { Stepper } from "primereact/stepper";
// import { StepperPanel } from "primereact/stepperpanel";
// import Button from "../../../controls/Button";
// import { useNavigate } from "react-router-dom";
// import FormItem from "../../../controls/FormItem";
// import Dropdown from "../../../controls/Dropdown";
// import { DropdownChangeEvent } from "primereact/dropdown";
// import InputText from "../../../controls/InputText";

// const AdjudicationAddEdit = () => {
//   const navigate = useNavigate();
//   const stepperRef = useRef(null);
//   const handleNavigate = () => {
//     navigate("/claims/mass-adjudication-list");
//   };
//   const [claimStatus, setClaimStatus] = useState(null);
//   const claimStatusList = [{ key: "Load", value: "Load" }];
//   const [formType, setFormType] = useState(null);
//   const formTypeList = [{ key: "HCFA", value: "HCFA" }];
//   const [claimSource, setClaimSource] = useState(null);
//   const claimSourceList = [{ key: "Paper", value: "Paper" }];
//   return (
//     <>
//       <h2 className="pb-4 flex align-center">
//         <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Mass Adjudication
//       </h2>
//       <div className="card custom-stepper">
//         <Stepper ref={stepperRef} orientation="vertical">
//           <StepperPanel header="Criteria">
//             <div className="flex flex-column">
//               <div className="border-2 border-dashed surface-border border-round !grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 p-4">
//                 <FormItem name="claimStatus" label="Claim Status">
//                   <Dropdown
//                     id="claimStatus"
//                     options={claimStatusList}
//                     value={claimStatus}
//                     optionLabel="key"
//                     optionValue="value"
//                     onChange={(event: DropdownChangeEvent) => setClaimStatus(event.value)}
//                     showClear
//                     placeholder="Select"
//                     className="w-full"
//                   />
//                 </FormItem>
//                 <FormItem name="formType" label="Form Type">
//                   <Dropdown
//                     id="formType"
//                     options={formTypeList}
//                     value={formType}
//                     optionLabel="key"
//                     optionValue="value"
//                     onChange={(event: DropdownChangeEvent) => setFormType(event.value)}
//                     showClear
//                     placeholder="Select"
//                     className="w-full"
//                   />
//                 </FormItem>
//                 <FormItem name="claimSource" label="Claim Source">
//                   <Dropdown
//                     id="claimSource"
//                     options={claimSourceList}
//                     value={claimSource}
//                     optionLabel="key"
//                     optionValue="value"
//                     onChange={(event: DropdownChangeEvent) => setClaimSource(event.value)}
//                     showClear
//                     placeholder="Select"
//                     className="w-full"
//                   />
//                 </FormItem>
//               </div>
//             </div>
//             <div className="flex py-4">
//               <Button label="Next" icon="cl_arrow_right text-2xl" iconPos="right" onClick={() => stepperRef.current.nextCallback()} />
//             </div>
//           </StepperPanel>
//           <StepperPanel header="Schedule">
//             <div className="flex flex-column ">
//               <div className="border-2 border-dashed surface-border border-round !grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 p-4">
//                 <FormItem name="jobName" label="Job Name">
//                   <InputText type="text" placeholder="Enter here" />
//                 </FormItem>
//               </div>
//             </div>
//             <div className="flex py-4 gap-2">
//               <Button label="Back" severity="secondary" icon="cl_arrow_left text-2xl" onClick={() => stepperRef.current.prevCallback()} />
//               <Button label="Submit" icon="cl_save text-2xl" iconPos="right" onClick={() => stepperRef.current.nextCallback()} />
//             </div>
//           </StepperPanel>
//         </Stepper>
//       </div>
//     </>
//   );
// };
// export default AdjudicationAddEdit;
