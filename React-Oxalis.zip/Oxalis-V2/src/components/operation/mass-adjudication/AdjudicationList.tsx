import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import Button from "../../../controls/Button";
import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

const AdjudicationList = () => {
  const navigate = useNavigate();
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [customers1, setCustomers1] = useState<any>([]);
  const [loading, setLoading] = useState(true);
  const handleView = () => {
    navigate("/claims/mass-adjudication-view");
  };
  const handleAdd = () => {
    navigate("/claims/mass-adjudication-add-edit");
  };
  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <Button outlined label="Add" onClick={handleAdd} />
        {selectedCustomer && <Button outlined label="Edit" />}
      </div>
    </div>
  );
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        setLoading(true);
        const customerData = [{ rank: "84", athlete: "Abel Brun", speed: "5.1" }];
        setCustomers1(customerData);
      } catch (error) {
        console.error("Error fetching customers:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCustomers();
  }, []);
  return (
    <>
      <h2 className="pb-4">Mass Adjudication</h2>
      <DataTable
        paginator
        value={customers1}
        className="p-datatable-gridlines"
        showGridlines
        rows={10}
        dataKey="ID"
        header={header1}
        loading={loading}
        responsiveLayout="scroll"
        emptyMessage="No records found."
        selectionMode="single" // Single row selection
        selection={selectedCustomer}
        onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
      >
        <Column
          field="rank"
          header="Rank"
          filter
          sortable
          body={(rowData) => (
            <a onClick={handleView} className="underline">
              {rowData.rank}
            </a>
          )}
        />
        <Column field="athlete" header="Athlete" filter sortable />
        <Column field="speed" header="Speed" filter sortable />
      </DataTable>
    </>
  );
};

export default AdjudicationList;
