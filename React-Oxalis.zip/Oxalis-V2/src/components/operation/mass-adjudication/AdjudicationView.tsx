import { useNavigate } from "react-router-dom";
import ViewForm from "../../../controls/ViewForm";

const AdjudicationView = () => {
  const navigate = useNavigate();
  const data = [
    { label: "Claim Status", value: "Load" },
    { label: "Form Type", value: "HCFA" },
    { label: "Claim Source", value: "Paper" },
    { label: "Claim Number(s)", value: "12345" },
    { label: "DOS From", value: "12-12-2013" },
    { label: "DOS To", value: "12-12-2014" },
    { label: "Recd Date Form", value: "12-12-2013" },
    { label: "Recd Date To", value: "12-12-2013" },
    { label: "Include Overrides", value: "N/A" },
  ];
  const memberdata = [
    { label: "Member ID", value: "04" },
    { label: "Provider ID", value: "03" },
    { label: "Providere Status", value: "PAR" },
    { label: "Payee City", value: "Sanford" },
    { label: "Network", value: "N/A" },
  ];
  const recurringdata = [
    { label: "Run Now", value: "No" },
    { label: "Recurring", value: "Yes" },
    { label: "Recurring Job Name", value: "Testing" },
    { label: "Recurring Time", value: "11:00 AM" },
    { label: "Recurring Frequency", value: "WeekDay" },
    { label: "Recurring Day", value: "Thursday" },
  ];
  const organizationdata = [
    { label: "Company", value: "Amegigroup" },
    { label: "Sub Company", value: "Amegigroup" },
    { label: "LOB", value: "Amerivantage Dual" },
  ];
  const contractdata = [
    { label: "Benefit Plan", value: "FIDA" },
    { label: "Contract", value: "General Therapy" },
    { label: "Fee Schedule", value: "Caid DME 100%" },
    { label: "Code", value: "5165251" },
    { label: "Edit Code", value: "656" },
  ];
  const handleNavigate = () => {
    navigate("/claims/mass-adjudication-list");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Mass Adjudication Information
      </h2>
      <ViewForm header="Claim Information" data={data} />
      <ViewForm header="Member & Provider Information" data={memberdata} />
      <ViewForm header="Recurring Information" data={recurringdata} />
      <ViewForm header="Organization Information" data={organizationdata} />
      <ViewForm header="Benefit & Contract Information" data={contractdata} />
    </>
  );
};

export default AdjudicationView;
