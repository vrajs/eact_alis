import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useEffect, useRef, useState } from "react";
import Button from "../../../controls/Button";
import Dropdown from "../../../controls/Dropdown";
import InputText from "../../../controls/InputText";
import InputNumber from "../../../controls/InputNumber";
import { useNavigate } from "react-router-dom";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import { LazyTableState } from "../../../model/LazyTableState";
import { FormInstance, useForm } from "rc-field-form";
import { GridModel } from "../../../model/GridModel";
import { ProviderViewModel } from "../../../model/ProviderViewModel";
import SpecialtyService from "../../../services/SpecialtyService";
import { ProviderDataModel } from "../../../model/ProviderDataModel";
import { ProviderService } from "../../../services/ProviderService";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import { CodeType, CommonCodeFetchingType } from "../../../data/constants/AppEnum";
import { KeyValueModel } from "../../../model/KeyValueModel";
import FormItem from "../../../controls/FormItem";
import CustomForm from "../../../controls/CustomForm";
import { REGEX_CONSTANTS } from "../../../data/constants/RegexConstants";
import * as XLSX from "xlsx";
import { ProviderExportModel } from "../../../model/ProviderExportModel";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { ClearKey } from "../../../Redux/features/keyboardShortcutSlice";
import { Tooltip } from 'primereact/tooltip';
import { useToaster } from "../../../layout/context/toastContext";
import useErrorHandler from "../../../hooks/useErrorHandler";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";

const ProviderSearch = () => {
  const navigate = useNavigate();
  const { getSpecialtyKeyValues, getLanguageKeyValues } = SpecialtyService();
  const groupTypes = useCommonCodeSubCategory(CodeType.ProviderType, CommonCodeFetchingType.Default);
  const [languageList, setLanguageList] = useState([]);
  const [specialtyList, setSpecialityList] = useState<KeyValueModel[]>([]);
  const [gridValues, setGridValues] = useState([]);
  const [form] = useForm();
  const { getProviderGrid, exportProvider, deleteProvider } = ProviderService();
  const [totalRecords, setTotalRecords] = useState(0);
  const [selectedProvider, setSelectedProvider] = useState<ProviderViewModel | null>();
  const ref = useRef<Panel>(null);
  const dispatch = useDispatch();
  const { isEdit, isAdd, isExport, isSearch, isDelete } = useSelector((state: RootState) => state.keyboardShortCut);
  const { showToast } = useToaster();
  const [showConfirm, setShowConfirm] = useState<boolean>(false);

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState]);

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedProvider) {
      try {
        const deleteResponse = await deleteProvider(selectedProvider.providerID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "Provider deleted successfully" });
          form.resetFields();
          loadLazyData();
          setSelectedProvider(null);
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setSelectedProvider(null);
  }

  const handleDelete = () => {
    if (selectedProvider) {
      setShowConfirm(true);
    }
  }

  useEffect(() => {
    const specialty = getSpecialtyKeyValues();
    const language = getLanguageKeyValues();
    Promise.all([specialty, language]).then((result) => {
      const specialtyResponse = result[0];
      const languageResponse = result[1];
      setSpecialityList(specialtyResponse);
      setLanguageList(languageResponse);
    })

    return () => {
      dispatch(ClearKey());
    }
  }, [])

  const loadLazyData = async () => {
    ref.current.collapse(undefined)
    const searchForm = form.getFieldsValue(true);
    const query = useQueryBuilder(lazyState);
    // setLoading(true);
    const groupGridData: GridModel<ProviderDataModel> = await getProviderGrid(searchForm, query);
    if (groupGridData) {
      setGridValues(groupGridData.data);
      setTotalRecords(groupGridData.totalCount);
      // setLoading(false);
    }
  };

  const handleCancel = () => {
    ref.current.collapse(undefined);
    form.resetFields();
    loadLazyData();
    setSelectedProvider(null);
  }

  const handleFormError = () => {
    console.log(form.getFieldsError());
  }

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedProvider(e.value)
    } else {
      setSelectedProvider(null);
    }
  }

  const handleNavigate = () => {
    navigate("/provider/provider-add-edit");
  };

  const handleView = () => {
    navigate("/provider/provider-view");
  };

  const handleEdit = () => {
    const providerid: number = selectedProvider.providerID;
    navigate(`/provider/provider-add-edit/${providerid}`);
  }

  const handleExport = async () => {
    const providerData: ProviderExportModel[] = await exportProvider();
    console.log(providerData);
    const providers = providerData.map((provider) => {
      const { providerID: ID, providerCode: Code, lastName, firstName, npi: NPI, middleName, fullName, primaryEmail, secondaryEmail, phone: Phone, fax: Fax, providerType } = provider;
      return { ID, Code, 'Provider Type': providerType, 'Last Name': lastName, 'First Name': firstName, 'Middle Name': middleName, 'Full Name': fullName, NPI, 'Primary Email': primaryEmail, Phone, Fax }
    })
    const ws = XLSX.utils.json_to_sheet(providers);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Provider List");
    XLSX.writeFile(wb, "Provider.xlsx");
    showToast({ severity: 'success', summary: 'Success', detail: "File downloaded successfully" });
  }

  useEffect(() => {
    if (isSearch) {
      ref.current.expand(undefined);
    }
    dispatch(ClearKey());
  }, [isSearch])

  useEffect(() => {
    if (isDelete) {
      handleDelete();
    }
    dispatch(ClearKey());
  }, [isDelete])

  useEffect(() => {
    if (isExport) {
      handleExport();
    }
    dispatch(ClearKey());
  }, [isExport])

  useEffect(() => {
    if (isEdit && selectedProvider) {
      handleEdit();
    }
    dispatch(ClearKey());
  }, [isEdit])

  useEffect(() => {
    if (isAdd) {
      handleNavigate();
    }
    dispatch(ClearKey());
  }, [isAdd])

  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Advance Search</div>
        <div className="flex align-items-center gap-2">
          {/* <Dropdown optionLabel="name" placeholder="Saved Search (0)" filter className="w-full" /> */}
          <Button outlined label="Add" onClick={handleNavigate} tooltip="Alt + A" />
          {selectedProvider && <Button outlined label="Edit" onClick={handleEdit} tooltip="Alt + E" />}
          {selectedProvider && <Button outlined label="Delete" onClick={handleDelete} tooltip="Alt + D"/>}
          <Button label="Export" outlined onClick={handleExport} tooltip="Alt + X" />
          {options.togglerElement}
        </div>
      </div>
    );
  };

  return (
    <>
      <h2 className="pb-4">Provider Configuration</h2>
      <Panel headerTemplate={headerTemplate} ref={ref} toggleable className="m-0 search-panel" collapsed>
        <CustomForm form={form} onFinish={loadLazyData} onFinishFailed={handleFormError}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <div>
              <FormItem name="providerTypeIDs" label="Provider Type">
                <Dropdown
                  id="dropdown"
                  options={groupTypes}
                  optionLabel="value"
                  optionValue="key"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
            </div>
            <div>
              <FormItem name="providerCode" label="Provider Code">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
            </div>
            <div>
              <FormItem name="fullName" label="Provider Name">
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
            </div>
            <div>
              <FormItem name="npi" label="NPI" rules={[

                { pattern: REGEX_CONSTANTS.NPI_VALIDATOR, message: "NPI is invalid" },
              ]}>
                <InputNumber placeholder="Enter here" useGrouping={false} />
              </FormItem>
            </div>
            <div>
              <FormItem name="tin" label="TIN">
                <InputNumber placeholder="Enter here" useGrouping={false} />
              </FormItem>
            </div>
            <div>
              <FormItem name="languageIDs" label="Language">
                <Dropdown
                  id="Language"
                  multiple
                  showHeader
                  options={languageList}
                  optionLabel="value"
                  optionValue="key"
                  placeholder="Select Language"
                  filter
                  className="w-full"
                />
              </FormItem>
            </div>
            <div>
              <FormItem name="specialtyIDs" label="Specialty">
                <Dropdown
                  id="Specialty"
                  multiple
                  showHeader
                  options={specialtyList}
                  optionLabel="value"
                  optionValue="key"
                  placeholder="Select Specialty"
                  filter
                  className="w-full"
                />
              </FormItem>
            </div>
          </div>

          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="clear" text type="button" onClick={handleCancel} />
            <Button label="Apply" outlined type="submit" />
            {/* <Button label="Apply & Save" raised /> */}
          </div>
        </CustomForm>
      </Panel>
      <div className="pb-4">
        <DataTable
          paginator
          rowsPerPageOptions={paginatorConstants.pageOptions}
          className="p-datatable-gridlines"
          showGridlines
          rows={lazyState.rows}
          tableStyle={{ minWidth: '50rem' }}
          paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
          currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
          dataKey="providerID"
          emptyMessage={paginatorConstants.emptyMessage}
          selectionMode="single"
          lazy onPage={onPage}
          onSort={onSort}
          sortField={lazyState.sortField}
          onFilter={onFilter}
          value={gridValues}
          onSelectionChange={(e) => handleSelection(e)}
          totalRecords={totalRecords}
          first={lazyState.first}
          sortOrder={lazyState.sortOrder}
        >
          <Column
            field="providerCode"
            header="Provider&nbsp;Code"
            sortable
            body={(rowData) => (
              <a onClick={handleView} className="underline">
                {rowData.providerCode}
              </a>
            )}
          />
          <Column field="fullName" header="Display name" sortable />
          <Column field="phone" header="Phone" sortable />
          <Column field="fax" header="Fax" sortable />
          <Column field="ssn" header="SSN" sortable />
          <Column field="primaryEmail" header="Email" sortable />
          <Column field="npi" header="NPI" sortable />
          <Column field="tin" header="TIN" sortable />
        </DataTable>
      </div>

      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </>
  );
};

export default ProviderSearch;
