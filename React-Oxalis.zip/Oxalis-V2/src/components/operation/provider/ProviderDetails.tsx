import { TabMenu } from "primereact/tabmenu";
import { useState } from "react";
import { Panel } from "primereact/panel";

// Import tab components
import Alert from "../tabcomponents/Alert";
import AuditHistory from "../tabcomponents/AuditHistory";
import Contracts from "../tabcomponents/Contracts";
import EligibiltyHistory from "../tabcomponents/EligibiltyHistory";
import Notes from "../tabcomponents/Notes";
import Reference from "../tabcomponents/Reference";
import Specialty from "../tabcomponents/Speciality";
import Location from "../tabcomponents/Location";
import Credentialing from "../tabcomponents/Credentialing";
import { TabView, TabPanel } from "primereact/tabview";

const ProviderDetails = () => {
  const items = [
    { label: "Contracts", component: <Contracts /> },
    // { label: "Status", component: <Status /> },
    { label: "Speciality", component: <Specialty /> },
    { label: "Locations", component: <Location /> },
    { label: "Alert", component: <Alert /> },
    { label: "Notes", component: <Notes /> },
    { label: "Reference", component: <Reference /> },
    { label: "Eligibility History", component: <EligibiltyHistory /> },
    { label: "Audit History", component: <AuditHistory /> },
    // { label: "Provider Location", component: <ProviderLocation isProviderAddEdit={true} /> },
    // { label: "Provider Contract", component: <ProviderContract isProviderAddEdit={true} /> },
    { label: "Credentialing", component: <Credentialing /> },
  ];

  const [activeIndex, setActiveIndex] = useState(0);

  const handleTabChange = (e) => {
    setActiveIndex(e.index);
  };

  return (
    <div className="pb-4">
      <Panel header="Provider Details" toggleable className="custom-tab-menu">
        <TabView scrollable activeIndex={activeIndex} onTabChange={handleTabChange}>
          {items.map((item, index) => (
            <TabPanel key={index} header={item.label}>
              {item.component}
            </TabPanel>
          ))}
        </TabView>
      </Panel>
    </div>
  );
};

export default ProviderDetails;
