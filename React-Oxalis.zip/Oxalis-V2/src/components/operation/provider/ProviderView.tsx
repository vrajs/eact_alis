import ProviderDetails from "./ProviderDetails";
import { useNavigate } from "react-router-dom";
import ViewForm from "../../../controls/ViewForm";

const ProviderView = () => {
  const navigate = useNavigate();
  const data = [
    { label: "NPI", value: "3394349384" },
    { label: "SSN", value: "N/A" },
    { label: "Is Person", value: "No" },
    { label: "Is PCP", value: "No" },
    { label: "Is Provider Watch", value: "No" },
    { label: "Primary Email", value: "N/A" },
    { label: "Secondary Email", value: "N/A" },
    { label: "Phone", value: "N/A" },
    { label: "FAX", value: "N/A" },
    { label: "DOB", value: "N/A" },
    { label: "Gender", value: "Female" },
    { label: "Race", value: "N/A" },
    { label: "Ethnicity", value: "N/A" },
    { label: "Language", value: "N/A" },
    { label: "MAX Member Count", value: "N/A" },
    { label: "Effective Date", value: "N/A" },
    { label: "Term Date", value: "Till Continue" },
  ];
  const handleNavigate = () => {
    navigate("/group");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Provider Information
      </h2>
      <ViewForm header="PPR000304 - Kesaven - Provider" data={data} />
      <ProviderDetails />
    </>
  );
};

export default ProviderView;
