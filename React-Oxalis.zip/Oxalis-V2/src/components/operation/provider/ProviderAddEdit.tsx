import { InputSwitch } from "primereact/inputswitch";
import { Panel } from "primereact/panel";
import { useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import Dropdown from "../../../controls/Dropdown";
import InputNumber from "../../../controls/InputNumber";
import InputMask from "../../../controls/InputMask";
import Calendar from "../../../controls/Calendar";
import Button from "../../../controls/Button";
import { useNavigate, useParams } from "react-router-dom";
import ProviderDetails from "./ProviderDetails";
import { useForm } from "rc-field-form";
import { CodeType, CommonCodeFetchingType, RecordStatus } from "../../../data/constants/AppEnum";
import FormItem from "../../../controls/FormItem";
import { ProviderService } from "../../../services/ProviderService";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import CustomForm from "../../../controls/CustomForm";
import { NPPESSearchModel, ProviderViewModel } from "../../../model/ProviderViewModel";
import { REGEX_CONSTANTS } from "../../../data/constants/RegexConstants";
import { useDispatch, useSelector } from "react-redux";
import { AddProviderData, AddProviderId, ProviderUpdated } from "../../../Redux/features/providerSlice";
import { ProviderModel } from "../../../model/ProviderModel";
import EligibilityDetails from "../tabcomponents/EligibilityDetails";
import { ProviderEligibilityModel } from "../../../model/ProviderEligibilityModel";
import { RootState } from "../../../Redux/app/store";
import ProviderEligibilityService from "../../../services/ProviderEligibilityService";
import moment from "moment";
import CommonCodeService from "../../../services/CommonCodeService";
import { KeyValueModel } from "../../../model/KeyValueModel";
import FormListItem from "../../../controls/FormListItem";
import { useToaster } from "../../../layout/context/toastContext";
import { CommonCodeModel } from "../../../model/CommonCodeModel";
import { ClearKey } from "../../../Redux/features/keyboardShortcutSlice";
import { DropdownChangeEvent } from "primereact/dropdown";
import useErrorHandler from "../../../hooks/useErrorHandler";

const ProviderAddEdit = () => {
  const navigate = useNavigate();

  const [providerData, setProviderData] = useState<ProviderViewModel>();
  const data = [
    { label: "Created by", value: providerData?.createdBy, name: "createdBy" },
    { label: "Created On", value: moment(providerData?.createdDate).format("MM/DD/YYYY"), name: "createdDate" },
    { label: "Last Modified By", value: providerData?.updatedBy ?? "N/A", name: "updatedBy" },
    { label: "Last Modified On", value: providerData?.updatedDate ? moment(providerData.updatedDate).format("MM/DD/YYYY") : "N/A", name: "updatedDate" },
  ];
  const [providerId, setProviderId] = useState<number>(0);
  const [eligibilityDetails, setEligibilityDetails] = useState<ProviderEligibilityModel[]>([]);
  const { providerEligibility } = useSelector((state: RootState) => state.provider);
  const { getEligibilityByProviderId } = ProviderEligibilityService();
  const [checked, setPortalAccess] = useState(false);
  const [person, setPerson] = useState(false);
  const [pcp, setPcp] = useState(false);
  const [providerWatch, setProviderWatch] = useState(false);
  const [medicaid, setMedicaid] = useState(false);
  const [memberCount, setMemberCount] = useState<number>(0);
  const { showToast } = useToaster();
  const eligibilityInitValue = {
    providerEligibilityID: 0,
    providerID: providerId,
    effectiveDate: null,
    termDate: null,
    providerEligibilityCode: ""
  }

  const dispatch = useDispatch();
  const handleNavigate = () => {
    navigate("/provider");
  };
  const [groupIds, setgroupIds] = useState(null);
  const [form] = useForm<ProviderViewModel>();
  const [npiSearchForm] = useForm<NPPESSearchModel>();
  const { providerEditId } = useParams();
  const { createProvider, getGroupIdList, updateProvider, providerView, checkNPI, dataFromNPPES, getCommonCodeByCodeTypeIdAll, getMemberCount } = ProviderService();
  const { getByCodeTypeId } = CommonCodeService();
  const providerTypes = useCommonCodeSubCategory(CodeType.ProviderType);
  const prefixList = [
    { key: 'Mr', value: 'Mr' },
    { key: 'Mrs', value: 'Mrs' },
    { key: 'Miss', value: 'Miss' }
  ];
  const genderList = [
    { key: 'Both', value: 'B' },
    { key: 'Male', value: 'M' },
    { key: 'Female', value: 'F' },
    { key: 'UnKnown', value: 'U' }
  ];

  const suffixList = useCommonCodeSubCategory(CodeType.Suffix, CommonCodeFetchingType.ByCode);
  const titleList = useCommonCodeSubCategory(CodeType.Title, CommonCodeFetchingType.ByCode);
  const raceList = useCommonCodeSubCategory(CodeType.Race);
  const ethinicityList = useCommonCodeSubCategory(CodeType.Ethnicity);

  const [languageOptions, setLanguageOptions] = useState<KeyValueModel[]>([]);
  const { isSave, isAdd } = useSelector((state: RootState) => state.keyboardShortCut);
  const [isUpdate, setIsUpdate] = useState<boolean>(false);

  const defaultValues = {
    ssn: "", race: "", gender: "", lastName: "", ethnicity: "",
    middleName: "", firstName: "", prefix: "", phone: "", fax: "", secondaryEmail: "", primaryEmail: ""
  }

  const emailValidator = async (rule, value) => {
    if (!value) {
      return Promise.resolve(null);
    }
    const isValid: boolean = REGEX_CONSTANTS.EMAIL.test(value);
    if (!isValid) {
      return Promise.reject("Email is invalid");
    }
    return Promise.resolve(null);
  }

  const [isSubmitting, setIsSubmitting] = useState(false);

  const credentialData = [
    { value: 'Active', key: 51401 },
    { value: 'Pending', key: 51402 }
  ];

  const providerNameValidator = async (rule, value, callback) => {
    if (!REGEX_CONSTANTS.PROVIDER_NAME.test(value)) {
      return Promise.reject("Provider Name is invalid");
    }

    return Promise.resolve(null);
  }

  const providerLengthValidator = (rule, value, callback) => {
    if (value?.length > 160) {
      // return Promise.reject("")
      return Promise.reject("Maximum 160 characters allowed");
    }
    return Promise.resolve(null);
  }

  useEffect(() => {
    if (isSave) {
      handleSave();
      dispatch(ClearKey());
    }
  }, [isSave])

  useEffect(() => {
    dispatch(ClearKey());
  }, [isAdd])

  useEffect(() => {
    const fetchGroupIdList = async () => {
      const data = await getGroupIdList();
      if (data) {
        setgroupIds(data); // Store the key-value pair result in state
      }
    };
    fetchGroupIdList();
    if (Number(providerEditId) > 0) {
      setProviderId(Number(providerEditId));
      const getByProviderID = providerView(Number(providerEditId));
      const getGroupEligibility = getEligibilityByProviderId(Number(providerEditId));
      const membersAssigned = getMemberCount(Number(providerEditId))

      form.setFieldValue("providerEligibility", [{ ...eligibilityInitValue }])

      Promise.all([getByProviderID, getGroupEligibility, getByCodeTypeId, membersAssigned]).then(result => {
        const groupData: ProviderViewModel = result[0];
        setPcp(groupData.isPCP)
        setProviderWatch(groupData.isProviderWatch)
        setMedicaid(groupData.isAcceptsMedicaid)
        const eligibilities: ProviderEligibilityModel[] = result[1].map(eligibility => {
          return { ...eligibility, effectiveDate: new Date(eligibility.effectiveDate), termDate: eligibility.termDate ? new Date(eligibility.termDate) : null }
        })
        setMemberCount(result[3]);
        eligibilities.length > 0 ? groupData.providerEligibility = [...eligibilities] : groupData.providerEligibility = [{ ...eligibilityInitValue }]

        setEligibilityDetails(eligibilities);
        if (groupData) {
          setProviderData(groupData);
        }
        const { isPerson, isProviderAccess } = groupData;
        setPerson(isPerson);
        setPortalAccess(isProviderAccess);
        const { providerLanguage: selectedLanguage, ethnicity: ethinicityID } = groupData;
        const providerLanguage = selectedLanguage.map((language) => language.languageID);
        const dob = groupData.dob ? moment(groupData.dob).toDate() : null;
        form.setFieldsValue({ ...groupData, languageIds: [...providerLanguage], dob, ethnicity: ethinicityID ? Number(ethinicityID) : null });
        dispatch(AddProviderData(groupData))
      })
      dispatch(AddProviderId(providerEditId))
    } else {
      if (providerId == 0) {
        form.setFieldValue("providerEligibility", [{ ...eligibilityInitValue }])
      }
    }
  }, [providerEditId, isUpdate]);

  useEffect(() => {
    const fetchLanguages = async () => {
      const languages = await getCommonCodeByCodeTypeIdAll(CodeType.Language);
      setLanguageOptions(languages);
    };

    fetchLanguages();
  }, []);


  const handleCancel = () => {
    navigate("/provider");
    form.resetFields();
  }


  const handleNPICheck = async (rule, value) => {
    const errorMessage = form.getFieldError("npi");
    if (!REGEX_CONSTANTS.NPI_VALIDATOR.test(value)) {
      return Promise.reject("NPI is invalid")
    }
    if (!value || errorMessage.length > 0) {
      return Promise.resolve();
    }
    const npiValidation: boolean = await checkNPI(value, Number(providerEditId) ?? 0);
    if (npiValidation) {
      return Promise.reject("NPI already exists");
    } else {
      return Promise.resolve();
    }
  }

  const getDataFromNPPES = async () => {
    const npi = npiSearchForm.getFieldValue('npiSearch');

    const errorMessage = npiSearchForm.getFieldError("npiSearch");
    if (!REGEX_CONSTANTS.NPI_VALIDATOR.test(npi)) {
      return Promise.reject("NPI is invalid")
    }
    if (!npi || errorMessage.length > 0) {
      return Promise.resolve();
    }

    if (npi && npi.toString().length === 10 && !isNaN(npi)) {
      const res: ProviderModel = await dataFromNPPES(npi)
      if (!res.npi) {
        return showToast({ severity: 'error', summary: 'Error', detail: "No data found from NPPES NPI Registry." });
      }
      res.fullName = (res.firstName ?? "") + " " + (res.middleName ?? "") + " " + (res.lastName ?? "");
      console.log("res", res)
      const formValue: ProviderViewModel = {
        ...res,
        dob: res.dob ? moment(res.dob).toDate() : null,
        suffix: res.suffix ? res.suffix : null,
        title: res.title ? res.title : null,
        providerID: 0,
        providerTypeID: null,
        tin: res.tin ? res.tin : null,
        credentialStatusID: res.credentialStatusID ? res.credentialStatusID : null,
        isPCP: false,
        providerEligibilityID: 0,
        termReasonId: 0,
        providerEligibility: [{ ...eligibilityInitValue }]
      };
      form.setFieldsValue({ ...formValue });
      console.log("formValue formValue formValue", formValue)
      if (res.lastName) {
        setPerson(false)
      } else {
        setPerson(true);
      }
    }
  };

  const handleSave = async () => {
    if (isSubmitting) return;
    setIsSubmitting(true);
    try {
      const formValues = form.getFieldsValue(true);
      console.log("formValues ", formValues);
      const suffix = form.getFieldValue("suffix");
      const mergedValues = Object.keys(defaultValues).reduce((acc, key) => {
        acc[key] = formValues[key] ?? defaultValues[key];
        return acc;
      }, { ...formValues });
      const dob = formValues?.dob ? moment(formValues?.dob).format("YYYY-MM-DD") : null;

      const selectedLanguage = form.getFieldValue("languageIds");

      const providerValues: ProviderViewModel = {
        ...mergedValues,
        isGroup: false,
        recordStatus: RecordStatus.Active,
        recordStatusChangeComment: RecordStatus[RecordStatus.Active],
        isPerson: person,
        isPCP: pcp,
        isAcceptsMedicaid: medicaid,
        dob,
        suffix: suffix ? suffix : "",
        isProviderWatch: providerWatch,
        providerLanguage: selectedLanguage ? selectedLanguage?.map((languageID) => {
          return { languageID, providerID: providerId, language: languageOptions.find(a => a.value === languageID).key, createdBy: "", recordStatus: RecordStatus.Active, recordStatusChangeComment: "" }
        }) : []
      };

      providerValues.providerEligibility = providerValues.providerEligibility?.map(a => {
        return { effectiveDate: moment(a.effectiveDate).format("YYYY-MM-DD"), termDate: a.termDate ? moment(a.termDate).format("YYYY-MM-DD") : null, providerEligibilityCode: providerEligibility.providerEligibilityCode, providerID: providerId, providerEligibilityID: a.providerEligibilityID };
      })
      const response = Number(providerEditId) > 0 ? await updateProvider(providerValues) : await createProvider(providerValues);
      if (response) {
        if (!providerEditId) {
          dispatch(ProviderUpdated());
          navigate("/provider");
        } else {
          setIsUpdate((prevState) => !prevState);
        }
        showToast({ severity: 'success', summary: 'Success', detail: "Provider data saved successfully" });
        // setIsUpdate(false);
      }
    } catch (error) {
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    } finally {
      setIsSubmitting(false); // Enable the button again
    }
  };

  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="flex align-items-center gap-2">
          <span className="font-bold">Provider Information {providerId > 0 && <label> - [ Total Members assigned: {memberCount} ]</label>}</span>
        </div>
        <div className="flex align-items-center gap-2">
          <label htmlFor="input-switch">Portal Access</label>
          <InputSwitch id="input-switch" checked={checked} onChange={(e) => setPortalAccess(e.value)} />
          <label htmlFor="Person">Person</label>
          <InputSwitch id="Person" checked={person} onChange={(e) => setPerson(e.value)} />
          {options.togglerElement}
        </div>
      </div>
    );
  };

  const initialValues = {
    ssn: "",
  }
  const prefixValidationRules = person ? [{ required: true, message: "Prefix is required" }] : [];
  const firstNameValidationRules = person ? [{ required: true, message: "First Name is required" }] : [];
  const lastNameValidationRules = person ? [{ required: true, message: "Last Name is required" }] : [];

  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Provider Configuration
      </h2>
      {providerEditId && providerData && <div className="card p-4 !mb-4">
        <div className="!grid xl:grid-cols-5 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 !gap-6">
          {data.map((item, index) => (
            <div key={index}>
              <div className="flex flex-nowrap justify-content-between align-items-center border-1 surface-border border-round p-3 cursor-pointer">
                <div className="flex align-items-center">
                  {/* <div className="relative md:mr-3">
                    <i className="cl_dot_big text-xxl"></i>
                  </div> */}
                  <div className="flex-col">
                    <div className="block text-600 text-overflow-ellipsis overflow-hidden white-space-nowrap text-sm">{item.label}</div>
                    <div className="text-900 font-semibold block">{item.value}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>}
      <Panel header="Provider Information" toggleable className="mb-4" headerTemplate={headerTemplate}>
        <CustomForm form={npiSearchForm} onFinish={getDataFromNPPES}>
          <div className="pb-4">
            <h5 className="border-bottom-1 pb-3 mb-3">Find Data From NPPES NPI Registry</h5>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 custom-group-search">
              <FormItem name="npiSearch" label="Search NPI" rules={[{ pattern: REGEX_CONSTANTS.NPI_VALIDATOR, message: "NPI is invalid" }]}>
                <InputNumber placeholder="Enter here" useGrouping={false} disabled={providerId > 0 ? true : false} onKeyDown={(e) => {
                  if (e.key === '-') {
                    e.preventDefault();
                  }
                }} />
              </FormItem>
              <Button icon="cl_search" className="mt-[27px] h-[39px]" outlined disabled={providerId > 0 ? true : false} />
            </div>
          </div>
        </CustomForm>
        <CustomForm form={form} onFinish={handleSave} initialValues={initialValues}>
          <div className="pb-4">
            <h5 className="border-bottom-1 pb-3 mb-3">Primary Details</h5>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">
              <div>
                <FormItem
                  name="groupId"
                  label="Group ID"
                >
                  <Dropdown
                    id="group"
                    options={groupIds}
                    optionLabel="value"
                    optionValue="key"
                    showClear
                    placeholder="Select"
                    className="w-full"
                  />
                </FormItem>

              </div>

              <div>
                <FormItem
                  name="providerTypeID"
                  label="Provider Type"
                  rules={[
                    { required: true }
                  ]}
                >
                  <Dropdown
                    id="providertypeID"
                    options={providerTypes}
                    optionLabel="value"
                    optionValue="key"
                    showClear
                    onChange={(event: DropdownChangeEvent) => form.setFieldValue("providerTypeID", event.value)}
                    placeholder="Select"
                    className="w-full"
                    disabled={providerEditId ? true : false}
                  />
                </FormItem>
              </div>
              <div>
                <FormItem
                  name="providerCode"
                  label="Provider Code (Auto Generate)"
                >
                  <InputText type="text" disabled />
                </FormItem>
              </div>
              <div>
                <FormListItem
                  name="npi"
                  label="NPI" rules={[
                    { required: true, message: "NPI is required" },
                    { pattern: REGEX_CONSTANTS.NPI_VALIDATOR, message: "NPI must be exactly 10 digits" },
                    { validator: handleNPICheck, message: "NPI already exists" }
                  ]}
                >
                  {/* <InputNumber placeholder="Enter here" useGrouping={false} /> */}
                  <InputNumber id="NPI" placeholder="Enter here" useGrouping={false} onKeyDown={(e) => {
                    if (e.key === '-') {
                      e.preventDefault();
                    }
                  }} />
                </FormListItem>
              </div>
              <div>
                <FormItem
                  name="tin"
                  label="TIN"
                  rules={[
                    { required: true, message: "TIN is required" },
                    { pattern: REGEX_CONSTANTS.TIN_VALIDATOR, message: "TIN must be exactly 9 digits" },
                  ]}
                >
                  <InputNumber
                    placeholder="Enter here"
                    useGrouping={false}
                    onKeyDown={(e) => {
                      if (e.key === '-') {
                        e.preventDefault();
                      }
                    }}
                  />
                </FormItem>
              </div>
              {person && (<div>
                <FormListItem
                  name="prefix"
                  label="Prefix"
                  rules={prefixValidationRules}
                >
                  <Dropdown
                    id="prefix"
                    options={prefixList}
                    optionLabel="value"
                    optionValue="key"
                    showClear
                    placeholder="Select"
                    className="w-full"
                  />
                </FormListItem>
              </div>)}
              {person && (<div>
                <FormListItem
                  name="firstName"
                  label="First Name"
                  rules={firstNameValidationRules}
                >
                  <InputText type="text" />
                </FormListItem>
              </div>)}
              {person && (<div>
                <FormListItem
                  name="middleName"
                  label="Middle Name"
                >
                  <InputText type="text" />
                </FormListItem>
              </div>)}
              {person && (<div>
                <FormListItem
                  name="lastName"
                  label="Last Name"
                  rules={lastNameValidationRules}
                >
                  <InputText type="text" />
                </FormListItem>
              </div>)}

              <div>
                <FormItem
                  name="suffix"
                  label="Suffix"
                // rules={[
                //   { required: true }
                // ]}
                >
                  <Dropdown
                    id="suffixDropDwn"
                    options={suffixList}
                    optionLabel="value"
                    optionValue="value"
                    showClear
                    placeholder="Select"
                    className="w-full"
                  />
                </FormItem>
              </div>
              <div>
                <FormItem
                  name="title"
                  label="Title"
                  rules={[
                    { required: true }
                  ]}
                >
                  <Dropdown
                    id="title"
                    options={titleList}
                    optionLabel="value"
                    optionValue="value"
                    showClear
                    placeholder="Select"
                    className="w-full"
                  />
                </FormItem>
              </div>

            </div>
          </div>

          <div className="pb-4">
            <h5 className="border-bottom-1 pb-3 mb-3">Secondary Details</h5>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">
              <div>
                <FormListItem
                  name="fullName"
                  label="Provider Name" rules={[
                    { required: true, message: "Provider Name is required" },
                    { validator: providerNameValidator, message: "Provider Name is invalid" },
                    { validator: providerLengthValidator, message: "Maximum 160 characters allowed" },
                  ]}
                >
                  <InputText type="text" placeholder="Enter here" />
                </FormListItem>
              </div>
              {person && (<div>
                <FormItem name="dob" label="DOB">
                  <Calendar
                    placeholder="Enter Date"
                    selectionMode="single"
                    icon="cl_calendar_today_line"
                    iconPos="right"
                    dateFormat="mm/dd/yy"
                    maxDate={new Date()}
                  />
                </FormItem>
              </div>)}
              {person && (<div>
                <FormListItem name="ssn" label="SSN" rules={[
                  { pattern: REGEX_CONSTANTS.SSN, message: "SSN is invalid" }
                ]}>
                  <InputMask id="Phone" mask="999-99-9999" inputClassName="w-full" placeholder="Enter here" name="phone" unmask={true} />
                </FormListItem>
              </div>)}
              <div>
                <FormItem
                  name="phone"
                  label="Phone"
                >
                  <InputMask id="Phone" mask="(999) 999-9999" inputClassName="w-full" placeholder="Enter here" name="phone" unmask={true} />
                </FormItem>
              </div>
              <div>
                <FormItem
                  name="fax"
                  label="Fax"
                >
                  <InputMask id="Fax" mask="999-999-9999" inputClassName="w-full" placeholder="Enter here" unmask={true} />
                </FormItem>
              </div>
              <div>
                {/* <FormItem
                  name="primaryEmail"
                  label="Primary Email"
                > */}

                <FormListItem
                  name="primaryEmail"
                  label="Primary Email"
                  rules={[{ validator: emailValidator, message: "Email is invalid" }]}
                >
                  <InputText id="primaryEmail" type="email" placeholder="Enter here" />
                </FormListItem>
              </div>
              <div>
                <FormListItem
                  name="secondaryEmail"
                  label="Secondary Email"
                  rules={[{ validator: emailValidator, message: "Email is invalid" }]}
                >
                  <InputText id="secondaryEmail" type="email" placeholder="Enter here" />
                </FormListItem>
              </div>
              <div>
                <FormItem
                  name="credentialStatusID"
                  label="Credential Status"
                // rules={[
                //   { required: true }
                // ]}
                >
                  <Dropdown
                    id="credentialStatus"
                    options={credentialData}
                    optionLabel="value"
                    optionValue="key"
                    showClear
                    placeholder="Select"
                    className="w-full"
                  />
                </FormItem>
              </div>
              {person && (<div>
                <FormItem
                  name="gender"
                  label="Gender"

                >
                  <Dropdown
                    id="gender"
                    options={genderList}
                    optionLabel="key"
                    optionValue="value"
                    showClear
                    placeholder="Select"
                    className="w-full"
                  />
                </FormItem>
              </div>)}
            </div>
          </div>
          {person && (<div className="pb-4">
            <h5 className="border-bottom-1 pb-3 mb-3">Other Details</h5>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6">

              <div>
                <FormItem
                  name="race"
                  label="Race"

                >
                  <Dropdown
                    id="race"
                    options={raceList}
                    optionLabel="value"
                    optionValue="key"
                    showClear
                    placeholder="Select"
                    className="w-full"
                  />
                </FormItem>
              </div>
              <div>
                <FormItem
                  name="ethnicity"
                  label="Ethnicity"
                >
                  <Dropdown
                    id="ethinicity"
                    options={ethinicityList}
                    optionLabel="value"
                    optionValue="key"
                    showClear
                    placeholder="Select"
                    className="w-full"
                  />
                </FormItem>
              </div>
              <div>
                <FormItem
                  name="languageIds"
                  label="Language"
                >
                  <Dropdown
                    id="language"
                    options={languageOptions}
                    optionLabel="key"
                    optionValue="value"
                    showClear
                    multiple
                    showHeader
                    placeholder="Select"
                    className="w-full"
                  />
                </FormItem>
              </div>
              <div>
                <FormItem
                  name="maxMemberCount"
                  label="Max Member Count"
                >
                  <InputNumber placeholder="Enter here" useGrouping={false} />
                </FormItem>
              </div>
            </div>
            <br />
            <div className="flex align-items-center gap-2">
              <label htmlFor="pcp">PCP</label>
              <InputSwitch id="pcp" checked={pcp} onChange={(e) => setPcp(e.value)} />&nbsp;&nbsp;&nbsp;
              <label htmlFor="acceptsMedicaid">Accepts Medicaid</label>
              <InputSwitch id="acceptsMedicaid" checked={medicaid} onChange={(e) => setMedicaid(e.value)} />&nbsp;&nbsp;&nbsp;
              <label htmlFor="providerWatch">Provider watch</label>
              <InputSwitch id="providerWatch" checked={providerWatch} onChange={(e) => setProviderWatch(e.value)} />
            </div>
          </div>)}
          <div className="pb-3">
            <h5 className="border-bottom-1 pb-3 mb-3">Eligibility Details</h5>
            <EligibilityDetails fieldName="providerEligibility" form={form} providerId={providerId} formData={eligibilityDetails} />
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancel} type="button" />
            <Button label="Save" raised disabled={isSubmitting} type="submit" />
          </div>


        </CustomForm>
      </Panel >
      {providerEditId && <ProviderDetails />
      }
    </>
  );
};

export default ProviderAddEdit;
