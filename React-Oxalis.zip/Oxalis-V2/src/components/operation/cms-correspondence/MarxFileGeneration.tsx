import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useEffect, useState } from "react";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import Calendar from "../../../controls/Calendar";

const MarxFileGeneration = () => {
  const [customers1, setCustomers1] = useState<any>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [contractID, setContractIDList] = useState(null);
  const contractIDList = [
    { key: "H0001", value: "H0001" },
    { key: "H0002", value: "H0002" },
  ];
  const [pbpID, setPBPIDList] = useState(null);
  const pbpIDList = [
    { key: "012", value: "012" },
    { key: "013", value: "013" },
  ];
  const [transactionType, setTransactionTypeList] = useState(null);
  const transactionTypeList = [
    { key: "51", value: "51" },
    { key: "61", value: "61" },
  ];
  // Simulate data fetching with a useEffect
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        setLoading(true);
        const customerData = [
          {
            transTypeCode: "61 - Enrollment",
            mbi: "24236E0003",
            lastName: "Test",
            firstName: "A",
            effectiveDate: "02/07/2024",
            contractID: "H0002",
          },
        ];
        setCustomers1(customerData);
      } catch (error) {
        console.error("Error fetching customers:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCustomers();
  }, []);
  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Advance Search</div>
        <div className="flex align-items-center gap-2">
          <Button outlined label="Generate" />
          <Button outlined label="Export" />
          {options.togglerElement}
        </div>
      </div>
    );
  };
  return (
    <>
      <h2 className="pb-4">Marx File Generation</h2>
      <Panel headerTemplate={headerTemplate} toggleable collapsed={true} className="search-panel">
        <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
          <FormItem name="transactionType" label="Transaction Type">
            <Dropdown
              id="transactionType"
              options={transactionTypeList}
              value={transactionType}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setTransactionTypeList(event.value)}
              showClear
              multiple
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
          <FormItem name="effectiveDate" label="Effective Date">
            <Calendar
              placeholder="Enter Date"
              selectionMode="single"
              icon="cl_calendar_today_line"
              iconPos="right"
              dateFormat="mm/dd/yy"
              maxDate={new Date()}
            />
          </FormItem>
          <FormItem name="contractID" label="contract ID">
            <Dropdown
              id="contractID"
              options={contractIDList}
              value={contractID}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setContractIDList(event.value)}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
          <FormItem name="pbpID" label="PBP ID">
            <Dropdown
              id="pbpID"
              options={pbpIDList}
              value={pbpID}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setPBPIDList(event.value)}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
        </div>
        <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
          <Button label="clear" text />
          <Button label="Apply" outlined />
        </div>
      </Panel>
      <div className="pb-4">
        <DataTable
          value={customers1}
          paginator
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          dataKey="claimId"
          responsiveLayout="scroll"
          emptyMessage="No records found."
          loading={loading}
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="multiple" // Single row selection
        >
          <Column selectionMode="multiple" />
          <Column field="transTypeCode" header="Trans&nbsp;Type&nbsp;Code" filter sortable />
          <Column field="mbi" header="MBI" filter sortable />
          <Column field="lastName" header="Last&nbsp;Name" filter sortable />
          <Column field="firstName" header="FIrst&nbsp;Name" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="contractID" header="Contract&nbsp;ID&nbsp;&&nbsp;PBP" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default MarxFileGeneration;
