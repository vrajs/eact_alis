import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useEffect, useState } from "react";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import Calendar from "../../../controls/Calendar";
import InputText from "../../../controls/InputText";

const TRRFallouts = () => {
  const [customers1, setCustomers1] = useState<any>([]);
  const [loading, setLoading] = useState(true);
  const [planID, setPlanIDList] = useState(null);
  const planIDList = [
    { key: "001", value: "1" },
    { key: "002", value: "2" },
  ];
  const [falloutStatus, setFalloutStatusList] = useState(null);
  const falloutStatusList = [
    { key: "Pending", value: "1" },
    { key: "Resolved", value: "2" },
  ];
  // Simulate data fetching with a useEffect
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        setLoading(true);
        const customerData = [
          {
            mbi: "24236E0003",
            trrDate: "11/15/2022",
            fileName: "test.txt",
            trrCodeDesc: "013 - Disenrollment Accepted as Submitted",
            falloutReason: "N/A",
            falloutStatus: "",
          },
        ];
        setCustomers1(customerData);
      } catch (error) {
        console.error("Error fetching customers:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCustomers();
  }, []);

  return (
    <>
      <h2 className="pb-4">TRR Fallouts</h2>
      <Panel header="Advance Search" toggleable collapsed={true} className="search-panel">
        <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
          <FormItem name="mbi" label="MBI">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="memberID" label="Member ID">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="trrDate" label="TRR Date">
            <Calendar
              placeholder="Enter Date"
              selectionMode="single"
              icon="cl_calendar_today_line"
              iconPos="right"
              dateFormat="mm/dd/yy"
              maxDate={new Date()}
            />
          </FormItem>
          <FormItem name="transCode" label="Trans Code">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="trc" label="TRC">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="falloutReason" label="Fallout Reason">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="falloutStatus" label="Transaction Type">
            <Dropdown
              id="falloutStatus"
              options={falloutStatusList}
              value={falloutStatus}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setFalloutStatusList(event.value)}
              showClear
              multiple
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
          <FormItem name="planID" label="Plan ID">
            <Dropdown
              id="planID"
              options={planIDList}
              value={planID}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setPlanIDList(event.value)}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
        </div>
        <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
          <Button label="clear" text />
          <Button label="Apply" outlined />
        </div>
      </Panel>
      <div className="pb-4">
        <DataTable
          value={customers1}
          paginator
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          dataKey="claimId"
          responsiveLayout="scroll"
          emptyMessage="No records found."
          loading={loading}
          selectionMode="single"
        >
          <Column field="mbi" header="MBI" filter sortable body={(rowData) => <a className="underline">{rowData.mbi}</a>} />
          <Column field="trrDate" header="TRR&nbsp;Date" filter sortable />
          <Column field="fileName" header="File&nbsp;Name" filter sortable />
          <Column field="trrCodeDesc" header="TRR&nbsp;Code&nbsp;Desc" filter sortable />
          <Column field="falloutReason" header="Fallout&nbsp;Reason" filter sortable />
          <Column
            field="contractID"
            header="Contract&nbsp;ID&nbsp;&&nbsp;PBP"
            filter
            sortable
            body={(rowData) => (
              <FormItem name="falloutStatus" label="">
                <Dropdown
                  id="falloutStatus"
                  options={falloutStatusList}
                  value={rowData.falloutStatus} // Use row-specific fallout status
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
            )}
          />
        </DataTable>
      </div>
    </>
  );
};

export default TRRFallouts;
