import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useEffect, useState } from "react";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import Calendar from "../../../controls/Calendar";
import InputText from "../../../controls/InputText";

const MemberCorrespondenceFile = () => {
  const [customers1, setCustomers1] = useState<any>([]);
  const [loading, setLoading] = useState(true);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [dateFilter, setDateFilterList] = useState(null);
  const dateFilterList = [
    { key: "Mail Date", value: "1" },
    { key: "Due Date", value: "2" },
  ];
  const [letterType, setLetterTypeList] = useState(null);
  const letterTypeList = [
    { key: "Enrollment Incomplete", value: "1" },
    { key: "Enrollment Denial", value: "2" },
  ];
  // Simulate data fetching with a useEffect
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        setLoading(true);
        const customerData = [
          {
            mbi: "24236E0003",
            memberID: "1",
            letterType: "Out Of Area",
            letterGenerationDate: "08-10-2024",
            letterMailDate: "08-10-2024",
            responseDueDate: "08-10-2024",
          },
        ];
        setCustomers1(customerData);
      } catch (error) {
        console.error("Error fetching customers:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCustomers();
  }, []);
  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Advance Search</div>
        <div className="flex align-items-center gap-2">
          <Button outlined label="Add" />
          <Button outlined label="Generate" />
          <Button outlined label="Generate Batch" />
          <Button outlined label="Export" />
          {options.togglerElement}
        </div>
      </div>
    );
  };
  return (
    <>
      <h2 className="pb-4">Member Dynamic Header</h2>
      <Panel headerTemplate={headerTemplate} toggleable collapsed={true} className="search-panel">
        <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
          <FormItem name="mbi" label="MBI">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="memberID" label="Member ID">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="letterType" label="Letter Type">
            <Dropdown
              id="letterType"
              options={letterTypeList}
              value={letterType}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setLetterTypeList(event.value)}
              showClear
              multiple
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
          <FormItem name="dateFilter" label="Date Filter">
            <Dropdown
              id="dateFilter"
              options={dateFilterList}
              value={dateFilter}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setDateFilterList(event.value)}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
          <FormItem name="fromDate" label="From Date">
            <Calendar
              placeholder="Enter Date"
              selectionMode="single"
              icon="cl_calendar_today_line"
              iconPos="right"
              dateFormat="mm/dd/yy"
              maxDate={new Date()}
            />
          </FormItem>
          <FormItem name="toDate" label="To Date">
            <Calendar
              placeholder="Enter Date"
              selectionMode="single"
              icon="cl_calendar_today_line"
              iconPos="right"
              dateFormat="mm/dd/yy"
              maxDate={new Date()}
            />
          </FormItem>
        </div>
        <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
          <Button label="clear" text />
          <Button label="Apply" outlined />
        </div>
      </Panel>
      <div className="pb-4">
        <DataTable
          value={customers1}
          paginator
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          dataKey="claimId"
          responsiveLayout="scroll"
          emptyMessage="No records found."
          loading={loading}
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="multiple"
        >
          <Column selectionMode="multiple" />
          <Column field="mbi" header="MBI" filter sortable body={(rowData) => <a className="underline">{rowData.mbi}</a>} />
          <Column field="memberID" header="Member&nbsp;Id" filter sortable />
          <Column field="letterType" header="Letter&nbsp;Type" filter sortable />
          <Column field="letterGenerationDate" header="Letter&nbsp;Generation&nbsp;Date" filter sortable />
          <Column field="letterMailDate" header="Letter&nbsp;Mail&nbsp;Date" filter sortable />
          <Column field="responseDueDate" header="Response&nbsp;Due&nbsp;Date" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default MemberCorrespondenceFile;
