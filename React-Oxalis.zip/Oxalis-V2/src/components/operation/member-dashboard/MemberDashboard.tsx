import { Panel } from "primereact/panel";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Calendar from "../../../controls/Calendar";
import { useState } from "react";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";

const MemberDashboard = () => {
  const [contractNumber, setContractNumberList] = useState(null);
  const [pbpID, setPBPIDList] = useState(null);
  const [transactionType, setTransactionTypeList] = useState(null);

  const transactionTypeList = [
    { key: "51", value: "51" },
    { key: "61", value: "61" },
  ];
  const pbpIDList = [
    { key: "H00002-006", value: "1" },
    { key: "H00002-008", value: "2" },
  ];
  const contractNumberList = [
    { key: "H0002", value: "1" },
    { key: "H0001", value: "2" },
  ];

  // Define the folders array with name, size, and icon
  const folders = [
    { name: "New", size: "30" },
    { name: "Incomplete", size: "2" },
    { name: "BEQ Passed", size: "8" },
    { name: "Pre-enroll ready", size: "0" },
    { name: "CMS Accepted", size: "159" },
    { name: "Exception", size: "0" },
    { name: "BEQ Ready", size: "0" },
    { name: "BEQ Failed", size: "0" },
    { name: "CMS Ready", size: "0" },
    { name: "CMS Rejected", size: "0" },
    { name: "Incomplete", size: "29" },
    { name: "BEQ Sent", size: "10" },
  ];
  const categories = [
    {
      icon: "cl_check_done",
      label: "Active",
      count: 46346,
      bgColor: "bg-teal-50",
      textColor: "text-teal-900",
    },
    {
      icon: "cl_info_fill",
      label: "Pending",
      count: 463,
      bgColor: "bg-purple-50",
      textColor: "text-purple-900",
    },
    {
      icon: "cl_cancel_fill",
      label: "Inactive-Cancelled",
      count: 2,
      bgColor: "bg-indigo-50",
      textColor: "text-indigo-900",
    },
    {
      icon: "cl_cancel_fill",
      label: "Inactive-Termed",
      count: 2,
      bgColor: "bg-red-50",
      textColor: "text-red-900",
    },
  ];
  return (
    <>
      <h2 className="pb-4">Member Dashboard</h2>
      <Panel header="Advance Search" toggleable className="search-panel mb-4">
        <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
          <FormItem name="fromDate" label="Effective Date From">
            <Calendar
              placeholder="Enter Date"
              selectionMode="single"
              icon="cl_calendar_today_line"
              iconPos="right"
              dateFormat="mm/dd/yy"
              maxDate={new Date()}
            />
          </FormItem>
          <FormItem name="toDate" label="Effective Date To">
            <Calendar
              placeholder="Enter Date"
              selectionMode="single"
              icon="cl_calendar_today_line"
              iconPos="right"
              dateFormat="mm/dd/yy"
              maxDate={new Date()}
            />
          </FormItem>
          <FormItem name="contractNumber" label="Contract Number">
            <Dropdown
              id="contractNumber"
              options={contractNumberList}
              value={contractNumber}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setContractNumberList(event.value)}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
          <FormItem name="pbpID" label="PBP Number">
            <Dropdown
              id="pbpID"
              options={pbpIDList}
              value={pbpID}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setPBPIDList(event.value)}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
          <FormItem name="transactionType" label="Transaction Type">
            <Dropdown
              id="transactionType"
              options={transactionTypeList}
              value={transactionType}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setTransactionTypeList(event.value)}
              showClear
              multiple
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
        </div>
        <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
          <Button label="clear" text />
          <Button label="Apply" outlined />
        </div>
      </Panel>
      <div className="!grid xl:grid-cols-3 lg:grid-cols-1 sm:grid-cols-1 !gap-6 pb-3">
        <div className="card mb-0">
          <div className="text-900 text-xl font-semibold mb-3">Categories</div>
          <ul className="list-none p-0 m-0">
            {categories.map((category, index) => (
              <li
                key={index}
                className={`p-3 mb-3 flex align-items-center justify-content-between cursor-pointer border-round ${category.bgColor} ${category.textColor}`}
              >
                <div className="flex align-items-center truncate">
                  <i className={`${category.icon} text-2xl mr-3`}></i>
                  <span className="text-lg font-medium truncate">{category.label}</span>
                </div>
                <span className="text-lg font-bold">{category.count}</span>
              </li>
            ))}
          </ul>
        </div>
        <div className="card xl:col-span-2">
          <div className="text-900 text-xl font-semibold mb-3">Folders</div>
          <div className="grid">
            {folders.map((folder, i) => (
              <div key={i} className="col-12 md:col-6 xl:col-4">
                <div className="p-3 border-1 surface-border flex align-items-center justify-content-between hover:surface-100 cursor-pointer border-round">
                  <div className="flex align-items-center truncate">
                    <span className="text-900 text-lg font-medium truncate">{folder.name}</span>
                  </div>
                  <span className="text-600 text-lg font-semibold">{folder.size}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default MemberDashboard;
