import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { LazyTableState } from "../../../model/LazyTableState";
import { useEffect, useState } from "react";
import { GridModel } from "../../../model/GridModel";
import { ProviderStatusGrid } from "../../../model/ProviderStatusModel";
import ProviderStatusService from "../../../services/ProviderStatusService";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { KeyValueModel } from "../../../model/KeyValueModel";
import SharedService, { KeyValLobModel } from "../../../services/SharedService";
import useFormattedDate from "../../../hooks/useFormattedDate";

const Status = () => {
  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined,
  });

  const { providerId } = useSelector((state: RootState) => state.provider);
  
  const [lobListS, setLobListS] = useState<KeyValLobModel[]>([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [gridValues, setGridValues] = useState<ProviderStatusGrid[]>([]);

  const { getByProviderId } = ProviderStatusService();
  const { getLobList } = SharedService();

  const onPage = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  useEffect(() => {
    const fetchLobList = async () => {
      const lobList = await getLobList(); // Assuming this returns a promise
      setLobListS(lobList);
    };

    fetchLobList();
  }, []);

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId, lobListS]);

  const loadLazyData = async () => {
    if (providerId > 0 && lobListS.length > 0) {
      const providerStatusResponse: ProviderStatusGrid[] = await getByProviderId(providerId, lazyState.first, lazyState.rows);

      if (Array.isArray(providerStatusResponse)) {
        // Map over the response and find the matching LOB by `lobId`
        const updatedProviderStatus = providerStatusResponse.map((providerStatus) => {
          const matchingLob = lobListS.find((item) => item.value === providerStatus.lobId);
          return { ...providerStatus, lob: matchingLob ? matchingLob.key : '' };
        });

        setGridValues(updatedProviderStatus);
        setTotalRecords(providerStatusResponse.length);
      } else {
        console.error("Unexpected response format:", providerStatusResponse);
      }
    }
  };
  return (
    <div>
      <DataTable
        paginator
        className="p-datatable-gridlines mt-4"
        showGridlines
        rows={lazyState.rows}
        dataKey="statusId"
        responsiveLayout="scroll"
        emptyMessage="No records found."
        selectionMode="single"
        lazy
        value={gridValues}
        totalRecords={totalRecords}
        first={lazyState.first}
        onPage={onPage}
        onSort={onSort}
        sortField={lazyState.sortField}
        onFilter={onFilter}
      >
        <Column field="providerStatus" header="Provider Status"  sortable />
        <Column field="lob" header="Lob"  sortable />
        <Column field="group" header="Group"  sortable />
        <Column field="address" header="Address"  sortable />
        {/* Use the body property to format the date */}
        <Column
          field="effectiveDate"
          header="Effective&nbsp;Date"
          sortable
          body={(rowData) => useFormattedDate(rowData, 'effectiveDate')}
        />

        <Column
          field="termDate"
          header="Term Date"
          sortable
          body={(rowData) => useFormattedDate(rowData, 'termDate')}
        />
        <Column field="statusId" header="Status Id"  sortable hidden />
      </DataTable>
    </div>
  );
};

export default Status;
