import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import Button from "../../../controls/Button";
import { LazyTableState } from "../../../model/LazyTableState";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { ProviderAuditHistoryModel } from "../../../model/ProviderAuditHistoryModel";
import { GridModel } from "../../../model/GridModel";
import { ProviderService } from "../../../services/ProviderService";
import moment from "moment";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import useFormattedDate from "../../../hooks/useFormattedDate";

const AuditHistory = () => {
  const [showTable, setShowTable] = useState(true);
  const { providerId } = useSelector((state: RootState) => state.provider);
  const [gridValues, setGridValues] = useState<ProviderAuditHistoryModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const { getProviderAuditHistory } = ProviderService();

  const handleAddClick = () => {
    setShowTable(false); // Hide table and show form
  };

  const handleSaveClick = () => {
    setShowTable(true); // Hide form and show table
  };

  const modifiedDateTemplate = (value: ProviderAuditHistoryModel) => {
    console.log(value);
    const formattedDate = moment(value.modifiedDate).format("MM/DD/YYYY HH:mm")
    return formattedDate
  }

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId]);

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      const auditHistoryResponse: GridModel<ProviderAuditHistoryModel> = await getProviderAuditHistory(providerId, query);
      if (auditHistoryResponse) {
        if (auditHistoryResponse.data?.length > 0) {
          const data = auditHistoryResponse.data?.map((history: ProviderAuditHistoryModel) => {
            const dateFields = ['DOB', 'Term Date', 'Effective Date'];
            const { modifiedField, afterValue: newValue, beforeValue: oldValue } = history;
            if (dateFields.includes(modifiedField)) {
              const afterValue = newValue ? useFormattedDate(history, "afterValue") : "N/A"
              const beforeValue = oldValue ? useFormattedDate(history, "beforeValue") : "N/A"
              return { ...history, modifiedField, afterValue, beforeValue };
            }
            return { ...history };
          })
          setGridValues(data);
          setTotalRecords(auditHistoryResponse.totalCount);
        }

      }
    }
  };

  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <Button outlined label="Add" onClick={handleAddClick} />
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            className="p-datatable-gridlines mt-4"
            showGridlines
            rows={10}
            dataKey="providerAuditHistoryId"
            responsiveLayout="scroll"
            emptyMessage="No records found."
            // header={header1}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            // sortOrder={lazyState.sortOrder}
            onFilter={onFilter}
            value={gridValues}
            totalRecords={totalRecords}
            first={lazyState.first}
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
          >
            <Column field="beforeValue" header="Old&nbsp;Value" />
            <Column field="afterValue" header="Updated&nbsp;Value" />
            <Column field="modifiedField" header="Updated&nbsp;Field" />
            <Column field="modifiedBy" header="Updated&nbsp;By" />
            <Column field="modifiedDate" body={modifiedDateTemplate} header="Updated&nbsp;On" />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text type="button"/>
            <Button label="Save" raised onClick={handleSaveClick} type="submit"/>
          </div>
        </div>
      )}
    </>
  );
};

export default AuditHistory;
