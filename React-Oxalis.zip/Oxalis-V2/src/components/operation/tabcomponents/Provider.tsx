import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import InputNumber from "../../../controls/InputNumber";
import Dropdown from "../../../controls/Dropdown";
import InputMask from "../../../controls/InputMask";
import Calendar from "../../../controls/Calendar";
import Button from "../../../controls/Button";
import { FormInstance, useForm } from "rc-field-form";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import { ProviderService } from "../../../services/ProviderService";
import { GridModel } from "../../../model/GridModel";
import ProviderView from "../provider/ProviderView";
import { ProviderViewModel } from "../../../model/ProviderViewModel";
import { DropdownChangeEvent } from "primereact/dropdown";
import { ProviderRelationFormModel } from "../../../model/ProviderRelationModel";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import ProviderRelationService from "../../../services/ProviderRelationService";
import { LazyTableState } from "../../../model/LazyTableState";
import { KeyValueModel } from "../../../model/KeyValueModel";
import moment from "moment";
import { useToaster } from "../../../layout/context/toastContext";
import useFormattedDate from "../../../hooks/useFormattedDate";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import useErrorHandler from "../../../hooks/useErrorHandler";
import { useNavigate } from "react-router";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";
import FormListItem from "../../../controls/FormListItem";
import { REGEX_CONSTANTS } from "../../../data/constants/RegexConstants";

const Provider = () => {
  const [showTable, setShowTable] = useState(true);
  const [selectedProvider, setsSelectedProvider] = useState<ProviderRelationFormModel | null>(null);
  const [providers, setProviders] = useState<ProviderViewModel[]>([]);
  const [providerOptions, setProviderOptions] = useState<KeyValueModel[]>([]);
  const [providerRelationId, setProviderRelationId] = useState<number>(0);
  const [form] = useForm();
  const { getActiveProviders } = ProviderService();
  const { create, update, deleteProvider, getByParentProviderId } = ProviderRelationService();
  const [gridValues, setGridValues] = useState<ProviderRelationFormModel[]>([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const { showToast } = useToaster();
  const navigate = useNavigate();
  const [showConfirm, setShowConfirm] = useState<boolean>(false);
  const handleAddClick = () => {
    setShowTable(false); // Hide table and show form
  };
  const { providerId } = useSelector((state: RootState) => state.provider);

  useEffect(() => {
    const activeProviders = async () => {
      const activeProviderResponse: ProviderViewModel[] = await getActiveProviders();
      if (activeProviderResponse) {
        setProviders(activeProviderResponse)
      }
    }
    activeProviders();
  }, [])

  const createProvider = () => {
    navigate("/provider/provider-add-edit");
  }

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedProvider) {
      try {
        const deleteResponse = await deleteProvider(selectedProvider.providerRelationID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "Contract deleted successfully" });
          setsSelectedProvider(null);
          setProviderRelationId(0);
          setShowTable(true);
          form.resetFields();
          loadLazyData();
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setsSelectedProvider(null);
    setProviderRelationId(0);
  }

  const handleDelete = () => {
    if (selectedProvider) {
      setShowConfirm(true);
    }
  }

  const handleProviderChange = (event: DropdownChangeEvent) => {
    if (event.value) {
      const provider = providers.find(a => a.providerID === event.value);
      console.log("provider provider", provider)
      form.setFieldsValue({
        firstName: provider.firstName,
        lastName: provider.lastName,
        title: provider.title,
        npi: provider.npi,
        ssn: provider.ssn,
        phone: provider.phone,
        fax: provider.fax,
        primaryEmail: provider.primaryEmail,
        languages: provider.languages
      })
    } else {
      form.resetFields();
    }
  }

  const dataMapper = async (value) => {
    const providerRelation: ProviderRelationFormModel = {
      parentProviderID: providerId,
      relatedProviderID: value.relatedProviderId,
      termDate: value.termDate ? moment(value.termDate).format("YYYY-MM-DD") : null,
      effectiveDate: moment(value.effectiveDate).format("YYYY-MM-DD"),
      providerRelationID: providerRelationId ?? 0,
      relatedProviderName: ""
    };

    return providerRelation;
  }

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    // console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    // console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  useEffect(() => {
    if (providerId > 0) {
      loadLazyData();
    }
  }, [lazyState, providerId]);

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      const providerRelationGridResponse: GridModel<ProviderRelationFormModel> = await getByParentProviderId(providerId, query);
      // console.log("providerRelationGridResponse", providerRelationGridResponse)
      if (providerRelationGridResponse) {
        setGridValues(providerRelationGridResponse.data);
        setTotalRecords(providerRelationGridResponse.totalCount);
      }
    }
  };

  useEffect(() => {
    if (providers?.length > 0) {
      const providerOpt = providers.map((provider: ProviderViewModel) => {
        return { key: provider.fullName, value: provider.providerID }
      })
      // console.log("providerOpt providerOpt providerOpt", providerOpt)
      setProviderOptions(providerOpt);
    }
  }, [providers])

  const handleEdit = () => {
    if (selectedProvider) {
      console.log(selectedProvider);
      const formData = {
        relatedProviderId: selectedProvider.relatedProviderID,
        firstName: selectedProvider.relatedProvider.firstName,
        lastName: selectedProvider.relatedProvider.lastName,
        title: selectedProvider.relatedProvider.title,
        npi: selectedProvider.relatedProvider.npi,
        ssn: selectedProvider.relatedProvider.ssn,
        languages: selectedProvider.relatedProvider.languages,
        phone: selectedProvider.relatedProvider.phone,
        fax: selectedProvider.relatedProvider.fax,
        primaryEmail: selectedProvider.relatedProvider.primaryEmail,
        effectiveDate: new Date(selectedProvider.effectiveDate),
        termDate: selectedProvider.termDate ?? null,
      }
      setProviderRelationId(selectedProvider.providerRelationID);
      console.log("formData formData", formData)
      const providerValue = { ...formData, effectiveDate: moment(formData.effectiveDate).toDate(), termDate: formData.termDate ? moment(formData.termDate).toDate() : null }
      form.setFieldsValue({ ...providerValue });
      setShowTable(false);
    }
  }

  const handleSelection = (e) => {
    if (e.value) {
      setsSelectedProvider(e.value)
    } else {
      setsSelectedProvider(null);
    }
  }

  const handleCancel = () => {
    setShowTable(true);
    setLazyState((prevState) => {
      return { ...prevState, first: 0 }
    })
    form.resetFields();
    setsSelectedProvider(null);
    setProviderRelationId(0);
    loadLazyData();
  }

  const effectiveDateTemplate = (data) => {
    return useFormattedDate(data, "effectiveDate")
  }

  const termDateTemplate = (data) => {
    return useFormattedDate(data, "termDate")
  }

  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true)
    const providerRelation: ProviderRelationFormModel = await dataMapper(formValues);
    try {
      const providerRelationResponse = providerRelationId > 0 ? await update(providerRelation) : await create(providerRelation);
      if (providerRelationResponse) {
        showToast({ severity: 'success', summary: 'Success', detail: "Provider saved successfully" });
      }
      setProviderRelationId(0);
      setsSelectedProvider(null);
      setShowTable(true);
      loadLazyData();
      form.resetFields();
    }
    catch (error) {
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
  }
  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedProvider && <Button outlined label="Edit" onClick={handleEdit} />}
          {selectedProvider && <Button outlined label="Delete" onClick={handleDelete} />}
          <Button outlined label="Create Provider" type="button" onClick={createProvider} />
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            className="p-datatable-gridlines mt-4"
            showGridlines
            rows={5}
            dataKey="providerRelationID"
            responsiveLayout="scroll"
            emptyMessage="No records found."
            header={header1}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
            // sortOrder={lazyState.sortOrder}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >

            <Column field="relatedProvider.firstName" header="First&nbsp;Name" sortable />
            <Column field="relatedProvider.lastName" header="Last&nbsp;Name" sortable />
            <Column field="relatedProvider.title" header="Title" sortable />
            <Column field="relatedProvider.npi" header="NPI" sortable />
            <Column field="relatedProvider.ssn" header="SSN" sortable />
            <Column field="relatedProvider.languages" header="Language" sortable />
            <Column field="relatedProvider.phone" header="Phone" sortable />
            <Column field="relatedProvider.fax" header="Fax" sortable />
            <Column field="relatedProvider.primaryEmail" header="Primary&nbsp;Email" sortable />
            <Column field="effectiveDate" header="Effective&nbsp;Date" sortable body={effectiveDateTemplate} />
            <Column field="termDate" header="Term&nbsp;Date" sortable body={termDateTemplate} />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="relatedProviderId" label="Provider Name" rules={[
                { required: true }
              ]}>
                <Dropdown
                  id="relatedProviderId"
                  options={providerOptions}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                  className="w-full"
                  onChange={(event) => handleProviderChange(event)}
                />
              </FormItem>

              <FormItem name="firstName" label="First Name">
                <InputText id="firstName" type="text" placeholder="Enter here" disabled />
              </FormItem>

              <FormItem name="lastName" label="Last Name">
                <InputText id="lastName" type="text" placeholder="Enter here" disabled />
              </FormItem>

              <FormItem name="title" label="Title">
                <InputText id="title" type="text" placeholder="Enter here" disabled />
              </FormItem>

              <FormItem name="npi" label="NPI">
                <InputNumber id="npi" placeholder="Enter here" useGrouping={false} disabled />
              </FormItem>

              {/* <FormItem name="ssn" label="SSN">
                <InputNumber id="ssn" placeholder="Enter here" disabled useGrouping={false} />
              </FormItem> */}

              <FormListItem name="ssn" label="SSN" rules={[
                { pattern: REGEX_CONSTANTS.SSN, message: "SSN is invalid" }
              ]}>
                <InputMask id="Phone" mask="999-999-9999" inputClassName="w-full" placeholder="Enter here" name="phone" unmask={true} />
              </FormListItem>

              <FormItem name="languages" label="Languages" >
                <InputText id="languages" type="text" placeholder="Enter here" disabled />
                {/* <Dropdown
                  id="languages"
                  options={languageOptions}
                  optionLabel="name"
                  multiple
                  showHeader
                  showClear
                  placeholder="Select"
                  className="w-full"
                  readOnly
                /> */}
              </FormItem>

              <FormItem name="phone" label="Phone">
                <InputMask id="phone" mask="(999) 999-9999" inputClassName="w-full" disabled placeholder="Enter here" />
              </FormItem>
              <FormItem name="fax" label="Fax">
                <InputMask id="fax" mask="999-999-9999" inputClassName="w-full" disabled placeholder="Enter here" />
              </FormItem>
              <FormItem name="primaryEmail" label="Primary Email">
                <InputText id="primaryEmail" type="email" placeholder="Enter here" disabled />
              </FormItem>

              <FormItem name="effectiveDate" label="Effective Date" rules={[
                { required: true }
              ]}>
                <Calendar
                  id="effectiveDate"
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar
                  id="termDate"
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={handleCancel} type='button' />
              <Button label="Save" raised type='submit' />
            </div>
          </CustomForm>
        </div>
      )}

      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </>
  );
};

export default Provider;
