import React from 'react'
import FormItem from '../../../controls/FormItem'
import { InputText } from 'primereact/inputtext'
import Dropdown from '../../../controls/Dropdown'
import Calendar from '../../../controls/Calendar'

const License = () => {
  const credentialStatusList = [
    { key: "Provisional", value: 60 },
    { key: "Credential", value: 61 },
    { key: "UnCredential", value: 62 },
    { key: "Not Required", value: 63 }
  ];
  return (
    <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
      {/* <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}> */}
        {/* <h2 style={{ textAlign: 'center', color: 'red' }}>License </h2>*/}
        <FormItem name="licensingBoardName" label="Licensing Board Name" rules={[{ required: true }]}>
          <InputText type="text" placeholder="Enter Licensing Board Name" />
        </FormItem>

        <FormItem name="licenseNumber" label="License Number" rules={[{ required: true }]}>
          <InputText type="text" placeholder="Enter License Number" />
        </FormItem>

        <FormItem name="credentialStatusId" label="Credential Status" rules={[{ required: true }]}>
          <Dropdown
            options={credentialStatusList}
            optionLabel="key"
            optionValue="value"
            showClear
            placeholder="Select Credential Status"
          />
        </FormItem>

        <FormItem name="effectiveDate" label="Effective Date" rules={[{ required: true }]}>
          <Calendar
            placeholder="Enter Effective Date"
            selectionMode="single"
            icon="oxalis:icon_today_fill"
            iconPos="right"
            dateFormat="mm/dd/yy"
          />
        </FormItem>

        <FormItem name="expirationDate" label="Expiration Date" rules={[{ required: true }]}>
          <Calendar
            placeholder="Enter Expiration Date"
            selectionMode="single"
            icon="oxalis:icon_today_fill"
            iconPos="right"
            dateFormat="mm/dd/yy"
          />
        </FormItem>
      {/* </div> */}
    </div>
  )
}

export default License