import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { lazy, useEffect, useState } from "react";
import Button from "../../../controls/Button";
import InputText from "../../../controls/InputText";
import Calendar from "../../../controls/Calendar";
import Dropdown from "../../../controls/Dropdown";
import { LazyTableState } from "../../../model/LazyTableState";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { useForm } from "rc-field-form";
import { GridModel } from "../../../model/GridModel";
import moment from "moment";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import { CodeType, CommonCodeFetchingType } from "../../../data/constants/AppEnum";
import ProviderEFTService from "../../../services/ProviderEFTService";
import { ProviderEFTViewModel } from "../../../model/ProviderEFTModel";
import { useToaster } from "../../../layout/context/toastContext";
import FormListItem from "../../../controls/FormListItem";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import useErrorHandler from "../../../hooks/useErrorHandler";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";

const EFTInfo = () => {
  const [selectedEFT, setSelectedEFT] = useState<ProviderEFTViewModel>(null);
  const [selectedEFTID, setSelectedEFTID] = useState<number>(0);
  const [showTable, setShowTable] = useState<boolean>(true);
  const { providerId } = useSelector((state: RootState) => state.provider);
  const [gridValues, setGridValues] = useState<ProviderEFTViewModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [form] = useForm();
  const payTypeOptions = useCommonCodeSubCategory(CodeType.PayType, CommonCodeFetchingType.Default);
  const { create, update, getByProviderId, deleteInfo } = ProviderEFTService();
  const { showToast } = useToaster();
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const [showConfirm, setShowConfirm] = useState<boolean>(false);

  const handleAddClick = () => {
    setShowTable(false); // Hide table and show form
  };

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const handleEffectiveDateChange = (event: Date) => {
    console.log("event ", event);
    setEffectiveDate(event);
  };

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedEFT) {
      try {
        const deleteResponse = await deleteInfo(selectedEFT.providerEFTID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "ETF info deleted successfully" });
          setSelectedEFTID(0);
          setSelectedEFT(null);
          setShowTable(true);
          form.resetFields();
          loadLazyData();
          setEffectiveDate(null);
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setSelectedEFTID(0);
    setSelectedEFT(null);
  }

  const handleDelete = () => {
    if (selectedEFT) {
      setShowConfirm(true);
    }
  }

  const lengthValidator = async (rule, value) => {
    if (!value) {
      return Promise.resolve();
    }

    if (value.length > 60) {
      return Promise.reject("Maximum 60 characters allowed");
    }
  }

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      try {
        const etfResponse: GridModel<ProviderEFTViewModel> = await getByProviderId(providerId, query);
        if (etfResponse) {
          setGridValues(etfResponse.data);
          setTotalRecords(etfResponse.totalCount);
        }
      } catch (error) {
        console.log("error error", error);
      }
    }
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId]);



  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true)

    console.log("formValues formValues", formValues)
    const providerNotes = await dataMapper(formValues);
    console.log(providerNotes)
    try {
      const eftResponse = selectedEFTID > 0 ? await update(providerNotes) : await create(providerNotes);
      if (eftResponse) {
        showToast({ severity: 'success', summary: 'Success', detail: "EFT saved successfully" });
        setShowTable(true);
        form.resetFields();
        form.resetFields();
        setSelectedEFT(null);
        setSelectedEFTID(0);
        loadLazyData();
        setEffectiveDate(null);
      }
    }
    catch (error) {
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
  };

  const termDateFormatTemplate = (value) => {
    const termDate = value.termDate;
    if (termDate) {
      return moment(termDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const effectiveDateFormatTemplate = (value) => {
    const effectiveDate = value.effectiveDate;
    if (effectiveDate) {
      return moment(effectiveDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const handleEdit = () => {
    if (selectedEFT) {

      console.log(selectedEFT)
      const formData = {
        providerEFTID: selectedEFT.providerEFTID,
        providerID: providerId,
        accountTypeID: selectedEFT.accountTypeID,
        accountTypeName: selectedEFT.accountTypeName,
        bankName: selectedEFT.bankName,
        nameOnAccount: selectedEFT.nameOnAccount,
        accountNumber: selectedEFT.accountNumber,
        routing: selectedEFT.routing,
        effectiveDate: moment(selectedEFT.effectiveDate).toDate(),
        termDate: selectedEFT.termDate ? moment(selectedEFT.termDate).toDate() : null,
      }
      setSelectedEFTID(selectedEFT.providerEFTID);
      setEffectiveDate(formData.effectiveDate);
      form.setFieldsValue(formData);
      setShowTable(false);
    }
  }

  const dataMapper = (formValue) => {

    const referenceModel: ProviderEFTViewModel = {
      providerEFTID: formValue.providerEFTID,
      providerID: providerId,
      accountTypeID: formValue.accountTypeID,
      accountTypeName: formValue.accountTypeName,
      bankName: formValue.bankName,
      nameOnAccount: formValue.nameOnAccount,
      accountNumber: formValue.accountNumber,
      routing: formValue.routing,
      effectiveDate: moment(formValue.effectiveDate).format("YYYY-MM-DD"),
      termDate: formValue.termDate ? moment(formValue.termDate).format("YYYY-MM-DD") : null,
    }
    return referenceModel;
  }

  const handleCancel = () => {
    setShowTable(true);
    form.resetFields();
    setSelectedEFT(null);
    setSelectedEFTID(0);
    loadLazyData();
    setEffectiveDate(null);
  }

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedEFT(e.value);
    } else {
      setSelectedEFT(null);
    }
  }


  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedEFT && <Button outlined label="Edit" onClick={handleEdit} />}
          {selectedEFT && <Button outlined label="Delete" onClick={handleDelete} />}
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            rowsPerPageOptions={paginatorConstants.pageOptions}
            className="p-datatable-gridlines"
            showGridlines
            rows={lazyState.rows}
            tableStyle={{ minWidth: '50rem' }}
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
            dataKey="alertModuleID"
            emptyMessage={paginatorConstants.emptyMessage}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortOrder={lazyState.sortOrder}
            sortField={lazyState.sortField}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
            header={header1}
          >
            <Column field="accountTypeName" header="Account&nbsp;Type" sortable />
            <Column field="bankName" header="Bank&nbsp;Name" sortable />
            <Column field="nameOnAccount" header="Name&nbsp;On&nbsp;Account" sortable />
            <Column field="accountNumber" header="Account&nbsp;Number" sortable />
            <Column field="routing" header="Routing" sortable />
            <Column field="effectiveDate" body={effectiveDateFormatTemplate} header="Effective&nbsp;Date" sortable />
            <Column field="termDate" body={termDateFormatTemplate} header="Term&nbsp;Date" sortable />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="accountTypeID" label="Account Type" rules={[
                { required: true }
              ]}>
                <Dropdown
                  id="type"
                  options={payTypeOptions}
                  optionLabel="value"
                  optionValue="key"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormListItem name="bankName" label="Bank Name" rules={[
                { required: true, message: "Bank Name is required" },
                { validator: lengthValidator, message: "Maximum 60 characters allowed" }
              ]}>
                <InputText type="text" placeholder="Enter here" />
              </FormListItem>

              <FormListItem name="nameOnAccount" label="Name On Account" rules={[
                { required: true, message: "Name On Account is required" },
                { validator: lengthValidator, message: "Maximum 60 characters allowed" }
              ]}>
                <InputText type="text" placeholder="Enter here" />
              </FormListItem>

              <FormListItem name="accountNumber" label="Account Number" rules={[
                { required: true, message: "Account Number is required" },
                { validator: lengthValidator, message: "Maximum 60 characters allowed" }
              ]}>
                <InputText type="text" placeholder="Enter here" />
              </FormListItem>

              <FormListItem name="routing" label="Routing" rules={[
                { required: true, message: "Routing is required" },
                { validator: lengthValidator, message: "Maximum 60 characters allowed" }
              ]}>
                <InputText type="text" placeholder="Enter here" />
              </FormListItem>

              <FormItem name="effectiveDate" label="Effective Date" rules={[
                { required: true }
              ]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  onChange={(event) => handleEffectiveDateChange(event as Date)}
                />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={effectiveDate}
                  disabled={!effectiveDate}
                />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={handleCancel} type="button" />
              <Button label="Save" raised type="submit" />
            </div>
          </CustomForm>
        </div>
      )}

      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </>
  );
};

export default EFTInfo;
