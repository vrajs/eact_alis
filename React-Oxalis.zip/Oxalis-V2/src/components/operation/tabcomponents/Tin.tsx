import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import Dropdown from "../../../controls/Dropdown";
import InputMask from "../../../controls/InputMask";
import Calendar from "../../../controls/Calendar";
import Button from "../../../controls/Button";
import { LazyTableState } from "../../../model/LazyTableState";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { GridModel } from "../../../model/GridModel";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import { CodeType, CommonCodeFetchingType } from "../../../data/constants/AppEnum";
import CustomForm from "../../../controls/CustomForm";
import { useForm } from "rc-field-form";
import FormItem from "../../../controls/FormItem";
import ProviderTINService from "../../../services/ProviderTINService";
import { ProviderTINFormModel, ProviderTINViewModel } from "../../../model/ProviderTINViewModel";
import moment from "moment";
import { useToaster } from "../../../layout/context/toastContext";
import useFormattedDate from "../../../hooks/useFormattedDate";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import useErrorHandler from "../../../hooks/useErrorHandler";
import FormListItem from "../../../controls/FormListItem";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";

const Tin = () => {
  const [selectedProviderTin, setSelectedProviderTin] = useState<ProviderTINFormModel | null>(null);
  const [selectedProviderTinId, setSelectedProviderTinId] = useState<number>(0);
  const [showTable, setShowTable] = useState(true);
  const { providerId } = useSelector((state: RootState) => state.provider);
  const [gridValues, setGridValues] = useState<ProviderTINFormModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const tinTypeOptions = useCommonCodeSubCategory(CodeType.TINType, CommonCodeFetchingType.Default);
  const { getByProviderId, create, update, deleteTIN } = ProviderTINService()
  const [form] = useForm<ProviderTINViewModel>();
  const { showToast } = useToaster()
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const [showConfirm, setShowConfirm] = useState<boolean>(false);

  const handleAddClick = () => {
    setShowTable(false); // Hide table and show form
  };

  const effectiveDateTemplate = (data) => {
    return useFormattedDate(data, "effectiveDate")
  }

  const termDateTemplate = (data) => {
    return useFormattedDate(data, "termDate")
  }

  const handleEffectiveDateChange = (event: Date) => {
    console.log("event ", event);
    setEffectiveDate(event);
  };

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: "",
    sortOrder: 0,
    filters: {}
  });


  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const maxLengthValidator = async (rule, value) => {
    if (value?.length > 40) {
      return Promise.reject("Maximum 40 characters allowed");
    }
    return Promise.resolve(null);
  }

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      const providerTINResponse: GridModel<ProviderTINFormModel> = await getByProviderId(providerId, query);
      console.log("providerRelationGridResponse", providerTINResponse)
      if (providerTINResponse) {
        setGridValues(providerTINResponse.data);
        setTotalRecords(providerTINResponse.totalCount);
      }
    }
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId]);


  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true)
    console.log(formValues)
    console.log("formValues", formValues)
    const providerTIN: ProviderTINFormModel = { ...formValues, providerID: providerId, providerTINID: selectedProviderTinId ? selectedProviderTinId : 0, effectiveDate: moment(formValues.effectiveDate).format("YYYY-MM-DD"), termDate: formValues.termDate ? moment(formValues.termDate).format("YYYY-MM-DD") : null };
    try {
      const providerRelationResponse = selectedProviderTinId > 0 ? await update(providerTIN) : await create(providerTIN);
      if (providerRelationResponse) {
        showToast({ severity: 'success', summary: 'Success', detail: "TIN saved successfully" });
        setSelectedProviderTinId(0);
        setSelectedProviderTin(null);
        setShowTable(true);
        form.resetFields();
        loadLazyData();
      }
    }
    catch (error) {
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }

  };

  const handleEdit = () => {
    if (selectedProviderTin) {
      console.log(selectedProviderTin);
      const formData = {
        tinTypeId: selectedProviderTin.tinTypeID,
        tinNumber: selectedProviderTin.tinNumber,
        tinName: selectedProviderTin.tinName,
        effectiveDate: new Date(selectedProviderTin.effectiveDate),
        termDate: selectedProviderTin.termDate ? new Date(selectedProviderTin.termDate) : null,
        providerID: providerId
      }
      setSelectedProviderTinId(selectedProviderTin.providerTINID);
      console.log("formData formData", formData);

      const tinValue = { ...formData, effectiveDate: moment(formData.effectiveDate).toDate(), termDate: formData.termDate ? moment(formData.termDate).toDate() : null }

      form.setFieldsValue({ ...tinValue });
      setShowTable(false);
    }
  }

  const handleCancel = () => {
    setShowTable(true);
    setSelectedProviderTinId(0);
    setSelectedProviderTin(null);
    setShowTable(true);
    form.resetFields();
    loadLazyData();
  }

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedProviderTin(e.value)
    } else {
      setSelectedProviderTin(null);
    }
  }

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedProviderTin) {
      try {
        const deleteResponse = await deleteTIN(selectedProviderTin.providerTINID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "TIN deleted successfully" });
          setSelectedProviderTinId(0);
          setSelectedProviderTin(null);
          setShowTable(true);
          form.resetFields();
          loadLazyData();
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setSelectedProviderTinId(0);
    setSelectedProviderTin(null);
  }

  const handleDelete = () => {
    if (selectedProviderTin) {
      setShowConfirm(true);
    }
  }

  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedProviderTin && <Button outlined label="Edit" onClick={handleEdit} />}
          {selectedProviderTin && <Button outlined label="Delete" onClick={handleDelete} />}
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            className="p-datatable-gridlines mt-4"
            showGridlines
            rows={10}
            dataKey="providerTINID"
            responsiveLayout="scroll"
            emptyMessage="No records found."
            header={header1}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
            sortField={lazyState.sortField}
            // sortOrder={lazyState.sortOrder}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >
            <Column field="tinType" header="TIN&nbsp;Type" sortable />
            <Column field="tinNumber" header="TIN" sortable />
            <Column field="tinName" header="TIN&nbsp;Name" sortable />
            <Column field="effectiveDate" header="Effective&nbsp;Date" sortable body={effectiveDateTemplate} />
            <Column field="termDate" header="Term&nbsp;Date" sortable body={termDateTemplate} />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="tinTypeId" label="TIN Type" rules={[
                { required: true }
              ]}>
                <Dropdown
                  id="tin"
                  options={tinTypeOptions}
                  optionLabel="value"
                  optionValue="key"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="tinNumber" label="TIN" rules={[
                { required: true }
              ]}>
                <InputMask mask="99-9999999" inputClassName="w-full" placeholder="Enter here" unmask={true} />
              </FormItem>

              <FormListItem name="tinName" label="1099 Name" rules={[
                { required: true, message: "1099 Name is required" },
                { validator: maxLengthValidator, message: "Maximum 40 characters allowed" }
              ]}>
                <InputText type="text" placeholder="Enter here" />
              </FormListItem>

              <FormItem name="effectiveDate" label="Effective Date" rules={[
                { required: true }
              ]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  onChange={(event) => handleEffectiveDateChange(event as Date)}
                />
              </FormItem>
              <FormItem name="termDate" label="Term Date">
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={effectiveDate}
                  disabled={!effectiveDate}
                />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={handleCancel} type='button' />
              <Button label="Save" raised type='submit' />
            </div>
          </CustomForm>
        </div>
      )}

      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </>
  );
};

export default Tin;
