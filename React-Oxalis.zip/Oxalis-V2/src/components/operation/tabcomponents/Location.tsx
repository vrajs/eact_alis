import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";

import InputText from "../../../controls/InputText";
import InputNumber from "../../../controls/InputNumber";
import Dropdown from "../../../controls/Dropdown";
import Calendar from "../../../controls/Calendar";
import Button from "../../../controls/Button";
import LocationService from "../../../services/LocationService";
import { useForm } from "rc-field-form";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import { LocationModel } from "../../../model/LocationModel";
import { LazyTableState } from "../../../model/LazyTableState";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import ProviderLocationService from "../../../services/ProviderLocationService";
import { ProviderLocationFormModel, ProviderLocationModel } from "../../../model/ProviderLocationModel";
import { GridModel } from "../../../model/GridModel";
import { DropdownChangeEvent } from "primereact/dropdown";
import { KeyValueModel } from "../../../model/KeyValueModel";
import moment from "moment";
import { useToaster } from "../../../layout/context/toastContext";
import useFormattedDate from "../../../hooks/useFormattedDate";
import useErrorHandler from "../../../hooks/useErrorHandler";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import { useNavigate } from "react-router";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";

const Location = () => {
  const [showTable, setShowTable] = useState(true);
  const [selectedProviderLocation, setSelectedProviderLocation] = useState<ProviderLocationModel | null>(null);
  const [gridValues, setGridValues] = useState<ProviderLocationModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [locations, setLocations] = useState<LocationModel[]>([]);
  const [locationOptions, setLocationOptions] = useState<KeyValueModel[]>([]);
  const { getAll } = LocationService();
  const { getByProviderId, create, update, deleteProviderLocation } = ProviderLocationService();
  const { providerId, providerData } = useSelector((state: RootState) => state.provider);
  const [form] = useForm();
  const [providerLocationId, setProviderLocationId] = useState<number>(0);
  const [showConfirm, setShowConfirm] = useState<boolean>(false);
  const { showToast } = useToaster();
  const navigate = useNavigate();
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const [minDate, setMinDate] = useState<Date | null>(null);
  const handleAddClick = () => {
    setShowTable(false);
  };

  const createLocation = () => {
    navigate("/location/location-add-edit")
  }

  useEffect(() => {
    const getLocationList = async () => {
      const locationResponse: LocationModel[] = await getAll();
      console.log("locationResponse.data ", locationResponse)
      if (locationResponse) {
        setLocations(locationResponse)
      }
    }
    getLocationList();
  }, [])

  useEffect(() => {
    if (providerData) {
      const eligibilities = providerData.providerEligibility;
      const providerEligibility = eligibilities?.[0];
      const { effectiveDate } = providerEligibility;
      setMinDate(() => {
        return effectiveDate ? moment(effectiveDate).toDate() : null
      })
    }
  }, [providerData])

  const handleEffectiveDateChange = (event: Date) => {
    console.log("event ", event);
    setEffectiveDate(event);
  };

  useEffect(() => {
    if (locations.length > 0) {
      const locationOpt = locations.map((location: LocationModel) => {
        return { key: location.locationName, value: location.locationID }
      });
      setLocationOptions(locationOpt);
    }
  }, [locations])

  const handleLocationChange = (event: DropdownChangeEvent) => {
    if (event.value) {
      const selectedLocation = locations.find((location: LocationModel) => location.locationID === event.value);
      console.log(selectedLocation);
      form.setFieldsValue({
        address1: selectedLocation.address1,
        address2: selectedLocation.address2,
        locationTypeName: selectedLocation.locationTypeName,
        city: selectedLocation.city,
        state: selectedLocation.state,
        zip: selectedLocation.zip,
        // effectiveDate: new Date(selectedLocation.effectiveDate),
        // termDate: selectedLocation.termDate ? new Date(selectedLocation.termDate) : null
      })
    } else {
      form.resetFields();
    }
  }

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedProviderLocation) {
      try {
        const deleteResponse = await deleteProviderLocation(selectedProviderLocation.providerLocationID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "Location deleted successfully" });
          setProviderLocationId(0);
          setShowTable(true);
          setSelectedProviderLocation(null);
          form.resetFields();
          loadLazyData();
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setSelectedProviderLocation(null);
    setProviderLocationId(0);
  }

  const handleDelete = () => {
    if (selectedProviderLocation) {
      setShowConfirm(true);
    }
  }

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });


  const onPage = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onSort = (event) => {
    console.log("event event", event)
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const effectiveDateTemplate = (data) => {
    return useFormattedDate(data, "effectiveDate")
  }

  const termDateTemplate = (data) => {
    return useFormattedDate(data, "termDate")
  }

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      setSelectedProviderLocation(null);
      setProviderLocationId(0);
      const providerLocationResponse: GridModel<ProviderLocationModel> = await getByProviderId(providerId, query);
      console.log("providerRelationGridResponse", providerLocationResponse)
      if (providerLocationResponse) {
        setGridValues(providerLocationResponse.data);
        setTotalRecords(providerLocationResponse.totalCount);
      }
    }
  };

  const dataMapper = (formValue) => {
    const providerLocation: ProviderLocationFormModel = {
      providerID: providerId,
      locationID: formValue.locationId,
      termDate: formValue.termDate ? moment(formValue.termDate).format("YYYY-MM-DD") : null,
      effectiveDate: moment(formValue.effectiveDate).format("YYYY-MM-DD"),
      providerLocationID: formValue.providerLocationId ?? providerLocationId,
    }
    return providerLocation;
  }

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId]);

  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true);
    console.log("formValues formValues", formValues)
    const providerLocation: ProviderLocationFormModel = await dataMapper(formValues);
    console.log("providerLocation", providerLocation)
    try {
      const providerLocationResponse = providerLocationId > 0 ? await update(providerLocation) : await create(providerLocation)
      if (providerLocationResponse) {
        showToast({ severity: 'success', summary: 'Success', detail: "Location data saved successfully" });
      }
      setProviderLocationId(0);
      setShowTable(true);
      setSelectedProviderLocation(null);
      form.resetFields();
      setEffectiveDate(null);
      loadLazyData()
    }
    catch (error) {
      console.log(error)
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
  };

  const handleCancel = () => {
    setShowTable(true);
    form.resetFields();
    setSelectedProviderLocation(null);
    setProviderLocationId(0);
    loadLazyData();
  }

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedProviderLocation(e.value)
    } else {
      setSelectedProviderLocation(null);
    }
  }

  const handleEdit = () => {
    if (selectedProviderLocation) {
      console.log(selectedProviderLocation);
      const selectedLocation = locations.find((location: LocationModel) => location.locationID === selectedProviderLocation.locationID);
      console.log(selectedLocation);
      const formData = {
        providerLocationId: selectedProviderLocation.providerLocationID,
        effectiveDate: moment(selectedProviderLocation.effectiveDate).toDate(),
        termDate: selectedProviderLocation.termDate ? moment(selectedProviderLocation.termDate).toDate() : null,
        locationId: selectedProviderLocation.locationID,
        providerId,
        address1: selectedLocation.address1,
        address2: selectedLocation.address2,
        locationTypeName: selectedLocation.locationTypeName,
        city: selectedLocation.city,
        state: selectedLocation.state,
        zip: selectedLocation.zip,
      }
      setEffectiveDate(formData.effectiveDate);
      setProviderLocationId(selectedProviderLocation.providerLocationID);
      // console.log("formData formData", formData)
      const location = { ...formData, effectiveDate: moment(formData.effectiveDate).toDate(), termDate: formData.termDate ? moment(formData.termDate).toDate() : null }
      form.setFieldsValue({ ...location });
      setShowTable(false);
    }
  }


  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedProviderLocation && <Button outlined label="Edit" onClick={handleEdit} />}
          {selectedProviderLocation && <Button outlined label="Delete" onClick={handleDelete} />}
          <Button outlined label="Create Location" onClick={createLocation} />
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            className="p-datatable-gridlines mt-4"
            showGridlines
            rows={10}
            dataKey="providerLocationId"
            responsiveLayout="scroll"
            emptyMessage="No records found."
            header={header1}
            selectionMode="single"
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            sortOrder={lazyState.sortOrder}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >
            <Column field="locationName" header="Office&nbsp;Name" sortable />
            <Column field="location.locationTypeName" header="Address&nbsp;Type" sortable />
            <Column field="location.address1" header="Address 1" sortable />
            <Column field="location.address2" header="Address 2" sortable />
            <Column field="location.city" header="City" sortable />
            <Column field="location.state" header="State" sortable />
            <Column field="location.zip" header="Zip" sortable />
            <Column field="effectiveDate" header="Effective&nbsp;Date" sortable body={effectiveDateTemplate} />
            <Column field="termDate" header="Term&nbsp;Date" sortable body={termDateTemplate} />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="locationId" label="Office Name" rules={[
                { required: true }
              ]}>
                <Dropdown
                  id="locationId"
                  options={locationOptions}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  onChange={(event) => handleLocationChange(event)}
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="locationTypeName" label="Address Type">
                <InputText type="text" placeholder="Enter here" disabled />
              </FormItem>

              <FormItem name="address1" label="Address 1">
                <InputText type="text" placeholder="Enter here" disabled />
              </FormItem>

              <FormItem name="address2" label="Address 2">
                <InputText type="text" placeholder="Enter here" disabled />
              </FormItem>

              <FormItem name="city" label="City">
                <InputText type="text" placeholder="Enter here" disabled />
              </FormItem>

              <FormItem name="state" label="State">
                <InputText placeholder="Enter here" disabled />
              </FormItem>

              <FormItem name="zip" label="Zip">
                <InputNumber placeholder="Enter here" disabled />
              </FormItem>

              <FormItem name="effectiveDate" label="Effective Date" rules={[
                { required: true }
              ]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={minDate}
                  onChange={(event) => handleEffectiveDateChange(event as Date)}
                />
              </FormItem>

              <FormItem name="termDate" label="Term Date">
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={effectiveDate ? effectiveDate : minDate}
                  disabled={!effectiveDate}
                />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={handleCancel} type='button' />
              <Button label="Save" raised type='submit' />
            </div>
          </CustomForm>
        </div>
      )}
      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </>
  );
};

export default Location;
