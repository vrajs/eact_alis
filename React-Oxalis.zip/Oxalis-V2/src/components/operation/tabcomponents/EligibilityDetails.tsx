import { useEffect } from 'react'
import Calendar from '../../../controls/Calendar'
import { FormInstance, List } from 'rc-field-form';
import Button from "../../../controls/Button";
import { ProviderEligibilityModel } from '../../../model/ProviderEligibilityModel';
import { ListField } from 'rc-field-form/es/List';
import * as React from 'react';
import moment from 'moment';
import FormListItem from '../../../controls/FormListItem';
import { useDispatch, useSelector } from 'react-redux';
import { ClearEligibilityDetails, ClearUpdate } from '../../../Redux/features/providerSlice';
import { RootState } from '../../../Redux/app/store';

interface EligibilityDetailsProps {
  form: FormInstance;
  fieldName?: string;
  providerId: number;
  formData: ProviderEligibilityModel[];
}

const EligibilityDetails = (props: EligibilityDetailsProps) => {
  const { fieldName, form, providerId } = props;
  const dispatch = useDispatch();
  const [isAllowed, setIsAllowed] = React.useState<boolean>(false);
  const [hideAddButton, setHideAddButton] = React.useState<boolean>(false);
  const { providerData } = useSelector((state: RootState) => state.provider);
  const { updated } = useSelector((state: RootState) => state.provider);

  const initialFormValue = {
    providerEligibilityID: 0,
    providerID: providerId,
    effectiveDate: null,
    termDate: null,
    providerEligibilityCode: ""
  }

  // useEffect(() => {
  //   if (updated) {
  //     const providerEligibility = form.getFieldValue("providerEligibility");
  //     const reOrderedEligibility = providerEligibility.sort((a, b) => {
  //       return b.termDate - a.termDate;
  //     })
  //     console.log(reOrderedEligibility);
  //   }
  //   dispatch(ClearUpdate());
  // }, [updated])

  useEffect(() => {
    if (providerData && providerData.providerID > 0) {
      const { providerEligibility } = providerData;
      const data = providerEligibility?.[0];
      const { effectiveDate, termDate } = data;
      if (effectiveDate && termDate) {
        setIsAllowed(true);
      }
    }
  }, [providerData])

  useEffect(() => {
    return () => {
      dispatch(ClearEligibilityDetails())
    }
  }, []);

  const handleAddFormItem = () => {
    // dispatch(AddEligibilityDetailItem());
    // setIsAdded(true);

    // new code starts
    const existingValue = form.getFieldValue("providerEligibility");
    const newValue = [...existingValue, { ...initialFormValue }];
    form.setFieldValue("providerEligibility", newValue);
    setHideAddButton(true);
    // new code ends
  }

  const handleRemoveItem = () => {
    // dispatch(RemoveEligibilityDetailItem(index));
    // setIsAdded(false);

    // new code starts
    const existingValue = form.getFieldValue("providerEligibility");
    existingValue.pop();
    form.setFieldValue("providerEligibility", existingValue);
    setHideAddButton(false);
    // new code ends
  }

  const allowedValidator = (rule, value) => {
    const providerEligibility = form.getFieldValue("providerEligibility");
    const eligibility = providerEligibility?.[0];
    const { effectiveDate, termDate } = eligibility;
    if (effectiveDate && termDate) {
      setIsAllowed(true);
    } else {
      setIsAllowed(false);
    }
    return Promise.resolve(null);
  }

  return (
    <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
      <List name={fieldName}>

        {(fields) => {
          return <>
            {fields.map((field: ListField, index: number) => {
              return (index === 0 || form.getFieldValue([fieldName, index, "providerEligibilityID"]) == 0) && <React.Fragment key={index} >
                <div>
                  <FormListItem name={[index, 'effectiveDate']} label='Effective Date' validateDebounce={300} validateTrigger={["onChange", "onBlur"]} rules={[
                    { required: true, message: "Effective Date is required" },
                    {
                      validator: (rule, value) => {
                        if (!value) {
                          return Promise.resolve(undefined);
                        }

                        const formData = form.getFieldValue(fieldName);

                        for (let i = 0; i < formData?.length; i++) {
                          if (index === i) {
                            const termDate = formData[i]["termDate"];
                            if (moment(value).isAfter(moment(termDate))) {
                              return Promise.reject(new Error("Effective Date should be before Term Date"));
                            }
                            continue;
                          }
                        }
                        return Promise.resolve(undefined);
                      }, message: "Effective date should be before Term date"
                    },
                    {
                      validator: async (rule, value) => {
                        return new Promise((resolve, reject) => {
                          if (!value) {
                            resolve(undefined);
                            return;
                          }
                          const formData = form.getFieldValue(fieldName);
                          for (let i = 0; i < formData?.length; i++) {
                            if (index === i) {
                              continue;
                            }

                            const effectiveDate = formData[i]["effectiveDate"];
                            const termDate = formData[i]["termDate"] ? formData[i]["termDate"] : new Date(9999, 11, 31);

                            if (effectiveDate && termDate && moment(value).isBetween(moment(effectiveDate), moment(termDate), null, '[]')) {
                              reject(new Error("Selected date is already active"));
                              return;
                            }
                          }
                          resolve(undefined);
                        });
                      }, message: "Effective date is already active"
                    },
                    { validator: allowedValidator, message: "" }
                  ]}
                    key={index}
                    dependencies={[index, 'termDate']}
                  >
                    <Calendar
                      placeholder="Enter Date"
                      selectionMode="single"
                      icon="cl_calendar_today_line"
                      iconPos="right"
                      dateFormat="mm/dd/yy"
                      // onChange={() => console.log(form.getFieldValue([fieldName, index, 'effectiveDate']))}
                      id={`effectiveDate-${index}`}
                    // minDate={eligibility.effectiveDate ? new Date(eligibility.effectiveDate) : null}
                    />
                  </FormListItem>
                </div>

                <div>
                  <FormListItem key={`termDate-${index}`} name={[index, 'termDate']}
                    label={'Term Date'}
                    validateTrigger={["onChange", "onBlur"]}
                    rules={[
                      {
                        validator: (rule, value) => {
                          return new Promise((resolve, reject) => {
                            if (!value) {
                              resolve(undefined);
                              return;
                            }

                            const formData = form.getFieldValue(fieldName);

                            for (let i = 0; i < formData?.length; i++) {
                              if (index === i) {
                                continue;
                              }

                              const effectiveDate = formData[i]["effectiveDate"];
                              const termDate = formData[i]["termDate"] ? formData[i]["termDate"] : new Date(9999, 11, 31);

                              if (effectiveDate && termDate && moment(value).isBetween(moment(effectiveDate), moment(termDate), null, '[]')) {
                                reject(new Error("Selected date is already active"));
                                return;
                              }
                            }
                            resolve(undefined);
                          });
                        }, message: "Term date is already active"
                      },
                      {
                        validator: (rule, value) => {
                          return new Promise((resolve, reject) => {
                            if (!value) {
                              resolve(undefined);
                              return;
                            }

                            const formData = form.getFieldValue(fieldName);

                            for (let i = 0; i < formData?.length; i++) {
                              if (index === i) {
                                const effectiveDate = formData[i]["effectiveDate"];
                                if (moment(value).isBefore(moment(effectiveDate))) {
                                  return reject(new Error("Term date should be after Effective date"));
                                }
                                continue;
                              }
                            }
                            resolve(undefined);
                          });
                        }, message: "Term date should be after Effective date"
                      },
                      { validator: allowedValidator, message: "" }
                    ]}
                    dependencies={[index, 'effectiveDate']}>
                    <Calendar
                      placeholder="Enter Date"
                      selectionMode="single"
                      icon="cl_calendar_today_line"
                      iconPos="right"
                      dateFormat="mm/dd/yy"
                      // minDate={moment(form.getFieldValue([fieldName, index, 'effectiveDate'])).toDate()}
                      // disabled={!eligibility.effectiveDate}
                      id={`termDate-${index}`}
                    />
                  </FormListItem>
                </div>

                <div></div>
                {/* {JSON.stringify(isAllowed)} */}
                <div className="flex justify-content-end pt-3 !gap-3">
                  {index == 0 && providerId > 0 && isAllowed && !hideAddButton && <Button label="Add" type='button' text onClick={() => handleAddFormItem()} />}
                  {index > 0 && <Button label="Delete" text type='button' onClick={() => handleRemoveItem()} />}
                </div>
              </React.Fragment>
            })}
          </>
        }}

      </List>

    </div>
  )
}

export default EligibilityDetails
