import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import Button from "../../../controls/Button";
import { LazyTableState } from "../../../model/LazyTableState";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { ProviderAuditHistoryModel } from "../../../model/ProviderAuditHistoryModel";
import { GridModel } from "../../../model/GridModel";
import { ProviderEligibilityModel } from "../../../model/ProviderEligibilityModel";
import moment from "moment";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import ProviderEligibilityService from "../../../services/ProviderEligibilityService";
import useFormattedDate from "../../../hooks/useFormattedDate";

const EligibiltyHistory = () => {
  const [showTable, setShowTable] = useState(true);
  const { providerId } = useSelector((state: RootState) => state.provider);
  const [gridValues, setGridValues] = useState<ProviderEligibilityModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const { eligibilityGrid } = ProviderEligibilityService();

  const handleSaveClick = () => {
    setShowTable(true); // Hide form and show table
  };

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId]);

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      const eligibilityResponse: GridModel<ProviderEligibilityModel> = await eligibilityGrid(providerId, query);
      console.log("eligibilityResponse eligibilityResponse", eligibilityResponse)
      if (eligibilityResponse) {
        setGridValues(eligibilityResponse.data);
        setTotalRecords(eligibilityResponse.totalCount);
      }
    }
  };

  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            className="p-datatable-gridlines mt-4"
            showGridlines
            rows={lazyState.rows}
            dataKey="providerEligibilityID"
            emptyMessage="No records found."
            // header={header1}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            sortOrder={lazyState.sortOrder}
            onFilter={onFilter}
            value={gridValues}
            totalRecords={totalRecords}
            first={lazyState.first}
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
          >
            <Column field="effectiveDate" body={(rowData) => useFormattedDate(rowData, "effectiveDate")} header="Effective&nbsp;Date" />
            <Column field="termDate" body={(rowData) => useFormattedDate(rowData, "termDate")} header="Term&nbsp;Date" />
            <Column field="updatedBy" header="Updated&nbsp;By" />
            {/* <Column field="modifiedDate" body={modifiedDateTemplate} header="Updated&nbsp;On" /> */}
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text type='button'/>
            <Button label="Save" raised onClick={handleSaveClick} type='submit'/>
          </div>
        </div>
      )}
    </>
  );
};

export default EligibiltyHistory;
