import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { lazy, SetStateAction, SyntheticEvent, useEffect, useState } from "react";
import Button from "../../../controls/Button";
import Dropdown from "../../../controls/Dropdown";
import Calendar from "../../../controls/Calendar";
import Checkbox from "../../../controls/CheckBox";
import ProviderContractService from "../../../services/ProviderContractService";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { ProviderContractModel } from "../../../model/ProviderContractModel";
import CustomForm from "../../../controls/CustomForm";
import { useForm } from "rc-field-form";
import FormItem from "../../../controls/FormItem";
import { LazyTableState } from "../../../model/LazyTableState";
import LobService from "../../../services/LobService";
import ContractHeaderService from "../../../services/ContractHeaderService";
import { CodeType, CommonCodeFetchingType, RecordStatus } from "../../../data/constants/AppEnum";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import TimelyFilingService from "../../../services/TimelyFilingService";
import InterestQuickPayService from "../../../services/InterestQuickPayService";
import UCRFeeScheduleService from "../../../services/UCRFeeScheduleService";
import ModifierDiscountGroupService from "../../../services/ModifierDiscountGroupService";
import { ProviderContractLobModel } from "../../../model/ProviderContractLobModel";
import { ProviderContractInterestModel } from "../../../model/ProviderContractInterestModel";
import { ProviderContractTimelyFilingModel } from "../../../model/ProviderContractTimelyFilingModel";
import { GridModel } from "../../../model/GridModel";
import { LobModel } from "../../../model/LobModel";
import { useToaster } from "../../../layout/context/toastContext";
import moment from "moment";
import useFormattedDate from "../../../hooks/useFormattedDate";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import useErrorHandler from "../../../hooks/useErrorHandler";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";

const Contracts = () => {
  const { getLobKeyValue } = LobService();
  const { getContractKeyValue } = ContractHeaderService();
  const { getTimelyFilingList } = TimelyFilingService();
  const { getInterestPayList } = InterestQuickPayService();
  const { getFeeScheduleList } = UCRFeeScheduleService();
  const { getModifierDiscountList } = ModifierDiscountGroupService();

  const [lobOptions, setLobOptions] = useState(null);
  const [contractOptions, setContractOptions] = useState(null);
  const [providerContractId, setProviderContractId] = useState(0);
  const [timelyOptions, setTimelyOptions] = useState(null);
  const [interestOptions, setInterestOptions] = useState(null);
  const [modifierOptions, setModifierOptions] = useState(null);
  const [feeScheduleOptions, setFeeScheduleOptions] = useState(null);
  const [isCapitatedChecked, setIsCapitatedChecked] = useState(false); // Checkbox state
  const [isExcludeChecked, setIsExcludeChecked] = useState(false); // Checkbox state
  const [showTable, setShowTable] = useState(true);
  const [totalRecords, setTotalRecords] = useState(0);
  const [selectedContract, setSelectedContract] = useState<ProviderContractModel | null>(null);
  const [gridValues, setGridValues] = useState<ProviderContractModel[]>([]);
  const { providerId, providerData } = useSelector((state: RootState) => state.provider);
  const { getByProviderId, create, update, getById, deleteContract } = ProviderContractService();
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const { showToast } = useToaster();
  const [showConfirm, setShowConfirm] = useState<boolean>(false);
  const [minDate, setMinDate] = useState<Date | null>(null);

  const handleEffectiveDateChange = (event: SetStateAction<Date>) => {
    setEffectiveDate(event);
  };

  useEffect(() => {
    if (providerData) {
      const eligibilities = providerData.providerEligibility;
      const providerEligibility = eligibilities?.[0];
      const { effectiveDate } = providerEligibility;
      setMinDate(() => {
        return effectiveDate ? moment(effectiveDate).toDate() : null
      })
    }
  }, [providerData])

  const providerStatusList = useCommonCodeSubCategory(CodeType.ProviderStatus, CommonCodeFetchingType.Default);
  const networkDataList = useCommonCodeSubCategory(CodeType.Network, CommonCodeFetchingType.Default);

  const [form] = useForm();

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined,
  });

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event["first"] = 0;
    setLazyState(event);
  };

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedContract) {
      try {
        const deleteResponse = await deleteContract(selectedContract.providerContractID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "Contract deleted successfully" });
          setProviderContractId(0);
          setShowTable(true);
          form.resetFields();
          setSelectedContract(null);
          loadLazyData();
          setEffectiveDate(null);
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setProviderContractId(0);
    setSelectedContract(null);
  }

  const handleCancel = () => {
    setShowTable(true);
    setLazyState((prevState) => {
      return { ...prevState, first: 0 };
    });
    setEffectiveDate(null);
    setProviderContractId(0);
    setSelectedContract(null);
    form.resetFields();
    setEffectiveDate(null);
  };

  useEffect(() => {
    if (providerId > 0) {
      loadLazyData();
    }
  }, [lazyState, providerId]);

  useEffect(() => {
    let lobDataList = getLobKeyValue();
    let contractHeaderList = getContractKeyValue();
    let timelyFilingList = getTimelyFilingList();
    let interestQuickPayList = getInterestPayList();
    let feeScheduleList = getFeeScheduleList();
    let modifierDiscountList = getModifierDiscountList();

    Promise.all([lobDataList, contractHeaderList, timelyFilingList, interestQuickPayList, feeScheduleList, modifierDiscountList]).then((result) => {
      setLobOptions(result[0]);
      setContractOptions(result[1]);
      setTimelyOptions(result[2]);
      setInterestOptions(result[3]);
      setFeeScheduleOptions(result[4]);
      setModifierOptions(result[5]);
    });
  }, []);

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      const providerContractResponse: GridModel<ProviderContractModel> = await getByProviderId(providerId, query);
      if (providerContractResponse) {
        setGridValues(providerContractResponse.data);
        setTotalRecords(providerContractResponse.totalCount);
      }
    }
  };

  const handleCheckboxChange = () => {
    setIsCapitatedChecked((prev) => !prev); // Toggle the checked state
  };
  const handleCheck = () => {
    setIsExcludeChecked((prev) => !prev); // Toggle the checked state
  };
  const handleAddClick = () => {
    setShowTable(false); // Hide table and show form
  };

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedContract(e.value);
    } else {
      setSelectedContract(null);
    }
  };

  const effectiveDateTemplate = (data) => {
    return useFormattedDate(data, "effectiveDate")
  }

  const termDateTemplate = (data) => {
    return useFormattedDate(data, "termDate")
  }

  const handleSave = async () => {
    const formValues = { ...form.getFieldsValue(true), providerId };
    const providerContract = await dataMapper(formValues);
    try {
      const providerContractResponse = providerContractId > 0 ? await update(providerContract) : await create(providerContract)
      if (providerContractResponse) {
        showToast({ severity: 'success', summary: 'Success', detail: "Contract saved successfully" });
      }
      setProviderContractId(0);
      setShowTable(true);
      form.resetFields();
      setLazyState((prevState) => {
        return { ...prevState, first: 0 };
      });
      setEffectiveDate(null);
    } catch (error) {
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }

  };

  const handleDelete = () => {
    if (selectedContract) {
      setShowConfirm(true);
    }
  }

  const handleEdit = async () => {

    const contracts = await getById(selectedContract.providerContractID);

    if (contracts.length > 0) {
      const contractDetails = contracts[0];
      const formData = {
        lobIds: contractDetails.lobIds.map((lob: LobModel) => lob.lobID),
        contractHeaderId: contractDetails.contractHeaderID,
        providerStatusId: contractDetails.providerStatusID,
        timelyFilingIds: contractDetails.providerContractTimelyFiling.map((a) => a.timelyFilingID),
        interestQuickPayIds: contractDetails.providerContractInterest.map((a) => a.interestQuickPayID),
        modifierDiscountGroupId: contractDetails?.modifierDiscountGroupID,
        feeScheduleHeaderId: contractDetails?.feeScheduleHeaderID,
        networkId: contractDetails?.networkID,
        isExcludeFromSequestration: contractDetails.isExcludeFromSequestration,
        isCapitated: contractDetails.isCapitated,
        effectiveDate: new Date(contractDetails.effectiveDate),
        termDate: contractDetails?.termDate ? moment(contractDetails.termDate).toDate() : null,
        providerContractId: contractDetails.providerContractID,
      };
      setProviderContractId(formData.providerContractId);
      setIsCapitatedChecked(formData.isCapitated);
      setIsExcludeChecked(formData.isExcludeFromSequestration);

      const contractValue = { ...formData, effectiveDate: moment(formData.effectiveDate).toDate(), termDate: formData.termDate ? moment(formData.termDate).toDate() : null }

      form.setFieldsValue({ ...contractValue });
      setEffectiveDate(moment(formData.effectiveDate).toDate());
      setShowTable(false);
    }
  };

  const dataMapper = async (formValues: any) => {
    const providerContractLob: ProviderContractLobModel[] = formValues.lobIds.map((lobId: number) => {
      return {
        recordStatus: RecordStatus.Active,
        recordStatusChangeComment: RecordStatus[RecordStatus.Active],
        lobId,
        providerContractId: providerContractId ?? 0,
        createdBy: "",
      };
    });
    const providerContractTimelyFiling: ProviderContractTimelyFilingModel[] = formValues.timelyFilingIds.map((timelyFilingId: number) => {
      return {
        recordStatus: RecordStatus.Active,
        recordStatusChangeComment: RecordStatus[RecordStatus.Active],
        timelyFilingId,
        providerContractId: providerContractId ?? 0,
        createdBy: "",
      };
    });
    const providerContractInterest: ProviderContractInterestModel = formValues.interestQuickPayIds.map((interestQuickPayId: number) => {
      return {
        recordStatus: RecordStatus.Active,
        recordStatusChangeComment: RecordStatus[RecordStatus.Active],
        interestQuickPayId,
        providerContractId: providerContractId ?? 0,
        createdBy: "",
      };
    });
    const providerContract: ProviderContractModel = await {
      ...formValues,
      effectiveDate: moment(formValues.effectiveDate).format("YYYY-MM-DD"),
      termDate: formValues?.termDate ? moment(formValues.termDate).format("YYYY-MM-DD") : null,
      providerContractLob,
      providerContractTimelyFiling,
      providerContractInterest,
      providerContractId,
    };
    providerContract.lobIds = [];
    providerContract.interestQuickPayIds = [];
    providerContract.timelyFilingIds = [];
    return providerContract;
  };

  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedContract && <Button outlined label="Edit" onClick={handleEdit} />}
          {selectedContract && <Button outlined label="Delete" onClick={handleDelete} />}
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );

  return (
    <>
      {showTable ? (
        <>
          <DataTable
           paginator
           className="p-datatable-gridlines mt-4"
           showGridlines
           rows={10}
           dataKey="providerLocationId"
           responsiveLayout="scroll"
           emptyMessage="No records found."
           header={header1}
           selectionMode="single"
           paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
           currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
           lazy onPage={onPage}
           onSort={onSort}
           sortField={lazyState.sortField}
           sortOrder={lazyState.sortOrder}
           onFilter={onFilter}
           value={gridValues}
           onSelectionChange={(e) => handleSelection(e)}
           totalRecords={totalRecords}
           first={lazyState.first}
          >
            <Column field="lobNames" header="Line&nbsp;Of&nbsp;Business" sortable />
            <Column field="contractHeaderName" header="Contract" sortable />
            <Column field="providerStatusName" header="Provider&nbsp;Status" sortable />
            {/* <Column field="isCapitated" header="Capitated" sortable /> */}
            <Column field="timelyFilingNames" header="Timely&nbsp;Filing" sortable/>
            {/* <Column field="interestQuickPayNames" header="Interest" sortable /> */}
            <Column field="modifierDiscountGroupName" header="Modifier&nbsp;Discount" sortable />
            <Column field="feeScheduleHeaderCode" header="Default&nbsp;Fee&nbsp;Schedule" sortable />
            <Column field="networkName" header="Network" sortable />
            {/* <Column field="isExcludeFromSequestration" header="Exclude&nbsp;From&nbsp;Seguestration" sortable /> */}
            <Column field="effectiveDate" body={effectiveDateTemplate} header="Effective&nbsp;Date" sortable />
            <Column field="termDate" body={termDateTemplate} header="Term&nbsp;Date" sortable />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="lobIds" label="Line Of Business" rules={[{ required: true }]}>
                <Dropdown
                  id="lob"
                  showHeader
                  multiple
                  options={lobOptions}
                  optionLabel="value"
                  optionValue="key"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="contractHeaderId" label="Contract" rules={[{ required: true }]}>
                <Dropdown
                  id="contract"
                  options={contractOptions}
                  optionLabel="value"
                  optionValue="key"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="providerStatusId" label="Provider Status" rules={[{ required: true }]}>
                <Dropdown
                  id="status"
                  options={providerStatusList}
                  optionLabel="value"
                  optionValue="key"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="timelyFilingIds" label="Timely Filling" rules={[{ required: true }]}>
                <Dropdown
                  id="timely"
                  showHeader
                  multiple
                  options={timelyOptions}
                  optionLabel="description"
                  optionValue="timelyFilingID"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="interestQuickPayIds" label="Interest" rules={[{ required: true }]}>
                <Dropdown
                  id="interest"
                  multiple
                  showHeader
                  options={interestOptions}
                  optionLabel="description"
                  optionValue="interestQuickPayID"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="modifierDiscountGroupId" label="Modifier Discount">
                <Dropdown
                  id="modifier"
                  options={modifierOptions}
                  optionLabel="value"
                  optionValue="key"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="feeScheduleHeaderId" label="Default Fee Schedule">
                <Dropdown
                  id="schedule"
                  options={feeScheduleOptions}
                  optionLabel="code"
                  optionValue="feeScheduleHeaderID"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="networkId" label="Network">
                <Dropdown
                  id="network"
                  options={networkDataList}
                  optionLabel="value"
                  optionValue="key"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="effectiveDate" label="Effective Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={minDate}
                  onChange={(event) => handleEffectiveDateChange(event)}
                />
              </FormItem>

              <FormItem name="termDate" label="Term Date">
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  disabled={!effectiveDate}
                  minDate={effectiveDate ? effectiveDate : minDate}
                />
              </FormItem>

              <div className="col flex flex-row gap-3 flex-wrap">
                <FormItem label="" name="isCapitated">
                  <Checkbox
                    inputId="isCapitated"
                    label={"Capitated"}
                    checked={isCapitatedChecked}
                    onChange={handleCheckboxChange} // Handle checkbox change
                  />
                </FormItem>
                <FormItem label="" name="isExcludeFromSequestration">
                  <Checkbox
                    inputId="isExcludeFromSequestration"
                    label={"Exclude From Sequestration"}
                    checked={isExcludeChecked}
                    onChange={handleCheck} // Handle checkbox change
                  />
                </FormItem>
              </div>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={handleCancel} type="button" />
              <Button label="Save" raised type="submit" />
            </div>
          </CustomForm>
        </div>
      )}

      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </>
  );
};

export default Contracts;
