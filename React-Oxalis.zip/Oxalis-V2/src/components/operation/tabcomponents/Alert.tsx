import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import Button from "../../../controls/Button";
import Dropdown from "../../../controls/Dropdown";
import Calendar from "../../../controls/Calendar";
import ModuleService from "../../../services/ModuleService";
import AlertCodeService from "../../../services/AlertCodeService";
import { KeyValueModel } from "../../../model/KeyValueModel";
import { AlertCodeViewModel, AlertModuleViewModel } from "../../../model/AlertCodeViewModel";
import AlertService from "../../../services/AlertService";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { useForm } from "rc-field-form";
import { LazyTableState } from "../../../model/LazyTableState";
import { GridModel } from "../../../model/GridModel";
import moment from "moment";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import { Modules } from "../../../data/constants/AppEnum";
import { useToaster } from "../../../layout/context/toastContext";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import useErrorHandler from "../../../hooks/useErrorHandler";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";

const Alert = () => {
  const [showTable, setShowTable] = useState(true);
  const { moduleKeyValue } = ModuleService();
  const { getActiveAlertCodes } = AlertCodeService();
  const [moduleOptions, setModuleOptions] = useState<KeyValueModel[]>([]);
  const [alertCodeOptions, setAlertCodeOptions] = useState<KeyValueModel[]>([]);
  const [alertCodeList, setAlertCodeList] = useState<AlertCodeViewModel[]>([]);
  const { getByAlertCodeTye, create, update, deleteAlert } = AlertService();
  const [selectedAlert, setSelectedAlert] = useState<AlertModuleViewModel>();
  const [selectedAlertId, setSelectedAlertId] = useState<number>(0);
  const { providerId, providerData } = useSelector((state: RootState) => state.provider);
  const [gridValues, setGridValues] = useState<AlertModuleViewModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [form] = useForm();
  const { showToast } = useToaster();
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const [showConfirm, setShowConfirm] = useState<boolean>(false);
  const [minDate, setMinDate] = useState<Date | null>(null);

  useEffect(() => {
    if (providerData) {
      const eligibilities = providerData.providerEligibility;
      const providerEligibility = eligibilities?.[0];
      const { effectiveDate } = providerEligibility;
      setMinDate(() => {
        return effectiveDate ? moment(effectiveDate).toDate() : null
      })
    }
  }, [providerData])


  const handleAddClick = () => {
    setShowTable(false); // Hide table and show form
  };

  useEffect(() => {
    const moduleResponse = moduleKeyValue();
    const alertCodeResponse = getActiveAlertCodes();

    Promise.all([moduleResponse, alertCodeResponse]).then(result => {
      const module = result[0];
      const alertCode = result[1];

      setModuleOptions(module);
      setAlertCodeList(alertCode)
    })
  }, []);

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedAlert) {
      try {
        const deleteResponse = await deleteAlert(selectedAlert.alertModuleID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "Alert deleted successfully" });
          setSelectedAlertId(0);
          setShowTable(true);
          form.resetFields();
          loadLazyData();
          setSelectedAlert(null);
          setEffectiveDate(null);
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setSelectedAlert(null);
    setSelectedAlertId(0);
  }

  const handleDelete = () => {
    if (selectedAlert) {
      setShowConfirm(true);
    }
  }

  const handleEffectiveDateChange = (event: Date) => {
    console.log("event ", event);
    setEffectiveDate(event);
  };

  useEffect(() => {
    if (alertCodeList.length) {
      const alertCodeKeyVal: KeyValueModel[] = alertCodeList.map((item: AlertCodeViewModel) => {
        return { key: item.name, value: item.alertCodeID };
      })
      setAlertCodeOptions(alertCodeKeyVal)
    }
  }, [alertCodeList]);

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      const alertResponse: GridModel<AlertModuleViewModel> = await getByAlertCodeTye(providerId, query);
      if (alertResponse) {
        setGridValues(alertResponse.data);
        setTotalRecords(alertResponse.totalCount);
      }
    }
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId]);

  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true)
    console.log(formValues)
    const alert = await dataMapper(formValues);
    try {
      const alertResponse = selectedAlertId > 0 ? await update(alert) : await create(alert);
      if (alertResponse) {
        showToast({ severity: 'success', summary: 'Success', detail: "Alert data saved successfully" });
        setSelectedAlertId(0);
        setShowTable(true);
        setLazyState((prevState) => {
          return { ...prevState, first: 0 }
        })
        form.resetFields();
        setSelectedAlert(null);
        setSelectedAlertId(0);
        loadLazyData();
        setEffectiveDate(null);
      }
    }
    catch (error) {
      console.log(error)
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
  };

  const termDateFormatTemplate = (value) => {
    const termDate = value.termDate;
    if (termDate) {
      return moment(termDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const moduleNameTemplate = (value) => {
    if (value && moduleOptions) {
      var obj = moduleOptions.find(x => x.key == value.destinationModuleID);
      if (!!(obj)) {
        return obj.value;
      }
      else {
        return "N/A";
      }
    }
  }

  const effectiveDateFormatTemplate = (value) => {
    const effectiveDate = value.effectiveDate;
    if (effectiveDate) {
      return moment(effectiveDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const handleEdit = () => {
    if (selectedAlert) {
      console.log(selectedAlert);

      const formData = {
        ...selectedAlert,
        effectiveDate: moment(selectedAlert.effectiveDate).toDate(),
        termDate: selectedAlert.termDate ? moment(selectedAlert.termDate).toDate() : null,
      }
      setEffectiveDate(formData.effectiveDate)
      setSelectedAlertId(selectedAlert.alertCodeID);

      form.setFieldsValue(formData);
      setShowTable(false);
    }
  }

  const dataMapper = (formValue) => {

    const referenceModel = {
      alertDataId: providerId,
      ...formValue,
      effectiveDate: moment(formValue.effectiveDate).format("YYYY-MM-DD"),
      termDate: formValue.termDate ? moment(formValue.termDate).format("YYYY-MM-DD") : null,
      sourceModuleId: Modules.Provider
    }
    return referenceModel;
  }

  const handleCancel = () => {
    setShowTable(true);
    form.resetFields();
    setSelectedAlert(null);
    setSelectedAlertId(0);
    loadLazyData();
    setEffectiveDate(null);
  }

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedAlert(e.value);
    } else {
      setSelectedAlert(null);
    }
  }

  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedAlert && <Button outlined label="Edit" onClick={handleEdit} />}
          {selectedAlert && <Button outlined label="Delete" onClick={handleDelete} />}
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            rowsPerPageOptions={paginatorConstants.pageOptions}
            className="p-datatable-gridlines"
            showGridlines
            rows={lazyState.rows}
            tableStyle={{ minWidth: '50rem' }}
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
            dataKey="alertModuleID"
            emptyMessage={paginatorConstants.emptyMessage}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortOrder={lazyState.sortOrder}
            sortField={lazyState.sortField}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
            header={header1}
          >
            <Column
              field="destinationModuleID"
              header="Module"
              body={moduleNameTemplate}
              sortable
            />
            <Column field="alertCodeName" header="Alert Code" sortable />
            <Column field="effectiveDate" body={effectiveDateFormatTemplate} header="Effective&nbsp;Date" sortable />
            <Column field="termDate" body={termDateFormatTemplate} header="Term&nbsp;Date" sortable />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="destinationModuleID" label="Module Type" rules={[
                { required: true }
              ]}>
                <Dropdown
                  id="moduletype"
                  options={moduleOptions}
                  optionLabel="value"
                  optionValue="key"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="alertCodeID" label="Provider" rules={[
                { required: true }
              ]}>
                <Dropdown
                  id="alerttype"
                  options={alertCodeOptions}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="effectiveDate" label="Effective Date" rules={[
                { required: true }
              ]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={minDate}
                  onChange={(event) => handleEffectiveDateChange(event as Date)}
                />
              </FormItem>

              <FormItem name="termDate" label="Term Date" >
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={effectiveDate ? effectiveDate : minDate}
                  disabled={!effectiveDate}
                />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={handleCancel} type="button" />
              <Button label="Save" raised type="submit" />
            </div>
          </CustomForm>
        </div>
      )}

      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </>
  );
};

export default Alert;
