import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import Calendar from "../../../controls/Calendar";
import Button from "../../../controls/Button";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { useForm } from "rc-field-form";
import { LazyTableState } from "../../../model/LazyTableState";
import { GridModel } from "../../../model/GridModel";
import moment from "moment";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import ProviderNotesService from "../../../services/ProviderNotesService";
import { ProviderNoteModel } from "../../../model/ProviderNoteModel";
import { useToaster } from "../../../layout/context/toastContext";
import useFormattedDate from "../../../hooks/useFormattedDate";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import useErrorHandler from "../../../hooks/useErrorHandler";
import FormListItem from "../../../controls/FormListItem";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";

const Notes = () => {
  const [showTable, setShowTable] = useState<boolean>(true);
  const [selectedNotes, setSelectedNotes] = useState<ProviderNoteModel>();
  const { create, update, getByProviderID, deleteNotes } = ProviderNotesService();

  const [selectedNotesId, setSelectedNotesId] = useState<number>(0);
  const { providerId, providerData } = useSelector((state: RootState) => state.provider);
  const [gridValues, setGridValues] = useState<ProviderNoteModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [form] = useForm();
  const { showToast } = useToaster();
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const [showConfirm, setShowConfirm] = useState<boolean>(false);
  const [minDate, setMinDate] = useState<Date | null>(null);

  const handleAddClick = () => {
    setShowTable(false);
    form.setFieldsValue({ noteDate: new Date() })
  };

  useEffect(() => {
    if (providerData) {
      const eligibilities = providerData.providerEligibility;
      const providerEligibility = eligibilities?.[0];
      const { effectiveDate } = providerEligibility;
      setMinDate(() => {
        return effectiveDate ? moment(effectiveDate).toDate() : null
      })
    }
  }, [providerData])

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedNotes) {
      try {
        const deleteResponse = await deleteNotes(selectedNotes.providerNoteID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "Contract deleted successfully" });
          setSelectedNotesId(0);
          setSelectedNotes(null);
          setShowTable(true);
          form.resetFields();
          loadLazyData();
          setEffectiveDate(null);
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setSelectedNotesId(0);
    setSelectedNotes(null);
  }

  const handleDelete = () => {
    if (selectedNotes) {
      setShowConfirm(true);
    }
  }

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId]);

  const handleEffectiveDateChange = (event: Date) => {
    console.log("event ", event);
    setEffectiveDate(event);
  };

  const effectiveDateTemplate = (data) => {
    return useFormattedDate(data, "effectiveDate")
  }

  const termDateTemplate = (data) => {
    return useFormattedDate(data, "termDate")
  }

  const noteDateTemplate = (data) => {
    return useFormattedDate(data, "noteDate")
  }

  const longDescLengthValidator = async (rule, value) => {
    if (value?.length > 400) {
      return Promise.reject("Maximum 400 characters allowed");
    }
    return Promise.resolve(null);
  }

  const shortDescLengthValidator = async (rule, value) => {
    if (value?.length > 80) {
      return Promise.reject("Maximum 80 characters allowed");
    }
    return Promise.resolve(null);
  }

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      const providerNoteResponse: GridModel<ProviderNoteModel> = await getByProviderID(providerId, query);
      if (providerNoteResponse) {
        setGridValues(providerNoteResponse.data);
        setTotalRecords(providerNoteResponse.totalCount);
      }
    }
  };

  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true)

    console.log("formValues formValues", formValues)
    const providerNotes = await dataMapper(formValues);
    console.log(providerNotes)
    try {
      const notesResponse = selectedNotesId > 0 ? await update(providerNotes) : await create(providerNotes);
      setSelectedNotesId(0);
      if (notesResponse) {
        showToast({ severity: 'success', summary: 'Success', detail: "Notes saved successfully" });
        setShowTable(true);
        form.resetFields();
        setSelectedNotes(null);
        setSelectedNotesId(0);
        loadLazyData();
        setEffectiveDate(null);
      }
    }
    catch (error) {
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
  };

  const handleEdit = () => {
    if (selectedNotes) {

      console.log(selectedNotes)
      const formData = {
        shortDescription: selectedNotes.shortDescription,
        longDescription: selectedNotes.longDescription,
        providerId,
        noteDate: selectedNotes.noteDate ? moment(selectedNotes.noteDate).toDate() : null,
        effectiveDate: selectedNotes.effectiveDate ? moment(selectedNotes.effectiveDate).toDate() : null,
        termDate: selectedNotes.termDate ? moment(selectedNotes.termDate).toDate() : null,
        providerNoteId: selectedNotesId ?? 0
      }
      setSelectedNotesId(selectedNotes.providerNoteID);
      setEffectiveDate(formData.effectiveDate);
      form.setFieldsValue(formData);
      setShowTable(false);
    }
  }

  const dataMapper = (formValue) => {

    const referenceModel = {
      shortDescription: formValue.shortDescription,
      longDescription: formValue.longDescription,
      providerId,
      noteDate: formValue.noteDate ? moment(formValue.noteDate).format("YYYY-MM-DD") : null,
      effectiveDate: moment(formValue.effectiveDate).format("YYYY-MM-DD"),
      termDate: formValue.termDate ? moment(formValue.termDate).format("YYYY-MM-DD") : null,
      providerNoteId: selectedNotesId ?? 0
    }

    return referenceModel;
  }

  const handleCancel = () => {
    setShowTable(true);
    setLazyState((prevState) => {
      return { ...prevState, first: 0 }
    })

    form.resetFields();
    setSelectedNotes(null);
    setSelectedNotesId(0);
    loadLazyData();
    setEffectiveDate(null);
  }

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedNotes(e.value);
    } else {
      setSelectedNotes(null);
    }
  }

  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedNotes && <Button outlined label="Edit" onClick={handleEdit} />}
          {selectedNotes && <Button outlined label="Delete" onClick={handleDelete} />}
          <Button outlined label="Add" onClick={handleAddClick} />
        </>

      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            className="p-datatable-gridlines mt-4"
            showGridlines
            rows={10}
            dataKey="providerSpecialtyID"
            responsiveLayout="scroll"
            emptyMessage="No records found."
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
            header={header1}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            sortOrder={lazyState.sortOrder}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >
            <Column field="shortDescription" header="Short&nbsp;Description" sortable />
            <Column field="longDescription" header="Long&nbsp;Description" sortable />
            <Column field="noteDate" body={noteDateTemplate} header="Add&nbsp;Date" sortable />
            <Column field="effectiveDate" body={effectiveDateTemplate} header="Effective&nbsp;Date" sortable />
            <Column field="termDate" body={termDateTemplate} header="Term&nbsp;Date" sortable />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormListItem name="shortDescription" label="Short Description" rules={[
                { required: true, message: "Short Description is required" },
                { validator: shortDescLengthValidator, message: "Maximum 80 characters allowed" }
              ]}>
                <InputText type="text" placeholder="Enter here" />
              </FormListItem>

              <FormListItem name="longDescription" label="Long Description" rules={[
                { required: true, message: "Long Description is required" },
                { validator: longDescLengthValidator, message: "Maximum 400 characters allowed" }
              ]}>
                <InputText type="text" placeholder="Enter here" />
              </FormListItem>

              <FormItem name="noteDate" label="Add Date" rules={[
                { required: true }
              ]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  disabled
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date" rules={[
                { required: true }
              ]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={minDate}
                  onChange={(event) => handleEffectiveDateChange(event as Date)}
                />
              </FormItem>

              <FormItem name="termDate" label="Term Date" >
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={effectiveDate ? effectiveDate : minDate}
                  disabled={!effectiveDate}
                />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={handleCancel} type='button' />
              <Button label="Save" raised type='submit' />
            </div>
          </CustomForm>
        </div>
      )}

      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </>
  );
};

export default Notes;
