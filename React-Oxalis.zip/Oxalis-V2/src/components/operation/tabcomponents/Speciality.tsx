import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { lazy, useEffect, useState } from "react";
import Dropdown from "../../../controls/Dropdown";
import Calendar from "../../../controls/Calendar";
import Button from "../../../controls/Button";
import CustomForm from "../../../controls/CustomForm";
import { useForm } from "rc-field-form";
import { LazyTableState } from "../../../model/LazyTableState";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import FormItem from "../../../controls/FormItem";
import SpecialtyService from "../../../services/SpecialtyService";
import { KeyValueModel } from "../../../model/KeyValueModel";
import ProviderSpecialtyService from "../../../services/ProviderSpecialtyService";
import { GridModel } from "../../../model/GridModel";
import { ProviderSpecialtyFormModel, ProviderSpecialtyModel } from "../../../model/ProviderSpecialtyModel";
import moment from "moment";
import { useToaster } from "../../../layout/context/toastContext";
import useFormattedDate from "../../../hooks/useFormattedDate";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import useErrorHandler from "../../../hooks/useErrorHandler";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";

const Specialty = () => {
  const [providerSpecialtyId, setProviderSpecialtyId] = useState<number>(0);
  const [selectedSpecialty, setSelectedSpecialty] = useState<ProviderSpecialtyModel>(null);
  const [showTable, setShowTable] = useState(true);
  const { providerId, providerData } = useSelector((state: RootState) => state.provider);
  const [specialtyOptions, setSpecialtyOptions] = useState<KeyValueModel[]>([]);
  const [gridValues, setGridValues] = useState<ProviderSpecialtyModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const { getSpecialtyKeyValues } = SpecialtyService()
  const { create, update, getByProvider, deleteProviderSpecialty } = ProviderSpecialtyService();
  const { showToast } = useToaster();
  const primarySpecialtyList: KeyValueModel[] = [
    { key: "Primary", value: 70 },
    { key: "Secondary", value: 71 },
    { key: "Tertiary", value: 72 },
    // { key: "OB/Gyn", value: 73 }
  ];
  const [showConfirm, setShowConfirm] = useState<boolean>(false);
  const [minDate, setMinDate] = useState<Date | null>(null);


  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const [form] = useForm();

  const handleAddClick = () => {
    setShowTable(false); // Hide table and show form
  };

  useEffect(() => {
    if (providerData) {
      const eligibilities = providerData.providerEligibility;
      const providerEligibility = eligibilities?.[0];
      const { effectiveDate } = providerEligibility;
      setMinDate(() => {
        return effectiveDate ? moment(effectiveDate).toDate() : null
      })
    }
  }, [providerData])

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      const providerSpecialtyResponse: GridModel<ProviderSpecialtyModel> = await getByProvider(providerId, query);
      console.log("providerSpecialtyResponse", providerSpecialtyResponse)
      if (providerSpecialtyResponse) {
        setGridValues(providerSpecialtyResponse.data);
        setTotalRecords(providerSpecialtyResponse.totalCount);
      }
    }
  };

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedSpecialty) {
      try {
        const deleteResponse = await deleteProviderSpecialty(selectedSpecialty.providerSpecialtyID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "Specialty deleted successfully" });
          setProviderSpecialtyId(0);
          setSelectedSpecialty(null);
          setShowTable(true);
          form.resetFields();
          loadLazyData()
          setEffectiveDate(null);
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setProviderSpecialtyId(0);
    setSelectedSpecialty(null);
  }

  const handleDelete = () => {
    if (selectedSpecialty) {
      setShowConfirm(true);
    }
  }

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId]);

  const dataMapper = (formValue) => {
    const providerSpecialtyModel: ProviderSpecialtyModel = {
      specialtyID: formValue.specialtyId,
      providerID: providerId,
      termDate: formValue.termDate ? moment(formValue.termDate).format("YYYY-MM-DD") : null,
      isPrimarySpecialty: (formValue.isPrimarySpecialty == null || formValue.isPrimarySpecialty == undefined) ? 0 : formValue.isPrimarySpecialty,
      effectiveDate: moment(formValue.effectiveDate).format("YYYY-MM-DD"),
      providerSpecialtyID: formValue.providerSpecialtyId ?? 0,
    }
    return providerSpecialtyModel;
  }

  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true)
    console.log(formValues)
    const providerSpecialty: ProviderSpecialtyModel = await dataMapper(formValues);
    try {
      const providerSpecialtyResponse = providerSpecialtyId > 0 ? await update(providerSpecialty) : await create(providerSpecialty);
      if (providerSpecialtyResponse) {
        showToast({ severity: 'success', summary: 'Success', detail: "Specialty saved successfully" });
        setProviderSpecialtyId(0);
        setShowTable(true);
        setLazyState((prevState) => {
          return { ...prevState, first: 0 }
        })
        form.resetFields();
      }
    }
    catch (error) {
      if (error instanceof Error) {
        console.log(" error error error error error")
        const errorMessage = useErrorHandler(error);
        console.log("errorMessage errorMessage", errorMessage)
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
  };

  const handleEdit = () => {
    if (selectedSpecialty) {
      console.log(selectedSpecialty);

      const formData: ProviderSpecialtyFormModel = {
        specialtyId: selectedSpecialty.specialtyID,
        effectiveDate: new Date(selectedSpecialty.effectiveDate),
        termDate: selectedSpecialty.termDate ? new Date(selectedSpecialty.termDate) : null,
        isPrimarySpecialty: selectedSpecialty.isPrimarySpecialty,
        providerSpecialtyId: selectedSpecialty.providerSpecialtyID,
        providerId: selectedSpecialty.providerID
      }
      setProviderSpecialtyId(selectedSpecialty.providerSpecialtyID);
      console.log("formData formData", formData)

      const specialtyValue = { ...formData, effectiveDate: moment(formData.effectiveDate).toDate(), termDate: formData.termDate ? moment(formData.termDate).toDate() : null }
      setEffectiveDate(specialtyValue.effectiveDate);
      form.setFieldsValue({ ...specialtyValue });
      setShowTable(false);
    }
  }

  const handleEffectiveDateChange = (event: Date) => {
    console.log("event ", event);
    setEffectiveDate(event);
  };

  const handleCancel = () => {
    setShowTable(true);
    form.resetFields();
    setSelectedSpecialty(null);
    setProviderSpecialtyId(0);
    loadLazyData();
    setEffectiveDate(null);
  }

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedSpecialty(e.value);
    } else {
      setSelectedSpecialty(null);
    }
  }

  const specialtyKeyVals = async () => {
    const specialtyKeyValueResponse = await getSpecialtyKeyValues()
    setSpecialtyOptions(specialtyKeyValueResponse);
  }

  useEffect(() => {
    specialtyKeyVals();
  }, [])

  const primaryTemplate = (value: ProviderSpecialtyModel) => {
    console.log("value", value)
    console.log("primarySpecialtyList", primarySpecialtyList)
    if (value.isPrimarySpecialty) {
      const isPrimary = primarySpecialtyList.find((isPrimary) => isPrimary.value === value.isPrimarySpecialty).key;
      return isPrimary;
    }

    return "N/A";

  }

  const effectiveDateTemplate = (data) => {
    return useFormattedDate(data, "effectiveDate")
  }

  const termDateTemplate = (data) => {
    return useFormattedDate(data, "termDate")
  }

  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedSpecialty && <Button outlined label="Edit" onClick={handleEdit} />}
          {selectedSpecialty && <Button outlined label="Delete" onClick={handleDelete} />}
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            className="p-datatable-gridlines mt-4"
            showGridlines
            rows={10}
            dataKey="providerSpecialtyID"
            responsiveLayout="scroll"
            emptyMessage="No records found."
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
            header={header1}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            sortOrder={lazyState.sortOrder}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >
            <Column field="specialtyName" header="Specialty&nbsp;Name" sortable />
            <Column field="isPrimarySpecialty" body={primaryTemplate} header="Is&nbsp;Primary" sortable />
            <Column field="effectiveDate" header="Effective&nbsp;Date" sortable body={effectiveDateTemplate} />
            <Column field="termDate" header="Term&nbsp;Date" sortable body={termDateTemplate} />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">

              <FormItem name="specialtyId" label="Specialty" rules={[
                { required: true }
              ]}>
                <Dropdown
                  id="specialty"
                  optionLabel="value"
                  optionValue="key"
                  options={specialtyOptions}
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="effectiveDate" label="Effective Date" rules={[
                { required: true }
              ]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={minDate}
                  onChange={(event) => handleEffectiveDateChange(event as Date)}
                />
              </FormItem>

              <FormItem name="termDate" label="Term Date">
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={effectiveDate ? effectiveDate : minDate}
                  disabled={!effectiveDate}
                />
              </FormItem>

              <FormItem name="isPrimarySpecialty" label="Is PrimarySpecialty">
                <Dropdown
                  id="primarySpecialty"
                  options={primarySpecialtyList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={handleCancel} type='button' />
              <Button label="Save" raised type='submit' />
            </div>
          </CustomForm>
        </div>
      )}

      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </>
  );
};

export default Specialty;
