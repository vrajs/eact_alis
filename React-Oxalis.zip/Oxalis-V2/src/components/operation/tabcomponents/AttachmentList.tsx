import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import Button from "../../../controls/Button";
import Calendar from "../../../controls/Calendar";
import ModuleService from "../../../services/ModuleService";
import AlertCodeService from "../../../services/AlertCodeService";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { useForm } from "rc-field-form";
import { LazyTableState } from "../../../model/LazyTableState";
import moment from "moment";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import { useToaster } from "../../../layout/context/toastContext";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import { ProviderAttachmentModel } from "../../../model/ProviderAttachmentModel";
import ProviderAttachmentService from "../../../services/ProviderAttachmentService";
import InputText from "../../../controls/InputText";
import { FileUpload } from "primereact/fileupload";

const AttachmentList = () => {
  const [showTable, setShowTable] = useState(true);
  const [gridValues, setGridValues] = useState<ProviderAttachmentModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const { providerId } = useSelector((state: RootState) => state.provider);
  const [form] = useForm<ProviderAttachmentModel>();
  const { showToast } = useToaster();
  const { create } = ProviderAttachmentService();
  const [formData, setFormData] = useState<FormData>();

  const handleAddClick = () => {
    setShowTable(false); // Hide table and show form
  };

  const uploadFile = (event) => {
    console.log(event);
  }

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  useEffect(() => {
    if (providerId > 0) {
      loadLazyData();
    }
  }, [lazyState, providerId]);

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      // const attachmentResponse: GridModel<AlertModuleViewModel> = await getByAlertCodeTye(providerId, query);
      // if (attachmentResponse) {
      //   setGridValues(attachmentResponse.data);
      //   setTotalRecords(attachmentResponse.totalCount);
      // }
    }
  };

  const dataMapping = () => {
    const formValue = form.getFieldsValue(true);

    return null;
  }

  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true)
    console.log(formValues)
    // try {
    //   const alertResponse = await create();
    //   if (alertResponse) {
    //     showToast({ severity: 'success', summary: 'Success', detail: "Attachment saved successfully" });
    //     setShowTable(true);
    //     setLazyState((prevState) => {
    //       return { ...prevState, first: 0 }
    //     })
    //     form.resetFields();
    //     loadLazyData();
    //   }
    // }
    // catch (error) {
    //   console.log(error)
    //   if (error instanceof Error) {
    //     const errorMessage = useErrorHandler(error);
    //     showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
    //   }
    // }
  };

  const termDateFormatTemplate = (value) => {
    const termDate = value.termDate;
    if (termDate) {
      return moment(termDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const handleCancel = () => {
    setShowTable(true);
    form.resetFields();
    loadLazyData();
  }

  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            className="p-datatable-gridlines mt-4"
            showGridlines
            rows={10}
            dataKey="providerAttachmentModelID"
            emptyMessage="No records found."
            header={header1}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            // sortOrder={lazyState.sortOrder}
            onFilter={onFilter}
            value={gridValues}
            totalRecords={totalRecords}
            first={lazyState.first}
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
          >
            <Column field="comments" header="Comments" sortable />
            <Column field="Attachment" header="Alert Code" sortable />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">

              <FormItem name="attachment" label="Attachment" rules={[{ required: true }]}>
                <FileUpload
                  mode="basic"
                  name="filePreEnroll"
                  maxFileSize={1000000}
                  customUpload
                  auto={false}
                  uploadHandler={uploadFile}
                />
              </FormItem>

              <FormItem name="comments" label="Comments" rules={[{ required: true }]}>
                <InputText type="text" placeholder="Enter here" />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={handleCancel} type="button" />
              <Button label="Save" raised type="submit" />
            </div>
          </CustomForm>
        </div>
      )}
    </>
  );
};

export default AttachmentList;
