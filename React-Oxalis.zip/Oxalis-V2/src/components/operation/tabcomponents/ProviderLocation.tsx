import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import Dropdown from "../../../controls/Dropdown";
import Calendar from "../../../controls/Calendar";
import Button from "../../../controls/Button";
import { LazyTableState } from "../../../model/LazyTableState";
import { RootState } from "../../../Redux/app/store";
import { useSelector } from "react-redux";
import { GridModel } from "../../../model/GridModel";
import { FormInstance, useForm } from "rc-field-form";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import ProviderRelationService from "../../../services/ProviderRelationService";
import ProviderLocationService from "../../../services/ProviderLocationService";
import { KeyValueModel } from "../../../model/KeyValueModel";
import { ProviderLocationModel } from "../../../model/ProviderLocationModel";
import moment from "moment";
import { ProviderService } from "../../../services/ProviderService";
import { useToaster } from "../../../layout/context/toastContext";
import useErrorHandler from "../../../hooks/useErrorHandler";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";

const ProviderLocation: React.FC<ProviderAddEditProps> = ({ isProviderAddEdit = false }) => {

  const [selectedProviderLocation, setSelectedProviderLocation] = useState<ProviderLocationModel>(null);
  const [providerLocationId, setProviderLocationId] = useState<number>(0);
  const [providerRelationOptions, setProviderRelationOptions] = useState<KeyValueModel[]>([]);
  const [locationOptions, setLocationOptions] = useState<KeyValueModel[]>([]);
  const [showTable, setShowTable] = useState(true);
  const { providerId } = useSelector((state: RootState) => state.provider);
  const [gridValues, setGridValues] = useState<ProviderLocationModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [form] = useForm();
  const { getKeyValueByParentProviderId } = ProviderRelationService();
  const { getKeyValueByProviderId, update, addGroupProvider, getByGroupId, deleteProviderLocation } = ProviderLocationService();
  const { getProviderLocation } = ProviderService();
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const { showToast } = useToaster();
  const [showConfirm, setShowConfirm] = useState<boolean>(false);

  const handleAddClick = () => {
    setShowTable(false); // Hide table and show form
  };

  const handleEffectiveDateChange = (event: Date) => {
    console.log("event ", event);
    setEffectiveDate(event);
  };

  useEffect(() => {
    if (providerId > 0 && !isProviderAddEdit) {
      const providerRelationResponse = getKeyValueByParentProviderId(providerId);
      const providerLocationResponse = getKeyValueByProviderId(providerId)
      Promise.all([providerRelationResponse, providerLocationResponse]).then((result) => {
        setProviderRelationOptions(result[0]);
        setLocationOptions(result[1]);
      })
    }
  }, [providerId]);

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId]);

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      if (isProviderAddEdit) {
        const providerLocationResponse: GridModel<ProviderLocationModel> = await getProviderLocation(providerId, query);

        if (providerLocationResponse) {
          setGridValues(providerLocationResponse.data);
          setTotalRecords(providerLocationResponse.totalCount);
        }
      }
      else {
        const providerLocationResponse: GridModel<ProviderLocationModel> = await getByGroupId(providerId, query);
        if (providerLocationResponse) {
          setGridValues(providerLocationResponse.data);
          setTotalRecords(providerLocationResponse.totalCount);
        }
      }
    };
  }

  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true)
    const providerLocation = await dataMapper(formValues);
    try {
      const providerSpecialtyResponse = providerLocationId > 0 ? await update(providerLocation) : await addGroupProvider(providerLocation);
      if (providerSpecialtyResponse) {
        setProviderLocationId(0);
        setShowTable(true);
        showToast({ severity: 'success', summary: 'Success', detail: "Provider Location saved successfully" });
        form.resetFields();
        setSelectedProviderLocation(null);
        setProviderLocationId(0);
        loadLazyData();
        setEffectiveDate(null);
      }
    }
    catch (error) {
      if (error instanceof Error) {
        console.log("error error", error)
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
  };

  const termDateFormatTemplate = (value: ProviderLocationModel) => {
    const termDate = value.termDate;
    if (termDate) {
      return moment(termDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const effectiveDateFormatTemplate = (value: ProviderLocationModel) => {
    const effectiveDate = value.effectiveDate;
    if (effectiveDate) {
      return moment(effectiveDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const handleEdit = () => {
    if (selectedProviderLocation) {

      const formData = {
        locationId: selectedProviderLocation.locationID,
        providerRelationIds: [selectedProviderLocation.providerID],
        effectiveDate: moment(selectedProviderLocation.effectiveDate).toDate(),
        termDate: selectedProviderLocation.termDate ? moment(selectedProviderLocation.termDate).toDate() : null,
      }
      setEffectiveDate(formData.effectiveDate);
      setProviderLocationId(selectedProviderLocation.providerLocationID);

      const locationValues = { ...formData, effectiveDate: moment(formData.effectiveDate).toDate(), termDate: formData.termDate ? moment(formData.termDate).toDate() : null }

      form.setFieldsValue({ ...locationValues });
      setShowTable(false);
    }
  }

  const dataMapper = (formValue) => {
    const providerRelationIds = formValue.providerRelationIds;
    if (!providerLocationId) {
      const result = providerRelationIds.map((item: number) => {
        return {
          groupId: providerId,
          locationId: formValue.locationId,
          providerId: item,
          termDate: formValue.termDate ? moment(formValue.termDate).format("YYYY-MM-DD") : null,
          effectiveDate: moment(formValue.effectiveDate).format("YYYY-MM-DD"),
          providerLocationId: formValue.providerLocationId ?? 0,
        }
      });
      return result;
    } else if (providerLocationId > 0) {
      return {
        ...selectedProviderLocation, termDate: formValue.termDate ? moment(formValue.termDate).format("YYYY-MM-DD") : null,
        effectiveDate: moment(formValue.effectiveDate).format("YYYY-MM-DD"),
      };
    }

  }

  const handleCancel = () => {
    setShowTable(true);
    form.resetFields();
    setSelectedProviderLocation(null);
    setProviderLocationId(0);
    loadLazyData();
    setEffectiveDate(null);
  }

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedProviderLocation(e.value);
    } else {
      setSelectedProviderLocation(null);
    }
  }


  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedProviderLocation && !isProviderAddEdit && <Button outlined label="Edit" onClick={handleEdit} />}
          {/* {selectedProviderLocation && !isProviderAddEdit && <Button outlined label="Delete" onClick={handleDelete} />} */}

          {/* Conditionally render the "Add" button when isProviderAddEdit is false */}
          {!isProviderAddEdit && <Button outlined label="Add" onClick={handleAddClick} />}
        </>
      </div>
    </div>
  );

  const addressTemplate = (rowData) => {
    const location = rowData.location;
    if (location) {
      const { address1, city, state, zip } = location;
      return `${address1 || ''}, ${city || ''}, ${state || ''}, ${zip || ''}`.trim().replace(/^,|,$/g, '');
    }
    return '';
  };

  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            className="p-datatable-gridlines mt-4"
            showGridlines
            rows={lazyState.rows}
            dataKey="providerLocationID"
            emptyMessage="No records found."
            header={header1}
            selectionMode="single"
            lazy onPage={onPage}
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
            onSort={onSort}
            sortField={lazyState.sortField}
            sortOrder={lazyState.sortOrder}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >
            <Column field="locationName" header="Location" sortable />
            {isProviderAddEdit && (
              <Column field="location.address1" header="Address" body={addressTemplate} sortable />
            )}
            {isProviderAddEdit && (
              <Column field="groupProviderName" header="Group" sortable />
            )}
            {!isProviderAddEdit && (
              <Column field="providerName" header="Provider" sortable />
            )}
            <Column field="effectiveDate" body={effectiveDateFormatTemplate} header="Effective&nbsp;Date" sortable />
            <Column field="termDate" body={termDateFormatTemplate} header="Term&nbsp;Date" sortable />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="locationId" label="Location" rules={[
                { required: true }
              ]}>
                <Dropdown
                  id="location"
                  options={locationOptions}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                  className="w-full"
                  disabled={providerLocationId > 0 ? true : false}
                />
              </FormItem>

              <FormItem name="providerRelationIds" label="Providers" rules={[
                { required: true }
              ]}>
                <Dropdown
                  id="provider"
                  options={providerRelationOptions}
                  optionLabel="key"
                  optionValue="value"
                  multiple
                  showHeader
                  showClear
                  placeholder="Select"
                  className="w-full"
                  disabled={providerLocationId > 0 ? true : false}
                />
              </FormItem>

              <FormItem name="effectiveDate" label="Effective Date" rules={[
                { required: true }
              ]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  onChange={(event) => handleEffectiveDateChange(event as Date)}
                />
              </FormItem>

              <FormItem name="termDate" label="Term Date">
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={effectiveDate}
                  disabled={!effectiveDate}
                />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={handleCancel} type='button' />
              <Button label="Save" raised type='submit' />
            </div>
          </CustomForm>
        </div>
      )}
    </>
  );
};

export default ProviderLocation;

interface ProviderAddEditProps {
  isProviderAddEdit?: boolean;
}