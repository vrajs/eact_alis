import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import Dropdown from "../../../controls/Dropdown";
import Calendar from "../../../controls/Calendar";
import Button from "../../../controls/Button";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { useForm } from "rc-field-form";
import { LazyTableState } from "../../../model/LazyTableState";
import moment from "moment";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import { ProviderContractModel } from "../../../model/ProviderContractModel";
import ProviderRelationService from "../../../services/ProviderRelationService";
import { KeyValueModel } from "../../../model/KeyValueModel";
import ProviderContractService from "../../../services/ProviderContractService";
import GroupProviderContractService from "../../../services/GroupProviderContractService";
import { GroupProviderContractModel, ProviderContractViewModel } from "../../../model/GroupProviderContractModel";
import { ProviderRelationFormModel } from "../../../model/ProviderRelationModel";
import { useToaster } from "../../../layout/context/toastContext";
import useErrorHandler from "../../../hooks/useErrorHandler";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";

const ProviderContract: React.FC<ProviderAddEditProps> = ({ isProviderAddEdit = false }) => {

  const [selectedContract, setSelectedContract] = useState<ProviderContractModel>(null);
  const [showTable, setShowTable] = useState(true);
  const [selectedContractId, setSelectedContractId] = useState<number>(0);
  const [providerRelations, setProviderRelations] = useState<ProviderRelationFormModel[]>([]);
  const [providerRelationsOptions, setProviderRelationsOptions] = useState<KeyValueModel[]>([]);
  const [providerContractOptions, setProviderContractOptions] = useState<ProviderContractModel[]>([]);
  const [contractOptions, setContractOptions] = useState<KeyValueModel[]>([]);

  const { providerId } = useSelector((state: RootState) => state.provider);
  const [gridValues, setGridValues] = useState<GroupProviderContractModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [form] = useForm();
  const { getByParentProvider } = ProviderRelationService();
  const { getProviderContractDropDownByProviderID, getProviderContractList } = ProviderContractService();
  const { getGroupContractList, create, update, createProviderContract, updateProviderContract, deleteProviderContract } = GroupProviderContractService();
  const { showToast } = useToaster();
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const [showConfirm, setShowConfirm] = useState<boolean>(false);

  const handleAddClick = () => {
    setShowTable(false);
    setSelectedContract(null);
  };

  useEffect(() => {
    const contractOptions: KeyValueModel[] = providerContractOptions.map(contract => {
      return { key: contract.contractHeaderName, value: contract.providerContractID };
    });
    setContractOptions(contractOptions);
  }, [providerContractOptions]);

  useEffect(() => {
    const providerRelation = providerRelations.map(providerRelation => {
      return { key: providerRelation.relatedProvider?.fullName, value: providerRelation.relatedProviderID };
    });
    setProviderRelationsOptions(providerRelation);
  }, [providerRelations]);

  useEffect(() => {
    if (providerId > 0) {
      const providerRelationResponse = getByParentProvider(providerId);
      const providerContractResponse = getProviderContractDropDownByProviderID(providerId);
      Promise.all([providerRelationResponse, providerContractResponse]).then(result => {
        setProviderRelations(result[0]);
        setProviderContractOptions(result[1]);
      });
    }
  }, [providerId]);

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined,
  });
  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId]);

  const handleEffectiveDateChange = (event: Date) => {
    console.log("event ", event);
    setEffectiveDate(event);
  };

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      if (isProviderAddEdit) {
        try {
          const response = await getProviderContractList(providerId, query);
          if (response) {
            setGridValues(response.data);
            setTotalRecords(response.totalCount);
          }
        }
        catch (error) {
          if (error instanceof Error) {
            const errorMessage = useErrorHandler(error);
            showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
          }
        }
      } else {
        try {
          const response = await getGroupContractList(providerId, query);
          if (response) {
            setGridValues(response.data);
            setTotalRecords(response.totalCount);
          }
        } catch (error) {
          if (error instanceof Error) {
            const errorMessage = useErrorHandler(error);
            showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
          }
        }
      }


    }
  };

  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true);
    const mappedData = isProviderAddEdit ? providerDataMapper(formValues) : dataMapper(formValues);

    if (isProviderAddEdit) {
      try {
        const response = selectedContractId > 0 ? await updateProviderContract(mappedData) : await createProviderContract(mappedData);
        if (response) {
          showToast({ severity: 'success', summary: 'Success', detail: "Provider contract saved successfully" });
          setShowTable(true);
          setSelectedContractId(0);
          loadLazyData();
          form.resetFields();
          setEffectiveDate(null);
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    } else {
      try {
        const response = selectedContractId > 0 ? await update(mappedData) : await create(mappedData);
        if (response) {
          showToast({ severity: 'success', summary: 'Success', detail: "Provider contract saved successfully" });
          setShowTable(true);
          setSelectedContractId(0);
          loadLazyData();
          form.resetFields();
          setEffectiveDate(null);
        }
      }
      catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  };

  const providerDataMapper = (formValue) => {
    return {
      ...selectedContract,
      effectiveDate: formValue.effectiveDate ? moment(formValue.effectiveDate).format("YYYY-MM-DD") : null,
      termDate: formValue.termDate ? moment(formValue.termDate).format("YYYY-MM-DD") : null,
      providerContractId: formValue.providerContractId,
      providerId,
    };
  };

  const dataMapper = (formValue) => {
    const providerRelationIds = formValue.providerRelationIds;
    console.log(providerRelations)
    if (!selectedContractId) {
      const result = providerRelationIds.map((item: number) => {
        return {
          groupId: providerId,
          providerContractId: formValue.providerContractId,
          providerRelationId: providerRelations.find(a => a.relatedProviderID === item)?.providerRelationID,
          providerId: item,
          termDate: formValue.termDate ? moment(formValue.termDate).format("YYYY-MM-DD") : null,
          effectiveDate: moment(formValue.effectiveDate).format("YYYY-MM-DD"),
          groupProviderContractId: selectedContractId ?? 0,
        }
      });
      return result;
    } else if (selectedContractId > 0) {
      return { ...selectedContract, effectiveDate: formValue.effectiveDate, termDate: formValue.termDate };
    }
  };
  const providerHandleSelection = (e) => {
    if (e.value) {
      setSelectedContract(e.value);
    } else {
      setSelectedContract(null);
    }
  }
  const handleEdit = () => {
    const formData = {
      providerContractId: selectedContract?.providerContractID,
      providerRelationIds: isProviderAddEdit ? undefined : [selectedContract?.providerID],
      effectiveDate: selectedContract?.effectiveDate ? moment(selectedContract?.effectiveDate).toDate() : null,
      termDate: selectedContract?.termDate ? moment(selectedContract?.termDate).toDate() : null,
    };
    setEffectiveDate(formData.effectiveDate)
    setSelectedContractId(selectedContract.providerContractID);
    setShowTable(false);
    form.setFieldsValue(formData);
  };

  const handleCancel = () => {
    setShowTable(true);
    form.resetFields();
    setSelectedContractId(0);
    loadLazyData();
    form.resetFields();
    setEffectiveDate(null);
  };

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedContract) {
      try {
        const deleteResponse = await deleteProviderContract(selectedContract.providerContractID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "Contract deleted successfully" });
          setSelectedContractId(0);
          setSelectedContract(null);
          setShowTable(true);
          form.resetFields();
          loadLazyData();
          setEffectiveDate(null);
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setSelectedContractId(0);
    setSelectedContract(null);
  }

  const handleDelete = () => {
    if (selectedContract) {
      setShowConfirm(true);
    }
  }

  const header = (
    <div className="flex justify-content-end gap-3">
      {selectedContract && <Button outlined label="Edit" onClick={handleEdit} />}
      <Button outlined label="Add" onClick={handleAddClick} />
    </div>
  );

  const dateFormatTemplate = (value, field) => {
    const date = value[field];
    return date ? moment(date).format("MM/DD/YYYY") : "N/A";
  };

  return (
    <>
      {showTable && (
        <>
          <DataTable
            paginator
            className="p-datatable-gridlines mt-4"
            showGridlines
            rows={lazyState.rows}
            dataKey="ID"
            emptyMessage={paginatorConstants.emptyMessage}
            rowsPerPageOptions={paginatorConstants.pageOptions}
            header={header}
            selectionMode="single"
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
            value={gridValues}
            totalRecords={totalRecords}
            first={lazyState.first}
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            sortOrder={lazyState.sortOrder}
            onFilter={onFilter}
            onSelectionChange={(e) => providerHandleSelection(e)}
          >
            {isProviderAddEdit && <Column field="groupProviderName" header="Group" sortable />}
            <Column field="contractHeaderName" header="Contract" sortable />
            {isProviderAddEdit && <Column field="lobNames" header="Line Of Business" />}
            {isProviderAddEdit && <Column field="providerStatusName" header="Provider Status" sortable />}
            {!isProviderAddEdit && <Column field="providerName" header="Provider" sortable />}
            <Column field="effectiveDate" body={(value) => dateFormatTemplate(value, 'effectiveDate')} header="Effective Date" sortable />
            <Column field="termDate" body={(value) => dateFormatTemplate(value, 'termDate')} header="Term Date" sortable />
          </DataTable>
        </>
      )}
      <div className="py-3">
        {!showTable && (
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="providerContractId" label="Contract" rules={[{ required: true }]}>
                <Dropdown
                  id="contract"
                  options={contractOptions}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                  className="w-full"
                  disabled={selectedContractId > 0 ? true : false}
                />
              </FormItem>

              {!isProviderAddEdit && (
                <FormItem name="providerRelationIds" label="Provider" rules={[{ required: true }]}>
                  <Dropdown
                    options={providerRelationsOptions}
                    optionLabel="key"
                    optionValue="value"
                    multiple
                    showHeader
                    showClear
                    placeholder="Select"
                    disabled={selectedContractId > 0 ? true : false}
                  />
                </FormItem>
              )}

              <FormItem name="effectiveDate" label="Effective Date" rules={[{ required: true }]}>
                <Calendar placeholder="Enter Date" selectionMode="single" icon="cl_calendar_today_line" iconPos="right" dateFormat="mm/dd/yy" onChange={(event) => handleEffectiveDateChange(event as Date)} />
              </FormItem>

              <FormItem name="termDate" label="Term Date">
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={effectiveDate}
                  disabled={!effectiveDate}
                />
              </FormItem>
            </div>

            <div className="flex justify-content-end gap-3 pt-3">
              <Button outlined label="Cancel" onClick={handleCancel} type='button' />
              <Button label="Save" type="submit" />
            </div>
          </CustomForm>
        )}
      </div>

      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </>
  );
};

export default ProviderContract;

interface ProviderAddEditProps {
  isProviderAddEdit?: boolean;
}