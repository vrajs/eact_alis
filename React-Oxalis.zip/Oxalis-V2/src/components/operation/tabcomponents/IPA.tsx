import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import InputNumber from "../../../controls/InputNumber";
import Dropdown from "../../../controls/Dropdown";
import InputMask from "../../../controls/InputMask";
import Calendar from "../../../controls/Calendar";
import Button from "../../../controls/Button";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { FormInstance, useForm } from "rc-field-form";
import { CodeType, CommonCodeFetchingType, FilterStatus } from "../../../data/constants/AppEnum";
import { LazyTableState } from "../../../model/LazyTableState";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import IPAService from "../../../services/IPAService";
import { IPAViewModel } from "../../../model/IPAViewModel";
import { GridModel } from "../../../model/GridModel";
import moment from "moment";
import { KeyValueModel } from "../../../model/KeyValueModel";
import ProviderIPAService from "../../../services/ProviderIPAService";
import { ProviderIPAModel } from "../../../model/ProviderIPAModel";
import { DropdownChangeEvent } from "primereact/dropdown";
import { useToaster } from "../../../layout/context/toastContext";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import useErrorHandler from "../../../hooks/useErrorHandler";
import useFormattedDate from "../../../hooks/useFormattedDate";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";

const IPA = () => {
  const [showTable, setShowTable] = useState(true);
  const lob = [{ name: "Medicare" }, { name: "Gold" }];
  const [selectedIPA, setSelectedIPA] = useState<ProviderIPAModel | null>();
  const [ipaID, setIpaID] = useState<number>(0);
  const { getActiveIPAs } = IPAService();
  const { create, deleteIPA, update, getByProvider } = ProviderIPAService()
  const [showConfirm, setShowConfirm] = useState<boolean>(false);

  const { providerId } = useSelector((state: RootState) => state.provider);
  const [gridValues, setGridValues] = useState<ProviderIPAModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [form] = useForm();
  const { showToast } = useToaster();
  const [ipaOptions, setIpaOptions] = useState<KeyValueModel[]>([]);
  const [ipaList, setIpaList] = useState<IPAViewModel[]>([]);
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);

  const handleAddClick = () => {
    setShowTable(false); // Hide table and show form
  };

  useEffect(() => {
    const getIPAs = async () => {
      const ipaResponse: IPAViewModel[] = await getActiveIPAs(FilterStatus.Active);
      setIpaList(ipaResponse);
    }
    getIPAs()
  }, [])

  const handleEffectiveDateChange = (event: Date) => {
    console.log("event ", event);
    setEffectiveDate(event);
  };

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedIPA) {
      try {
        const deleteResponse = await deleteIPA(selectedIPA.providerIPAID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "IPA deleted successfully" });
          setShowTable(true);
          form.resetFields();
          setSelectedIPA(null);
          setIpaID(0);
          loadLazyData();
          setEffectiveDate(null);
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setSelectedIPA(null);
    setIpaID(0);
  }

  const handleDelete = () => {
    if (selectedIPA) {
      setShowConfirm(true);
    }
  }

  const handleIPAChange = (event: DropdownChangeEvent) => {
    if (event.value) {
      const selectedIPA = ipaList.find(a => a.ipaid === event.value);
      const formValue = {
        contactName: selectedIPA.contactName,
        npi: selectedIPA.npi,
        lobs: selectedIPA.lobs,
        phone: selectedIPA.phone,
        fax: selectedIPA.fax,
        primaryEmail: selectedIPA.primaryEmail,
        secondaryEmail: selectedIPA.secondaryEmail,
      }
      form.setFieldsValue(formValue)
    } else {
      form.resetFields();
    }
  }

  useEffect(() => {
    const ipaOptions = ipaList.map((a: IPAViewModel) => {
      return { key: a.ipaName, value: a.ipaid }
    })
    setIpaOptions(ipaOptions);
  }, [ipaList])

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId]);

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      const ipaResponse: GridModel<ProviderIPAModel> = await getByProvider(providerId, query);
      if (ipaResponse) {
        setGridValues(ipaResponse.data);
        setTotalRecords(ipaResponse.totalCount);
      }
    }
  };

  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true)

    const ipaValue = await dataMapper(formValues);
    try {
      const ipaResponse = ipaID > 0 ? await update(ipaValue) : await create(ipaValue);
      if (ipaResponse) {
        showToast({ severity: 'success', summary: 'Success', detail: "IPA saved successfully" });
        setIpaID(0);
        setShowTable(true);
        setLazyState((prevState) => {
          return { ...prevState, first: 0 }
        })
        form.resetFields();
        setSelectedIPA(null);
        setIpaID(0);
        loadLazyData();
        setEffectiveDate(null);
      }
    } catch (error) {
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
  };

  const termDateFormatTemplate = (value) => {
    return useFormattedDate(value, "termDate");
  }

  const effectiveDateFormatTemplate = (value) => {
    return useFormattedDate(value, "effectiveDate");
  }

  const handleEdit = () => {
    if (selectedIPA) {
      const ipa = selectedIPA.ipa;

      const formData = {
        ipaid: selectedIPA.ipaid,
        contactName: ipa.contactName,
        npi: ipa.npi,
        lobs: ipa.lobs,
        phone: ipa.phone,
        fax: ipa.fax,
        primaryEmail: ipa.primaryEmail,
        secondaryEmail: ipa.secondaryEmail,
        effectiveDate: moment(selectedIPA.effectiveDate).toDate(),
        termDate: selectedIPA.termDate ? moment(selectedIPA.termDate).toDate() : null
      }
      setIpaID(selectedIPA.providerIPAID);

      form.setFieldsValue(formData);
      setShowTable(false);
    }
  }

  const dataMapper = (formValue: IPAViewModel) => {

    const referenceModel = {
      providerId,
      providerIPAID: ipaID > 0 ? ipaID : 0,
      ipaid: formValue.ipaid,
      effectiveDate: moment(formValue.effectiveDate).format("YYYY-MM-DD"),
      termDate: formValue.termDate ? moment(formValue.termDate).format("YYYY-MM-DD") : null,
    }
    return referenceModel;
  }

  const handleCancel = () => {
    setShowTable(true);
    form.resetFields();
    setSelectedIPA(null);
    setIpaID(0);
    loadLazyData();
    setEffectiveDate(null);
  }

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedIPA(e.value);
    } else {
      setSelectedIPA(null);
    }
  }

  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedIPA && <Button outlined label="Edit" onClick={handleEdit} />}
          {selectedIPA && <Button outlined label="Delete" onClick={handleDelete} />}
          <Button outlined label="Add" onClick={handleAddClick} />
        </>
      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            rowsPerPageOptions={paginatorConstants.pageOptions}
            className="p-datatable-gridlines"
            showGridlines
            rows={lazyState.rows}
            tableStyle={{ minWidth: '50rem' }}
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
            dataKey="alertModuleID"
            emptyMessage={paginatorConstants.emptyMessage}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortOrder={lazyState.sortOrder}
            sortField={lazyState.sortField}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
            header={header1}
          >
            <Column field="ipa.ipaName" header="IPA&nbsp;Name" sortable />
            <Column field="ipa.contactName" header="Contact&nbsp;Name" sortable />
            <Column field="ipa.npi" header="NPI" sortable />
            <Column field="ipa.lobs" header="LOB" sortable />
            <Column field="ipa.phone" header="Phone" sortable />
            <Column field="ipa.fax" header="Fax" sortable />
            <Column field="ipa.primaryEmail" header="Primay Email" sortable />
            <Column field="effectiveDate" body={effectiveDateFormatTemplate} header="Effective&nbsp;Date" sortable />
            <Column field="termDate" body={termDateFormatTemplate} header="Term&nbsp;Date" sortable />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="ipaid" label="IPA Name" rules={[
                { required: true }
              ]}>
                <Dropdown
                  id="type"
                  options={ipaOptions}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  onChange={handleIPAChange}
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormItem name="contactName" label="Contact Name" >
                <InputText type="text" placeholder="Enter here" disabled />
              </FormItem>

              <FormItem name="npi" label="NPI" >
                <InputNumber placeholder="Enter here" useGrouping={false} disabled />
              </FormItem>

              <FormItem name="lobs" label="Line Of Business" >
                <InputText placeholder="Enter here" disabled />
              </FormItem>

              <FormItem name="phone" label="Phone">
                <InputMask mask="(999) 999-9999" inputClassName="w-full" placeholder="Enter here" unmask disabled />
              </FormItem>
              <FormItem name="fax" label="Fax" >
                <InputMask mask="999-999-9999" inputClassName="w-full" placeholder="Enter here" unmask disabled />
              </FormItem>
              <FormItem name="primaryEmail" label="Primary Email" >
                <InputText type="email" placeholder="Enter here" disabled />
              </FormItem>
              <FormItem name="secondaryEmail" label="Secondary Email" >
                <InputText type="email" placeholder="Enter here" disabled />
              </FormItem>
              <FormItem name="effectiveDate" label="Effective Date" rules={[
                { required: true }
              ]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  onChange={(event) => handleEffectiveDateChange(event as Date)}
                />
              </FormItem>
              <FormItem name="termDate" label="Term Date" >
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={effectiveDate}
                  disabled={!effectiveDate}
                />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={handleCancel} type='button' />
              <Button label="Save" raised type='submit' />
            </div>
          </CustomForm>
        </div>
      )}

      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </>
  );
};

export default IPA;
