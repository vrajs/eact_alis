import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { lazy, useEffect, useState } from "react";
import InputText from "../../../controls/InputText";
import Dropdown from "../../../controls/Dropdown";
import Calendar from "../../../controls/Calendar";
import Button from "../../../controls/Button";
import { useForm } from "rc-field-form";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { LazyTableState } from "../../../model/LazyTableState";
import { GridModel } from "../../../model/GridModel";
import moment from "moment";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import { CodeType, CommonCodeFetchingType } from "../../../data/constants/AppEnum";
import ProviderCodeService from "../../../services/ProviderCodeService";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import { ProviderCodeViewModel } from "../../../model/ProviderCodeViewModel";
import { useToaster } from "../../../layout/context/toastContext";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import useErrorHandler from "../../../hooks/useErrorHandler";
import FormListItem from "../../../controls/FormListItem";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";

const Reference = () => {
  const [showTable, setShowTable] = useState(true);
  const [selectedReferenceId, setSelectedReferenceId] = useState<number>(0);
  const [selectedReference, setSelectedReference] = useState<ProviderCodeViewModel | null>();
  const referenceOptions = useCommonCodeSubCategory(CodeType.RefValueType, CommonCodeFetchingType.Default);
  const [effectiveDate, setEffectiveDate] = useState<Date | null>(null);
  const [showConfirm, setShowConfirm] = useState<boolean>(false);
  const [minDate, setMinDate] = useState<Date | null>(null);

  const { providerId, providerData } = useSelector((state: RootState) => state.provider);
  const [gridValues, setGridValues] = useState<ProviderCodeViewModel[]>([]);
  const [totalRecords, setTotalRecords] = useState<number>(0);
  const [form] = useForm();
  const { showToast } = useToaster();

  const { create, update, getByProviderId, deleteCode } = ProviderCodeService();

  const handleAddClick = () => {
    setShowTable(false); // Hide table and show form
  };

  useEffect(() => {
    if (providerData) {
      const eligibilities = providerData.providerEligibility;
      const providerEligibility = eligibilities?.[0];
      const { effectiveDate } = providerEligibility;
      setMinDate(() => {
        return effectiveDate ? moment(effectiveDate).toDate() : null
      })
    }
  }, [providerData])

  const handleEffectiveDateChange = (event: Date) => {
    console.log("event ", event);
    setEffectiveDate(event);
  };

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId]);

  const loadLazyData = async () => {
    const query = useQueryBuilder(lazyState);
    if (providerId > 0) {
      const providerCodeResponse: GridModel<ProviderCodeViewModel> = await getByProviderId(providerId, query);
      if (providerCodeResponse) {
        setGridValues(providerCodeResponse.data);
        setTotalRecords(providerCodeResponse.totalCount);
      }
    }
  };

  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true)
    console.log("formValues formValues", formValues)
    const providerReference = await dataMapper(formValues);
    console.log(providerReference)
    try {
      const providerContractResponse = selectedReferenceId > 0 ? await update(providerReference) : await create(providerReference);
      if (providerContractResponse) {
        showToast({ severity: 'success', summary: 'Success', detail: "Reference saved successfully" });
        setSelectedReferenceId(0);
        form.resetFields();

        setShowTable(true);
        setSelectedReference(null);
        loadLazyData();
        setEffectiveDate(null);
      }
    }
    catch (error) {
      console.log(error)
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
  };

  const termDateFormatTemplate = (value) => {
    const termDate = value.termDate;
    if (termDate) {
      return moment(termDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const effectiveDateFormatTemplate = (value) => {
    const effectiveDate = value.effectiveDate;
    if (effectiveDate) {
      return moment(effectiveDate).format("MM/DD/YYYY")
    }
    return "N/A";
  }

  const handleEdit = () => {
    if (selectedReference) {

      console.log(selectedReference)
      const formData = {
        codeTypeId: selectedReference.codeTypeID,
        providerId: selectedReference.providerID,
        codeValue: selectedReference.codeValue,
        codeName: selectedReference.codeName,
        effectiveDate: moment(selectedReference.effectiveDate).toDate(),
        controlTypeId: selectedReference.controlTypeID,
        providerCodeId: selectedReference.providerCodeID,
        termDate: selectedReference.termDate ? moment(selectedReference.termDate).toDate() : null,
      }
      setSelectedReferenceId(selectedReference.providerCodeID);
      setEffectiveDate(formData.effectiveDate);
      form.setFieldsValue(formData);
      setShowTable(false);
    }
  }

  const dataMapper = (formValue) => {

    console.log("formValue", formValue);

    const referenceModel = {
      codeTypeId: formValue.codeTypeId,
      providerId: providerId,
      termDate: formValue.termDate ? moment(formValue.termDate).format("YYYY-MM-DD") : null,
      codeValue: formValue.codeValue,
      effectiveDate: moment(formValue.effectiveDate).format("YYYY-MM-DD"),
      codeName: formValue.codeName == null || undefined ? '' : formValue.codeName,
      controlTypeId: formValue.codeTypeId,
      providerCodeId: formValue.providerCodeId ? formValue.providerCodeId : 0,
    }

    return referenceModel;
  }

  const refValueLengthValidator = async (rule, value) => {
    if (value?.length > 80) {
      return Promise.reject("Maximum 80 characters allowed");
    }
    return Promise.resolve(null);
  }

  const handleCancel = () => {
    setShowTable(true);
    setLazyState((prevState) => {
      return { ...prevState, first: 0 }
    })
    setShowTable(true);
    setSelectedReference(null);
    loadLazyData();
    setEffectiveDate(null);
  }

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedReference) {
      try {
        const deleteResponse = await deleteCode(selectedReference.providerCodeID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "Reference deleted successfully" });
          setSelectedReferenceId(0);
          setSelectedReference(null);
          setShowTable(true);
          form.resetFields();
          loadLazyData();
          setEffectiveDate(null);
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setSelectedReferenceId(0);
    setSelectedReference(null);
  }

  const handleDelete = () => {
    if (selectedReference) {
      setShowConfirm(true);
    }
  }

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedReference(e.value);
    } else {
      setSelectedReference(null);
    }
  }

  const header1 = (
    <div>
      <div className="flex justify-content-end gap-3">
        <>
          {selectedReference && <Button outlined label="Edit" onClick={handleEdit} />}
          {selectedReference && <Button outlined label="Delete" onClick={handleDelete} />}
          <Button outlined label="Add" onClick={handleAddClick} />
        </>

      </div>
    </div>
  );
  return (
    <>
      {showTable ? (
        <>
          <DataTable
            paginator
            className="p-datatable-gridlines mt-4"
            showGridlines
            rows={10}
            dataKey="ID"
            responsiveLayout="scroll"
            emptyMessage="No records found."
            header={header1}
            selectionMode="single"
            lazy onPage={onPage}
            onSort={onSort}
            sortField={lazyState.sortField}
            sortOrder={lazyState.sortOrder}
            paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
            currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
            onFilter={onFilter}
            value={gridValues}
            onSelectionChange={(e) => handleSelection(e)}
            totalRecords={totalRecords}
            first={lazyState.first}
          >
            <Column field="codeTypeName" header="Type" sortable />
            <Column field="codeValue" header="Ref&nbsp;Value" sortable />
            <Column field="effectiveDate" body={effectiveDateFormatTemplate} header="Effective&nbsp;Date" sortable />
            <Column field="termDate" body={termDateFormatTemplate} header="Term&nbsp;Date" sortable />
          </DataTable>
        </>
      ) : (
        <div className="py-3">
          <CustomForm form={form} onFinish={handleSave}>
            <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
              <FormItem name="codeTypeId" label="Type" rules={[
                { required: true }
              ]}>
                <Dropdown
                  id="type"
                  options={referenceOptions}
                  optionLabel="value"
                  optionValue="key"
                  showClear
                  placeholder="Select"
                  className="w-full"
                />
              </FormItem>

              <FormListItem name="codeValue" label="Ref Value" rules={[
                { required: true, message: "Ref Value is required" },
                { validator: refValueLengthValidator, message: "Maximum 80 characters allowed" }
              ]}>
                <InputText type="text" placeholder="Enter here" />
              </FormListItem>

              <FormItem name="effectiveDate" label="Effective Date" rules={[
                { required: true }
              ]}>
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={minDate}
                  onChange={(event) => handleEffectiveDateChange(event as Date)}
                />
              </FormItem>

              <FormItem name="termDate" label="Term Date">
                <Calendar
                  placeholder="Enter Date"
                  selectionMode="single"
                  icon="cl_calendar_today_line"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                  minDate={effectiveDate ? effectiveDate : minDate}
                  disabled={!effectiveDate}
                />
              </FormItem>
            </div>
            <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
              <Button label="Cancel" text onClick={handleCancel} type='button' />
              <Button label="Save" raised type='submit' />
            </div>
          </CustomForm>
        </div>
      )}

      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </>
  );
};

export default Reference;
