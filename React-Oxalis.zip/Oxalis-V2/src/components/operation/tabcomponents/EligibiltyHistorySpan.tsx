import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { LazyTableState } from "../../../model/LazyTableState";
import { useEffect, useState } from "react";
import { GridModel } from "../../../model/GridModel";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { ProviderAuditHistory } from "../../../model/ProviderAuditHistory";
import { ProviderService } from "../../../services/ProviderService";
import useFormattedDateTime from "../../../hooks/useFormattedDateTime";

const AuditHistory = () => {
  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined,
  });

  const { providerId } = useSelector((state: RootState) => state.provider);

  const [totalRecords, setTotalRecords] = useState(0);
  const [gridValues, setGridValues] = useState<ProviderAuditHistory[]>([]);

  const { getProviderIdAuditHistory } = ProviderService();

  const onPage = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const modifiedTemplate = (data) => {
    return useFormattedDateTime(data, "modifiedDate");
  }

  useEffect(() => {
    loadLazyData();
  }, [lazyState, providerId]);

  const loadLazyData = async () => {
    if (providerId > 0) {
      // const providerAuditResponse: ProviderAuditHistory[] = await getProviderIdAuditHistory(providerId, lazyState.first, lazyState.rows);


      // Map over the response and find the matching LOB by `lobId`

      const providerAuditResponse: GridModel<ProviderAuditHistory> = await getProviderIdAuditHistory(providerId, lazyState.first, lazyState.rows);
      if (providerAuditResponse) {
        setGridValues(providerAuditResponse.data);
        setTotalRecords(providerAuditResponse.totalCount);

      } else {
        console.error("Unexpected response format:", providerAuditResponse);
      }
    }
  };
  return (
    <div>
      <DataTable
        paginator
        className="p-datatable-gridlines mt-4"
        showGridlines
        rows={lazyState.rows}

        responsiveLayout="scroll"
        emptyMessage="No records found."
        selectionMode="single"
        lazy
        value={gridValues}
        totalRecords={totalRecords}
        first={lazyState.first}
        onPage={onPage}
        onSort={onSort}
        sortField={lazyState.sortField}
        onFilter={onFilter}
      >
        <Column field="modifiedField" header="Modified&nbsp;Field" />
        <Column field="beforeValue" header="Before&nbsp;Value" />
        <Column field="afterValue" header="After&nbsp;Value" />
        <Column field="modifiedDate" body={modifiedTemplate} header="Modified&nbsp;Date" />
        <Column field="modifiedBy" header="Modified&nbsp;By" />
      </DataTable>
    </div>
  );
};

export default AuditHistory;