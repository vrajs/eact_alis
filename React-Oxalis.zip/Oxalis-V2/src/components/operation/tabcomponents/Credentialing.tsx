import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useEffect, useState } from "react";
import Button from "../../../controls/Button";
import Dropdown from "../../../controls/Dropdown";
import Calendar from "../../../controls/Calendar";
import InputText from "../../../controls/InputText";
import { useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { FormInstance, useForm } from "rc-field-form";
import { LazyTableState } from "../../../model/LazyTableState";
import { GridModel } from "../../../model/GridModel";
import moment from "moment";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import SharedService, { KeyValLobModel } from "../../../services/SharedService";
import { CredentialingService } from "../../../services/CredentialingService";
import { CredentialingModel } from "../../../model/CredentialingModel";
import useErrorHandler from "../../../hooks/useErrorHandler";
import { useToaster } from "../../../layout/context/toastContext";

const Credentialing = () => {
  const [showTable, setShowTable] = useState(true);
  const [credData, setCredData] = useState<CredentialingModel>();
  const [isSaving, setIsSaving] = useState(false);
  const { showToast } = useToaster();
  const handleAddClick = () => {
    setShowTable(false); // Hide table and show form
  };
  const [form] = useForm();
  const { providerId } = useSelector((state: RootState) => state.provider);
  const handleSaveClick = () => {
    setShowTable(true); // Hide form and show table
  };
  const { getProviderCredentialing, createCredentialing, updatecreateCredentialing } = CredentialingService();
  const credentialStatusList = [
    { key: "Provisional", value: 60 },
    { key: "Credential", value: 61 },
    { key: "UnCredential", value: 62 },
    { key: "Not Required", value: 63 }
  ];
  const levelList = [
    { key: "High Abuse Potential", value: 100 },
    { key: "Certain Narcotic, Stimulant and Depressant Drugs ", value: 101 },
    { key: "Certain Narcotic and Non-Narcotic Drugs", value: 102 },
    { key: "Low Abuse Potential", value: 103 },
    { key: "Lowest Abuse Potential", value: 104 }
  ];
  const jCAHOAccreditedList = [
    { key: "Yes", value: 200 },
    { key: "No", value: 201 },
  ];
  const amaList = [
    { key: "Yes", value: 202 },
    { key: "No", value: 203 },
  ];
  const emergencyRoomCapabilityList = [
    { key: "Yes", value: 204 },
    { key: "No", value: 205 },
  ];
  const hospitalMedicalServicesList = [
    { key: "Yes", value: 206 },
    { key: "No", value: 207 },
  ];
  const hospitalPrivilegesList = [
    { key: "Yes", value: 208 },
    { key: "No", value: 209 },
  ];
  const correctiveActionRequiredList = [
    { key: "Yes", value: 210 },
    { key: "No", value: 211 },
  ];
  const yesNoList = [
    { key: "Yes", value: 222 },
    { key: "No", value: 223 },
  ];
  const serviceList = [
    { key: "Claims", value: 50 },
    { key: "Credentialing", value: 51 },
    { key: "Authorizations", value: 52 }
  ];
  const medicalDirectorApprovalList = [
    { key: "Yes", value: 21 },
    { key: "No", value: 31 },
  ];
  const disciplinaryActionList = [
    { key: "Yes", value: 24 },
    { key: "No", value: 34 },
  ];
  const letterOfCensureList = [
    { key: "Yes", value: 23 },
    { key: "No", value: 33 },
  ];
  const malpracticeClaimPendingList = [
    { key: "Yes", value: 22 },
    { key: "No", value: 32 },
  ];
  const CLIlevelList = [
    { key: "Knowledge", value: 40 },
    { key: "Training and Experience", value: 41 },
    { key: "Reagents and Materials Preparation", value: 42 },
    { key: "Characteristics of Operational Steps", value: 43 },
    { key: "Calibration,Quality Control, And Proficiency Test", value: 44 },
    { key: "Test System troubleshooting and Equipment management", value: 45 },
    { key: "Interpretation and Judgement", value: 46 },
    { key: "Waiver", value: 47 }
  ];
  
  const handleSave = async () => {
    const formValues = await form.getFieldsValue(true);
    // const mappedData = dataMapper(formValues);

    console.log("formValues formValues", formValues)
    try {
      const response = providerId > 0 ? await updatecreateCredentialing(formValues) : await createCredentialing(formValues);
      if (response) {
        showToast({ severity: 'success', summary: 'Success', detail: "Credentials saved successfully" });
        setIsSaving(false);
      }
    }
    catch (error) {
      if (error instanceof Error) {
        setIsSaving(false);
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
  };
  const [lobListS, setLobListS] = useState<KeyValLobModel[]>([]);
  const { getLobList } = SharedService();
  useEffect(() => {
    const fetchLobList = async () => {
      const lobList = await getLobList(); // Assuming this returns a promise
      setLobListS(lobList);
      const providerCredData: CredentialingModel = await getProviderCredentialing(providerId);
      if (providerCredData) {
        console.log(providerCredData)
        // Set group data in state
        const providerCredentialingData = {
          ...providerCredData,
          effectiveDate: providerCredData.effectiveDate ? moment(providerCredData.effectiveDate).toDate() : null,
          expirationDate: providerCredData.expirationDate ? moment(providerCredData.expirationDate).toDate() : null,
          educationEffectiveDate: providerCredData.educationEffectiveDate ? moment(providerCredData.educationEffectiveDate).toDate() : null,
          educationExpirationDate: providerCredData.educationExpirationDate ? moment(providerCredData.educationExpirationDate).toDate() : null,
          verificationDate: providerCredData.verificationDate ? moment(providerCredData.verificationDate).toDate() : null,
          malPracticeEffectiveDate: providerCredData.malPracticeEffectiveDate ? moment(providerCredData.malPracticeEffectiveDate).toDate() : null,
          malPracticeExpirationDate: providerCredData.malPracticeExpirationDate ? moment(providerCredData.malPracticeExpirationDate).toDate() : null,
          deaEffectiveDate: providerCredData.deaEffectiveDate ? moment(providerCredData.deaEffectiveDate).toDate() : null,
          deaExpirationDate: providerCredData.deaExpirationDate ? moment(providerCredData.deaExpirationDate).toDate() : null,
          cliaEffectiveDate: providerCredData.cliaEffectiveDate ? moment(providerCredData.cliaEffectiveDate).toDate() : null,
          cliaExpirationDate: providerCredData.cliaExpirationDate ? moment(providerCredData.cliaExpirationDate).toDate() : null,
          issueDate: providerCredData.issueDate ? moment(providerCredData.issueDate).toDate() : null,
          hospitalEffectiveDate: providerCredData.hospitalEffectiveDate ? moment(providerCredData.hospitalEffectiveDate).toDate() : null,
          hospitalExpirationDate: providerCredData.hospitalExpirationDate ? moment(providerCredData.hospitalExpirationDate).toDate() : null,
          amaExpirationDate: providerCredData.amaExpirationDate ? moment(providerCredData.amaExpirationDate).toDate() : null,
          initialSiteVisitDate: providerCredData.initialSiteVisitDate ? moment(providerCredData.initialSiteVisitDate).toDate() : null,
          followUpSiteVisitDate: providerCredData.followUpSiteVisitDate ? moment(providerCredData.followUpSiteVisitDate).toDate() : null,
          followUpLetterDate: providerCredData.followupLetterDate ? moment(providerCredData.followupLetterDate).toDate() : null,
          finalSiteVisitDate: providerCredData.finalSiteVisitDate ? moment(providerCredData.finalSiteVisitDate).toDate() : null,
          nabpEffectiveDate: providerCredData.nabpEffectiveDate ? moment(providerCredData.nabpEffectiveDate).toDate() : null,
          nabpExpirationDate: providerCredData.nabpExpirationDate ? moment(providerCredData.nabpExpirationDate).toDate() : null,
          delegatedEffectiveDate: providerCredData.delegateEffectiveDate ? moment(providerCredData.delegatedServiceId).toDate() : null,
          dateCredApproved: providerCredData.dateCredApproved ? moment(providerCredData.dateCredApproved).toDate() : null,
          reviewDate: providerCredData.reviewDate ? moment(providerCredData.reviewDate).toDate() : null,
          nextReviewDate: providerCredData.nextReviewDate ? moment(providerCredData.nextReviewDate).toDate() : null,

        };
        setCredData(providerCredData);
        form.setFieldsValue(providerCredentialingData); // Set form values
      }
    };

    fetchLobList();
  }, []);
  return (
    <>
      <div className="py-3">

        <CustomForm form={form} onFinish={handleSave}>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px' }}>

            {/* First Box */}
            <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
              <h2 style={{ textAlign: 'center', color: 'red' }}>License </h2> {/* Header for first section */}
              <FormItem name="licensingBoardName" label="Licensing Board Name" rules={[{ required: true }]}>
                <InputText type="text" placeholder="Enter Licensing Board Name" />
              </FormItem>

              <FormItem name="licenseNumber" label="License Number" rules={[{ required: true }]}>
                <InputText type="text" placeholder="Enter License Number" />
              </FormItem>

              <FormItem name="credentialStatusId" label="Credential Status" rules={[{ required: true }]}>
                <Dropdown
                  options={credentialStatusList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select Credential Status"
                />
              </FormItem>

              <FormItem name="effectiveDate" label="Effective Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Effective Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="expirationDate" label="Expiration Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Expiration Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>
            </div>

            {/* Second Box */}
            <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
              <h2 style={{ textAlign: 'center', color: 'red' }}>Education </h2> {/* Header for first section */}
              <FormItem name="schoolName" label="School Name" rules={[{ required: true }]}>
                <InputText type="text" placeholder="Enter School Name" />
              </FormItem>

              <FormItem name="degree" label="Degree" rules={[{ required: true }]}>
                <InputText type="text" placeholder="Enter Degree" />
              </FormItem>

              <FormItem name="educationEffectiveDate" label="Education Effective Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Education Effective Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="educationExpirationDate" label="Education Expiration Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Education Expiration Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="verificationDate" label="Verification Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Verification Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="verificationBy" label="Verification By" rules={[{ required: true }]}>
                <InputText type="text" placeholder="Enter Verification By" />
              </FormItem>
            </div>

            {/* Third Box */}
            <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
              <h2 style={{ textAlign: 'center', color: 'red' }}>MalPractice </h2> {/* Header for first section */}
              <FormItem name="carrierId" label="Carrier" rules={[{ required: true }]}>
                <Dropdown
                  options={credentialStatusList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>

              <FormItem name="policyNumber" label="Policy Number" rules={[{ required: true }]}>
                <InputText type="text" placeholder="Enter Policy Number" />
              </FormItem>

              <FormItem name="malPracticeEffectiveDate" label="Effective Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Effective Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="malPracticeExpirationDate" label="Expiration Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Expiration Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="perClaimAmount" label="Per Claim Amount" rules={[{ required: true }]}>
                <InputText type="text" placeholder="Enter Per Claim Amount" />
              </FormItem>

              <FormItem name="coverageLimit" label="Coverage Limit" rules={[{ required: true }]}>
                <InputText type="text" placeholder="Enter Coverage Limit" />
              </FormItem>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px' }}>
            {/* First Box */}
            <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
              <h2 style={{ textAlign: 'center', color: 'red' }}>DEA </h2> {/* Header for first section */}
              <FormItem name="deaNumber" label="DEA Number" rules={[{ required: true }]}>
                <InputText type="text" placeholder="Enter Licensing Board Name" />
              </FormItem>

              <FormItem name="levelId" label="Level" rules={[{ required: true }]}>
                <Dropdown
                  options={levelList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>

              <FormItem name="deaEffectiveDate" label="Effective Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Effective Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="deaExpirationDate" label="Expiration Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Expiration Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>
            </div>

            {/* Second Box */}
            <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
              <h2 style={{ textAlign: 'center', color: 'red' }}>CLIA </h2> {/* Header for first section */}
              <FormItem name="certNumber" label="Cert Number" rules={[{ required: true }]}>
                <InputText type="text" placeholder="Enter Cert Number" />
              </FormItem>

              <FormItem name="cliaLevelId" label="Level" rules={[{ required: true }]}>
                <Dropdown
                  options={CLIlevelList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>

              <FormItem name="cliaEffectiveDate" label="Education Effective Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Education Effective Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="cliaExpirationDate" label="Education Expiration Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Education Expiration Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

            </div>

            {/* Third Box */}
            <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
              <h2 style={{ textAlign: 'center', color: 'red' }}>ECFMG </h2> {/* Header for first section */}
              <FormItem name="ecfmgNumber" label="ECFMG Number" rules={[{ required: true }]}>
                <InputText type="text" />
              </FormItem>
              <FormItem name="issueDate" label="Issue Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Issue Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>
            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px' }}>
            {/* First Box */}
            <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
              <h2 style={{ textAlign: 'center', color: 'red' }}>Hospital </h2> {/* Header for first section */}
              <FormItem name="jcahoAccredited" label="jCAHO Accredited" rules={[{ required: true }]}>
                <Dropdown
                  options={jCAHOAccreditedList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>

              <FormItem name="hospitalEffectiveDate" label="Effective Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Effective Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="hospitalExpirationDate" label="Expiration Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Expiration Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>
              <FormItem name="amaMember" label="AMA Member" rules={[{ required: true }]}>
                <Dropdown
                  options={amaList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>
              <FormItem name="amaExpirationDate" label="AMA Expiration Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Expiration Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>
              <FormItem name="emergencyRoomCapability" label="Emergency Room Capability" rules={[{ required: true }]}>
                <Dropdown
                  options={emergencyRoomCapabilityList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>
              <FormItem name="hospitalMedicalServices" label="Hospital Medical Services" rules={[{ required: true }]}>
                <Dropdown
                  options={hospitalMedicalServicesList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>
              <FormItem name="hospitalPrivileges" label="Hospital Privileges" rules={[{ required: true }]}>
                <Dropdown
                  options={hospitalPrivilegesList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>
              <FormItem name="rateOfOccupancy" label="ECFMG Number" rules={[{ required: true }]}>
                <InputText type="text" />
              </FormItem>
              <FormItem name="noOfLicensedBeds" label="# Of Licensed Beds" rules={[{ required: true }]}>
                <InputText type="text" />
              </FormItem>
            </div>

            {/* Second Box */}
            <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
              <h2 style={{ textAlign: 'center', color: 'red' }}>SiteVisit </h2> {/* Header for first section */}
              <FormItem name="initialSiteVisitDate" label="AMA Expiration Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Expiration Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="followUpSiteVisitDate" label="AMA Expiration Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Expiration Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="followUpLetterDate" label="Education Effective Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Education Effective Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="finalSiteVisitDate" label="Final SiteVisit Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Education Expiration Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="correctiveActionRequired" label="Corrective Action Required" rules={[{ required: true }]}>
                <Dropdown
                  options={correctiveActionRequiredList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>

              <FormItem name="correctionActionComments" label="Corrective Action Comments" rules={[{ required: true }]}>
                <InputText type="text" />
              </FormItem>
              <FormItem name="providerRepName" label="Provider RepName" rules={[{ required: true }]}>
                <InputText type="text" />
              </FormItem>
              <FormItem name="providerRepContact" label="Provider RepContact" rules={[{ required: true }]}>
                <InputText type="text" />
              </FormItem>
              <FormItem name="comments" label="Comments" rules={[{ required: true }]}>
                <InputText type="text" />
              </FormItem>
            </div>

            {/* Third Box */}
            <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
              <h2 style={{ textAlign: 'center', color: 'red' }}>NABP </h2> {/* Header for first section */}
              <FormItem name="nabpNumber" label="NABP Number" rules={[{ required: true }]}>
                <InputText type="text" placeholder="Enter NABP Number" />
              </FormItem>

              <FormItem name="nabpEffectiveDate" label="Effective Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Effective Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="nabpExpirationDate" label="Expiration Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Expiration Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

            </div>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '20px' }}>
            {/* First Box */}
            <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
              <h2 style={{ textAlign: 'center', color: 'red' }}>Delegated </h2> {/* Header for first section */}
              <FormItem name="lobId" label="Lob List" rules={[{ required: true }]}>
                <Dropdown
                  options={lobListS}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select Lob List"
                />
              </FormItem>

              <FormItem name="planId" label="Plan" rules={[{ required: true }]}>
                <Dropdown
                  options={yesNoList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select Plan"
                />
              </FormItem>

              <FormItem name="delegatedEffectiveDate" label="Effective Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Effective Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="termDate" label="Term Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Term Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>
              <FormItem name="delegatedServiceId" label="Delegated Service" rules={[{ required: true }]}>
                <Dropdown
                  options={serviceList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>
            </div>

            {/* Second Box */}
            <div style={{ padding: '20px', border: '1px solid #ddd', borderRadius: '8px' }}>
              <h2 style={{ textAlign: 'center', color: 'red' }}>Actions </h2> {/* Header for first section */}
              <FormItem name="dateCredApproved" label="Date Cred Approved" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Date Cred Approved"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="disciplinaryAction" label="Displinary Action" rules={[{ required: true }]}>
                <Dropdown
                  options={disciplinaryActionList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>

              <FormItem name="letterOfCensure" label="Letter Of Censure" rules={[{ required: true }]}>
                <Dropdown
                  options={letterOfCensureList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>

              <FormItem name="malpracticeClaimPending" label="MalPractice Claim Pending" rules={[{ required: true }]}>
                <Dropdown
                  options={malpracticeClaimPendingList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>
              <FormItem name="medicalDirectorApproval" label="Medical Director Approval" rules={[{ required: true }]}>
                <Dropdown
                  options={medicalDirectorApprovalList}
                  optionLabel="key"
                  optionValue="value"
                  showClear
                  placeholder="Select"
                />
              </FormItem>
              <FormItem name="reviewDate" label="Review Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Verification Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>
              <FormItem name="nextReviewDate" label="Next Review Date" rules={[{ required: true }]}>
                <Calendar
                  placeholder="Enter Next Review Date"
                  selectionMode="single"
                  icon="oxalis:icon_today_fill"
                  iconPos="right"
                  dateFormat="mm/dd/yy"
                />
              </FormItem>

              <FormItem name="reviewedBy" label="Reviewed By" rules={[{ required: true }]}>
                <InputText type="text" placeholder="Enter Reviewed By" />
              </FormItem>
            </div>
          </div>
          <div className="flex justify-content-end gap-3 pt-3">

            <Button label="Save" type="submit" />
          </div>
        </CustomForm>
      </div>
    </>
  );
};

export default Credentialing;
