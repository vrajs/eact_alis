import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useState } from "react";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import Calendar from "../../../controls/Calendar";
import InputText from "../../../controls/InputText";
import CustomForm from "../../../controls/CustomForm";

const TimeLinesReports = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [county, setCountyList] = useState(null);
  const countyList = [{ key: "Test", value: "1" }];
  const [state, setStateList] = useState(null);
  const stateList = [
    { key: "AL", value: "1" },
    { key: "AZ", value: "2" },
  ];
  const [enrollmentSource, setEnrollmentSourceList] = useState(null);
  const enrollmentSourceList = [
    { key: "Mail In", value: "1" },
    { key: "Fax", value: "2" },
  ];
  const [contractNumber, setContractNumberList] = useState(null);
  const contractNumberList = [
    { key: "H0002", value: "1" },
    { key: "H0001", value: "2" },
  ];
  const [PBPNumber, setPBPNumberList] = useState(null);
  const PBPNumberList = [
    { key: "02", value: "1" },
    { key: "01", value: "2" },
  ];
  const [memberStatus, setMemberStatusList] = useState(null);
  const memberStatusList = [
    { key: "Active", value: "1" },
    { key: "Pending", value: "2" },
  ];
  const [transactionStatus, setTransactionStatusList] = useState(null);
  const transactionStatusList = [
    { key: "New", value: "1" },
    { key: "Exception", value: "2" },
  ];
  const [snp, setSNPList] = useState(null);
  const snpList = [
    { key: "CSNP", value: "1" },
    { key: "DSNP", value: "2" },
  ];
  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Advance Search</div>
        <div className="flex align-items-center gap-2">
          <Button outlined label="Export" />
          {options.togglerElement}
        </div>
      </div>
    );
  };
  return (
    <>
      <h2 className="pb-4">Dynamic Timeliness Reports</h2>
      <CustomForm form={undefined}>
        <Panel headerTemplate={headerTemplate} toggleable collapsed={true} className="search-panel">
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="enrollmentSource" label="Enrollment Source">
              <Dropdown
                id="enrollmentSource"
                options={enrollmentSourceList}
                value={enrollmentSource}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setEnrollmentSourceList(event.value)}
                multiple
                showHeader
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="state" label="State">
              <Dropdown
                id="state"
                options={stateList}
                value={state}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setStateList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="name" label="Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="memberID" label="Member ID">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="county" label="County">
              <Dropdown
                id="county"
                options={countyList}
                value={county}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setCountyList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="salesAgentID" label="Sales Agent ID">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date From">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="effectiveDate" label="Effective Date To">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="processedDateFrom" label="Processed Date From">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="processedDateTo" label="Processed Date To">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="contractNumber" label="Contract Number">
              <Dropdown
                id="contractNumber"
                options={contractNumberList}
                value={contractNumber}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setContractNumberList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="PBPNumber" label="PBP Number">
              <Dropdown
                id="PBPNumber"
                options={PBPNumberList}
                value={PBPNumber}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setPBPNumberList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="memberStatus" label="Member Status">
              <Dropdown
                id="memberStatus"
                options={memberStatusList}
                value={memberStatus}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setMemberStatusList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="transactionStatus" label="Transaction Status">
              <Dropdown
                id="transactionStatus"
                options={transactionStatusList}
                value={transactionStatus}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setTransactionStatusList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="snp" label="SNP">
              <Dropdown
                id="snp"
                options={snpList}
                value={snp}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setSNPList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="clear" text />
            <Button label="Apply" outlined />
          </div>
        </Panel>
      </CustomForm>

      <div className="pb-4">
        <DataTable
          paginator
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          dataKey="claimId"
          responsiveLayout="scroll"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single"
        >
          <Column field="memberID" header="Member&nbsp;Id" filter sortable />
          <Column field="memberName" header="Member&nbsp;Name" filter sortable />
          <Column field="pbpId" header="PBP&nbsp;ID" filter sortable />
          <Column field="contractId" header="Contract&nbsp;ID" filter sortable />
          <Column field="incompleteReason" header="Incomplete&nbsp;Reason" filter sortable />
          <Column field="effectiveDate" header="Effective&nbsp;Date" filter sortable />
          <Column field="rfiRequestDate" header="RFI&nbsp;Request&nbsp;Date" filter sortable />
          <Column field="rfiDueDate" header="RFI&nbsp;Due&nbsp;Date" filter sortable />
          <Column field="age" header="Age" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default TimeLinesReports;
