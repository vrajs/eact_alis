import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useState } from "react";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import Calendar from "../../../controls/Calendar";
import InputText from "../../../controls/InputText";

const MemberReportsAudit = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row

  const [fieldName, setFieldNameList] = useState(null);
  const fieldNameList = [
    { key: "First Name", value: "1" },
    { key: "Last Name", value: "2" },
  ];

  return (
    <>
      <h2 className="pb-4">Audit Information</h2>
      <Panel header="Advance Search" toggleable collapsed={true} className="search-panel">
        <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
          <FormItem name="mbi" label="MBI">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="memberID" label="Member ID">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="firstName" label="First Name">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="fieldName" label="Field Name">
            <Dropdown
              id="fieldName"
              options={fieldNameList}
              value={fieldName}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setFieldNameList(event.value)}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
          <FormItem name="monthFrom" label="From Date">
            <Calendar
              placeholder="Enter Date"
              selectionMode="single"
              icon="cl_calendar_today_line"
              iconPos="right"
              dateFormat="mm/dd/yy"
              maxDate={new Date()}
            />
          </FormItem>
          <FormItem name="monthTo" label="To Date">
            <Calendar
              placeholder="Enter Date"
              selectionMode="single"
              icon="cl_calendar_today_line"
              iconPos="right"
              dateFormat="mm/dd/yy"
              maxDate={new Date()}
            />
          </FormItem>
        </div>
        <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
          <Button label="clear" text />
          <Button label="Apply" outlined />
        </div>
      </Panel>
      <div className="pb-4">
        <DataTable
          paginator
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          dataKey="claimId"
          responsiveLayout="scroll"
          emptyMessage="No records found."
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single"
        >
          <Column field="modifiedField" header="Modified&nbsp;Field" filter sortable />
          <Column field="mbi" header="MBI" filter sortable />
          <Column field="memberID" header="Member&nbsp;Id" filter sortable />
          <Column field="beforeValue" header="Before&nbsp;Value" filter sortable />
          <Column field="afterValue" header="After&nbsp;Value" filter sortable />
          <Column field="modifiedDate" header="Modified&nbsp;Date" filter sortable />
          <Column field="modifiedBy" header="Modified&nbsp;By" filter sortable />
          <Column field="source" header="Source" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default MemberReportsAudit;
