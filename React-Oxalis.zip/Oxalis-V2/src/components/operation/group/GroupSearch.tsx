import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useEffect, useRef, useState } from "react";
import Button from "../../../controls/Button";
import Dropdown from "../../../controls/Dropdown";
import InputText from "../../../controls/InputText";
import InputNumber from "../../../controls/InputNumber";
import { useNavigate } from "react-router-dom";
import { CodeType, CommonCodeFetchingType } from "../../../data/constants/AppEnum";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import SpecialtyService from "../../../services/SpecialtyService";
import { KeyValueModel } from "../../../model/KeyValueModel";
import { useForm } from "rc-field-form";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import { LazyTableState } from "../../../model/LazyTableState";
import { GridModel } from "../../../model/GridModel";
import { ProviderViewModel } from "../../../model/ProviderViewModel";
import { ProviderService } from "../../../services/ProviderService";
import { paginatorConstants } from "../../../data/constants/PaginatorConstants";
import { GroupSearchModel } from "../../../model/GroupSearchModel";
import * as XLSX from 'xlsx';
import { GroupExportModel } from "../../../model/GroupExportModel";
import { useToaster } from "../../../layout/context/toastContext";
import useQueryBuilder from "../../../hooks/useQueryBuilder";
import useErrorHandler from "../../../hooks/useErrorHandler";
import { useDispatch, useSelector } from "react-redux";
import { RootState } from "../../../Redux/app/store";
import { ClearKey } from "../../../Redux/features/keyboardShortcutSlice";
import ConfirmationDialog from "../../generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";

const GroupSearch = () => {
  const groupTypes = useCommonCodeSubCategory(CodeType.GroupType, CommonCodeFetchingType.Default);
  const { getSpecialtyKeyValues } = SpecialtyService();
  const navigate = useNavigate();
  const [specialtyList, setSpecialityList] = useState<KeyValueModel[]>([]);
  const [totalRecords, setTotalRecords] = useState(0);
  const [gridValues, setGridValues] = useState([]);
  const { getGroupGrid, exportGroup, deleteProvider } = ProviderService();
  const [selectedGroup, setSelectedGroup] = useState<ProviderViewModel | null>(null);
  const [loading, setLoading] = useState(true);
  const [form] = useForm<GroupSearchModel>();
  const ref = useRef<Panel>(null);
  const { showToast } = useToaster();
  const dispatch = useDispatch();
  const { isEdit, isAdd, isExport, isSearch, isDelete } = useSelector((state: RootState) => state.keyboardShortCut);
  const [showConfirm, setShowConfirm] = useState<boolean>(false);

  const handleSelection = (e) => {
    if (e.value) {
      setSelectedGroup(e.value)
    } else {
      setSelectedGroup(null);
    }
  }

  const handleFormError = () => {
    console.log(form.getFieldsError());
  }

  useEffect(() => {
    if (isSearch) {
      ref.current.expand(undefined);
    }
    dispatch(ClearKey());
  }, [isSearch])

  useEffect(() => {
    if (isExport) {
      handleExport();
    }
    dispatch(ClearKey());
  }, [isExport])

  useEffect(() => {
    if (isEdit && selectedGroup) {
      handleEdit();
    }
    dispatch(ClearKey());
  }, [isEdit])

  useEffect(() => {
    if (isAdd) {
      handleAdd();
    }
    dispatch(ClearKey());
  }, [isAdd])

  useEffect(() => {
    if (isDelete) {
      handleDelete();
    }
    dispatch(ClearKey());
  }, [isDelete])

  const [lazyState, setLazyState] = useState<LazyTableState>({
    first: 0,
    rows: 10,
    page: 1,
    sortField: null,
    sortOrder: null,
    filters: undefined
  });

  const handleConfirm = async () => {
    setShowConfirm(false);
    if (selectedGroup) {
      try {
        const deleteResponse = await deleteProvider(selectedGroup.providerID);
        if (deleteResponse) {
          showToast({ severity: 'success', summary: 'Success', detail: "Group deleted successfully" });
          form.resetFields();
          loadLazyData();
          setSelectedGroup(null);
        }
      } catch (error) {
        if (error instanceof Error) {
          const errorMessage = useErrorHandler(error);
          showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
        }
      }
    }
  }

  const handleConfirmCancel = () => {
    setShowConfirm(false);
    setSelectedGroup(null);
  }

  const handleDelete = () => {
    if (selectedGroup) {
      setShowConfirm(true);
    }
  }

  const onPage = (event) => {
    setLazyState(event);
  };

  const onSort = (event) => {
    setLazyState(event);
  };

  const onFilter = (event) => {
    event['first'] = 0;
    setLazyState(event);
  };

  const handleGroupChange = (event) => {
    if (!event.value) {
      form.setFieldValue("providerTypeIDs", null);
    }
  }

  useEffect(() => {
    loadLazyData();
  }, [lazyState]);

  const handleEdit = () => {
    const groupID: number = selectedGroup.providerID;
    navigate(`/group/group-add-edit/${groupID}`);
    dispatch(ClearKey());
  }

  const loadLazyData = async () => {
    ref.current.collapse(undefined)
    const searchForm = form.getFieldsValue(true);
    console.log("searchForm searchForm", searchForm)
    setLoading(true);
    setSelectedGroup(null);
    const query = useQueryBuilder(lazyState);
    console.log("query query", query);

    try {
      const groupGridData: GridModel<ProviderViewModel> = await getGroupGrid(searchForm, query)
      console.log(groupGridData)
      if (groupGridData) {
        setGridValues(groupGridData.data);
        setTotalRecords(groupGridData.totalCount);
        setLoading(false);
      }
    } catch (error) {
      if (error instanceof Error) {
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }

  };

  useEffect(() => {
    dispatch(ClearKey());
    const specialty = getSpecialtyKeyValues();
    Promise.all([specialty]).then((result) => {
      const specialtyResponse = result[0];
      setSpecialityList(specialtyResponse);
    })
    return () => {
      dispatch(ClearKey());
    }
  }, [])

  const handleCancel = () => {
    ref.current.collapse(undefined);
    form.resetFields();
    loadLazyData();
    setSelectedGroup(null);
  }

  const handleExport = async () => {
    const groupData = await exportGroup();
    console.log(" groupDatagroupData", groupData)
    const groups = groupData.map((a: GroupExportModel) => {
      const { providerID: ID, providerCode: Code, fullName, primaryEmail, secondaryEmail, npi: NPI, phone: Phone, fax: Fax } = a;
      return { ID, Code, NPI, 'Group Name': fullName, 'Primary Email': primaryEmail, 'Secondary Email': secondaryEmail, Phone, Fax, }
    })
    // console.log(groupData);
    const ws = XLSX.utils.json_to_sheet(groups);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Group List");
    XLSX.writeFile(wb, "Group.xlsx");
    showToast({ severity: 'success', summary: 'Success', detail: "File downloaded successfully" });
  }

  const handleAdd = () => {
    navigate("/group/group-add-edit");
    dispatch(ClearKey());
  };
  const handleView = (providerID: number) => {
    navigate(`/group/group-view/${providerID}`);
  };
  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;

    return (
      <div className={className}>
        <div className="font-bold">Advance Search</div>
        <div className="flex align-items-center gap-2">
          {/* <Dropdown optionLabel="name" placeholder="Saved Search (0)" filter className="w-full" /> */}
          <Button outlined label="Add" onClick={handleAdd} tooltip="Alt + A" />
          {selectedGroup && <Button outlined label="Edit" onClick={handleEdit} tooltip="Alt + E" />}
          {selectedGroup && <Button outlined label="Delete" onClick={handleDelete} tooltip="Alt + D"/>}
          <Button label="Export" outlined onClick={handleExport} tooltip="Alt + X" />
          {options.togglerElement}
        </div>
      </div>
    );
  };
  return (
    <div className="layout-content">
      <h2 className="pb-4">Group Configuration</h2>
      <Panel toggleable className="m-0 search-panel" headerTemplate={headerTemplate} ref={ref} collapsed>
        <CustomForm form={form} onFinish={loadLazyData} onFinishFailed={handleFormError}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
            <FormItem name="providerTypeIDs" label="Group Type">
              <Dropdown
                id="dropdown"
                options={groupTypes}
                optionLabel="value"
                optionValue="key"
                showClear
                onChange={handleGroupChange}
                placeholder="Select"
                className="w-full"
              />
            </FormItem>

            <FormItem name="providerCode" label="Group Id">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>

            <FormItem name="fullName" label="Group Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>

            {/* rules={[
                { pattern: REGEX_CONSTANTS.NPI_VALIDATOR, message: "NPI is invalid" },
              ]} */}
            <FormItem name="npi" label="NPI" >
              <InputNumber placeholder="Enter here" useGrouping={false} />
            </FormItem>

            {/* <FormItem name="tin" label="TIN">
              <InputNumber placeholder="Enter here" useGrouping={false}/>
            </FormItem> */}

            <FormItem name="specialtyIDs" label="Specialty">
              <Dropdown
                id="Specialty"
                multiple
                showHeader
                options={specialtyList}
                optionLabel="value"
                optionValue="key"
                placeholder="Select Specialty"
                filter
                className="w-full"
              />
            </FormItem>

          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="clear" text onClick={handleCancel} type="button" />
            <Button label="Apply" outlined type="submit" />
            {/* <Button label="Apply & Save" raised onClick={handleFilterSave} /> */}
          </div>
        </CustomForm>
      </Panel>
      <div className="pb-4">
        <DataTable
          paginator
          rowsPerPageOptions={paginatorConstants.pageOptions}
          className="p-datatable-gridlines"
          showGridlines
          rows={lazyState.rows}
          tableStyle={{ minWidth: '50rem' }}
          paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
          currentPageReportTemplate={`${totalRecords > 0 ? (lazyState.first + 1) : totalRecords}  to ${(lazyState.rows + lazyState.first) > totalRecords ? totalRecords : (lazyState.rows + lazyState.first)} of ${totalRecords} records`}
          dataKey="providerID"
          emptyMessage={paginatorConstants.emptyMessage}
          selectionMode="single"
          lazy onPage={onPage}
          onSort={onSort}
          sortOrder={lazyState.sortOrder}
          sortField={lazyState.sortField}
          onFilter={onFilter}
          value={gridValues}
          onSelectionChange={(e) => handleSelection(e)}
          totalRecords={totalRecords}
          first={lazyState.first}
        >
          <Column
            field="providerCode"
            sortable
            header="ID"
            body={(rowData) => (
              <a onClick={() => handleView(rowData.providerID)} className="underline">
                {rowData.providerCode}
              </a>
            )}
          />
          <Column field="fullName" header="Display name" sortable />
          <Column field="phone" header="Phone" sortable />
          <Column field="fax" header="Fax" sortable />
          <Column field="primaryEmail" header="Primary Email" sortable />
          <Column field="secondaryEmail" header="Secondary Email" sortable />
          <Column field="npi" header="NPI" sortable />
        </DataTable>
      </div>

      <ConfirmationDialog
        visible={showConfirm}
        onConfirm={handleConfirm}
        onCancel={handleConfirmCancel}
        message={"Are you sure want to delete this record?"}
        header={"Confirm"} />
    </div>
  );
};

export default GroupSearch;
