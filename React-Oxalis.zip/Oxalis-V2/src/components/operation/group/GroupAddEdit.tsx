import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import GroupDetails from "./GroupDetails";
import { Panel } from "primereact/panel";
import { ProviderViewModel } from "../../../model/ProviderViewModel";
import { ProviderService } from "../../../services/ProviderService";
import { useForm } from "rc-field-form";
import useCommonCodeSubCategory from "../../../hooks/useCommonCodeSubCategory";
import { CodeType, CommonCodeFetchingType, RecordStatus } from "../../../data/constants/AppEnum";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import InputText from "../../../controls/InputText";
import { REGEX_CONSTANTS } from "../../../data/constants/RegexConstants";
import InputNumber from "../../../controls/InputNumber";
import InputMask from "../../../controls/InputMask";
import Button from "../../../controls/Button";
import { InputSwitch } from "primereact/inputswitch";
import { useDispatch, useSelector } from "react-redux";
import { AddProviderData, AddProviderId, ClearProviderData, AddEligibilityDetails } from "../../../Redux/features/providerSlice";
import { ProviderEligibilityModel } from "../../../model/ProviderEligibilityModel";
import ProviderEligibilityService from "../../../services/ProviderEligibilityService";
import EligibilityDetails from "../tabcomponents/EligibilityDetails";
import { RootState } from "../../../Redux/app/store";
import moment from "moment";
import FormListItem from "../../../controls/FormListItem";
import { useToaster } from "../../../layout/context/toastContext";
import useErrorHandler from "../../../hooks/useErrorHandler";
import { ClearKey } from "../../../Redux/features/keyboardShortcutSlice";
import { DropdownChangeEvent } from "primereact/dropdown";


const GroupAddEdit = () => {
  const navigate = useNavigate();
  const dispatch = useDispatch();
  const { groupEditId } = useParams();
  const [providerId, setProviderId] = useState<number>(0);
  const [isSaving, setIsSaving] = useState<boolean>(false);
  const { showToast } = useToaster();
  const [isUpdate, setIsUpdate] = useState<boolean>(false);

  const eligibilityInitValue = {
    providerEligibilityID: 0,
    providerID: providerId,
    effectiveDate: null,
    termDate: null,
    providerEligibilityCode: ""
  }

  const [groupData, setGroupData] = useState<ProviderViewModel>();

  const [form] = useForm<ProviderViewModel>();

  const initialValues: ProviderViewModel = {
    providerID: 0,
    providerTypeID: null,
    providerCode: "",
    title: "",
    lastName: "",
    firstName: "",
    middleName: "",
    suffix: "",
    fullName: "",
    gender: "",
    ssn: "",
    npi: null,
    tin: "",
    phone: "",
    fax: "",
    primaryEmail: "",
    secondaryEmail: "",
    credentialStatusID: 0,
    groupId: "",
    isPCP: false,
    isSpecialist: false,
    isProviderWatch: false,
    isAcceptsMedicaid: false,
    isPerson: false,
    isGroup: false,
    race: 0,
    ethnicity: "",
    maxMemberCount: 0,
    providerEligibilityID: 0,
    effectiveDate: "",
    termReasonId: 0,
    prefix: "",
    providerEligibility: [],
    providerLanguage: []
  }

  const emailValidator = async (rule, value) => {
    if (!value) {
      return Promise.resolve(null);
    }
    const isValid: boolean = REGEX_CONSTANTS.EMAIL.test(value);
    if (!isValid) {
      return Promise.reject("Email is invalid");
    }
    return Promise.resolve(null);
  }

  const { createProvider, updateProvider, providerView, checkNPI } = ProviderService();
  const [eligibilityDetails, setEligibilityDetails] = useState<ProviderEligibilityModel[]>([]);
  const { getEligibilityByProviderId } = ProviderEligibilityService();
  const { isSave, isAdd } = useSelector((state: RootState) => state.keyboardShortCut);

  // const defaultValues = {
  //   ssn: "", race: "", title: "", gender: "", suffix: "", lastName: "", ethnicity: "",
  //   middleName: "", firstName: "", prefix: ""
  // }
  const groupTypes = useCommonCodeSubCategory(CodeType.GroupType, CommonCodeFetchingType.Default);

  const data = [
    { label: "Created by", value: groupData?.createdBy },
    { label: "Created On", value: moment(groupData?.createdDate).format("MM/DD/YYYY") },
    { label: "Last Modified By", value: groupData?.updatedBy ?? "N/A" },
    { label: "Last Modified On", value: groupData?.updatedDate ? moment(groupData.updatedDate).format("MM/DD/YYYY") : "N/A" },
  ];
  const [checked, setChecked] = useState(false);

  const handleNavigate = () => {
    navigate("/group");
  };

  useEffect(() => {
    dispatch(ClearKey());
  }, [isAdd])

  const providerNameValidator = async (rule, value, callback) => {
    if (!REGEX_CONSTANTS.PROVIDER_NAME.test(value)) {
      return Promise.reject("Group Name is invalid");
    }

    return Promise.resolve(null);
  }

  const providerLengthValidator = (rule, value, callback) => {
    if (value?.length > 160) {
      // return Promise.reject("")
      return Promise.reject("Maximum 160 characters allowed");
    }
    return Promise.resolve(null);
  }

  const handleNPICheck = async (rule, value) => {
    const errorMessage = form.getFieldError("npi");
    if (!REGEX_CONSTANTS.NPI_VALIDATOR.test(value)) {
      return Promise.reject("NPI is invalid")
    }
    if (!value || errorMessage.length > 0) {
      return Promise.resolve();
    }
    const npiValidation: boolean = await checkNPI(value, Number(groupEditId) ?? 0);
    if (npiValidation) {
      return Promise.reject("NPI already exists");
    } else {
      return Promise.resolve();
    }
  }

  const handleCancel = () => {
    navigate("/group");
    form.resetFields();
    dispatch(ClearKey());
  }

  const handleSave = async () => {
    const formValues = form.getFieldsValue(true);
    setIsSaving(true);
    // ...defaultValues
    const groupValues: ProviderViewModel = { ...formValues, isGroup: true, recordStatus: RecordStatus.Active, recordStatusChangeComment: RecordStatus[RecordStatus.Active], isProviderAccess: checked };

    const providerEligibility = groupValues.providerEligibility.map((eligibility: ProviderEligibilityModel) => {
      return { ...eligibility, effectiveDate: moment(eligibility.effectiveDate).format("YYYY-MM-DD"), termDate: eligibility.termDate ? moment(eligibility.termDate).format("YYYY-MM-DD") : null };
    })

    console.log("groupValues groupValues", groupValues)

    const groupData = { ...groupValues, providerEligibility }

    try {
      const response = Number(groupEditId) > 0 ? await updateProvider(groupData) : await createProvider(groupData);
      if (response) {
        showToast({ severity: 'success', summary: 'Success', detail: "Group data saved successfully" });
        setIsSaving(false);
        if (!groupEditId) {
          navigate("/group");
        } else {
          setIsUpdate((prevState) => !prevState);
        }
      } else {
        setIsSaving(false);
      }
    }
    catch (error) {
      if (error instanceof Error) {
        setIsSaving(false);
        const errorMessage = useErrorHandler(error);
        showToast({ severity: 'error', summary: 'Error', detail: errorMessage });
      }
    }
    dispatch(ClearKey());
  }

  useEffect(() => {
    if (isSave) {
      handleSave();
      dispatch(ClearKey());
    }
  }, [isSave])

  const handleFinishFail = () => {
    console.log(form.getFieldsError());
    console.log("form values", form.getFieldsValue(true))
  }

  useEffect(() => {
    dispatch(ClearProviderData())
    dispatch(ClearKey());
    return () => {
      dispatch(ClearProviderData())
      dispatch(ClearKey());
    }
  }, []);

  useEffect(() => {
    if (Number(groupEditId) > 0) {
      setProviderId(Number(groupEditId));
      const getByProviderID = providerView(Number(groupEditId));
      const getGroupEligibility = getEligibilityByProviderId(Number(groupEditId));

      form.setFieldValue("providerEligibility", [{ ...eligibilityInitValue }])
      Promise.all([getByProviderID, getGroupEligibility]).then(result => {
        const groupData: ProviderViewModel = result[0];
        const eligibilities: ProviderEligibilityModel[] = result[1].map(eligibility => {
          return { ...eligibility, effectiveDate: moment(eligibility.effectiveDate).toDate(), termDate: eligibility.termDate ? moment(eligibility.termDate).toDate() : null }
        })

        // if (eligibilities.length > 0) {
        //   groupData.providerEligibility = [eligibilities[0]];
        // }

        dispatch(AddEligibilityDetails([eligibilities[0]]))
        // new code
        groupData.providerEligibility = [...eligibilities];
        // form.setFieldValue("providerEligibility", [{...eligibilityInitValue}])
        // new code
        setEligibilityDetails(eligibilities);
        if (groupData) {
          setGroupData(groupData);
        }
        const portalAccess = groupData.isProviderAccess;
        setChecked(portalAccess);
        form.setFieldsValue(groupData);
        dispatch(AddProviderData(groupData))
      })
      dispatch(AddProviderId(groupEditId))
    } else {
      if (providerId == 0) {
        // dispatch(AddEligibilityDetailItem());
        form.setFieldValue("providerEligibility", [{ ...eligibilityInitValue }])
      }

    }
  }, [groupEditId, isUpdate]);

  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;

    return (
      <div className={className}>
        <div className="flex align-items-center gap-2">
          <span className="font-bold">Group Information</span>
        </div>
        <div className="flex align-items-center gap-2">
          <label htmlFor="input-switch">Portal Access</label>
          <InputSwitch id="input-switch" checked={checked} onChange={(e) => setChecked(e.value)} />
          {options.togglerElement}
        </div>
      </div>
    );
  };

  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Group Configuration
      </h2>
      {providerId > 0 && groupData && <div className="card p-4 !mb-4">
        <div className="!grid xl:grid-cols-5 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 !gap-6">
          {data.map((item, index) => (
            <div key={index}>
              <div className="flex flex-nowrap justify-content-between align-items-center border-1 surface-border border-round p-3 cursor-pointer">
                <div className="flex align-items-center">
                  <div className="flex-col">
                    <div className="block text-600 text-overflow-ellipsis overflow-hidden white-space-nowrap text-sm">{item.label}</div>
                    <div className="text-900 font-semibold block">{item.value}</div>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>}
      <Panel header="Group Information" toggleable className="mb-4" headerTemplate={headerTemplate}>
        <CustomForm form={form} onFinish={handleSave} onFinishFailed={handleFinishFail} initialValues={initialValues}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-4">
            <FormItem
              name="providerTypeID"
              label="Group Type"
              rules={[
                { required: true }
              ]}
            >
              <Dropdown
                id="groupType"
                options={groupTypes}
                optionLabel="value"
                optionValue="key"
                showClear
                onChange={(event: DropdownChangeEvent) => form.setFieldValue("providerTypeID", event.value)}
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormListItem
              name="fullName"
              label="Group Name"
              rules={[
                { required: true, message: "Group Name is required" },
                { validator: providerNameValidator, message: "Group Name is invalid" },
                { validator: providerLengthValidator, message: "Maximum 160 characters allowed" },
              ]}
            >
              <InputText id="groupName" type="text" placeholder="Enter here" />
            </FormListItem>
            <FormItem
              name="groupId"
              label="Group Id (Auto Generate)"
            >
              <InputText id="groupId" type="text" placeholder="Enter here" readOnly />
            </FormItem>
            <FormListItem
              name="npi"
              label="NPI"
              rules={[
                { required: true, message: "NPI is required" },
                { pattern: REGEX_CONSTANTS.NPI_VALIDATOR, message: "NPI is invalid" },
                { validator: handleNPICheck, message: "NPI already exists" }
              ]}

            >
              <InputNumber id="NPI" placeholder="Enter here" useGrouping={false} />
            </FormListItem>

            <FormListItem
              name="primaryEmail"
              label="Primary Email"
              rules={[{ validator: emailValidator, message: "Email is invalid" }]}
            >
              <InputText id="primaryEmail" type="email" placeholder="Enter here" />
            </FormListItem>

            <FormListItem
              name="secondaryEmail"
              label="Secondary Email"
              rules={[{ validator: emailValidator, message: "Email is invalid" }]}
            >
              <InputText id="secondaryEmail" type="email" placeholder="Enter here" />
            </FormListItem>

            <FormItem
              name="phone"
              label="Phone"
            >
              <InputMask id="Phone" mask="(999) 999-9999" inputClassName="w-full" placeholder="Enter here" unmask={true} />
            </FormItem>


            <FormItem
              name="fax"
              label="Fax"
            >
              <InputMask id="Fax" mask="999-999-9999" inputClassName="w-full" placeholder="Enter here" unmask={true} />
            </FormItem>

          </div>

          <div className="pb-3">
            <h5 className="border-bottom-1 pb-3 mb-3">Eligibility Details</h5>
            <EligibilityDetails fieldName="providerEligibility" form={form} providerId={providerId} formData={eligibilityDetails} />
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text onClick={handleCancel} type="button" />
            <Button label="Save" raised disabled={isSaving} type="submit" />
          </div>
        </CustomForm>
      </Panel>
      {groupEditId && <GroupDetails />}
    </>
  );
};

export default GroupAddEdit;