import { useEffect, useState } from "react";
import { Panel } from "primereact/panel";
import { TabView, TabPanel } from "primereact/tabview";

// Import tab components
import Alert from "../tabcomponents/Alert";
import Contracts from "../tabcomponents/Contracts";
import EFTInfo from "../tabcomponents/EFTInfo";
import EligibiltyHistory from "../tabcomponents/EligibiltyHistory";
import IPA from "../tabcomponents/IPA";
import Notes from "../tabcomponents/Notes";
import ProviderContract from "../tabcomponents/ProviderContract";
import ProviderLocation from "../tabcomponents/ProviderLocation";
import Reference from "../tabcomponents/Reference";
import Specialty from "../tabcomponents/Speciality";
import Tin from "../tabcomponents/Tin";
import Provider from "../tabcomponents/Provider";
import Location from "../tabcomponents/Location";
import AuditHistory from "../tabcomponents/AuditHistory";

const GroupDetails = () => {
  const items = [
    { label: "Contracts", component: <Contracts /> },
    { label: "Providers", component: <Provider /> },
    { label: "TIN", component: <Tin /> },
    { label: "Specialty", component: <Specialty /> },
    { label: "Locations", component: <Location /> },
    { label: "Alert", component: <Alert /> },
    { label: "Notes", component: <Notes /> },
    { label: "Reference", component: <Reference /> },
    { label: "Eligibility History", component: <EligibiltyHistory /> },
    { label: "ProviderLocation", component: <ProviderLocation isProviderAddEdit={false} /> },
    { label: "ProviderContract", component: <ProviderContract isProviderAddEdit={false} /> },
    { label: "EFTInfo", component: <EFTInfo /> },
    { label: "IPA", component: <IPA /> },
    { label: "Audit History", component: <AuditHistory /> },
  ];

  const [activeIndex, setActiveIndex] = useState(0);

  const handleTabChange = (e) => {
    setActiveIndex(e.index);
  };

  return (
    <div className="pb-4">
      <Panel header="Group Details" toggleable className="custom-tab-menu">
        <TabView scrollable activeIndex={activeIndex} onTabChange={handleTabChange}>
          {items.map((item, index) => (
            <TabPanel key={index} header={item.label}>
              {item.component}
            </TabPanel>
          ))}
        </TabView>
      </Panel>
    </div>
  );
};

export default GroupDetails;
