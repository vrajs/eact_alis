import GroupDetails from "./GroupDetails";
import { useNavigate, useParams } from "react-router-dom";
import ViewForm from "../../../controls/ViewForm";
import { useEffect, useState } from "react";
import { AddProviderId, ClearProviderData } from "../../../Redux/features/providerSlice";
import { useDispatch } from "react-redux";
import { ProviderViewModel } from "../../../model/ProviderViewModel";
import { ProviderService } from "../../../services/ProviderService";
import moment from "moment";


const GroupView = () => {
  const navigate = useNavigate();
  const { groupId } = useParams();
  const dispatch = useDispatch();
  const [providerId, setProviderId] = useState<number>(0);
  const { providerView } = ProviderService();
  const [groupData, setGroupData] = useState<null | ProviderViewModel>(null);
  const data = [
    { label: "NPI", value: groupData?.npi },
    { label: "Primary Email", value: groupData?.primaryEmail },
    { label: "Secondary Email", value: groupData?.secondaryEmail },
    { label: "Phone", value: groupData?.phone },
    { label: "FAX", value: groupData?.fax },
    // { label: "Effective Date", value: groupData?.effectiveDate ? moment(groupData?.effectiveDate).format("MM/DD/YYYY") : "N/A" },
    // { label: "Term Date", value: groupData?.termDate ? moment(groupData?.termDate).format("MM/DD/YYYY") : "N/A" },
  ];

  useEffect(() => {
    if (Number(groupId) > 0) {
      setProviderId(Number(groupId));
      const getByProviderID = providerView(Number(groupId));

      Promise.all([getByProviderID]).then(result => {
        const groupData: ProviderViewModel = result[0];
        setGroupData(groupData);
      })
      dispatch(AddProviderId(groupId))
    }
  }, [groupId]);

  useEffect(() => {
    dispatch(ClearProviderData())
    return () => {
      dispatch(ClearProviderData())
    }
  }, []);

  const handleNavigate = () => {
    navigate("/group");
  };
  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Group Information
      </h2>
      {groupData && <ViewForm header={`${groupData?.providerCode} - ${groupData?.fullName}`} data={data} /> }
      <GroupDetails />
    </>
  );
};

export default GroupView;
