import React, { useState } from "react";
import { Column } from "primereact/column";
import { ColumnGroup } from "primereact/columngroup";
import { Row } from "primereact/row";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import InputText from "../../../controls/InputText";
import { Panel } from "primereact/panel";
import { DataTable } from "primereact/datatable";
import Calendar from "../../../controls/Calendar";

const PremiumAccountSearch = () => {
  const [sales] = useState([
    { invoiceMonth: "January", invoice: 80, invoiceAmount: 80, paidDate: "08-10-2024", payRef: "#", PaidVia: "Cash", PaidAmount: 40 },
    { invoiceMonth: "February", invoice: 64, invoiceAmount: 60, paidDate: "08-10-2024", payRef: "#", PaidVia: "Card", PaidAmount: 40 },
  ]);

  // Calculate total sales and profits for the footer
  const lastYearTotal = sales.reduce((acc, sale) => acc + sale.invoiceAmount, 0);
  const thisYearTotal = sales.reduce((acc, sale) => acc + sale.PaidAmount, 0);

  const headerGroup = (
    <ColumnGroup>
      <Row>
        <Column header="Billed Details" colSpan={3} />
        <Column header="Paid Details" colSpan={4} />
      </Row>
      <Row>
        <Column header="Invoice Month" filter sortable />
        <Column header="Invoice" filter sortable />
        <Column header="Invoice Amount" filter sortable />
        <Column header="Paid Date" filter sortable />
        <Column header="Pay Ref" filter sortable />
        <Column header="Paid Via" filter sortable />
        <Column header="Paid Amount" filter sortable />
      </Row>
    </ColumnGroup>
  );

  const footerGroup = (
    <ColumnGroup>
      <Row>
        <Column footer="Invoice Total" colSpan={2} footerStyle={{ textAlign: "right" }} />
        <Column footer={lastYearTotal} />
        <Column footer="Paid Total" colSpan={3} footerStyle={{ textAlign: "right" }} />
        <Column footer={thisYearTotal} />
      </Row>
    </ColumnGroup>
  );
  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Member ID: </div>
        <div className="flex align-items-center gap-2">
          <Button outlined label="Export" />
          {options.togglerElement}
        </div>
      </div>
    );
  };
  return (
    <>
      <h2 className="pb-4">Premium Account Summary</h2>
      <Panel headerTemplate={headerTemplate} toggleable collapsed={true} className="search-panel">
        <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
          <FormItem name="mbi" label="MBI">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="memberID" label="Member ID">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="invoiceFromDate" label="Invoice From Date">
            <Calendar
              placeholder="Enter Date"
              selectionMode="single"
              icon="cl_calendar_today_line"
              iconPos="right"
              dateFormat="mm/dd/yy"
              maxDate={new Date()}
            />
          </FormItem>
          <FormItem name="invoiceToDate" label="Invoice To Date">
            <Calendar
              placeholder="Enter Date"
              selectionMode="single"
              icon="cl_calendar_today_line"
              iconPos="right"
              dateFormat="mm/dd/yy"
              maxDate={new Date()}
            />
          </FormItem>
        </div>
        <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
          <Button label="clear" text />
          <Button label="Apply" outlined />
        </div>
      </Panel>
      <DataTable
        value={sales}
        className="p-datatable-gridlines"
        showGridlines
        rows={10}
        headerColumnGroup={headerGroup}
        footerColumnGroup={footerGroup}
        columnResizeMode="expand" // Use "expand" or "fit" depending on the behavior you prefer
      >
        <Column field="invoiceMonth" header="Invoice Month" />
        <Column field="invoice" header="Invoice" />
        <Column field="invoiceAmount" header="Invoice Amount" />
        <Column field="paidDate" header="Paid Date" />
        <Column field="payRef" header="Pay Ref" />
        <Column field="PaidVia" header="Paid Via" />
        <Column field="PaidAmount" header="Paid Amount" />
      </DataTable>
    </>
  );
};

export default PremiumAccountSearch;
