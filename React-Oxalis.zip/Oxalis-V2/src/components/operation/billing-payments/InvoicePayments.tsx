import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { Panel } from "primereact/panel";
import { useEffect, useState } from "react";
import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import Calendar from "../../../controls/Calendar";
import InputText from "../../../controls/InputText";
import { useNavigate } from "react-router-dom";

const InvoicePayments = () => {
  const [customers1, setCustomers1] = useState<any>([]);
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [invoiceType, setInvoiceTypeList] = useState(null);
  const invoiceTypeList = [
    { key: "Current", value: "1" },
    { key: "Retro", value: "2" },
  ];
  const [pbpID, setPBPIDList] = useState(null);
  const pbpIDList = [
    { key: "H00002-006", value: "1" },
    { key: "H00002-008", value: "2" },
  ];
  const [planID, setPlanIDList] = useState(null);
  const planIDList = [
    { key: "001", value: "1" },
    { key: "002", value: "2" },
  ];
  // Simulate data fetching with a useEffect
  useEffect(() => {
    const fetchCustomers = async () => {
      try {
        setLoading(true);
        const customerData = [
          {
            mbi: "1N19M19FM83",
            memberID: "47993",
            firstName: "Victoria",
            lastName: "Garcia",
            planID: "H0001-013",
            paidDate: "08-10-2024",
            paidVia: "Online",
            PaidAmount: "5",
          },
        ];
        setCustomers1(customerData);
      } catch (error) {
        console.error("Error fetching customers:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchCustomers();
  }, []);
  const handleNavigate = () => {
    navigate("/operation/member/billing-and-payments/post-member-payments");
  };
  const headerTemplate = (options: any) => {
    const className = `${options.className} justify-content-space-between`;
    return (
      <div className={className}>
        <div className="font-bold">Advance Search</div>
        <div className="flex align-items-center gap-2">
          <Button outlined label="Export" />
          <Button outlined label="Post New Payment" onClick={handleNavigate} />
          {options.togglerElement}
        </div>
      </div>
    );
  };
  return (
    <>
      <h2 className="pb-4">Dynamic Billing Headers</h2>
      <Panel headerTemplate={headerTemplate} toggleable collapsed={true} className="search-panel">
        <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3">
          <FormItem name="planID" label="Plan ID">
            <Dropdown
              id="planID"
              options={planIDList}
              value={planID}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setPlanIDList(event.value)}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
          <FormItem name="mbi" label="MBI">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="memberID" label="Member ID">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="invoiceNumber" label="Invoice Number">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="lastName" label="Last Name">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="firstName" label="First Name">
            <InputText type="text" placeholder="Enter here" />
          </FormItem>
          <FormItem name="monthFrom" label="Month From">
            <Calendar
              placeholder="Enter Date"
              selectionMode="single"
              icon="cl_calendar_today_line"
              iconPos="right"
              dateFormat="mm/dd/yy"
              maxDate={new Date()}
            />
          </FormItem>
          <FormItem name="monthTo" label="Month To">
            <Calendar
              placeholder="Enter Date"
              selectionMode="single"
              icon="cl_calendar_today_line"
              iconPos="right"
              dateFormat="mm/dd/yy"
              maxDate={new Date()}
            />
          </FormItem>
          <FormItem name="pbpID" label="PBP Number">
            <Dropdown
              id="pbpID"
              options={pbpIDList}
              value={pbpID}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setPBPIDList(event.value)}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
          <FormItem name="invoiceType" label="Invoice Type">
            <Dropdown
              id="invoiceType"
              options={invoiceTypeList}
              value={invoiceType}
              optionLabel="key"
              optionValue="value"
              onChange={(event: DropdownChangeEvent) => setInvoiceTypeList(event.value)}
              showClear
              placeholder="Select"
              className="w-full"
            />
          </FormItem>
        </div>
        <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
          <Button label="clear" text />
          <Button label="Apply" outlined />
        </div>
      </Panel>
      <div className="pb-4">
        <DataTable
          value={customers1}
          paginator
          className="p-datatable-gridlines"
          showGridlines
          rows={10}
          dataKey="claimId"
          responsiveLayout="scroll"
          emptyMessage="No records found."
          loading={loading}
          selection={selectedCustomer}
          onSelectionChange={(e) => setSelectedCustomer(e.value)} // Track selected row
          selectionMode="single"
        >
          <Column field="mbi" header="MBI" filter sortable />
          <Column field="memberID" header="Member&nbsp;Id" filter sortable />
          <Column field="firstName" header="First&nbsp;Name" filter sortable />
          <Column field="lastName" header="Last&nbsp;Name" filter sortable />
          <Column field="planID" header="Plan&nbsp;ID" filter sortable />
          <Column field="paidDate" header="Paid&nbsp;Date" filter sortable />
          <Column field="paidVia" header="Paid&nbsp;Via" filter sortable />
          <Column field="PaidAmount" header="Paid&nbsp;Amount" filter sortable />
        </DataTable>
      </div>
    </>
  );
};

export default InvoicePayments;
