import Button from "../../../controls/Button";
import FormItem from "../../../controls/FormItem";
import InputText from "../../../controls/InputText";
import { useNavigate } from "react-router-dom";
import CustomForm from "../../../controls/CustomForm";
import { Panel } from "primereact/panel";
import InputNumber from "../../../controls/InputNumber";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import { useState } from "react";
import Calendar from "../../../controls/Calendar";
import { Sidebar } from "primereact/sidebar";
import NotesAttachment from "../claims/NotesAttachment";

const PostMemberDeatils = () => {
  const navigate = useNavigate();
  const [visibleBottom, setVisibleBottom] = useState(false);
  const [paymentMonth, setPaymentMonthList] = useState(null);
  const paymentMonthList = [
    { key: "January", value: "1" },
    { key: "February", value: "2" },
  ];
  const [paidVia, setPaidVia] = useState(null);
  const paidViaList = [
    { key: "Cheque", value: "1" },
    { key: "Online", value: "2" },
  ];
  const handleNavigate = () => {
    navigate("/operation/member/billing-and-payments/post-member-payments");
  };

  return (
    <>
      <h2 className="pb-4 flex align-center">
        <i className="cl_arrow_left !text-3xl pr-2 cursor-pointer" onClick={handleNavigate}></i>Member Details
      </h2>
      <Panel header="Details" toggleable collapsed={false} className="search-panel">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3 items-center">
            <FormItem name="mbi" label="MBI">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="memberID" label="Member ID">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="lastName" label="Last Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="firstName" label="First Name">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="currentDueAmount" label="Current Due Amount">
              <InputNumber placeholder="Enter here" />
            </FormItem>
            <FormItem name="paymentMonth" label="Payment Month">
              <Dropdown
                id="paymentMonth"
                options={paymentMonthList}
                value={paymentMonth}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setPaymentMonthList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="invoice" label="Invoice">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="paidVia" label="Paid Via">
              <Dropdown
                id="paidVia"
                options={paidViaList}
                value={paidVia}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => setPaidVia(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FormItem name="paidDate" label="Paid Date">
              <Calendar
                placeholder="Enter Date"
                selectionMode="single"
                icon="cl_calendar_today_line"
                iconPos="right"
                dateFormat="mm/dd/yy"
                maxDate={new Date()}
              />
            </FormItem>
            <FormItem name="paidAmount" label="paid Amount">
              <InputNumber placeholder="Enter here" />
            </FormItem>
            <FormItem name="check" label="Check">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="account" label="Account">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="creditCard" label="Credit Card">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
            <FormItem name="onlinePaymentReference" label="Online Payment Reference">
              <InputText type="text" placeholder="Enter here" />
            </FormItem>
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text />
            <Button label="Notes & Attachments" outlined onClick={() => setVisibleBottom(true)} />
            <Button label="Save" raised />
          </div>
        </CustomForm>
      </Panel>
      <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-4/6 text-xl"
        header="Notes"
      >
        <NotesAttachment />
      </Sidebar>
    </>
  );
};

export default PostMemberDeatils;
