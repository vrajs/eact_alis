import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import Button from "../../../controls/Button";
import { useState } from "react";
import { Sidebar } from "primereact/sidebar";
import ClearingFileHistory from "./ClearingFileHistory";

const ClearingHouseList = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row
  const [visibleBottom, setVisibleBottom] = useState(false);

  const headerTemplate = () => {
    return (
      <div>
        <div className="flex align-items-center justify-content-between ">
          <div className="font-bold">Dynamic Table Header</div>
          <div className="flex gap-2">
            <Button outlined label="ACK 999" />
            <Button outlined label="Post" />
            <Button outlined label="277 CA" />
            <Button outlined icon="cl_history" onClick={() => setVisibleBottom(true)} />
            <Button outlined icon="cl_download_fill" />
            <Button outlined icon="cl_delete" />
          </div>
        </div>
      </div>
    );
  };
  const codeData = [
    {
      codesID: 1,
      field: "3266",
      fileName: "testing 837.TXT",
      tradingPartner: "Emdeon",
      payerName: "HPS",
      fileMonth: "April-2024",
      filePath: "Oxalis/Professtional Files/837P/testing 837_20240402142103.TXT",
      x12: "5dc41672-c6c7-438b-bf2c-a5f69e94f475",
      total: "4",
      failed: "1",
      createdDate: "2024-04-02T14:21:53.8Z",
      createdBy: "Vraj.Shah",
      fileStatus: "Success",
      error: "false",
      version: "T-005010X222A1",
    },
  ];
  return (
    <>
      <DataTable
        paginator
        header={headerTemplate}
        className="p-datatable-gridlines"
        showGridlines
        rows={10}
        value={codeData}
        dataKey="codesID"
        emptyMessage="No records found."
        selection={selectedCustomer}
        onSelectionChange={(e) => setSelectedCustomer(e.value)}
        selectionMode="single"
      >
        <Column field="field" header="Field" filter sortable />
        <Column field="fileName" header="File&nbsp;Name" filter sortable />
        <Column field="tradingPartner" header="Trading&nbsp;Partner" filter sortable />
        <Column field="payerName" header="Payer&nbsp;Name" filter sortable />
        <Column field="fileMonth" header="File&nbsp;Month" filter sortable />
        <Column field="filePath" header="File&nbsp;Path" filter sortable />
        <Column field="x12" header="X12_ID" filter sortable />
        <Column field="total" header="Total" filter sortable />
        <Column field="failed" header="Failed" filter sortable />
        <Column field="createdDate" header="Created&nbsp;Date" filter sortable />
        <Column field="createdBy" header="Created&nbsp;By" filter sortable />
        <Column field="fileStatus" header="File&nbsp;Status" filter sortable />
        <Column field="error" header="Error" filter sortable />
        <Column field="version" header="Version" filter sortable />
      </DataTable>
      <Sidebar
        visible={visibleBottom}
        onHide={() => setVisibleBottom(false)}
        baseZIndex={1000}
        position="bottom"
        className="h-4/6 text-xl"
        header="File History : Testing.txt"
      >
        <ClearingFileHistory />
      </Sidebar>
    </>
  );
};

export default ClearingHouseList;
