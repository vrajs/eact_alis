import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import { useState } from "react";

const ClearingFileHistory = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row

  const codeData = [
    {
      codesID: 1,
      serialNumber: "1",
      processSteps: "Apply Basic Validation",
      processedBy: "Vraj",
      processedDate: "02/04/2024",
      status: "Done",
    },
  ];
  return (
    <>
      <DataTable
        paginator
        className="p-datatable-gridlines"
        showGridlines
        rows={10}
        value={codeData}
        dataKey="codesID"
        emptyMessage="No records found."
      >
        <Column field="serialNumber" header="Serial&nbsp;Number" filter sortable />
        <Column field="processSteps" header="Process&nbsp;Steps" filter sortable />
        <Column field="processedBy" header="Processed&nbsp;By" filter sortable />
        <Column field="processedDate" header="Processed&nbsp;Date" filter sortable />
        <Column field="status" header="Status" filter sortable />
      </DataTable>
    </>
  );
};

export default ClearingFileHistory;
