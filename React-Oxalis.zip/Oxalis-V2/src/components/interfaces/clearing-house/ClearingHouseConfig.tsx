import { TabView, TabPanel } from "primereact/tabview";
import ClearingHousingSearch from "./ClearingHouseSearch";
import ClearingHouseList from "./ClearingHouseList";
import ListingMembers from "./ListingMembers";

const ClearHousingConfig = () => {
  return (
    <>
      <h2 className="pb-4">Dynamic Clearing House Header</h2>
      <TabView>
        <TabPanel header="File Listing">
          <ClearingHousingSearch />
          <ClearingHouseList />
        </TabPanel>
        <TabPanel header="Claim Listing">
          <ListingMembers />
        </TabPanel>
      </TabView>
    </>
  );
};

export default ClearHousingConfig;
