import { Panel } from "primereact/panel";
import CustomForm from "../../../controls/CustomForm";
import FormItem from "../../../controls/FormItem";
import Button from "../../../controls/Button";
import { useState } from "react";
import Dropdown from "../../../controls/Dropdown";
import { DropdownChangeEvent } from "primereact/dropdown";
import { FileUpload } from "primereact/fileupload";

const ClearingHousingSearch = () => {
  const [tradingPartner, settradingPartnerList] = useState(null);
  const tradingPartnerList = [
    { key: "HCPCS", value: "1" },
    { key: "POS", value: "2" },
  ];
  return (
    <>
      <Panel header="New Files" toggleable className="search-panel mb-4">
        <CustomForm form={undefined}>
          <div className="!grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-3 sm:grid-cols-2 !gap-6 pb-3 items-end">
            <FormItem name="tradingPartner" label="Trading Partner">
              <Dropdown
                id="tradingPartner"
                options={tradingPartnerList}
                value={tradingPartner}
                optionLabel="key"
                optionValue="value"
                onChange={(event: DropdownChangeEvent) => settradingPartnerList(event.value)}
                showClear
                placeholder="Select"
                className="w-full"
              />
            </FormItem>
            <FileUpload
              mode="basic"
              name="uploadFile"
              maxFileSize={1000000}
              customUpload
              auto={false}
              chooseOptions={{
                label: "Upload",
                icon: "cl_upload_line",
                className: "p-button-sm",
              }}
            />
          </div>
          <div className="flex justify-content-end border-top-1 pt-3 !gap-3">
            <Button label="Cancel" text />
            <Button label="Upload" raised />
          </div>
        </CustomForm>
      </Panel>
    </>
  );
};

export default ClearingHousingSearch;
