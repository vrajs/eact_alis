import { Column } from "primereact/column";
import { DataTable } from "primereact/datatable";
import Button from "../../../controls/Button";
import { useState } from "react";

const ListingMembers = () => {
  const [selectedCustomer, setSelectedCustomer] = useState<any>(null); // State for selected row

  const headerTemplate = () => {
    return (
      <div>
        <div className="flex align-items-center justify-content-end">
          <div className="flex gap-2">
            <Button outlined label="Export" />
          </div>
        </div>
      </div>
    );
  };
  const codeData = [
    {
      codesID: 1,
      fileName: "testing 837.TXT",
      tradingPartner: "Emdeon",
      uploadedDate: "08/20/2024",
      uploadedBy: "Das",
      memberID: "78415",
      name: "Lineitem1, Test P",
      dob: "07/22/1956",
      renderingProvider: "BILASANO, VIVIAN",
      billingProvider: "BCK PRIMCARE DBA VIVIAN BILASANO MD",
      billingNpi: "1154313252",
      billType: "11",
      patientControlNumber: "2024319CHA15908",
      claimNo: "24236E0003",
      billed: "0.1",
      claimStatus: "success",
      claimErrorCount: "0",
      hasError: "No",
    },
  ];
  return (
    <>
      <DataTable
        paginator
        header={headerTemplate}
        className="p-datatable-gridlines"
        showGridlines
        rows={10}
        value={codeData}
        dataKey="codesID"
        emptyMessage="No records found."
        selection={selectedCustomer}
        onSelectionChange={(e) => setSelectedCustomer(e.value)}
        selectionMode="single"
      >
        <Column field="fileName" header="File&nbsp;Name" filter sortable />
        <Column field="tradingPartner" header="Trading&nbsp;Partner" filter sortable />
        <Column field="uploadedDate" header="Uploaded&nbsp;Date" filter sortable />
        <Column field="uploadedBy" header="Uploaded&nbsp;By" filter sortable />
        <Column field="memberID" header="Member&nbsp;ID" filter sortable />
        <Column field="name" header="Name" filter sortable />
        <Column field="dob" header="DOB" filter sortable />
        <Column field="renderingProvider" header="Rendering&nbsp;Provider" filter sortable />
        <Column field="billingProvider" header="Billing&nbsp;Provider" filter sortable />
        <Column field="billingNpi" header="Billing&nbsp;Npi" filter sortable />
        <Column field="billType" header="Bill&nbsp;Type" filter sortable />
        <Column field="patientControlNumber" header="Patient&nbsp;Control&nbsp;Number" filter sortable />
        <Column field="claimNo" header="Claim&nbsp;No" filter sortable />
        <Column field="billed" header="Billed" filter sortable />
        <Column field="claimStatus" header="Claim&nbsp;Status" filter sortable />
        <Column field="claimErrorCount" header="Claim&nbsp;Error&nbsp;Count" filter sortable />
        <Column field="hasError" header="Has&nbsp;Error" filter sortable />
      </DataTable>
    </>
  );
};

export default ListingMembers;
