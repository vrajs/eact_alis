import { Button } from "primereact/button";
import { ConfirmDialog } from "primereact/confirmdialog";

interface ConfirmationDialogProps {
  visible: boolean;
  header?: string;
  onConfirm: () => void;
  onCancel?: () => void;
  message?: JSX.Element | string;
  contentClassName?: string;
  className?: string;
  confirmText?: string;
  cancelText?: string;
  confirmOnly?: boolean;
}

const ConfirmationDialog: React.FC<ConfirmationDialogProps> = ({
  visible = false,
  header,
  onConfirm,
  onCancel,
  message,
  contentClassName,
  className,
  confirmText = "Confirm", // Set default value for confirmText
  cancelText = "Cancel",
  confirmOnly = false,
}) => {
  return (
    <ConfirmDialog
      visible={visible}
      closable={false}
      draggable={false}
      header={header}
      headerClassName={`text-primary font-medium text-xl text-center ${header ? "" : "p-2"}`}
      contentClassName={message ? `${contentClassName}` : "p-0"}
      message={message}
      className={className}
      footer={
        <div className="flex flex-row items-center justify-center !gap-4">
          <Button label={confirmText} type="submit" className="py-2 m-0" aria-label={confirmText} rounded onClick={onConfirm} />
          {!confirmOnly && <Button label={cancelText} type="button" aria-label={cancelText} rounded className="py-2 m-0" outlined onClick={onCancel} />}
        </div>
      }
    ></ConfirmDialog>
  );
};

export default ConfirmationDialog;
