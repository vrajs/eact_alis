import { Button } from "primereact/button";
import { ConfirmPopup, confirmPopup } from "primereact/confirmpopup";
import { Toast } from "primereact/toast";
import React, { useRef } from "react";

interface CustomConfirmPopupProps {
  message: string;
  icon?: string;
  acceptClassName?: string;
  rejectClassName?: string;
  onAccept: () => void;
  onReject?: () => void;
  acceptLabel?: string;
  rejectLabel?: string;
}

const CustomConfirmPopup: React.FC<CustomConfirmPopupProps> = ({
  message,
  acceptClassName = "p-button-primary",
  rejectClassName = "p-button-secondary",
  onAccept,
  onReject,
}) => {
  const toast = useRef<Toast>(null);

  const accept = () => {
    onAccept();
    if (toast.current) {
      toast.current.show({ severity: "info", summary: "Confirmed", detail: "You have accepted", life: 3000 });
    }
  };

  const reject = () => {
    if (onReject) {
      onReject();
    }
    if (toast.current) {
      toast.current.show({ severity: "warn", summary: "Rejected", detail: "You have rejected", life: 3000 });
    }
  };

  const showConfirm = (event: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    confirmPopup({
      target: event.currentTarget,
      message,
      acceptClassName,
      rejectClassName,
      accept,
      reject,
    });
  };

  return (
    <div className="custom-confirm-popup">
      <Toast ref={toast} />
      <ConfirmPopup />
      <Button onClick={showConfirm} label="Delete" className="p-button-danger" />
    </div>
  );
};

export default CustomConfirmPopup;
