// import React from 'react'
// import { DataTableBaseProps, DataTableProps, DataTableValueArray, DataTable as PrimeReactTable } from 'primereact/datatable'
// import { TableColumnModel } from '../../model/TableColumnModel';

// interface PrimeTableProps {
//   primaryKey: string;
//   value: [];
//   onSort: () => void;
//   onPage: () => void;
//   onFilter: () => void;
//   paginator?: boolean;
//   rows: number;
//   selectionMode: "single" | "multiple";
//   // sortOrder: number;
//   sortField: string;
//   onSelectionChange: () => void;
//   totalRecords: number;
//   first: number;
//   columns: TableColumnModel
// }

// const DataTable = ({ primaryKey, value, onSort, onPage, onFilter, paginator = true, rows, selectionMode = "single", sortField, onSelectionChange, totalRecords, first }: PrimeTableProps) => {
//   return (
//     <></>
//     // <PrimeReactTable onFilter={onFilter} dataKey={primaryKey} value={value} onSort={onSort} onPage={onPage}
//     // paginator={paginator} rows={rows} selectionMode={selectionMode} sortField={sortField} onSelectionChange={onSelectionChange} first={first}
//     //   >
//     //     {}
//     // </PrimeReactTable>
//   )
// }

// export default DataTable

import React from 'react'

const DataTable1 = () => {
  return (
    <div>DataTable</div>
  )
}

export default DataTable1