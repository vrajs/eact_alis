import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { getCities, getStates, getZipCodes, getCounties } from "../Redux/features/locationSlice";
import { AppDispatch } from "../Redux/app/store";

const Home = () => {
    const dispatch = useDispatch<AppDispatch>();
    useEffect(() => {
        dispatch(getCities());
        dispatch(getStates());
        dispatch(getZipCodes());
        dispatch(getCounties());
    }, [])

    return <>Hello from Home :-)</>
}

export default Home;