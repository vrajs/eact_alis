import { useEffect } from 'react'
import { useDispatch } from 'react-redux';
import { AddKey, ClearKey, DeleteKey, EditKey, ExportKey, SaveKey, SearchKey } from '../Redux/features/keyboardShortcutSlice';
import { ShortCutKeys } from '../data/constants/AppEnum';

const KeyboardShortcut = ({ children }) => {

  const dispatch = useDispatch();

  useEffect(() => {
    const handleKeyDown = (event) => {
      // if (event.ctrlKey && event.altKey && event.keyCode === 83) {
      if (event.altKey && event.keyCode === ShortCutKeys.S) {
        event.preventDefault();
        dispatch(SaveKey());
      } else if (event.altKey && event.keyCode === ShortCutKeys.E) {
        event.preventDefault();
        dispatch(EditKey());
      } else if (event.altKey && event.keyCode === ShortCutKeys.A) {
        event.preventDefault();
        dispatch(AddKey());
      } else if (event.altKey && event.keyCode === ShortCutKeys.X) {
        event.preventDefault();
        dispatch(ExportKey());
      } else if (event.altKey && event.keyCode === ShortCutKeys.D) {
        event.preventDefault();
        dispatch(DeleteKey());
      } else if (event.altKey && (event.keyCode === 187 || event.keyCode === 107)) {
        event.preventDefault();
        dispatch(SearchKey());
      }
    };

    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      dispatch(ClearKey());
    };
  }, []);

  return <>
    {children}
  </>
}

export default KeyboardShortcut