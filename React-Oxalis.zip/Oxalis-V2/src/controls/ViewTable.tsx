import { Panel } from "primereact/panel";
import { DataTable } from "primereact/datatable";
import { Column } from "primereact/column";

interface ReusablePanelTableProps {
  panelHeader: string;
  value: any[];
  columns: { field: string; header: string }[];
  rows?: number;
  emptyMessage?: string;
  toggleable?: boolean;
}

const PanelTable = ({ panelHeader, value, columns, rows = 10, emptyMessage = "No records found.", toggleable = true }: ReusablePanelTableProps) => {
  return (
    <Panel header={panelHeader} toggleable={toggleable} className="mb-4">
      <DataTable
        value={value}
        paginator
        className="p-datatable-gridlines"
        showGridlines
        rows={rows}
        dataKey="ID"
        responsiveLayout="scroll"
        emptyMessage={emptyMessage}
      >
        {columns.map((col, index) => (
          <Column key={index} field={col.field} header={col.header} filter sortable />
        ))}
      </DataTable>
    </Panel>
  );
};

export default PanelTable;
