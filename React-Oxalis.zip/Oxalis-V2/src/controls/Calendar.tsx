import { CalendarPropsMultiple, CalendarPropsRange, CalendarPropsSingle, Calendar as PrimeCalendar } from "primereact/calendar";
import { FieldProps } from "rc-field-form/es/Field";
import React, { FormEvent, useRef } from "react";

interface BaseCalendarProps extends FieldProps {
  label?: string;
  required?: boolean;
  notAvailableOffline?: boolean;
  icon?: string;
  iconPos?: "left" | "right";
  iconOnly?: boolean;
  iconOnlyWithVerticalYearAndMonth?: boolean;
  selectedDate?: Date;
  onBlur?: () => void;
  onChange?: (event: FormEvent<Date> | string | number | null | undefined) => void;
  labelClassName?: string;
  className?: string;
}

type CalendarProps = BaseCalendarProps & (CalendarPropsSingle | CalendarPropsMultiple | CalendarPropsRange);

const Calendar: React.FC<CalendarProps> = ({
  icon,
  iconPos = "right",
  iconOnly = false,
  iconOnlyWithVerticalYearAndMonth = false,
  selectedDate,
  onChange,
  onBlur,
  ...rest
}) => {
  const calendarRef = useRef<PrimeCalendar>(null);

  const renderVerticalMonthAndYear = () => {
    if (iconOnlyWithVerticalYearAndMonth && selectedDate instanceof Date) {
      return (
        <div onClick={() => calendarRef.current?.focus()} className={`flex flex-col justify-center items-center cursor-pointer`}>
          <div className="text-sm">
            {selectedDate.toLocaleString(undefined, {
              month: "short",
              timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            })}
          </div>
          <div className="text-sm">
            {selectedDate.toLocaleString(undefined, {
              year: "numeric",
              timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
            })}
          </div>
        </div>
      );
    }
    return null;
  };

  const handleChange = (event: any) => {
    const newValue = event.target.value;

    if (onChange) {
      onChange(newValue);
    }
  };

  const handleBlur = () => {
    if (onBlur) {
      onBlur();
    }
  };

  return (
    <div className={`flex flex-col ${iconOnly ? `calendar-with-only-icon` : `gap-2`}`}>
      {/* <label htmlFor={rest.id}>
        {label} {required && <span className="text-danger">*</span>}
      </label> */}
      <div
        className={`${icon ? `input-icon-${iconPos}` : ""} ${iconOnlyWithVerticalYearAndMonth ? "!flex !flex-col !justify-center !items-center vertical-ym" : ""}`}
      >
        <PrimeCalendar ref={calendarRef} {...rest} className="p-inputtext-sm" disabled={rest.disabled} onChange={handleChange} onBlur={handleBlur} />
        {icon ? <i onClick={() => calendarRef.current?.focus()} className={`${icon} cursor-pointer`}></i> : null}
        {renderVerticalMonthAndYear()}
      </div>
    </div>
  );
};

export default Calendar;
