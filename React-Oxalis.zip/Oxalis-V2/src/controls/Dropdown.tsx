import { DropdownProps, Dropdown as PrimeDropdown } from "primereact/dropdown";
import { MultiSelectChangeEvent, MultiSelectProps, MultiSelect as PrimeMultiSelect } from "primereact/multiselect";
import { FieldProps } from "rc-field-form/es/Field";
import React, { useEffect } from "react";
import { KeyValueModel } from "../model/KeyValueModel";

interface BaseProps extends FieldProps {
  label?: string;
  required?: boolean;
  notAvailableOffline?: boolean;
  name?: string;
  inputClassName?: string;
  className?: string;
  onReset?: () => void;
  options?: KeyValueModel[];
  grouped?: boolean;
  groupId?: string;
}

interface DropdownProp extends BaseProps {
  multiple?: false;
  onChange?: (e: any) => void;
  showHeader?: false;
}

interface MultiSelectProp extends BaseProps {
  multiple: true;
  onChange?: (e: any) => void;
  showHeader?: boolean;
}

type Props = (DropdownProp & DropdownProps) | (MultiSelectProp & MultiSelectProps);

const Dropdown: React.FC<Props> = ({ inputClassName, options, onChange, multiple, showHeader = false, grouped, groupId, ...rest }) => {
  const handleChange = (event: any) => {
    if (onChange) onChange(event);
  };

  useEffect(() => {
    if (groupId) {
      const parentDiv = document.getElementById(groupId);
      if (parentDiv) {
        if (grouped) {
          parentDiv.classList.add("feature-not-available-offline");
        } else {
          parentDiv.classList.remove("feature-not-available-offline");
        }
      }
    }
  }, [groupId, grouped]);

  return (
    <div>
      {multiple ? (
        <PrimeMultiSelect
          {...(rest as MultiSelectProps)}
          className={`p-inputtext-sm ${inputClassName}`}
          panelClassName={!showHeader ? "hide-header" : ""}
          disabled={rest.disabled}
          onChange={(e: MultiSelectChangeEvent) => handleChange(e)}
          options={options}
          filter
          //optionLabel="listValue"
          //optionValue="id"
        />
      ) : (
        <PrimeDropdown
          {...(rest as DropdownProps)}
          className={`p-inputtext-sm ${inputClassName}`}
          disabled={rest.disabled}
          onChange={handleChange}
          filter
          options={options}
          // optionLabel="listValue"
          // optionValue="id"
        />
      )}
    </div>
  );
};

export default Dropdown;
