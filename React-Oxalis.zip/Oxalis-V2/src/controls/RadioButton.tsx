import { RadioButton as PrimeRadioButton, RadioButtonChangeEvent, RadioButtonProps } from "primereact/radiobutton";

interface RadioButtonProp extends RadioButtonProps {
  label: string;
  onChange?: (event: RadioButtonChangeEvent) => void;
}

const RadioButton: React.FC<RadioButtonProp> = ({ label, onChange, checked, ...rest }) => {
  const handleChange = (event: RadioButtonChangeEvent) => {
    const newValue = event.target.value;
    if (onChange) {
      onChange(newValue);
    }
  };

  const handleLabelClick = () => {
    const radioElement = document.getElementById(rest.inputId as string);
    if (radioElement) {
      radioElement.click();
    }
  };

  return (
    <>
      <PrimeRadioButton {...rest} onChange={handleChange} checked={checked} disabled={rest.disabled} />
      <label htmlFor={rest.inputId} onClick={handleLabelClick}>
        {label}
      </label>
    </>
  );
};
export default RadioButton;
