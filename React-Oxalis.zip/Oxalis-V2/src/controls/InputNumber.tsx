import { InputNumberProps, InputNumber as PrimeInputNumber } from "primereact/inputnumber";
import { FieldProps } from "rc-field-form/es/Field";
import React, { useEffect } from "react";

interface InputNumberProp extends React.ComponentProps<typeof PrimeInputNumber>, FieldProps {
  label?: string;
  required?: boolean;
  notAvailableOffline?: boolean;
  icon?: string;
  iconPos?: "left" | "right";
  onIconClick?: () => void;
  labelClassName?: string;
  inputClassName?: string;
  className?: string;
  name?: string;
  onReset?: () => void;
  onBlur?: () => void;
  onChange?: (event: InputNumberProps | string | number | null | undefined) => void;
  children?: React.ReactElement;
  grouped?: boolean;
  groupId?: string;
}

const InputNumber: React.FC<InputNumberProp> = ({
  icon,
  iconPos = "right",
  onIconClick,
  inputClassName,
  className,
  onBlur,
  onChange,
  grouped = false,
  groupId,
  ...rest
}) => {
  const iconClassName = onIconClick ? "cursor-pointer" : "";

  const handleChange = (event: InputNumberProps) => {
    const newValue = event.value;
    if (onChange) {
      onChange(newValue);
    }
  };

  const handleBlur = () => {
    if (onBlur) {
      onBlur();
    }
  };

  const handleClick = () => {
    if (onIconClick) {
      onIconClick();
    }
  };

  useEffect(() => {
    if (groupId) {
      const parentDiv = document.getElementById(groupId);
      if (parentDiv) {
        if (grouped) {
          parentDiv.classList.add("feature-not-available-offline");
        } else {
          parentDiv.classList.remove("feature-not-available-offline");
        }
      }
    }
  }, [groupId, grouped]);

  return (
    <div className={`${className}`}>
      <div className={`${icon ? `input-icon-${iconPos}` : ""}`}>
        {icon && <i className={`${icon} ${iconClassName}`} onClick={handleClick}></i>}
        <PrimeInputNumber
          {...rest}
          className={`p-inputtext-sm ${inputClassName}`}
          onChange={handleChange}
          onBlur={handleBlur}
          disabled={rest.disabled}
        />
      </div>
    </div>
  );
};

export default InputNumber;
