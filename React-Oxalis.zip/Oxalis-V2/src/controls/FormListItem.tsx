import { Field } from 'rc-field-form';
import { FieldProps } from 'rc-field-form/es/Field';
import { NamePath, RuleObject, ValidatorRule } from 'rc-field-form/es/interface';
import React, { useState } from 'react'

interface FormListProps extends FieldProps {
  label: string;
  name: NamePath;
  rules?: RuleObject[];
  children: React.ReactElement<any>;
  validateRule?: Partial<ValidatorRule>;
  labelClassName?: string;
  dependencies?: NamePath[];
  validateTrigger?: string | string[] | false;
}

const FormListItem = ({ label, name, rules = [], labelClassName = "font-medium font-base !mb-2", dependencies = [], children, ...rest }: FormListProps) => {
  const getFieldLabel = () => label;
  const [validationMessage, setValidationMessage] = useState<string | undefined>(undefined);

  const setError = (errors: string[]) => {
    if (errors?.length === 0) {
      setValidationMessage(undefined);
    }
    for (let i = 0; i < errors.length; i++) {
      setValidationMessage(errors[0]);
    }
  }

  return (
    <div>
      <Field name={name} rules={rules} validateTrigger="onChange" dependencies={dependencies} preserve={false} {...rest}>
        {(_control, meta, form) => {
          const { value, onChange } = _control;
          const { name: fieldName, errors } = meta;

          setError(errors);
          const hasError = errors.length > 0 || validationMessage !== undefined;

          return (<>
            {label && (
              <label className={`${labelClassName} flex flex-row gap-2 align-items-center`}>
                <span>
                  {getFieldLabel()} {rules && rules.some((rule: RuleObject) => rule.required) && <span className="text-danger">*</span>}
                </span>
              </label>
            )}
            {React.cloneElement(children, {
              onBlur: (e) => {
                if (children.props.onBlur) {
                  children.props.onBlur(e);
                }
                form.validateFields([fieldName]);
              },
              onChange: async (e) => {
                if (children.props.onChange) {
                  children.props.onChange(e);
                }
                await onChange(e);
              },
              value,
            })}
            {hasError && <span className="text-danger text-xs">{validationMessage ?? `${getFieldLabel()} is required.`}</span>}
          </>)
        }}

      </Field>
    </div>
  )
}

export default FormListItem;