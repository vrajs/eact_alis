import { Field } from "rc-field-form";
import { FormInstance, NamePath, RuleObject, ValidatorRule } from "rc-field-form/es/interface";
import React, { useState } from "react";

// check FieldEntity for props and methods


interface FormItemProps {
  label: string;
  name: NamePath;
  rules?: RuleObject[];
  children: React.ReactElement<any>;
  validateRule?: Partial<ValidatorRule>;
  labelClassName?: string;
}

const FieldSample: React.FC<FormItemProps> = ({ label, name, rules, children, validateRule, labelClassName = "font-medium font-base !mb-2" }) => {
  const getFieldLabel = () => label;

  const [validationMessage, setValidationMessage] = useState<string | undefined>(undefined);

  const handleInputChange = (value: any, form: FormInstance<any>, fieldName: any) => {
    console.log("name name", fieldName)
    // if (Array.isArray(fieldName) && value) {
    //   form.setFieldValue([...fieldName], value );
    // } else if ((typeof value !== "object" && value) || !value) {
    //   form.setFieldsValue({ [fieldName]: value });
    // } else if (typeof value === "object" && value?.target?.type === "checkbox") {
    //   form.setFieldsValue({ [fieldName]: value?.checked });
    // } else if (typeof value === "object" && value?.value) {
    //   form.setFieldsValue({ [fieldName]: value?.value });
    // } else if (typeof value === "object" && value?.type !== "change") {
    //   form.setFieldsValue({ [fieldName]: value });
    // }

    if (Array.isArray(fieldName) && value) {
      console.log("working but error is not working")
      // form.setFieldValue([...fieldName], value );
      form.setFieldValue([...fieldName], value);
    } else if ((typeof value !== "object" && value) || !value) {
      console.log(1)
      form.setFieldsValue({ [fieldName]: value });
    } else if (typeof value === "object" && value?.target?.type === "checkbox") {
      console.log(2)
      form.setFieldsValue({ [fieldName]: value?.checked });
    } else if (typeof value === "object" && value?.value) {
      console.log(3)
      form.setFieldsValue({ [fieldName]: value?.value });
    } else if (typeof value === "object" && value?.type !== "change") {
      console.log(4)
      form.setFieldsValue({ [fieldName]: value });
    }

    if (validateRule) {
      validateRule.validator({}, value, (error) => {
        if (error) {
          setValidationMessage(error ?? "Validation error");
        } else {
          setValidationMessage(undefined);
        }
      });
    }

    if (rules) {
      for (const rule of rules) {
        if (rule.required && !value) {
          setValidationMessage(rule.message ? String(rule.message) : `${getFieldLabel()} is required.`);
          return;
        }
        if (rule.whitespace && /^\s+$/.test(value) && value) {
          setValidationMessage(rule.message ? String(rule.message) : `${getFieldLabel()} cannot be empty or contain only whitespace.`);
          return;
        }
        if (rule.min && value && value.length < rule.min) {
          setValidationMessage(rule.message ? String(rule.message) : `Minimum ${rule.min} characters required for ${getFieldLabel()}.`);
          return;
        }
        if (rule.max && value && value.length > rule.max) {
          setValidationMessage(rule.message ? String(rule.message) : `Maximum ${rule.max} characters allowed for ${getFieldLabel()}.`);
          return;
        }
        if (rule.pattern && value && !rule.pattern.test(value)) {
          setValidationMessage(rule.message ? String(rule.message) : `${getFieldLabel()} is invalid.`);
          return;
        }
      }
    }

    setValidationMessage(undefined);
  };

  return (
    <div>
      <Field name={name} rules={rules}>
        {(_control, meta, form) => {
          const { errors, name: fieldName } = meta;
          // Ensure the value is correctly managed by form state and parent state
          const value = form.getFieldValue(fieldName);

          if (value === "" || value === undefined || value === null) {
            setValidationMessage(undefined);
          }
          // if (value != undefined || value != null) {
          //   setValidationMessage(undefined);
          // }

          console.log("errors errors errors", errors);

          const hasError = errors.length > 0 || validationMessage !== undefined;

          return (
            <div>
              {label && (
                <label className={`${labelClassName} flex flex-row gap-2 align-items-center`}>
                  <span>
                    {getFieldLabel()} {rules && rules.some((rule: RuleObject) => rule.required) && <span className="text-danger">*</span>}
                  </span>
                </label>
              )}
              {React.cloneElement(children, {
                onBlur: () => {
                  form.validateFields([fieldName]);
                },
                onChange: (event: React.ChangeEvent<HTMLInputElement>) => {
                  handleInputChange(event, form, fieldName);
                  if (children.props.onChange) {
                    children.props.onChange(event);
                  }
                },
                value: value,
              })}
              {hasError && <span className="text-danger text-xs">{validationMessage ?? `${getFieldLabel()} is required.`}</span>}
            </div>
          );
        }}
      </Field>
    </div>
  );
};

export default FieldSample;
