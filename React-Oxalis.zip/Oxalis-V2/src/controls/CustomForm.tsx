import Form, { FormInstance, FormProps } from "rc-field-form";
import React from "react";
import useDirtyCheck from "./dirty-check/useDirtyCheck";

interface CustomFormProps extends FormProps {
  form: FormInstance;
  children?: React.ReactNode;
  initialValues?: { [key: string]: any };
  validateMessages?: any;
  onFinish?: () => void;
}

const CustomForm: React.FC<CustomFormProps> = ({ initialValues = {}, children, form, validateMessages, onFinish, ...rest }) => {
  const { checkForUnsavedData, resetDirtyCheckStores } = useDirtyCheck(form, initialValues);

  // useEffect(() => {
  //   const handleKeyDown = (event: KeyboardEvent) => {
  //     if (event.ctrlKey && event.key === "s") {
  //       event.preventDefault(); // Prevent default action, if any
  //       if (form) {
  //         form.submit();
  //       }
  //     }
  //   };

  //   window.addEventListener("keydown", handleKeyDown);

  //   return () => {
  //     window.removeEventListener("keydown", handleKeyDown);
  //   };
  // }, [form]);

  return (
    <Form
      {...rest}
      initialValues={initialValues}
      form={form}
      validateMessages={validateMessages}
      onFieldsChange={checkForUnsavedData}
      onFinish={() => {
        onFinish?.();
        resetDirtyCheckStores();
      }}
      className="add-edit-form"
    >
      {children}
    </Form>
  );
};

export default CustomForm;
