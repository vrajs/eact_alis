import { InputTextProps, InputText as PrimeInputText } from "primereact/inputtext";
import { FieldProps } from "rc-field-form/es/Field";
import React, { useEffect } from "react";

interface InputTextProp extends FieldProps, InputTextProps {
  label?: string;
  required?: boolean;
  notAvailableOffline?: boolean;
  labelClassName?: string;
  inputClassName?: string;
  className?: string;
  children?: React.ReactElement;
  onBlur?: () => void;
  onChange?: (event: React.ChangeEvent<HTMLInputElement> | string | number | null | undefined) => void;
  name?: string;
  onReset?: () => void;
  icon?: string;
  iconPos?: "left" | "right";
  onIconClick?: () => void;
  grouped?: boolean;
  groupId?: string;
}

const InputText: React.FC<InputTextProp> = ({
  icon,
  iconPos = "right",
  onIconClick,
  inputClassName,
  className,
  name,
  onChange,
  onBlur,
  grouped = false,
  groupId,
  ...rest
}) => {
  const iconClassName = onIconClick ? "cursor-pointer" : "";

  const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = event.target.value;
    if (onChange) {
      onChange(newValue);
    }
  };

  const handleBlur = () => {
    if (onBlur) {
      onBlur();
    }
  };

  const handleClick = () => {
    if (onIconClick) {
      onIconClick();
    }
  };

  useEffect(() => {
    if (groupId) {
      const parentDiv = document.getElementById(groupId);
      if (parentDiv) {
        if (grouped) {
          parentDiv.classList.add("feature-not-available-offline");
        } else {
          parentDiv.classList.remove("feature-not-available-offline");
        }
      }
    }
  }, [groupId, grouped]);

  return (
    <div className={`${className}`}>
      <div className={`${icon ? `input-icon-${iconPos}` : ""}`}>
        {icon && <i className={`${icon} ${iconClassName}`} onClick={handleClick}></i>}
        <PrimeInputText
          {...rest}
          name={name}
          className={`p-inputtext-sm ${inputClassName}`}
          disabled={rest.disabled}
          onChange={handleChange}
          onBlur={handleBlur}
        />
      </div>
    </div>
  );
};

export default InputText;
