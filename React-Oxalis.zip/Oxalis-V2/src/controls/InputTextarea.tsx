import { InputTextarea as PrimeInputTextarea } from "primereact/inputtextarea";
import { FieldProps } from "rc-field-form/es/Field";
import React from "react";

interface InputTextareaProps extends React.ComponentProps<typeof PrimeInputTextarea>, FieldProps {
  label?: string;
  required?: boolean;
  notAvailableOffline?: boolean;
  name?: string;
  onReset?: () => void;
  children?: React.ReactElement;
}

const InputTextarea: React.FC<InputTextareaProps> = ({ label, required, ...rest }) => {
  return (
    <div className="flex flex-col">
      <label htmlFor={rest.id}>
        {label} {required && <span className="text-danger">*</span>}
      </label>
      <div>
        <PrimeInputTextarea {...rest} className="p-inputtext-sm" disabled={rest.disabled} />
      </div>
    </div>
  );
};

export default InputTextarea;
