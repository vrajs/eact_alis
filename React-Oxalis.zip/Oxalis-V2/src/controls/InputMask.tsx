import { InputMaskChangeEvent, InputMaskProps, InputMask as PrimeInputMask } from "primereact/inputmask";
import { FieldProps } from "rc-field-form/es/Field";
import React, { useEffect } from "react";

interface InputMaskProp extends InputMaskProps, FieldProps {
  label?: string;
  required?: boolean;
  notAvailableOffline?: boolean;
  onChange?: (event: InputMaskChangeEvent | string | number | null | undefined) => void;
  labelClassName?: string;
  inputClassName?: string;
  className?: string;
  icon?: string;
  iconPos?: "left" | "right";
  name?: string;
  onReset?: () => void;
  children?: React.ReactElement;
  onIconClick?: () => void;
  grouped?: boolean;
  groupId?: string;
}

const InputMask: React.FC<InputMaskProp> = ({
  onChange,
  icon,
  iconPos = "right",
  onIconClick,
  inputClassName,
  className,
  grouped = false,
  groupId,
  ...rest
}) => {
  const iconClassName = onIconClick ? "cursor-pointer" : "";

  const handleChange = (event: InputMaskChangeEvent) => {
    const newValue = event.target.value;
    if (onChange) {
      onChange(newValue);
    }
  };

  const handleClick = () => {
    if (onIconClick) {
      onIconClick();
    }
  };

  useEffect(() => {
    if (groupId) {
      const parentDiv = document.getElementById(groupId);
      if (parentDiv) {
        if (grouped) {
          parentDiv.classList.add("feature-not-available-offline");
        } else {
          parentDiv.classList.remove("feature-not-available-offline");
        }
      }
    }
  }, [groupId, grouped]);

  return (
    <div className={`${className}`}>
      {/* <label htmlFor={rest.id} className={`${labelClassName} flex flex-row gap-2 align-items-center`}>
        {label} {required && <span className="text-danger">*</span>}
      </label> */}
      <div className={`${icon ? `input-icon-${iconPos}` : ""}`}>
        {icon && <i className={`${icon} ${iconClassName}`} onClick={handleClick}></i>}
        <PrimeInputMask {...rest} className={`p-inputtext-sm ${inputClassName}`} disabled={rest.disabled} onChange={handleChange} />
      </div>
    </div>
  );
};

export default InputMask;
