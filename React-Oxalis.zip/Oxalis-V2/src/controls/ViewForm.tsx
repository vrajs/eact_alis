import { Panel } from "primereact/panel";

const ViewForm = ({ header, data }) => {
  return (
    <Panel header={header} toggleable className="mb-4">
      <div className="!grid xl:grid-cols-5 lg:grid-cols-4 md:grid-cols-3 sm:grid-cols-2 !gap-6">
        {data.map((item, index) => (
          <div key={index}>
            <div className="flex flex-nowrap justify-content-between align-items-center border-1 surface-border border-round px-3 py-2 cursor-pointer">
              <div className="flex align-items-center">
                <div className="flex-col">
                  <div className="block text-600 text-overflow-ellipsis overflow-hidden white-space-nowrap text-sm">{item.label}</div>
                  <div className="text-900 font-semibold block">{item.value}</div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Panel>
  );
};

export default ViewForm;
