import { Password as PrimeInputPassword } from "primereact/password";
import { FieldProps } from "rc-field-form/es/Field";
import React from "react";

interface PasswordProps extends React.ComponentProps<typeof PrimeInputPassword>, FieldProps {
  label?: string;
  required?: boolean;
  notAvailableOffline?: boolean;
  name?: string;
  onReset?: () => void;
  children?: React.ReactElement;
}

const Password: React.FC<PasswordProps> = ({ label, required, ...rest }) => {
  return (
    <div className="flex flex-col">
      <label htmlFor={rest.id}>
        {label} {required && <span className="text-danger">*</span>}
      </label>
      <div>
        <PrimeInputPassword {...rest} className="p-inputtext-sm w-full" showIcon="cl_eye_fill" hideIcon="cl_eye_off_fill" disabled={rest.disabled} />
      </div>
    </div>
  );
};

export default Password;
