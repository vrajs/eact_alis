import moment from "moment";
import { Button } from "primereact/button";
import { FieldProps } from "rc-field-form/es/Field";
import React, { useEffect, useMemo, useState } from "react";
import { DateTimeConstant } from "../data/constants/DateTimeConstants";

interface DateFormats {
  weekday?: "long" | "short" | "narrow";
  date?: "numeric" | "2-digit";
  month?: "long" | "short" | "narrow" | "numeric" | "2-digit";
  year?: "numeric" | "2-digit";
}

export type WeekStartDay = 0 | 1 | 2 | 3 | 4 | 5 | 6;

interface WeekPickerProps extends FieldProps {
  value?: Date;
  onChange?: (value: Date | undefined) => void;
  dateFormats?: DateFormats;
  prevButtonIcon?: string | JSX.Element;
  prevButtonText?: string;
  nextButtonIcon?: string | JSX.Element;
  nextButtonText?: string;
  weekStartDay?: WeekStartDay;
  enabledDates?: Date[];
  orientation?: "horizontal" | "vertical";
  onWeekChange?: (weekStartDate: Date) => void;
  showTodayButton?: boolean;
  onTodayClick?: () => void;
  notAvailableOffline?: boolean;
}

const WeekPicker: React.FC<WeekPickerProps> = ({
  value,
  onChange,
  dateFormats = {},
  prevButtonIcon,
  prevButtonText,
  nextButtonIcon,
  nextButtonText,
  weekStartDay = 0,
  enabledDates = [],
  orientation = "horizontal",
  onWeekChange,
  showTodayButton = false,
  onTodayClick,
}) => {
  if (weekStartDay !== undefined && (weekStartDay < 0 || weekStartDay > 6)) {
    throw new Error("Invalid weekStartDay value. Value should be between 0 and 6.");
  }

  const [selectedDate, setSelectedDate] = useState<Date | undefined>(value || new Date());
  const today = new Date();

  const getFirstDayOfWeek = (date: Date, startDay: WeekStartDay): Date => {
    const dayOfWeek = date.getDay();
    const diff = date.getDate() - dayOfWeek + (dayOfWeek < startDay ? -7 + startDay : startDay);
    return new Date(date.getFullYear(), date.getMonth(), diff);
  };

  const [currentWeekStart, setCurrentWeekStart] = useState<Date>(getFirstDayOfWeek(selectedDate || new Date(), weekStartDay));

  useEffect(() => {
    setSelectedDate(value || new Date());
    const newWeekStart = getFirstDayOfWeek(value || new Date(), weekStartDay);
    setCurrentWeekStart(newWeekStart);
    if (onWeekChange) {
      onWeekChange(newWeekStart);
    }
  }, [value]);

  const handlePrevWeek = () => {
    const prevWeekStart = new Date(currentWeekStart);
    prevWeekStart.setDate(prevWeekStart.getDate() - 7);
    setCurrentWeekStart(prevWeekStart);
    if (onWeekChange) {
      onWeekChange(prevWeekStart);
    }
  };

  const handleNextWeek = () => {
    const nextWeekStart = new Date(currentWeekStart);
    nextWeekStart.setDate(nextWeekStart.getDate() + 7);
    setCurrentWeekStart(nextWeekStart);
    if (onWeekChange) {
      onWeekChange(nextWeekStart);
    }
  };

  const handleTodayClick = () => {
    const today = new Date();
    setSelectedDate(today);
    const newWeekStart = getFirstDayOfWeek(today, weekStartDay);
    setCurrentWeekStart(newWeekStart);
    if (onChange) {
      onChange(today);
    }
    if (onTodayClick) {
      onTodayClick();
    }
  };

  const currentWeekDates = useMemo(() => {
    const dates: Date[] = [];
    for (let i = 0; i < 7; i++) {
      const newDate: Date = new Date(currentWeekStart);
      newDate.setDate(currentWeekStart.getDate() + i);
      dates.push(newDate);
    }
    return dates;
  }, [currentWeekStart]);

  const isDateDisabled = (date: Date): boolean => {
    if (enabledDates.length > 0) {
      const enabledDateList = enabledDates?.map((a: Date) => {
        return moment(a).format(DateTimeConstant.DF);
      });
      const dateStr = moment(date).format(DateTimeConstant.DF);
      return !enabledDateList.some((enabledDate) => enabledDate === dateStr);
    }

    return false;
  };

  const handleDateClick = (date: Date) => {
    if (isDateDisabled(date)) {
      return;
    }
    setSelectedDate(date);
    if (onChange) {
      onChange(date);
    }
  };

  const options: Intl.DateTimeFormatOptions = {
    weekday: dateFormats.weekday,
    month: dateFormats.month,
    day: dateFormats.date,
  };

  const isSameDate = (date1: Date, date2: Date): boolean => {
    return date1.getFullYear() === date2.getFullYear() && date1.getMonth() === date2.getMonth() && date1.getDate() === date2.getDate();
  };

  const renderVerticalDate = (date: Date) => {
    const weekDate = dateFormats.date ? date.toLocaleDateString("en-US", { day: dateFormats.date }) : "";
    const weekday = dateFormats.weekday ? date.toLocaleDateString("en-US", { weekday: dateFormats.weekday }) : "";
    const month = dateFormats.month ? date.toLocaleDateString("en-US", { month: dateFormats.month }) : "";
    const year = dateFormats.year ? date.toLocaleDateString("en-US", { year: dateFormats.year }) : "";

    return (
      <div className={`flex flex-col items-center leading-normal`}>
        {weekDate && <div className="text-2xl mt-1">{weekDate}</div>}
        {month && <div>{month}</div>}
        {weekday && <div>{weekday}</div>}
        {year && <div>{year}</div>}
      </div>
    );
  };

  const isCurrentWeek = (date: Date): boolean => {
    const today = new Date();
    const currentWeekStart = getFirstDayOfWeek(today, weekStartDay);
    const currentWeekEnd = new Date(currentWeekStart);
    currentWeekEnd.setDate(currentWeekEnd.getDate() + 6);
    return date >= currentWeekStart && date <= currentWeekEnd;
  };

  const showTodayButtonCondition = showTodayButton && ((selectedDate && !isSameDate(selectedDate, today)) || !isCurrentWeek(currentWeekStart));

  return (
    <div className={`week-picker flex flex-row gap-2 items-center`}>
      {(prevButtonIcon || prevButtonText) && (
        <Button
          className={`weekpicker-nav-button ${!prevButtonText ? "!w-6 !h-6 p-0" : ""}`}
          icon={prevButtonIcon as string}
          label={prevButtonText}
          rounded
          aria-label="Previous"
          onClick={handlePrevWeek}
        />
      )}
      <div className="week-days">
        {currentWeekDates.map((date, index) => (
          <div
            key={index}
            className={`day${isSameDate(date, new Date()) ? " today" : ""}${selectedDate && isSameDate(date, selectedDate) ? " selected" : ""}${isDateDisabled(date) ? " disabled" : ""}`}
            onClick={() => handleDateClick(date)}
          >
            {orientation === "vertical" ? renderVerticalDate(date) : <div>{date.toLocaleDateString("en-US", options)}</div>}
          </div>
        ))}
      </div>
      {(nextButtonIcon || nextButtonText) && (
        <Button
          className={`weekpicker-nav-button ${!nextButtonText ? "!w-6 !h-6 p-0" : ""}`}
          icon={nextButtonIcon as string}
          label={nextButtonText}
          rounded
          aria-label="Next"
          onClick={handleNextWeek}
        />
      )}
      {showTodayButtonCondition && (
        <Button className="!h-6 px-3 text-sm font-medium" outlined rounded label="Today" aria-label="Today" onClick={handleTodayClick} />
      )}
    </div>
  );
};

export default WeekPicker;
