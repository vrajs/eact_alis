import { Button as PrimeButton, ButtonProps as PrimeButtonProps } from "primereact/button";
import React, { useEffect } from "react";

interface ButtonProps extends PrimeButtonProps {
  notAvailableOffline?: boolean;
  grouped?: boolean;
  groupId?: string;
}

const Button: React.FC<ButtonProps> = ({ notAvailableOffline, grouped = false, groupId, ...rest }) => {
  useEffect(() => {
    if (groupId) {
      const parentDiv = document.getElementById(groupId);
      if (parentDiv) {
        if (grouped) {
          parentDiv.classList.add("feature-not-available-offline");
        } else {
          parentDiv.classList.remove("feature-not-available-offline");
        }
      }
    }
  }, [groupId, grouped]);

  return notAvailableOffline && !grouped ? (
    <div className={`w-full`}>
      <PrimeButton {...rest} disabled={rest.disabled} className={`${rest.className} ${"cursor-pointer"}`} />
    </div>
  ) : (
    <PrimeButton {...rest} disabled={rest.disabled} className={`${rest.className} ${"cursor-pointer"}`} />
  );
};

export default Button;
