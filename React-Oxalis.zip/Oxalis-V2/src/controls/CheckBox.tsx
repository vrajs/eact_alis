import { CheckboxChangeEvent, CheckboxProps, Checkbox as PrimeCheckbox } from "primereact/checkbox";
import { FieldProps } from "rc-field-form/es/Field";
import React, { useEffect } from "react";

interface CheckboxProp extends FieldProps, CheckboxProps {
  label: string;
  onChange?: (e: CheckboxChangeEvent) => void;
  notAvailableOffline?: boolean;
  grouped?: boolean;
  groupId?: string;
  name?: string;
  onReset?: () => void;
  children?: React.ReactElement;
}

const Checkbox: React.FC<CheckboxProp> = ({ label, onChange, checked, grouped = false, groupId, ...rest }) => {
  const handleChange = (event: CheckboxChangeEvent) => {
    if (onChange) {
      onChange(event);
    }
  };

  useEffect(() => {
    if (groupId) {
      const parentDiv = document.getElementById(groupId);
      if (parentDiv) {
        if (grouped) {
          parentDiv.classList.add("feature-not-available-offline");
        } else {
          parentDiv.classList.remove("feature-not-available-offline");
        }
      }
    }
  }, [groupId, grouped]);

  return (
    <div className={`flex align-items-center checkbox ${checked ? "checkbox-checked" : ""}`}>
      <PrimeCheckbox {...rest} onChange={handleChange} checked={checked} disabled={rest.disabled} className={``} />
      <label htmlFor={rest.inputId} className={`ml-2 ${"cursor-pointer"}`}>
        {label}
      </label>
    </div>
  );
};

export default Checkbox;
