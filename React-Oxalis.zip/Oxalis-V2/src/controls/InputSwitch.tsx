// import { InputSwitchChangeEvent, InputSwitchProps } from 'primereact/inputswitch';
// import { FieldProps } from 'rc-field-form/es/Field';
// import React from 'react'

// interface InputSwitchProp extends FieldProps, InputSwitchProps {
//   checked: boolean;
//   onChange?(event: InputSwitchChangeEvent): void;
//   onBlur?(event: React.FocusEvent<HTMLInputElement>): void;

// const InputSwitch: React.FC<InputSwitchProp> = () => {
//   return (
//     <>
//       <label htmlFor={switchItem.id}>{switchItem.label}</label>
//       <InputSwitch id={switchItem.id} checked={switchItem.state} onChange={(e) => switchItem.setState(e.value)} /> 
//     </>
//   )
// }

// export default InputSwitch