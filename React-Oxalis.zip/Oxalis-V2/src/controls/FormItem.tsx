import { Field } from "rc-field-form";
import { FieldProps } from "rc-field-form/es/Field";
import { FormInstance, NamePath, RuleObject, ValidatorRule } from "rc-field-form/es/interface";
import React, { useState } from "react";

interface FormItemProps extends FieldProps {
  label: string;
  name: NamePath;
  rules?: RuleObject[];
  children: React.ReactElement<any>;
  validateRule?: Partial<ValidatorRule>;
  labelClassName?: string;
}

const FormItem: React.FC<FormItemProps> = ({ label, name, rules, children, validateRule, labelClassName = "font-medium font-base !mb-2" }) => {
  const getFieldLabel = () => label;

  const [validationMessage, setValidationMessage] = useState<string | undefined>(undefined);

  const handleInputChange = (value: any, form: FormInstance<any>) => {
    if (Array.isArray(name) && value) {
      form.setFieldValue([...name], value );
    } else if ((typeof value !== "object" && value) || !value) {
      form.setFieldsValue({ [name]: value });
    } else if (typeof value === "object" && value?.target?.type === "checkbox") {
      form.setFieldsValue({ [name]: value?.checked });
    } else if (typeof value === "object" && value?.value) {
      form.setFieldsValue({ [name]: value?.value });
    } else if (typeof value === "object" && value?.type !== "change") {
      form.setFieldsValue({ [name]: value });
    }

    if (validateRule) {
      validateRule.validator({}, value, (error) => {
        if (error) {
          setValidationMessage(error ?? "Validation error");
        } else {
          setValidationMessage(undefined);
        }
      });
    }

    if (rules) {
      for (const rule of rules) {
        if (rule.required && (value === undefined || value === null || value === '')) {        
          setValidationMessage(rule.message ? String(rule.message) : `${getFieldLabel()} is required.`);
          return;
        }
        if (rule.whitespace && /^\s+$/.test(value) && value) {
          setValidationMessage(rule.message ? String(rule.message) : `${getFieldLabel()} cannot be empty or contain only whitespace.`);
          return;
        }
        if (rule.min && value && value < rule.min) {
          setValidationMessage(rule.message ? String(rule.message) : `Minimum ${rule.min} characters required for ${getFieldLabel()}.`);
          return;
        }
        if (rule.len && value && value?.length > rule.len) {
          setValidationMessage(rule.message ? String(rule.message) : `Maximum ${rule.len} characters required for ${getFieldLabel()}.`);
          return;
        }
        if (rule.max && value && value > rule.max) {
          setValidationMessage(rule.message ? String(rule.message) : `Maximum ${rule.max} characters allowed for ${getFieldLabel()}.`);
          return;
        }
        if (rule.pattern && value && !rule.pattern.test(value)) {
          setValidationMessage(rule.message ? String(rule.message) : `${getFieldLabel()} is invalid.`);
          return;
        }
      }
    }

    setValidationMessage(undefined);
  };

  return (
    <div>
      <Field name={name} rules={rules}>
        {(_control, meta, form) => {
          const { errors } = meta;
          // Ensure the value is correctly managed by form state and parent state
          const value = form.getFieldValue(name);

          if (value === "" || value === undefined || value === null) {
            setValidationMessage(undefined);
          }
          // if (value != undefined || value != null) {
          //   setValidationMessage(undefined);
          // }

          const hasError = errors.length > 0 || validationMessage !== undefined;

          return (
            <div>
              {label && (
                <label htmlFor={name} className={`${labelClassName} flex flex-row gap-2 align-items-center`}>
                  <span>
                    {getFieldLabel()} {rules && rules.some((rule: RuleObject) => rule.required) && <span className="text-danger">*</span>}
                  </span>
                </label>
              )}
              {React.cloneElement(children, {
                onBlur: () => {
                  form.validateFields([name]);
                },
                onChange: (event: React.ChangeEvent<HTMLInputElement>) => {
                  handleInputChange(event, form);
                  if (children.props.onChange) {
                    children.props.onChange(event);
                  }
                },
                value: value,
              })}
              {hasError && <span className="text-danger text-xs">{validationMessage ?? `${getFieldLabel()} is required.`}</span>}
            </div>
          );
        }}
      </Field>
    </div>
  );
};

export default FormItem;
