import { AutoCompleteChangeEvent, AutoCompleteCompleteEvent, AutoCompleteProps, AutoComplete as PrimeAutoComplete } from "primereact/autocomplete";
import { FieldProps } from "rc-field-form/es/Field";
import React, { useEffect, useState } from "react";

interface BaseProps extends FieldProps {
  label?: string;
  required?: boolean;
  notAvailableOffline?: boolean;
  name?: string;
  inputClassName?: string;
  className?: string;
  onReset?: () => void;
  // suggestions?: { key: string; value: string }[];
  grouped?: boolean;
  groupId?: string;
}

interface AutoCompleteProp extends BaseProps {
  onChange?: (value: AutoCompleteChangeEvent) => void;
  onBlur?: (value: string) => void;
  completeMethod?: (e: AutoCompleteCompleteEvent) => void;
}

type Props = AutoCompleteProp & AutoCompleteProps;

const AutoComplete: React.FC<Props> = ({ className, inputClassName, suggestions, onChange, onBlur, completeMethod, grouped, groupId, ...rest }) => {
  const [filteredSuggestions, setFilteredSuggestions] = useState<{ key: string; value: string }[]>([]);

  const handleComplete = (event: AutoCompleteCompleteEvent) => {
    if (completeMethod) {
      completeMethod(event);
    }
    if (event.query.length > 1) {
      const filtered = suggestions?.filter((item) => item.key.toLowerCase().startsWith(event.query.toLowerCase()));
      setFilteredSuggestions(filtered || []);
    } else {
      setFilteredSuggestions([]);
    }
  };

  const handleChange = (event: AutoCompleteChangeEvent) => {
    const value = typeof event.value === "object" ? event.value.key : event.value;
    if (onChange) {
      onChange(value || "");
    }
  };

  const handleBlur = (event: React.FocusEvent<HTMLInputElement>) => {
    const value = event.target.value;
    if (onBlur) {
      onBlur(value);
    }
  };

  useEffect(() => {
    if (groupId) {
      const parentDiv = document.getElementById(groupId);
      if (parentDiv) {
        if (grouped) {
          parentDiv.classList.add("feature-not-available-offline");
        } else {
          parentDiv.classList.remove("feature-not-available-offline");
        }
      }
    }
  }, [groupId, grouped]);

  return (
    <div className={`${className}`}>
      <div className={``}>
        <PrimeAutoComplete
          {...rest}
          className={`p-inputtext-sm ${inputClassName}`}
          disabled={rest.disabled}
          completeMethod={handleComplete}
          suggestions={filteredSuggestions}
          // field="name"
          onChange={handleChange}
          onBlur={handleBlur}
        />
      </div>
    </div>
  );
};

export default AutoComplete;
