import { FormInstance } from "rc-field-form";
// import { useEffect, useRef } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { RootState } from "../../Redux/app/store";
// import { setDirtyCheckForm } from "../../Redux/features/dirtyCheckFormSlice";

const useDirtyCheck = (form: FormInstance, initialValue: object) => {
  // const dispatch = useDispatch();
  // const { isUnSavedFormData } = useSelector((state: RootState) => state.formDirty);
  // const initialValues = useRef<any>({});

  // useEffect(() => {
  //   if (initialValue) {
  //     initialValues.current = initialValue;
  //   }
  // }, [initialValue]);
  // console.log(form);
  // console.log(initialValue);
  const checkForUnsavedData = () => {
    // if (form) {
    //   const currentValues = form.getFieldsValue();
    //   const isDirty = Object.keys(currentValues).some((key) => currentValues[key] !== initialValues.current[key]);
    //   if (isDirty && !isUnSavedFormData) {
    //     dispatch(setDirtyCheckForm({ isUnSavedFormData: true, isOpen: false }));
    //   } else if (!isDirty && isUnSavedFormData) {
    //     dispatch(setDirtyCheckForm({ isUnSavedFormData: false, isOpen: false }));
    //   }
    // }
  };

  const resetDirtyCheckStores = () => {
    // dispatch(setDirtyCheckForm({ isCallSave: false, isUnSavedFormData: false, isCallLogout: false, clickedRoute: null }));
  };

  return { checkForUnsavedData, resetDirtyCheckStores };
};

export default useDirtyCheck;
