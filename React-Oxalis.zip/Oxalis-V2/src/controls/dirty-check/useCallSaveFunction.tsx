// import { useEffect } from "react";
// import { useDispatch, useSelector } from "react-redux";
// import { useNavigate } from "react-router";
// import { RootState } from "../../Redux/app/store";
// import { setDirtyCheckForm } from "../../Redux/features/dirtyCheckFormSlice";

const useCallSaveFunction = (handleSave: any) => {
  // const { isCallSave, isCallLogout, clickedRoute } = useSelector((state: RootState) => state.formDirty);
  // const dispatch = useDispatch();
  // const history = useNavigate();

  // useEffect(() => {
  //   saveData();
  // }, [isCallSave]);
  console.log(handleSave);
  // const saveData = async () => {
  //   // const tempRoute = clickedRoute;
  //   // if (isCallSave || isCallLogout) {
  //   //   const tempIsCallLogout = isCallLogout;
  //   //   // dispatch(setDirtyCheckForm({ isCallSave: false, isCallLogout: false, clickedRoute: null }));
  //   //   await handleSave();
  //   //   if (tempIsCallLogout) {
  //   //     //Need to call logout
  //   //     return history("/#/logout");
  //   //   } else {
  //   //     history(tempRoute);
  //   //   }
  //   // }
  // };

  return {};
};

export default useCallSaveFunction;
