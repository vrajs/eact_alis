import ConfirmationDialog from "../../components/generic-components/pop-ups/confirmation-dialog/ConfirmationDialog";

interface IDirtyCheckModal {
  isConfirmationVisible: boolean;
  handleLeavePageConfirmation: () => void;
  handleStayPageConfirmation: () => void;
}

const DirtyCheckModal = ({ isConfirmationVisible, handleLeavePageConfirmation, handleStayPageConfirmation }: IDirtyCheckModal) => {
  return (
    <ConfirmationDialog
      visible={isConfirmationVisible}
      header="You have unsaved changes"
      confirmText="Leave"
      cancelText="Stay"
      onConfirm={handleLeavePageConfirmation}
      onCancel={handleStayPageConfirmation}
      // onCancel={handleCancelClick}
      // footer={[
      //   <InputControls.CustomButtonWithoutAccess icon="check" onClick={onClickYes} text="Yes" key="yes" />,
      //   <InputControls.CustomButtonWithoutAccess icon="ban" onClick={onClickNo} text="No" key="no" />,
      //   <InputControls.CustomButtonWithoutAccess icon="xmark" onClick={handleCancelClick} text="Cancel" key="cancel" />,
      // ]}
    />
  );
};

export default DirtyCheckModal;
