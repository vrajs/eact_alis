import { RouterProvider } from "react-router";
import "./App.css";
import { AppRouter } from "./core/router/AppRouter";
import { ToastProvider } from "./layout/context/toastContext";
import KeyboardShortcut from "./components/KeyboardShortcut";

const App = () => {
  return (
    <>
      <KeyboardShortcut>
        <ToastProvider>
          <RouterProvider router={AppRouter} />
        </ToastProvider>
      </KeyboardShortcut>
    </>
  );
};

export default App;
