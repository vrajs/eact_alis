import { combineReducers, configureStore } from "@reduxjs/toolkit";
import { persistReducer } from "redux-persist";
import storage from "redux-persist/lib/storage";

import activeSideMenuReducer from "../features/activeSideMenuSlice";
import layoutConfigReducer from "../features/layoutConfigSlice";
import layoutStateReducer from "../features/layoutStateSlice";
import providerSlice from "../features/providerSlice";
import claimSlice from "../features/claimSlice";
import preEnrollmentSlice from "../features/preEnrollmentSlice";
import keyboardShortcutSlice from "../features/keyboardShortcutSlice";
import toasterInfoSlice from "../features/toasterInfoSlice";
import locationReducer from "../features/locationSlice";
import enrollmentSlice from "../features/enrollmentSlice";

const persistConfig = {
  key: "root",
  storage,
};

const reducer = combineReducers({
  // Core application
  layoutConfig: layoutConfigReducer,
  layoutState: layoutStateReducer,
  activeSideMenu: activeSideMenuReducer,
  toaster: toasterInfoSlice,

  // Keyboard shortcut
  keyboardShortCut: keyboardShortcutSlice,


  // Oxalis application  
  provider: providerSlice,
  enrollment: enrollmentSlice,
  preEnrollment: preEnrollmentSlice,
  claim: claimSlice,
  location: locationReducer,
  // enrollment: enrollmentSlice
});

const persistedReducer = persistReducer(persistConfig, reducer);

const store = configureStore({
  reducer: persistedReducer,
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }),
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;

export default store;
