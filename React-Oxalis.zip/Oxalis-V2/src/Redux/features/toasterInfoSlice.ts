import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "../app/store";

export interface IToasterInfo {
  summary: string;
  severity: 'success' | 'info' | 'warn' | 'error' | undefined;
  detail: string;
}

const initialState: IToasterInfo = {
  summary: "",
  severity: undefined,
  detail: "",
};

const toasterInfoSlice = createSlice({
  name: "toasterInfo",
  initialState,
  reducers: {
    SetMessage: (state, action) => {
      state.summary = action.payload?.summary;
      state.severity = action.payload?.severity;
      state.detail = action.payload?.detail;
    },
  },
});

export const { SetMessage } = toasterInfoSlice.actions;

export default toasterInfoSlice.reducer;
