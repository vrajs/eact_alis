import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { LocationStateModel } from "../../model/LocationStateModel";
import HttpClient from "../../utils/http-client";
import { KeyValueModel } from "../../model/KeyValueModel";
import { API_ENDPOINTS } from "../../data/constants/AppConstants";
import { ZipCodeModel } from "../../model/ZipCodeModel";
import { CityModel } from "../../model/CityModel";
import { CountyModel } from "../../model/CountyModel";

const initialState: LocationStateModel = {
  zipCodes: [],
  cities: [],
  counties: [],
  states: []
}

// const { get, getCities, getCounties, getZipCodeState } = ZipCodeService();

export const getCities = createAsyncThunk("location/cities", async () => {
  const citiesLocal: string = localStorage.getItem("cities");
  const cityList = JSON.parse(citiesLocal);
  if (cityList?.length > 0) {
    return cityList;
  }
  const http = new HttpClient();
  const cities = await http.get<CityModel[]>(`${API_ENDPOINTS.ZIP_CODE_CITIES}`);
  localStorage.setItem("cities", JSON.stringify(cities));
  return cities;
})

export const getCounties = createAsyncThunk("location/counties", async () => {
  const countyLocal: string = localStorage.getItem("counties");
  const countyList = JSON.parse(countyLocal);
  if (countyList?.length > 0) {
    return countyList;
  }
  const http = new HttpClient();
  const counties = await http.get<CountyModel[]>(`${API_ENDPOINTS.ZIP_CODE_COUNTIES}`);
  localStorage.setItem("counties", JSON.stringify(counties));
  return counties;
})

export const getZipCodes = createAsyncThunk("location/zipCodes", async () => {
  const zipCodes: string = sessionStorage.getItem("zipCodes");
  if (zipCodes) {
    const zipList = JSON.parse(zipCodes);
    if (zipList?.length > 0) {
      console.log("zipList zipList", zipList)
      return zipList;
    }
  } else {
    const http = new HttpClient();
    const zip = await http.get<ZipCodeModel[]>(`${API_ENDPOINTS.ZIP_CODE}`);
    console.log(zip);
    const localResult = await JSON.stringify(zip);
    console.log("localResult localResult", localResult)
    sessionStorage.setItem("zipCodes", localResult);
    return zip;
  }
})

export const getStates = createAsyncThunk("location/getStates", async () => {
  const states: string = localStorage.getItem("states");
  const statesList = JSON.parse(states);
  if (statesList?.length > 0) {
    return statesList;
  }
  const http = new HttpClient();
  const statesRes = await http.get<KeyValueModel[]>(`${API_ENDPOINTS.ZIP_CODE_STATES}`);
  localStorage.setItem("states", JSON.stringify(statesRes));
  return statesRes;
});

const locationSlice = createSlice({
  name: "location",
  initialState,
  reducers: {
    AddZipCodes: (state, action) => {
      state.zipCodes = action.payload;
    },
    AddCities: (state, action) => {
      state.cities = action.payload
    },
    AddStates: (state, action) => {
      state.states = action.payload
    },
    AddCounties: (state, action) => {
      state.counties = action.payload
    },
    // ClearLocation: (state) => {
    //   state = initialState
    // },
  },
  extraReducers: (builder) => {
    builder.addCase(getCities.fulfilled, (state, action) => {
      state.cities = action.payload
    }),
      builder.addCase(getZipCodes.fulfilled, (state, action) => {
        state.zipCodes = action.payload
      }),
      builder.addCase(getCounties.fulfilled, (state, action) => {
        state.counties = action.payload
      }),
      builder.addCase(getStates.fulfilled, (state, action) => {
        state.states = action.payload
      })
  }
})

export const { AddZipCodes, AddCities, AddStates, AddCounties } = locationSlice.actions;

export default locationSlice.reducer;