import { createSlice } from "@reduxjs/toolkit";
import { ProviderStateModel } from "../../model/ProviderStateModel";

const initialState: ProviderStateModel = {
  providerData: null,
  providerId: 0,
  eligibilityDetails: [],
  providerEligibility: {
    providerEligibilityID: 0,
    providerID: 0,
    effectiveDate: null,
    termDate: null,
    providerEligibilityCode: ""
  },
  updated: false,
}

const providerSlice = createSlice({
  name: "provider",
  initialState,
  reducers: {
    AddProviderData: (state: ProviderStateModel, action) => {
      const { type, payload } = action;
      state.providerData = payload;
    },
    AddProviderId: (state: ProviderStateModel, action) => {
      const { type, payload } = action;
      state.providerId = payload;
    },
    ClearProviderData: (state: ProviderStateModel) => {
      state = {...initialState};
    },
    ProviderUpdated: (state) => {
      state.updated = true;
    },
    ClearUpdate: (state) => {
      state.updated = false;
    },
    ClearEligibilityDetails: (state: ProviderStateModel) => {
      state.eligibilityDetails = [];
    },
    AddEligibilityDetails: (state: ProviderStateModel, action) => {
      const { type, payload } = action;
      state.eligibilityDetails = payload
    },
    AddEligibilityDetailItem: (state: ProviderStateModel) => {
      state.eligibilityDetails.push(initialState.providerEligibility);
    },
    RemoveEligibilityDetailItem: (state: ProviderStateModel, action) => {
      const { type, payload } = action;
      state.eligibilityDetails.pop();
    },
  }
})

export const { AddProviderData, AddProviderId, ClearProviderData, AddEligibilityDetails, AddEligibilityDetailItem, RemoveEligibilityDetailItem, ClearEligibilityDetails, ProviderUpdated, ClearUpdate } = providerSlice.actions;
// export const getProviderId = (state: RootState) => state.provider.providerId;

export default providerSlice.reducer;