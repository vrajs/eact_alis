import { createSlice } from "@reduxjs/toolkit";
import { ClaimStateModel } from "../../model/ClaimStateModel";
import { RootState } from "../app/store";

const initialState: ClaimStateModel = {
  formType: "",
  formTypeID: 0,
  claimNumber: "",
  claimData: null,
  claimHeaderID: 0,
  memberInfo: null,
  providerInfo: null,
  alternatePayee: null,
  splitPayment: null,
  facility: null,
}

const claimSlice = createSlice({
  name: "claim",
  initialState,
  reducers: {
    AddFormTypeDetails: (state: ClaimStateModel, action) => {
      const {type, payload} = action;
      state = {...state, formType: payload.formType, formTypeID: payload.formTypeID};
    },
    ClearClaimDetails: (state: ClaimStateModel) => {
      state = {...initialState};
    },
    AddClaimData: (state: ClaimStateModel, action) => {
      state.claimData = action.payload;
      state.claimNumber = action.payload.claimNumber;
      state.claimHeaderID = action.payload.claimHeaderID;
      state.formTypeID = action.payload.formTypeID;
    },
    AddMemberData: (state, action) => {
      state.memberInfo = action.payload;
    },
    AddProviderData: (state, action) => {
      state.providerInfo = action.payload;
    },
    AddFacilityData: (state, action) => {
      state.facility = action.payload;
    },
    AddAlternatePayee: (state, action) => {
      state.alternatePayee = action.payload;
    },
    AddSplitPayment: (state, action) => {
      state.splitPayment = action.payload;
    }
  }
})

export const { AddFormTypeDetails, ClearClaimDetails, AddClaimData, AddMemberData, AddProviderData, AddAlternatePayee, AddSplitPayment, AddFacilityData } = claimSlice.actions;

export default claimSlice.reducer;