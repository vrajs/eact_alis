import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "../app/store";

const initialState: PreEnrollmentStateViewModel = {
  noteName: '',
  filePreEnroll: null,
  attachmentTypeId: 0
};

const preEnrollmentSlice = createSlice({
  name: "preEnrollment",
  initialState,
  reducers: {
    AddPreEnrollmentData: (state, action) => {
      const { noteName, attachmentTypeId, filePreEnroll } = action.payload;
      state.noteName = noteName;
      state.attachmentTypeId = attachmentTypeId;
      state.filePreEnroll = filePreEnroll;
    }
  }
});

export const { AddPreEnrollmentData } = preEnrollmentSlice.actions;
export const selectPreEnrollmentData = (state: RootState) => state.preEnrollment;

export default preEnrollmentSlice.reducer;

export interface PreEnrollmentStateViewModel {
  noteName: string;
  filePreEnroll: File | null;
  attachmentTypeId: number;
}
