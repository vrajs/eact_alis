import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "../app/store";

interface ActiveMenuModel {
  menuName?: string;
}

const initialState: ActiveMenuModel = {
  menuName: "",
};

const activeSideMenuSlice = createSlice({
  name: "syncLoadingDone",
  initialState,
  reducers: {
    setActiveSideMenu: (state, action) => {
      state.menuName = action.payload?.menuName;
    },
  },
});

export const { setActiveSideMenu } = activeSideMenuSlice.actions;
export const selectActiveSideMenu = (state: RootState) =>
  state.activeSideMenu.menuName;

export default activeSideMenuSlice.reducer;
