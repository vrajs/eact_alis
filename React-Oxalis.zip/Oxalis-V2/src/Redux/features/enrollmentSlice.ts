import { createSlice } from "@reduxjs/toolkit";
import { RootState } from "../app/store";

const initialState: EnrollmentStateModel = {
    dob: null,
    next: false,
    previous: false
};

const enrollmentSlice = createSlice({
    name: "dob",
    initialState,
    reducers: {
        AddDob: (state, action) => {
            state.dob = action.payload; // Directly set dob from payload
        },
        NextTab: (state) => {
            state.next = true
        },
        CancelNextTab: (state) => {
            state.next = false
        },
        PreviousTab: (state) => {
            state.previous = true
        },
        CancelPreviousTab: (state) => {
            state.previous = false
        }
    }
});

export const { AddDob, NextTab, CancelNextTab, PreviousTab, CancelPreviousTab } = enrollmentSlice.actions;
export const selectDob = (state: RootState) => state.enrollment.dob;


export default enrollmentSlice.reducer;

export interface EnrollmentStateModel {
    dob: string;
    next: boolean;
    previous: boolean;
}
