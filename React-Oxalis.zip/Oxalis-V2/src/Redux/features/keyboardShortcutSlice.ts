import { createSlice } from "@reduxjs/toolkit";

interface KeyboardShortCutState {
  isSave: boolean;
  isEdit: boolean;
  isAdd: boolean;
  isExport: boolean;
  isSearch: boolean;
  isDelete: boolean;
}

const initialState: KeyboardShortCutState = {
  isSave: false,
  isEdit: false,
  isAdd: false,
  isExport: false,
  isSearch: false,
  isDelete: false
}

const keyboardShortcutSlice = createSlice({
  name: "keyboardShortCut",
  initialState,
  reducers: {
    SaveKey: (state) => {
      state.isSave = true;
    },
    EditKey: (state) => {
      state.isEdit = true;
    },
    AddKey: (state) => {
      state.isAdd = true;
    },
    ExportKey: (state) => {
      state.isExport = true
    },
    DeleteKey: (state) => {
      state.isDelete = true
    },
    SearchKey: (state) => {
      state.isSearch = true
    },
    ClearKey: (state) => {
      state.isSave = false;
      state.isAdd = false;
      state.isEdit = false;
      state.isExport = false;
      state.isSearch = false;
      state.isDelete = false;
    }
  }
})

export const { SaveKey, EditKey, ClearKey, AddKey, ExportKey, SearchKey, DeleteKey } = keyboardShortcutSlice.actions

export default keyboardShortcutSlice.reducer;
