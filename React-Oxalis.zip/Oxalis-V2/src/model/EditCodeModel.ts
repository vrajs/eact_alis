export interface EditCodeModel {
    editCodeID: number;
    code: string;
    codeName: string;
    defaultOutComeID: number | null;
    defaultOutComeCodeID: number | null;
    effectiveDate: string;
    termDate: string;
    adjudicationLevel: number;
    claimApplyLevel: number;
    priority: number;
    category: string;
    criteriaDescription: string;
    claimAdjudicationDataFetchingTypeID: number;
}