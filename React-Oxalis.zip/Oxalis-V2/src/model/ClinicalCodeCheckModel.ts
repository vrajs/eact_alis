export interface ClinicalCodeCheckModel {
  iD: number;
  clinicalCodeTypeID: number;
  code: string;
  recordStatus: number;
  effectiveDate: string;
  termDate: string;
  sequenceNumber: number;
  shortDescription?: string | null;
}