export interface ClaimProcessingStepsViewModel {
  claimProcessingStepsID: number;
  claimHeaderID: number;
  claimDetailLine: number;
  processDate: string;
  processStep: string;
  processValue: string;
  createdDate: string;
}