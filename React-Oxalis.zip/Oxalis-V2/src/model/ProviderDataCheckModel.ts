export interface ProviderDataCheckModel {
  providerID: number;
  providerCode: string;
  recordStatus: number;
  effectiveDate: string;
  termDate: string;
}