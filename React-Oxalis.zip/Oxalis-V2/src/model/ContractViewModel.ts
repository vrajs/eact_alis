export interface ContractViewModel {
  contractHeaderID: number;
  contractCode: string;
  contractName: string;
  contractDescription: string;
  claimType: string;
  capitationName: string;
  anesConversionFactorCode: string;
  effectiveDate: string;
  termDate: string;
  recordStatus: number;
}