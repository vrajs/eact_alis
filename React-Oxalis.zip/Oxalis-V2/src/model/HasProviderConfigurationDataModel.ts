export interface HasProviderConfigurationDataModel {
  hasEligigbilityData: boolean;
  hasSpecialtyData: boolean;
  hasReferenceData: boolean;
  hasNotesData: boolean;
  hasProviderLocationData: boolean;
  hasProviderContractData: boolean;
}