export interface MemberProviderDataModel {
  label: string;
  value: string | null;
  name: string;
  format?: boolean;
}