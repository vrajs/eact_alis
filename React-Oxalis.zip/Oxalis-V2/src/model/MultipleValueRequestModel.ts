export interface MultipleValueRequestModel {
  codeTypeIds: number[];
  fetchingTypeId: number;
}
