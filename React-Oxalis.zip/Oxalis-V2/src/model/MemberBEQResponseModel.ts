import { BaseModel } from "./ProviderModel";

export interface MemberBEQResponseModel extends BaseModel {

    memberEnrollmentHeaderId: number;
    trackingId: string;
    applicationStatusId: number | null;
    attachmentTypeId: number | null;
    attachmentTypeName: string | null;
    memberId: number;
    mbi: string;
    firstName: string;
    lastName: string;
    middleInitial: string;
    dob: Date;
    genderId: number | null;
    permanentAddressCity: string;
    permanentAddressState: string;
    permanentAddressZip: string;
    permanentAddressCounty: string;
    permanentStateAndCountyCode: string;
    medicarePartAEffectiveDate: Date | string | null;
    medicarePartBEffectiveDate: Date | string | null;
    isEsrd: boolean | null;
    isEnrolledInStateMedicaId: boolean | null;
    isEghp: boolean | null;
    receiptDate: Date | string | null;
    memberMedicarePartAEffectiveDate: Date | string | null;
    memberMedicarePartBEffectiveDate: Date | string | null;
    notes: string;
    memberEnrollmentHeaderAttachment: OtherDocument[];
    enrollmentHeaderAttachment: File[];


}
export interface OtherDocument {
    DocumentId: number;
    MemberID: number;
    DocumentName: string;
    DocumentContent: string;
    ContentType: string;
    IsDeleted: number;
    UpdatedDate: Date;
    UpdatedBy: string;
    CreatedDate: Date;
    CreatedBy: string;
    AttachmentType: string;
    FolderName: string;
}