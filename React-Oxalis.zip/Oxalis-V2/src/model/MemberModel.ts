
export interface MemberModel {
    memberId: number;
    memberCode: string;
    familyCode: string;
    prefix: string;
    memberName: string;
    lastName: string;
    firstName: string;
    middleName: string;
    suffix: string;
    displayName: string;
    previousName: string;
    genderId: number;
    dob: Date;
    ssn: string;
    relationshipId: number;
    primaryLanguageId: number;
    secondaryLanguageId: number;
    isDeceased: boolean;
    deceasedDate: Date;
    deceasedReason: string;
    maritalStatusId: number;
    residingAtId: number;
    raceId: number;
    ethnicityId: number;
    primaryEmail: string;
    secondaryEmail: string;
    isHippaEmail: boolean;
    isHippaMail: boolean;
    isHippaText: boolean;
    isHippaVoiceMessage: boolean;
    isAdvanceDirective: boolean;
    studentStatusId: number;
    employeeStatusId: number;
    isHandicap: boolean;
    isTestMember: boolean;
    isExcludeFromClaimEditing: boolean;
    medicareNumber: string;
    medicaidNumber: string;
    memberContactId: number;
    memberEligibilityId: number;
    memberPCPId: number;
    recordStatus: number;
    isFreezed: number;
    recordStatusChangeComment: string;
    createdBy: string;
    createdDate: Date;
    updatedBy: string;
    updatedDate: Date;
    addedSource: string;
    updatedSource: string;
    loadComment: string;
    hippaCommunication: Array<number>;
    employeeStatusValue: string;
    ethnicityValue: string;
    genderValue: string;
    maritalStatusValue: string;
    raceValue: string;
    residingAtValue: string;
    studentStatusValue: string;
    primaryLanguageValue: string;
    secondaryLanguageValue: string;
    relationshipValue: string;
    planName: string;
    pcpName: string;
    maskedSSN: string;
    effectiveDate?: Date;
    termDate?: Date;
    riskType?: string;
    familyId: number;
    selfMemberId: number;
    selfMemberCode: string;
    memberEligibilityInfo: MemberEligibilityModel;



}
export interface BaseModel {

    recordStatus: number;
    isFreezed: number;
    recordStatusChangeComment: string;

    createdBy: string;
    createdDate: Date;

    updatedBy?: string;
    updatedDate?: Date | null | undefined;


}
export interface GetPlanModel {
    healthPlanID: number;
    planCode: string;
    planName: string;
    lob: string;
    pbpCode: string;
    productType: string;
    state: string;
    county: string;
    company: string;
    subCompany: string;
    effectiveDate: Date;
    termDate: Date;
    approvalDate: Date;
    approvalStatus: string;
    recordStatus: number;
    lobID: number;
}

export interface MemberEligibilityModel extends BaseModel {
    memberEligibilityID: number;
    memberID: number;
    company: string;
    companyID: number;
    subCompanyID: number;
    subCompany: string;
    lobid: number;
    lob: string;
    healthPlanID: number;
    healthPlan: string;
    coverageTypeID: number;
    coverageType: string;
    insuranceMemberCode: string;
    policyNumber: string;
    groupName: string;
    riskTypeID: number;
    riskType: string;
    effectiveDate: Date;
    termDate?: Date;
    disenrollmentReasonID?: number;
    disenrollmentReason: string;
    healthPlanInfo?: GetPlanModel

    productType?: string;
    pbp?: string;
    memberCode?: string;
    memberName?: string;
    relationship?: string;

}
