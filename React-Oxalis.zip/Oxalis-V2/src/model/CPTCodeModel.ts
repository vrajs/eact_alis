export interface CPTCodeModel {
  cPTCodeID: number;
  code: string;
  homeGrown: string;
  shortDescription: string;
  longDescription: string;
  sequenceNumber: number;
  clinicalCodeTypeID: number;
  effectiveDate: string;
  termDate: string | null;
  gender: string;
  clinicalCodeType: string;
  clinicalCodeTypeName: string;
  isFreezed: number;
}