export interface MemberLookupSearchModel {
  memberCode: string
  firstName: string
  lastName: string
  dob: string
  pcpName: string
  planID: number
  effectiveDate: string
  relationshipID: number
  mediCareMediCaidID: string
}
