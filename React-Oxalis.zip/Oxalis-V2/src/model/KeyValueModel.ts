export interface KeyValueModel {
  key: string | number;
  value: string | number;
}

export interface DropdownOptions {
  name: string;
  key: number | string;
}