export interface LocationSearchModel {
  officeName?: string | null;
  addressType?: number | null;
}