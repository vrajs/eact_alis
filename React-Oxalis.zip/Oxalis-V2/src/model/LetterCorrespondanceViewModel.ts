import { PlaceHolderReplaceViewModel } from "./PlaceHolderReplaceViewModel";

export interface LetterCorrespondanceViewModel {
    letterCorrespondanceId: number;
    letterTypeId: number | null;
    memberId: number | null;
    letterGenerationDate: string | null;
    letterMailDate: string | null;
    responseDueDate: string | null;
    updatedDate: string | null;
    updatedBy: string;
    createdDate: string | null;
    comments: string;
    createdBy: string;
    mBI: string;
    source: string;
    folderName: string;
    letterTypeName: string;
    placeHolderReplaceViewModel: PlaceHolderReplaceViewModel;
}