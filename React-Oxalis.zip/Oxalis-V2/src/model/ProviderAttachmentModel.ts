export interface ProviderAttachmentModel {
  providerAttachmentID: number;
  comments: string;
}