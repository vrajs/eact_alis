export interface DRGCodeModel {
  dRGCodeID: number;
  code: string;
  homeGrown: string;
  majorCategory: string;
  dRGType: string;
  shortDescription: string;
  longDescription: string;
  sequenceNumber: number;
  clinicalCodeTypeID: number;
  effectiveDate: string;
  termDate: string | null;
  clinicalCodeType: string;
  clinicalCodeTypeName: string;
  isFreezed: number;
}