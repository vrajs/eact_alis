export interface BillTypeCodeModel {
  billTypeCodeID: number;
  clinicalCodeTypeID: number;
  code: string;
  shortDescription: string;
  sequenceNumber: number;
}