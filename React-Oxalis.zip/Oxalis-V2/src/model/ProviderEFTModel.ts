export interface ProviderEFTViewModel {
  providerEFTID: number;
  providerID: number;
  accountTypeID: number;
  accountTypeName: string;
  bankName: string;
  nameOnAccount: string;
  accountNumber: string;
  routing: string;
  effectiveDate: string | Date ;
  termDate: string | null | Date;
}