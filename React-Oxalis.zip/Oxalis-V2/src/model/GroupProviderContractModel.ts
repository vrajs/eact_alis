export interface GroupProviderContractModel {
  groupProviderContractID: number;
  providerRelationID: number | null;
  providerContractID: number;
  providerID: number;
  providerName: string;
  groupID: number | null;
  groupProviderName: string;
  contractHeaderID: number;
  contractHeaderName: string;
  providerStatusName: string;
  lOBNames: string;
  effectiveDate: string;
  termDate: string | null | Date | undefined;
  groupContractEffectiveDate: string;
  groupContractTermDate: string | null;
  isIndividual: boolean;
}
export interface ProviderContractViewModel {
  groupProviderContractId: number;
  providerRelationId: number;
  providerContractID: number;
  providerId: number;
  providerName: string;
  groupId: number | null;
  groupProviderName: string;
  contractHeaderId: number;
  contractHeaderName: string;
  providerStatusName: string;
  lobNames: string;
  effectiveDate: Date;
  termDate: Date | null | undefined;
}