import { CityModel } from "./CityModel";
import { CountyModel } from "./CountyModel";
import { KeyValueModel } from "./KeyValueModel";
import { ZipCodeModel } from "./ZipCodeModel";

export interface LocationStateModel {
  zipCodes: Array<ZipCodeModel>;
  cities: Array<CityModel>;
  states: Array<KeyValueModel>;
  counties: Array<CountyModel>;
}