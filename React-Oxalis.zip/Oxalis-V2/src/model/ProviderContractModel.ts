import { LobModel } from "./LobModel";
import { ProviderContractInterestModel } from "./ProviderContractInterestModel";
import { ProviderContractLobModel } from "./ProviderContractLobModel";
import { ProviderContractTimelyFilingModel } from "./ProviderContractTimelyFilingModel";

export interface ProviderContractModel {
    providerContractID: number;
    providerID: number;
    providerName: string;
    contractHeaderID: number;
    contractHeaderName: string;
    providerStatusID: number;
    providerStatusName: string;
    isCapitated: boolean;
    modifierDiscountGroupID: number | null;
    modifierDiscountGroupName: string;
    feeScheduleHeaderID: number | null;
    feeScheduleHeaderCode: string;
    networkID: number | null;
    networkName: string;
    isExcludeFromSequestration: boolean;
    effectiveDate: string;
    termDate: string | null;
    lobIds: LobModel[];
    lOBNames: string;
    providerContractLob: ProviderContractLobModel[];
    interestQuickPayIds: number[];
    interestQuickPayNames: string;
    providerContractInterest: ProviderContractInterestModel[];
    timelyFilingIds: number[];
    timelyFilingNames: string;
    providerContractTimelyFiling: ProviderContractTimelyFilingModel[];
}