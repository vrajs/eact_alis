export interface CountyModel {
  county: string;
  recordStatus: number;
  state: string;
}