export interface ClaimProviderSearchModel {
  providerFirstName: string | null;
  providerLastName: string | null;
  providerNPI: string | null;
  tin: string | null;
  vendor: string | null;
}