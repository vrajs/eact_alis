export interface FacilityLookUpModel {
  facilityID: number;
  facilityCode: string;
  facilityFirstName: string;
  facilityLastName: string;
  facilityName: string;
  facilityNPI: string;
  vendorName: string;
  tIN: string;
  effectiveDate: string | null;
  termDate: string | null;
  facilityEligibilityID: number | null;
  recordStatus: number | null;
  groupEffectiveDate: string | null;
  groupTermDate: string | null;
  groupEligibilityID: number | null;
  groupRecordStatus: number | null;
  pREffectiveDate: string | null;
  pRTermDate: string | null;
  providerRelationID: number | null;
  pRRecordStatus: number | null;
  groupID: number | null;
  vendorID: number | null;
}

export interface FacilitySearchModel {
  firstName?: string | null;
  lastName?: string | null;
  vendorName?: string | null;
  npi?: number | string | null;
  tin?: number | string | null;
}