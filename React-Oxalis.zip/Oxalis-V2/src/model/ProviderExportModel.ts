export interface ProviderExportModel {
  providerID: number;
  providerCode: string;
  lastName: string;
  firstName: string;
  npi: string;
  middleName: string;
  fullName: string;
  primaryEmail: string;
  secondaryEmail: string;
  phone: string;
  fax: string;
  providerType: string;
}