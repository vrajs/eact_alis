export interface ClaimNotesViewModel {
  claimNotesID: number;
  claimHeaderID: number;
  memberID: number;
  shortDesc: string;
  longDesc: string;
  noteDate: string | Date;
  effectiveDate: string | Date;
  termDate: string | null | Date;
  userInitials: string;
  addedSource: string;
  url: string;
}