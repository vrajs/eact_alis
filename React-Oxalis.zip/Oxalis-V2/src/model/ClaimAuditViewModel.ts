export interface ClaimAuditViewModel {
  claimAuditID: number;
  claimHeaderID: number;
  actionID: number;
  userInitials: string;
  actionDescription: string;
  createdDate: string;
}