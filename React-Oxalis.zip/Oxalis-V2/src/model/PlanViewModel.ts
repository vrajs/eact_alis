export interface PlanViewModel {
  healthPlanID: number;
  planCode: string;
  planName: string;
  lOB: string;
  pBPCode: string;
  productType: string;
  state: string;
  county: string;
  company: string;
  subCompany: string;
  effectiveDate: string;
  termDate: string | null;
  approvalDate: string | null;
  approvalStatus: string;
  recordStatus: number;
  lobID: number;
  lobRecordStatus: number;
  subCompanyRecordStatus: number;
  companyRecordStatus: number;
}