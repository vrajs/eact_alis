export interface OtherNote {
    NoteId: number;
    MemberID: number;
    Name: string;
    IsDeleted: number;
    UpdatedDate: Date;
    UpdatedBy: string;
    CreatedDate: Date;
    CreatedBy: string;
}