import { ProviderEligibilityModel } from "./ProviderEligibilityModel";
import { ProviderLanguageModel } from "./ProviderLanguageModel";


export interface ProviderDataModel {
    providerId: number;
    providerTypeId: number;
    providerTypeName?: string;
    providerCode: string;
    title: string;
    lastName: string;
    firstName: string;
    middleName: string;
    suffix: string;
    fullName: string;
    dob?: Date;
    gender: string;
    ssn: string;
    npi: string;
    tin: string;
    phone: string;
    fax: string;
    primaryEmail: string;
    secondaryEmail: string;
    credentialStatusId: number;
    groupId: string;
    isPcp: boolean;
    isGroup: boolean;
    isSpecialist: boolean;
    isProviderWatch: boolean;
    isPerson: boolean;
    isProviderAccess?: boolean;
    isAcceptsMedicaid: boolean;
    race: number;
    ethnicity: string;
    maxMemberCount: number;
    providerEligibilityId?: number;
    languages?: string;
    providerLanguage: Array<ProviderLanguageModel>;
    providerLanguageIds: string[];
    prefix?: string;
    providerEligibility: ProviderEligibilityModel[];
    effectiveDate: Date;
    termDate?: Date;
    createdBy?: string | null;
    createdDate?: string | Date;
    updatedDate?: string | Date | null;
    updatedBy?: string | null;

}

export interface ProviderViewModel {
    providerId: number;
    providerTypeID: number;
    providerCode: string;
    title: string;
    lastName: string;
    firstName: string;
    middleName: string;
    suffix: string;
    fullName: string;
    dob?: Date;
    gender: string;
    ssn: string;
    npi: string;
    tin: string;
    phone: string;
    fax: string;
    primaryEmail: string;
    secondaryEmail: string;
    credentialStatusID: number;
    isPCP: boolean;
    isSpecialist: boolean;
    isProviderWatch: boolean;
    isPerson: boolean;
    isProviderAccess?: boolean;
    race: string;
    ethnicity: string;
    maxMemberCount: number;
    providerEligibilityID?: number;
    serviceRenderedID: number;
    effectiveDate?: Date;
    termDate?: Date;
    prefix?: string;

}

export interface HasProviderConfigurationData {
    hasEligigbilityData: boolean;
    hasSpecialtyData: boolean;
    hasReferenceData: boolean;
    hasNotesData: boolean;
    hasProviderLocationData: boolean;
    hasProviderContractData: boolean;
}

export interface HasGroupConfigurationData {
    hasEligigbilityData: boolean;
    hasSpecialtyData: boolean;
    hasIPAData: boolean;
    hasProviderRelationData: boolean;
    hasLocationData: boolean;
    hasProviderLocationData: boolean;
    hasContractData: boolean;
    hasProviderContractData: boolean;
    hasReferenceData: boolean;
    hasNotesData: boolean;
    hasEftData: boolean;
    hasTinData: boolean;
    hasCheckHistoryData: boolean;
}


