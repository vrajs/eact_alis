export interface ProviderAuditHistory {
  providerAuditHistoryId: number;
  providerId: number | null;
  modifiedField: string;
  beforeValue: string;
  afterValue: string;
  modifiedDate: string | null;
  modifiedBy: string;
}