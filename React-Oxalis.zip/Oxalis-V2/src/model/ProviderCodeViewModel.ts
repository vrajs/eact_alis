export interface ProviderCodeViewModel {
  providerCodeID: number;
  providerID: number;
  controlTypeID: number;
  controlTypeName: string;
  codeTypeID: number;
  codeTypeName: string;
  codeValue: string;
  codeName: string;
  effectiveDate: string;
  termDate: string | null;
}