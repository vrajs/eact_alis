import { LetterCorrespondanceViewModel } from "./LetterCorrespondanceViewModel";
import { MemberTransactionDetailViewModel } from "./MemberTransactionDetailViewModel";
import { OtherNote } from "./OtherNoteModel";
import { PlaceHolderReplaceViewModel } from "./PlaceHolderReplaceViewModel";


export interface MemberEnrollmentViewModel {
  memberEnrollmentHeaderID: number;
  lOBID: number;
  applicationStatusID: number | null;
  otherNote: OtherNote;
  applicationStatusName: string;
  sourceCode: string;
  city: string;
  city2: string;
  nepName: string;
  nepPhoneNumber: string;
  nepCity: string;
  city3: string;
  speciality: string;
  isPortalAccess: boolean | null;
  speciality2: string;
  speciality3: string;
  medicalGroup: string;
  phoneNumber: string;
  faxNumber2: string;
  faxNumber3: string;
  phoneNumber2: string;
  phoneNumber3: string;
  foundGoldKidney: string;
  location: string;
  authorizedPersonSignature: string;
  accessibilityFormatLanguage: string;
  accessibilityFormatFontSize: string;
  homePhoneNo: string;
  benefitedBy: string;
  cellPhoneNo: string;
  prefix: string;
  planType: number;
  contactPrefrence: string;
  contractID: number | null;
  contractNumber: string;
  pBPID: number | null;
  pBPNumber: string;
  folderName: string;
  trackingID: string;
  memberID: number;
  pCPID: number | null;
  pCPCode: string | null;
  pCPName: string;
  pCPName2: string;
  pCPName3: string;
  salutation: string;
  firstName: string;
  lastName: string;
  middleName: string;
  raceID: number | null;
  ethnicityID: number | null;
  dob: string;
  genderID: number;
  ssn: string;
  mbi: string;
  memberCode: string;
  memberStatusID: number | null;
  primaryLanguageID: number | null;
  accessibilityFormatID: number | null;
  permanentAddressLine1: string;
  permanentAddressLine2: string;
  permanentAddressCity: string;
  permanentAddressState: string;
  permanentAddressZip: string;
  permanentAddressCounty: string;
  permanentStateAndCountyCode: string;
  phonenumber: string;
  altPhonenumber: string;
  contactTypeID: number;
  email: string;
  emailAddress: string;
  mailingAddress: string;
  mailingAddressLine1: string;
  mailingAddressLine2: string;
  mailingAddressZip: string;
  mailingAddressCity: string;
  mailingAddressState: string;
  salesDate: string | null;
  electionPeriod: string | null;
  medicareEffectiveDatePartA: string | null;
  proposedEffectiveDate: string | null;
  medicareEffectiveDatePartB: string | null;
  mailingAddressZipCode: string;
  authorizedPersonName: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  authorizedPersonAddress: string;
  authorizedPersonPhoneNumber: string;
  emergencyContactRelationshipID: number | null;
  authorizedPersonRelationshiptoEnrollee: number | null;
  emergencyContactRelationship: number | null;
  medicarePartAEffectiveDate: string;
  medicarePartBEffectiveDate: string;
  dateOfDeath: string | null;
  incarceratedDate: string | null;
  medicarePartDEffectiveDate: string | null;
  isESRD: boolean;
  diabetes1: boolean;
  diabetes2: boolean;
  cardiovascular1: boolean;
  cardiovascular2: boolean;
  cardiovascular3: boolean;
  dialysis1: boolean;
  dialysis2: boolean;
  isElectronic: boolean | null;
  isEmployed: boolean | null;
  lISLevelID: number | null;
  lowIncomeCopayID: number | null;
  partDLEPAmount: number | null;
  partDLEPWaivedAmount: number | null;
  partDLEPSubsidyAmount: number | null;
  lowIncomePartDPremiumSubsidyAmount: number | null;
  partCPremiumAmount: number;
  partDPremiumAmount: number;
  enrollmentSourceID: number | null;
  enrollmentMechanismID: number | null;
  salesAgentID: number | null;
  salesAgentName: string;
  saleDate: string | null;
  isEnrolledInStateMedicaId: boolean | null;
  medicaidNumber: string;
  medicaidLevelForSNP: string;
  planSpecificChronicConditionID: number | null;
  providerOfficeNameForVerification: string;
  providerOfficeAddress: string;
  iCEP_IEP: string;
  aEP: string;
  sEP: string;
  providerOfficeCity: string;
  scopeOfSeminar: boolean;
  providerOfficeState: string;
  providerOfficeZip: string;
  providerOfficeContactCount: string;
  longTermCare: boolean;
  longTermName: string;
  longTermAddress: string;
  longTermPhone: string;
  employerGroupNumber: number | null;
  employerGroupName: string;
  isOtherPrescriptionDrugCoverage: boolean | null;
  otherCoverageName: string;
  otherCoverageID: string;
  otherCoverageGroup: string;
  secondaryDrugBIN: number | null;
  secondaryDrugPCN: number | null;
  authorisedRepName: string;
  authorisedRepAddress: string;
  authorisedRepRelationship: number | null;
  authorisedRepContactNumber: string;
  notes: string;
  priorCoverageName: string;
  isEGHP: boolean | null;
  isCreditableCoverage: boolean | null;
  numberOfUncoveredMonths: number | null;
  lepRequestedDate: string | null;
  lepResponseDate: string | null;
  lepStartDate: string | null;
  lepEndDate: string | null;
  primaryRxID: number | null;
  primaryRxGroup: number | null;
  primaryRxBIN: number | null;
  primaryRxPCN: number | null;
  electionTypeID: number | null;
  sepReasonDate: string;
  effectiveDate: string;
  termDate: string;
  signatureDate: string;
  receiptDate: string;
  isPartDOptOut: boolean | null;
  premiumWithholdOptionID: number | null;
  employerSubsidyOverride: string;
  disenrollmentReasonCodeID: number | null;
  rFIRequestedDate: string;
  rFIDueDate: string | null;
  rFIResponseDate: string | null;
  transactionStatusID: number | null;
  pendReasonID: number | null;
  incompleteReasonID: number | null;
  denialFlagID: number | null;
  denialReasonID: number | null;
  cMSSubmissionDate: string | null;
  tRRResponseDate: string | null;
  bEQSubmissionDate: string | null;
  bEQResponseDate: string | null;
  oEVLetterSentDate: string | null;
  transactionReplyCode: number | null;
  cMSSubmissionTrackingID: string;
  memberSpanID: number | null;
  spanTypeID: number | null;
  spanEffectivedate: string | null;
  spanTermDate: string | null;
  spanValue: number | null;
  source: number | null;
  comments: string;
  allTRRFields: string;
  letterTypeDate: string;
  letterGenerationDate: string | null;
  letterMailDate: string | null;
  responseDueDate: string | null;
  allBEQFields: string;
  confirmationNumber: string;
  isTestMember: boolean | null;
  isCompareWithCMS: boolean;
  recordStatus: number | null;
  recordStatusChangeComment: string;
  spouseEmployedStatusID: boolean | null;
  memberGUID: string | null;
  memberEligibilityID: number;
  memberCMSDetailID: number;
  memberContactID: number;
  memberContactMailingID: number;
  memberContactAuthID: number;
  memberPremiumDetailID: number;
  memberEnrollmentDetailID: number;
  memberOtherCoverageID: number;
  memberNoteID: number;
  contactPreference: string;
  memberPCPID: number;
  isCurrentPatient: boolean;
  memberTransactionList: MemberTransactionDetailViewModel[];
  memberCorrespondanceList: LetterCorrespondanceViewModel[];
  createdBy: string;
  updatedBy: string;
  createdDate: string;
  updatedDate: string | null;
  placeHolderReplaceViewModel: PlaceHolderReplaceViewModel;
  spanSourceId: number;
}

export const enrollmentInitValue: MemberEnrollmentViewModel = {
  memberEnrollmentHeaderID: 0,
  lOBID: 0,
  applicationStatusID: 0,
  otherNote: undefined,
  applicationStatusName: "",
  sourceCode: "",
  city: "",
  city2: "",
  nepName: "",
  nepPhoneNumber: "",
  nepCity: "",
  city3: "",
  speciality: "",
  isPortalAccess: false,
  speciality2: "",
  speciality3: "",
  medicalGroup: "",
  phoneNumber: "",
  faxNumber2: "",
  faxNumber3: "",
  phoneNumber2: "",
  phoneNumber3: "",
  foundGoldKidney: "",
  location: "",
  authorizedPersonSignature: "",
  accessibilityFormatLanguage: "",
  accessibilityFormatFontSize: "",
  homePhoneNo: "",
  benefitedBy: "",
  cellPhoneNo: "",
  prefix: "",
  planType: 0,
  contactPrefrence: "",
  contractID: 0,
  contractNumber: "",
  pBPID: 0,
  pBPNumber: "",
  folderName: "",
  trackingID: "",
  memberID: 0,
  pCPID: 0,
  pCPCode: "",
  pCPName: "",
  pCPName2: "",
  pCPName3: "",
  salutation: "",
  firstName: "",
  lastName: "",
  middleName: "",
  raceID: 0,
  ethnicityID: 0,
  dob: "",
  genderID: null,
  ssn: null,
  mbi: "",
  memberCode: "",
  memberStatusID: null,
  primaryLanguageID: null,
  accessibilityFormatID: null,
  permanentAddressLine1: "",
  permanentAddressLine2: "",
  permanentAddressCity: "",
  permanentAddressState: "",
  permanentAddressZip: "",
  permanentAddressCounty: "",
  permanentStateAndCountyCode: "",
  phonenumber: "",
  altPhonenumber: "",
  contactTypeID: 0,
  email: "",
  emailAddress: "",
  mailingAddress: "",
  mailingAddressLine1: "",
  mailingAddressLine2: "",
  mailingAddressZip: "",
  mailingAddressCity: "",
  mailingAddressState: "",
  salesDate: "",
  electionPeriod: "",
  medicareEffectiveDatePartA: "",
  proposedEffectiveDate: "",
  medicareEffectiveDatePartB: "",
  mailingAddressZipCode: "",
  authorizedPersonName: "",
  emergencyContactName: "",
  emergencyContactPhone: "",
  authorizedPersonAddress: "",
  authorizedPersonPhoneNumber: "",
  emergencyContactRelationshipID: null,
  authorizedPersonRelationshiptoEnrollee: 0,
  emergencyContactRelationship: 0,
  medicarePartAEffectiveDate: null,
  medicarePartBEffectiveDate: null,
  dateOfDeath: null,
  incarceratedDate: null,
  medicarePartDEffectiveDate: null,
  isESRD: false,
  diabetes1: false,
  diabetes2: false,
  cardiovascular1: false,
  cardiovascular2: false,
  cardiovascular3: false,
  dialysis1: false,
  dialysis2: false,
  isElectronic: false,
  isEmployed: false,
  lISLevelID: 0,
  lowIncomeCopayID: 0,
  partDLEPAmount: 0,
  partDLEPWaivedAmount: 0,
  partDLEPSubsidyAmount: 0,
  lowIncomePartDPremiumSubsidyAmount: 0,
  partCPremiumAmount: 0,
  partDPremiumAmount: 0,
  enrollmentSourceID: null,
  enrollmentMechanismID: null,
  salesAgentID: null,
  salesAgentName: "",
  saleDate: null,
  isEnrolledInStateMedicaId: false,
  medicaidNumber: "",
  medicaidLevelForSNP: "",
  planSpecificChronicConditionID: 0,
  providerOfficeNameForVerification: "",
  providerOfficeAddress: "",
  iCEP_IEP: "",
  aEP: "",
  sEP: "",
  providerOfficeCity: "",
  scopeOfSeminar: false,
  providerOfficeState: "",
  providerOfficeZip: "",
  providerOfficeContactCount: "",
  longTermCare: false,
  longTermName: "",
  longTermAddress: "",
  longTermPhone: "",
  employerGroupNumber: 0,
  employerGroupName: "",
  isOtherPrescriptionDrugCoverage: false,
  otherCoverageName: "",
  otherCoverageID: "",
  otherCoverageGroup: "",
  secondaryDrugBIN: 0,
  secondaryDrugPCN: 0,
  authorisedRepName: "",
  authorisedRepAddress: "",
  authorisedRepRelationship: 0,
  authorisedRepContactNumber: "",
  notes: "",
  priorCoverageName: "",
  isEGHP: false,
  isCreditableCoverage: false,
  numberOfUncoveredMonths: 0,
  lepRequestedDate: "",
  lepResponseDate: "",
  lepStartDate: "",
  lepEndDate: "",
  primaryRxID: 0,
  primaryRxGroup: 0,
  primaryRxBIN: 0,
  primaryRxPCN: 0,
  electionTypeID: 0,
  sepReasonDate: "",
  effectiveDate: "",
  termDate: "",
  signatureDate: "",
  receiptDate: "",
  isPartDOptOut: false,
  premiumWithholdOptionID: 0,
  employerSubsidyOverride: "",
  disenrollmentReasonCodeID: 0,
  rFIRequestedDate: "",
  rFIDueDate: "",
  rFIResponseDate: "",
  transactionStatusID: 0,
  pendReasonID: 0,
  incompleteReasonID: 0,
  denialFlagID: 0,
  denialReasonID: 0,
  cMSSubmissionDate: "",
  tRRResponseDate: "",
  bEQSubmissionDate: "",
  bEQResponseDate: "",
  oEVLetterSentDate: "",
  transactionReplyCode: 0,
  cMSSubmissionTrackingID: "",
  memberSpanID: 0,
  spanTypeID: 0,
  spanEffectivedate: "",
  spanTermDate: "",
  spanValue: 0,
  source: 0,
  comments: "",
  allTRRFields: "",
  letterTypeDate: "",
  letterGenerationDate: "",
  letterMailDate: "",
  responseDueDate: "",
  allBEQFields: "",
  confirmationNumber: "",
  isTestMember: false,
  isCompareWithCMS: false,
  recordStatus: 0,
  recordStatusChangeComment: "",
  spouseEmployedStatusID: false,
  memberGUID: "",
  memberEligibilityID: 0,
  memberCMSDetailID: 0,
  memberContactID: 0,
  memberContactMailingID: 0,
  memberContactAuthID: 0,
  memberPremiumDetailID: 0,
  memberEnrollmentDetailID: 0,
  memberOtherCoverageID: 0,
  memberNoteID: 0,
  contactPreference: "",
  memberPCPID: 0,
  isCurrentPatient: false,
  memberTransactionList: [],
  memberCorrespondanceList: [],
  createdBy: "",
  updatedBy: "",
  createdDate: "",
  updatedDate: "",
  placeHolderReplaceViewModel: undefined,
  spanSourceId: 0
}