export interface ProviderContractLobModel {
  providerContractLOBID: number;
  providerContractID: number;
  lOBID: number;
  recordStatus: number;
  isFreezed: number;
  recordStatusChangeComment: string;
  createdBy: string;
  createdDate: string;
  updatedBy: string;
  updatedDate: string | null;
}