export interface ClaimUBCodesViewModel {
  claimUBCodesID: number;
  claimHeaderID: number;
  typeID: number;
  ubCode: string;
  description: string;
  fromDate: string | Date | null;
  toDate: string | null | Date;
  amount: number;
  addedSource: string;
  url: string;
}