export interface ClaimReferenceViewModel {
  claimReferenceID: number;
  claimHeaderID: number;
  memberID: number;
  controlTypeID: number;
  codeTypeID: number;
  codeValue: string | Date | number;
  effectiveDate: string | Date;
  termDate: string | null | Date;
  addedSource: string;
  url: string;
}