export interface LocationModel {
  locationID: number;
  locationTypeID: number;
  locationTypeName: string;
  locationName: string;
  regionID: number | null;
  regionName: string | null;
  address1: string;
  address2: string;
  city: string;
  state: string;
  stateFullName: string | null;
  county: string | null;
  country: string | null;
  zip: string;
  phone: string | null;
  fax: string | null;
  emergencyPhone: string | null;
  secondaryPhone: string | null;
  primaryEmail: string | null;
  secondaryEmail: string | null;
  afterHoursCoverage: string | null;
  minimumAge: number;
  maximumAge: number;
  isHandicapAccessible: boolean;
  isPCP: boolean;
  isAcceptingNewPatient: boolean;
  isIncludeInProviderDirectory: boolean;
  genderRestriction: string | null;
  sundayFromHour: string | null;
  mondayFromHour: string | null;
  tuesdayFromHour: string | null;
  wednesdayFromHour: string | null;
  thursdayFromHour: string | null;
  fridayFromHour: string | null;
  saturdayFromHour: string | null;
  sundayToHour: string | null;
  mondayToHour: string | null;
  tuesdayToHour: string | null;
  wednesdayToHour: string | null;
  thursdayToHour: string | null;
  fridayToHour: string | null;
  saturdayToHour: string | null;
  effectiveDate: string | Date;
  termDate: string | null | Date;
  recordStatus: number;
  isFreezed: number;
  recordStatusChangeComment: string;
  createdBy: string;
}

export interface LocationTimeForm {
  from: string | Date | null;
  to: string | Date | null;
}