export interface GroupExportModel {
  providerID: number;
  providerCode: string;
  npi: string;
  fullName: string;
  primaryEmail: string;
  secondaryEmail: string;
  phone: string;
  fax: string;
  providerType: string;
}