export interface LobModel {
  url: string;
  lobID: number;
  lobCode: string;
  lobName: string;
  submitterCode: string;
  caidContractNumber: string;
  careContractNumber: string;
  nICNumber: string;
  effectiveDate: string;
  termDate: string | null;
  organizationID: number;
  sponsorID: number;
  categoryID: number;
  productID: number;
  companyID: number | null;
  subCompanyID: number;
  organizationName: string;
  sponsorName: string;
  categoryName: string;
  productName: string;
}