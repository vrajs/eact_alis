export interface ClaimEditViewModel {
  claimEditsID: number;
  claimHeaderID: number;
  claimLineID: number;
  editCode: string;
  editDescription: string;
  outComeID: number;
  outComeCodeID: number | null;
  comments: string;
  editCodeID: number;
  isOverride: boolean;
  lastUpdatedDate: string | null;
  lastUpdatedBy: string;
  addedSource: string;
  url: string;
  outCome: string;
  outComeCode: string;
  lineNumber: number;
  recordDisplayOrder: number;
  isFreezedEditCode: number;
}