export interface GroupSearchModel {
  providerCode: string;
  providerTypeIDs: number | null;
  providerName: string;
  firstName: string;
  lastName: string;
  fullName: string;
  npi: number;
  tin: number | null;
  specialtyIDs: number[] | null;
  languageIDs: string;
}