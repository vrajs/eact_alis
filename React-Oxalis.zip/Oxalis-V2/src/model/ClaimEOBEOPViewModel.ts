export interface ClaimEOBEOPViewModel {
  claimEOBEOPID: number;
  claimHeaderID: number;
  eOBEOPTypeID: number;
  lineNumber: number;
  code: string;
  description: string;
  addedSource: string;
  url: string;
}