export interface ClaimOtherPhysicianViewModel {
  claimOtherPhysicianID: number;
  claimHeaderID: number;
  physicianTypeID: number;
  physicianCode: string;
  qualifierID: number;
  lastName: string;
  firstName: string;
  addedSource: string;
  url: string;
}