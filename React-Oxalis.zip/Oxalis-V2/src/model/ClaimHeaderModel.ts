export interface ClaimHeaderModel {
  claimHeaderID: number
  claimNumber: string
  receivedDate: Date | string | null;
  formTypeID: number
  enteredDate: Date | string | null;
  dosFrom: Date | string | null;
  dosTo: Date | string | null;
  billedAmount: number
  paidAmount: number
  paidDate: Date | string | null;
  otherInsurancePaid: number
  patientAccountNumber: string
  externalClaimID: string
  priorAuthNumber: string
  claimStatusID: number
  claimStatusReason: string
  claimSourceID: number
  isFinal: boolean;
  memberID: number
  providerID: number
  providerTypeID: number;
  vendorName: string
  provider837Address: string
  member837Address: string
  isCorrectedClaim: boolean
  isPatientReimbursement: boolean
  isRefundRequest: boolean
  isCleanClaim: boolean
  isEncounter: boolean
  isAlternatePayee: boolean
  isSplitPayment: boolean
  isSuppressEOB: boolean
  isPayAndPursue: boolean
  altFeeScheduleID: number;
  isEmployment: boolean
  isAuto: boolean
  isOtherAccident: boolean
  illnessDate: Date | string | null;
  otherDate: Date | string | null;
  physicianName: string
  physicianNPI: string
  isAcceptsAssignment: boolean
  billTypeID: number
  admitDate: Date | string | null;
  admitHour: any
  admitTypeID: number;
  admitSourceID: number;
  dischargeHour: any
  dischargeStatusID: number;
  billedDRGCode: any
  revisedDRGCode: any
  isPreDetermiantion: any
  isEPSDTTitleXIX: any
  serviceRendered: string
  serviceRenderedName: string | null;
  serviceRenderedSpecialty?: string | null;
  dcn?: string | null;
  claimAge: number
  url: any
  memberCode: string
  memberName: string
  dob?: string | Date | null;
  gender: string
  memberEligibilityID: number;
  plan: string;
  planID?: number | null;
  memberPCPID: number;
  pcpid?: number;
  pcpName: string;
  relationship: string;
  relationshipID?: number;
  providerCode: string;
  providerName: string;
  providerNPI: string;
  providerGroupTIN: string;
  effectiveDate: Date | string | null;
  reimburseAmount: number;
  reimburseReminderToProvider: boolean;
  reasonForSplitPayment: string;
  payeeName: string;
  payeeAddress1: string;
  payeeAddress2: string;
  payeeCity: string;
  payeeState: string;
  payeeZip: string;
  payeeTin: string;
  paymentRedirectReason: string;
  vendorID: number
  accidentStateOrProvince: string
  addedSource: string;
  providerStatus: string;
  providerSpecialtyID: number;
  providerStatusID: number;
  // claimEditsCodes: any[];
}
