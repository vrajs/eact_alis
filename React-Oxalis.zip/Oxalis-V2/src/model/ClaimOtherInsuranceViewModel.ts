export interface ClaimOtherInsuranceViewModel {
  claimOtherInsuranceID: number;
  claimHeaderID: number;
  isLineLevel: boolean;
  serviceLineNumber: number;
  dosFrom: string | Date;
  dosTo: string | Date;
  posCode: string;
  revenueCode: string;
  procedureCode: string;
  modifiers: string;
  billedAmount: number;
  units: number;
  eobDate: string;
  allowedAmount: number;
  deductibleAmount: number;
  copayAmount: number;
  coinsuranceAmount: number;
  netAllowedAmount: number;
  totalPaidAmount: number;
  insuranceCarrierID: number | null;
  sourceInsuranceName: string;
  memberID: number;
  addedSource: string;
  url: string;
}