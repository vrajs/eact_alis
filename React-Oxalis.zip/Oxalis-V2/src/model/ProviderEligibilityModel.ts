export interface ProviderEligibilityModel {
  providerEligibilityID: number;
  providerID: number;
  providerName?: string;
  providerEligibilityCode?: string;
  effectiveDate: string | Date | null;
  termDate: string | null | Date;
  termReasonId?: number | null;
}