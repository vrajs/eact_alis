export interface ProviderContractTimelyFilingModel {
  providerContractTimelyFilingID: number;
  providerContractID: number;
  timelyFilingID: number;
  recordStatus: number;
  isFreezed: number;
  recordStatusChangeComment: string;
  createdBy: string;
  createdDate: string;
  updatedBy: string;
  updatedDate: string | null;
}