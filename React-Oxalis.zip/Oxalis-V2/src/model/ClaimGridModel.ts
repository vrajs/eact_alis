export interface ClaimGridModel {
  claimHeaderID: number;
  claimNumber: string;
  claimStatusCode: string;
  formType: string;
  dosFrom: string;
  dosTo: string;
  createdDate: string | null;
  receivedDate: string;
  formTypeID: number;
  priorAuthNumber: string;
  billedAmount: number;
  paidAmount: number;
  datePaid: string | null;
  checkNumber: number | null;
  denyPendCode: string;
  memberID: number;
  memberCode: string;
  memberName: string;
  providerID: number;
  providerCode: string;
  providerName: string;
  vendorName: string;
  claimStatusID: number;
  claimStatusCategory: string;
  recordStatus: number;
}