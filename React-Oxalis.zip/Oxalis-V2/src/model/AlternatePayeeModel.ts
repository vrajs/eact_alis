export interface AlternatePayeeModel {
  payeeName: string;
  payeeAddress1: string;
  payeeAddress2: string;
  payeeZip: string;
  payeeCity: string;
  payeeState: string;
  payeeTin: string;
  paymentRedirectReason: string;
}