export interface AlertCodeViewModel {
  alertCodeID: number;
  code: string;
  name: string;
  url: string;
}

export interface AlertModuleViewModel {
  alertModuleID: number;
  sourceModuleID: number;
  sourceModuleName: string;
  destinationModuleID: number;
  destinationModuleName: string;
  alertDataID: number;
  alertCodeID: number;
  alertCodeValue: string;
  alertCodeName: string;
  effectiveDate: string;
  termDate: string | null;
  url: string;
  relationship: string;
  memberName: string;
  memberCode: string;
  alertType: string;
}