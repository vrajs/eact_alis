export interface ClaimSplitPaymentModel {
  reimburseAmount: number;
  reasonForSplitPayment: string;
  reimburseReminderToProvider: boolean;
}