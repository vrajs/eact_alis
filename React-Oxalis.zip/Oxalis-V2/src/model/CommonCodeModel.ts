export interface CommonCodeModel {
  commonCodeID: number;
  addedSource: string;
  charValue: string;
  code: string;
  codeTypeID: number;
  displayOrder: number;
  effectiveDate: string;
  isFreezed: boolean;
  loadComment: string;
  longDescription: string;
  numericValue: number | null;
  otherValue: string;
  shortName: string;
  termDate: string | null;
  controlTypeID: number | null;
}