export interface ClaimDiagnosisViewModel {
  claimDiagnosisID: number;
  claimHeaderID: number;
  memberID: number;
  diagnosisTypeID: number | null;
  diagnosisCode: string;
  diagnosisProdedure: string;
  diagnosisDescription: string;
  qualifier: string;
  diagnosisPointer: number;
  isPOA: boolean;
  procDate: string | null;
  dosFrom: string;
  dosTo: string;
  diagnosisPointerStr: string;
  url: string;
  addedSource: string;
}