export interface PlaceHolderReplaceViewModel {
  clientMemberId: string;
  primaryRxId: string;
  primaryRxGroup: string;
  primaryRxBIN: string;
  primaryRxPCN: string;
  firstName: string;
  middleInitial: string;
  lastName: string;
  contractDescription: string;
  pBPDescription: string;
  pBPId: number | null;
  effectiveDate: string | null;
  partCPremiumAmount: number | null;
  partDPremiumAmount: number | null;
  lowIncomePartD: number | null;
  lowIncomeCoPay: number | null;
  ttyHoursOfOperation: string;
  ttyNumber: string;
}