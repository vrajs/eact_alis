
export interface FileTemplateSearch {

    fileSubCategoryId: number;
    fileCategoryId: number;
    fileName: any;
    fileDateFrom: any;
    fileDateTo: any;
    orderByColumn: string;
    isDesc: boolean;
    fileTemplateTypeId: number;
    dataFileTemplateId: number;
    skip:number;
    take:number;
}
