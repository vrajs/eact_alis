export interface FileTemplateListView {
    fileTemplateList: FileTemplateList[];
    totalRecords: number;
}
export interface FileTemplateList {
    fileSubCategoryId: number;
    fileCategoryId: number;
    dataFileToProcessDetailsID: number;
    fileName: string;
    fileType: string;
    fileDate: Date;
    createdBy: string;
    records: number;
}