export interface GridModel<T> {
  totalCount: number;
  data: Array<T>;
}