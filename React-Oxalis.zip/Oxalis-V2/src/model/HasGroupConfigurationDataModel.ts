export interface HasGroupConfigurationDataModel {
  hasEligigbilityData: boolean;
  hasSpecialtyData: boolean;
  hasIPAData: boolean;
  hasProviderRelationData: boolean;
  hasLocationData: boolean;
  hasProviderLocationData: boolean;
  hasContractData: boolean;
  hasProviderContractData: boolean;
  hasReferenceData: boolean;
  hasNotesData: boolean;
  hasEFTData: boolean;
  hasTINData: boolean;
  hasCheckHistoryData: boolean;
}