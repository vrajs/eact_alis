import { AlternatePayeeModel } from "./AlternatePayeeModel";
import { ClaimHeaderViewModel } from "./ClaimHeaderViewModel";
import { ClaimSplitPaymentModel } from "./ClaimSplitPaymentModel";
import { FacilityLookUpModel } from "./FacilityLookUpModel";
import { MemberLookUpModel } from "./MemberLookUpModel";
import { ProviderLookUpModel } from "./ProviderLookUpModel";

export interface ClaimStateModel {
  formType: string;
  formTypeID: number;
  claimNumber: string;
  claimData: ClaimHeaderViewModel | null;
  claimHeaderID: number;
  memberInfo: MemberLookUpModel | null;
  providerInfo: ProviderLookUpModel | null;
  alternatePayee: AlternatePayeeModel | null;
  splitPayment: ClaimSplitPaymentModel | null;
  facility: FacilityLookUpModel | null;
}