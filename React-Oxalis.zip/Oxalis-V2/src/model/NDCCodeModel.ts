import { CommonCodeModel } from "./CommonCodeModel";

export interface NDCCodeModel {
    nDCCodeID: number;
    code: string;
    clinicalCodeTypeID: number;
    shortDescription: string;
    longDescription: string;
    nDCType: string;
    dosageForm: string;
    route: string;
    strength: string;
    unit: string;
    effectiveDate: string;
    termDate: string | null;
    nDCCommonCode: CommonCodeModel;
    homeGrown: string;
    mappedCode: string;
    clinicalCodeType: string;
    clinicalCodeTypeName: string;
    isFreezed: number;
}