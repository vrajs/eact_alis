export interface CityModel {
  city: string;
  recordStatus: number;
}