export interface PosCodeModel {
  pOSCodeID: number;
  code: string;
  homeGrown: string;
  facilityNonFacility: string;
  shortDescription: string;
  longDescription: string;
  sequenceNumber: number;
  clinicalCodeTypeID: number;
  effectiveDate: string;
  termDate: string | null;
  clinicalCodeType: string;
  clinicalCodeTypeName: string;
  isFreezed: number;
}