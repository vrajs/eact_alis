export interface ProviderContractInterestModel {
  providerContractInterestID: number;
  providerContractID: number;
  interestQuickPayID: number;
  recordStatus: number;
  isFreezed: number;
  recordStatusChangeComment: string;
  createdBy: string;
  createdDate: string;
  updatedBy: string;
  updatedDate: string | null;
}