export interface PaginationModel {
  skip: number;
  take: number;
  sortBy?: string | null;
  sortOrder?: number | null;
}