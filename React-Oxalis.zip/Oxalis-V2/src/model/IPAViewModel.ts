export interface IPAViewModel {
  providerIPAID: number;
  ipaid: number;
  ipaCode: string;
  ipaName: string;
  npi: string;
  contactName: string;
  phone: string;
  fax: string;
  primaryEmail: string;
  secondaryEmail: string;
  effectiveDate: string | Date;
  termDate: string | null | Date;
  recordStatus: number;
  lobs: string;
}