import "primeflex/primeflex.css";
import "primeicons/primeicons.css";
import { PrimeReactProvider } from "primereact/api";
import "primereact/resources/primereact.min.css";
import { createRoot } from "react-dom/client";
import { Provider } from "react-redux";
import "./index.css";
import "./stylesheets/Styles.scss";
import "./stylesheets/color-palletes.scss";
import "./stylesheets/layout/fonts/icon-fonts/style.css";
import "./stylesheets/layout/layout.scss";
import store from "./Redux/app/store";
import { LayoutProvider } from "./layout/context/layoutcontext";
import App from "./App";

const root = createRoot(document.getElementById("root") as HTMLElement);

root.render(
  <PrimeReactProvider>
    <Provider store={store}>
      <LayoutProvider>
        <App />
      </LayoutProvider>
    </Provider>
  </PrimeReactProvider>,
);
