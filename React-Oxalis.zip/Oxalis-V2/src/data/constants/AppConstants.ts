import { CodeType, CommonCodeFetchingType } from "./AppEnum";

export const API_ENDPOINTS = {

  // Common codes
  COMMON_CODES: "/api/CommonCode",
  SALES_AGENT: "/api/CommonCode/getSalesAgents",
  GET_COMMON_CODE_CONFIGURATION: "/api/CommonCode/GetCommonCodeConfigurationByCodeTypeId",
  GET_BY_TYPE_IDS: "/api/CommonCode/GetCodeByTypeIds",
  GET_ALL: "GetAll",
  KEY_VALUE: "KeyValue",
  GetCommonCodeByCodeTypeIdAll: "GetCommonCodeByCodeTypeIdAll",
  GetCommonCodeByCodeTypeId:"GetCommonCodeByCodeTypeId",
  // PROVIDER / GROUP END POINTS
  VALIDATE_NPI: "/api/Provider/ValidateNpi",
  GET_BY_NPI: "/api/Provider/GetByNPI",
  PROVIDER_LOOKUP: "/api/Provider/ProviderLookup",
  GET_CLAIM_FACILITY: "/api/Provider/GetClaimFacility",
  GET_CLAIM_PROVIDER: "/api/Provider/GetClaimProvider",
  CHECK_GROUP_CONFIGURATION: "/api/Provider/checkGroupConfigurationHasData",
  GET_PROVIDER_CREDENTIALING: "/api/ProviderCredentialing/GetCredByProvider",
  GET_PROVIDER_CONTRACT: "/api/Provider/GetProviderContract",
  GET_PROVIDER_LOCATION: "/api/Provider/GetProviderLocation",
  CREATE_GROUP_FROM_PROVIDER: "/api/Provider/CreateGroupFromProvider",
  CHECK_PROVIDER_CONFIGURATION: "/api/Provider/checkProviderConfigurationHasData",
  PROVIDER: "/api/Provider",
  Get_ZipCode_By_Search_Value: "/api/ZipCode/GetZipCodeBySearchValue",
  Get_MemberEnrollment_HeaderById :"/api/MemberEnrollmentHeader/GetMemberEnrollmentHeaderById",
  PROVIDER_CRED: "/api/ProviderCredentialing",
  GROUP_PROVIDER: "/api/Provider/Group",
  GET_FROM_NPPES: "/api/Provider/GetDataFromNPPES",
  GET_PROVIDER_VIEW: "/api/Provider/getView",
  GET_GROUP_LIST: "/api/Provider/GetGroupIdList",
  PROVIDER_HISTORY: "/api/Provider/GetProviderAuditHistory",
  ACTIVE_PROVIDERS: "/api/Provider/GetActiveProviders",
  GROUP_GRID: "/api/Provider/GroupGrid",
  GROUP_EXPORT: "/api/Provider/GroupExport",
  PROVIDER_GRID: "/api/Provider/GetProviders",
  PROVIDER_EXPORT: "/api/Provider/ProvidersExport",
  TOTAL_MEMBERS_ASSIGNED: "/api/Provider/ProvidersAssigned",
  MemberEnrollment_Detail: "/api/MemberEnrollmentDetail/MemberEnrollmentDetail",
  Get_FileTemplateDetails: "/api/FileTemplateType/GetFileTemplateDetails",
  PROVIDER_ATTACHMENT: "/api/Provider/ProviderAttachment",
  FACILITY_LOOKUP: "/api/Provider/FacilityLookUp",

  // PROVIDER / GROUP CONTRACTS
  PROVIDER_CONTRACT: "/api/ProviderContract",
  GET_PROVIDER_CONTRACT_BY_PROVIDER_ID: "GetProviderContractByProviderId",
  GET_PROVIDER_CONTRACT_DROPDOWN_PROVIDER_ID: "GetProviderContractDropDownByProviderID",

  // LOB
  LOB: "/api/Lob",

  // TIMELY FILING
  TIMELY_FILING: "/api/TimelyFiling",

  // Interest Quick Pay
  INTEREST_QUICK_PAY: "/api/InterestQuickPay",

  // FEE SCHEDULER
  FEE_SCHEDULER: "/api/FeeScheduleHeader",

  //ModifierDiscountGroup
  MODIFIER_DISCOUNT_GROUP: "/api/ModifierDiscountGroup",
  MODIFIER_KEY_VALUES: "GetModifierDiscountGroupKeyVal",

  // CONTRACT
  CONTRACT: "/api/Contract",

  // PROVIDER RELATION
  PROVIDER_RELATION: "/api/ProviderRelation",
  PROVIDER_RELATION_BY_PARENT_ID: "GetProviderRelationByParentProviderId",
  PROVIDER_RELATION_BY_PARENT: "GetProviderRelationByParentProvider",
  PROVIDER_RELATION_BY_PARENT_KEY_VALUE: "/api/ProviderRelation/GetAllProviderRelationByParentProviderIdKeyValue",

  // LOCATION
  LOCATION: "/api/location",
  TERMINATE_LOCATION: "/api/location/Terminate",
  LOCATION_GRID: "/api/location/Grid",
  LOCATION_EXPORT: "/api/location/Export",

  // PROVIDER LOCATION
  PROVIDER_LOCATION: "/api/ProviderLocation",
  PROVIDER_LOCATION_BY_PROVIDER_ID: "/api/ProviderLocation/GetProviderLocationByProviderId",
  PROVIDER_LOCATION_BY_PROVIDER_ID_KEY_VALUE: "/api/ProviderLocation/GetAllProviderLocationByProviderIdKeyValue",
  ADD_GROUP_PROVIDER_LOCATION: "AddGroupProviderLocation",
  GET_BY_GROUP_ID_LOCATION_ID: "GetGroupProviderLocationByGroupID",
  GET_BY_GROUP_ID: "GetProviderLocationByGroupID",



  // PROVIDER TIN
  PROVIDER_TIN: "/api/ProviderTIN",
  PROVIDER_TIN_BY_PROVIDER_ID: "/api/ProviderTIN/GetProviderTINByProviderId",

  // PROVIDER SPECIALTY
  PROVIDER_SPECIALTY: "/api/ProviderSpecialty",
  CHECK_PRIMARY_SPECIALTY: "/api/ProviderSpecialty/CheckIfExistIsPrimary",
  PROVIDER_SPECIALTY_BY_PROVIDER_ID: "/api/ProviderSpecialty/GetByProvider",

  // SPECIALTY
  SPECIALTY_KEY_VAL: "/api/Specialty/GetSpecialtiesKeyVal",
  LANGUAGE_KEY_VAL: `/api/CommonCode/${CodeType.Language}/${CommonCodeFetchingType.Default}`, // Using template literals


  // MODULE
  MODULE_KEY_VALUE: "/api/Module/GetKeyValue",


  // GROUP PROVIDER CONTRACT
  GROUP_PROVIDER_CONTRACT: "/api/GroupProviderContract",
  GET_PROVIDER_CONTRACT_BY_GROUP_ID: "GetByGroupId",
  INDIVIDUAL: "Individual",
  GET_GROUP_CONTRACT: "GetGroupProviderContract",

  // PROVIDER CODE
  PROVIDER_CODE: "/api/ProviderCode",
  GET_BY_PROVIDER_ID: "GetByProviderId",
 
  //Pre-Enrollment
  GetMember_PreEnrollmentBy_MBI: "/api/MemberEnrollmentBEQ/GetMemberPreEnrollmentByMBI",
  GetBEQ_Response_WorkArround:"/api/MemberEnrollmentBEQ/GetBEQResponseWorkArround",
  Insert_Member_PreEnrollmentFinal:"/api/MemberEnrollmentBEQ/InsertMemberPreEnrollmentFinal",
  OtherAttachment_Upload:"/api/OtherFiles/OtherAttachmentUpload",
  Insert_Note:"/api/OtherNotes/InsertNote",

  // PROVIDER NOTES
  PROVIDER_NOTE: "/api/ProviderNote",
  PROVIDER_NOTE_BY_PROVIDER_ID: "/api/ProviderNote/GetByProviderID",

  // PROVIDER EFT
  PROVIDER_EFT: "/api/ProviderEFT",
  PROVIDER_EFT_BY_PROVIDER_ID: "/api/ProviderEFT/GetByProviderId",

  //PROVIDER STATUS
  PROVIDER_STATUS: "/api/ProviderStatus/GetAllStatusByProvider",
  // IPA
  IPA: "/api/IPA",
  GET_ACTIVE_IPA: "/api/IPA/GetIPAs",
  GET_IPA_BY_PROVIDER_ID: "/api/IPA/getByProviderId",

  // PROVIDER IPA
  PROVIDER_IPA: "/api/ProviderIPA",
  PROVIDER_IPA_BY_PROVIDER: "/api/ProviderIPA/GetByProvider",

  // ALERT CODES
  GET_ACTIVE_ALERT_CODES: "/api/AlertCode/GetActiveAlerts",

  // ALERT 
  ALERT: "/api/Alert",
  GET_ALERT_BY_CODE_TYPE: "/api/Alert/GetByAlertCodeType",

  // PROVIDER ELIGIBILITY
  PROVIDER_ELIGIBILITY_BY_PROVIDER: "/api/ProviderEligibility/GetByProvider",
  PROVIDER_ELIGIBILITY_GRID: "/api/ProviderEligibility/EligibilityGrid",

  // ZIP CODE
ZIP_CODE_COUNTRIES: "/api/ZipCode/GetCountries",
  ZIP_CODE_COUNTIES: "/api/ZipCode/Counties",
  ZIP_CODE_STATES: "/api/ZipCode/GetStates",
  ZIP_CODE_CITIES: "/api/ZipCode/Cities",
  ZIP_CODE: "/api/ZipCode",

  // CLAIM
  CLAIM: "/api/ClaimHeader",
  CLAIM_STATUS: "/api/ClaimStatus/GetAllStatus",
  CLAIM_LIST: "/api/ClaimHeader/GetClaimsList",
  PROVIDER_STATUS_BY_CLAIM_NO: "/api/ClaimHeader/GetProviderStatus",
  PROVIDER_SPECIALTY_BY_CLAIM_NO: "/api/ClaimHeader/GetProviderSpecialty",
  GENERATE_CLAIM_NUMBER: "/api/ClaimHeader/GenerateClaimNumber",
  GET_BY_CLAIM_NUMBER: "/api/ClaimHeader/GetClaimByClaimNumber",
  EXPORT_CLAIMS: "/api/ClaimHeader/ExportClaims",
  CLAIM_SERVICE_HEADER_ID: "/api/ClaimHeader/ServiceClaimSave",
  CLAIM_HAS_REQUIRED_INFO: "/api/ClaimHeader/CheckClaimHasRequireInfoForAdjudication",
  CLAIM_CHECK_STATUS: "/api/ClaimHeader/CheckStatusByClaimHeader",

  // CONTRACTS
  GET_ACTIVE_CONTRACTS: "/api/Contract/GetContracts",

  // CLAIM DIAGNOSIS
  CLAIM_DIAGNOSIS: "/api/ClaimDiagnosis",
  GET_BY_CLAIM_HEADER: "/api/ClaimDiagnosis/GetClaimDiagnosis",
  GET_BY_CLAIM_HEADER_ID: "/api/ClaimDiagnosis/GeByHeaderID",
  GET_CLAIM_ADMIT: "/api/ClaimDiagnosis/GetClaimAdmit",


  // CLAIM REFERENCE
  CLAIM_REFERENCE: "/api/ClaimReference",
  CLAIM_REFERENCE_GRID: "/api/ClaimReference/ByClaimHeaderId",

  // CLAIM OTHER PHYSICIAN
  CLAIM_OTHER_PHYSICIAN: "api/ClaimOtherPhysician",
  CLAIM_OTHER_PHYSICIAN_GRID: "api/ClaimOtherPhysician/Grid",

  // CLAIM UB CODES
  CLAIM_UB_CODES: "/api/ClaimUBCodes",
  // CLAIM OTHER INSURANCE
  CLAIM_OTHER_INSURANCE: "/api/ClaimOtherInsurance",

  // PLAN 
  PLAN: "/api/Plan",
  ACTIVE_PLANS: "/api/Plan/GetPlans",

  // MEMBER
  MEMBER: "/api/Member",
  MEMBER_LOOKUP: "/api/Member/GetMemberLookup",

  // COMMON CLINICAL CODE
  COMMON_CLINICAL_CODE: "/api/CommonClinicalCode",
  EFFECTIVE_CLINICAL_CODE: "/api/CommonClinicalCode/EffectiveClinicalCode",

  // POS CODE
  POS_CODE: "/api/POSCode",

  // CPT CODE
  CPT_CODES: "/api/CPT",
  GET_MODIFIED_CODES: "/api/CPT/GetModifierCodes",

  // ClaimService
  CLAIM_SERVICE: "/api/ClaimService",
  CLAIM_SERVICE_BY_CLAIM_HEADER: "/api/ClaimService/GetByClaimHeader",
  CLAIM_BENEFITS_BY_CLAIM_HEADER: "/api/ClaimService/GetClaimBenefitsByClaimNumber",
  GET_FEE_SCHEDULE_BY_CLAIM_HEADER: "/api/ClaimService/GetServiceFeeSchedule",
  GET_TERM_CONTRACT_BY_CLAIM_HEADER: "/api/ClaimService/GetServiceTermContract",
  CLAIM_SERVICE_GRID: "/api/ClaimService/ClaimServiceGrid",
  CLAIM_STATUS_NO_DENIAL: "/api/ClaimService/GetClaimStatusWithNoDenialCode",

  // CLAIM AUDIT
  CLAIM_AUDIT: "/api/ClaimAudit",
  GET_AUDIT_BY_CLAIM_HEADER: "/api/ClaimAudit/GetByClaimHeader",

  // CLAIM EDITS
  CLAIM_EDITS: "/api/ClaimEdits",
  CLAIM_EDIT_GRID: "/api/ClaimEdits/ClaimEditGrid",
  PROCESS_EDITS: "/api/ClaimEdits/ProcessEdits",

  // EDIT CODE
  EDIT_CODE: "/api/EditCode",

  // CLAIM NOTES
  CLAIM_NOTES: "/api/ClaimNotes",
  CLAIM_NOTES_BY_HEADER_ID: "/api/ClaimNotes/ClaimHeader",

  // CLAIM PROCESSING STEPS
  CLAIM_PROCESSING_STEPS: "/api/ClaimProcessingSteps",

  // NDC CODES
  NDC_CODES: "/api/NDCCodes",

  // BILL TYPE CODES
  BILL_TYPE_CODES: "/api/BillTypeCode",

  // DRG CODES
  DRG_CODES: "/api/DRGCode",
  DRG_ALL_CODES: "/api/DRGCode/GetAllCodes",


  // CLAIM ADJUDICATION
  FINAL_ADJUDICATION: "/api/ClaimHeader/FinalClaimAdjudication",
  SERVICE_CLAIM: "/api/ClaimHeader/ServiceClaimSave",
};