export const ODATA_ENDPOINTS = {
  // LOB 
  LOB: "/odata/Lobs",

  // CONTRACT HEADER
  CONTRACT_HEADER: "/odata/GetContracts",
}