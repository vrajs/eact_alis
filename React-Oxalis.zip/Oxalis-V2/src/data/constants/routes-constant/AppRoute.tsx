import { MenuModel } from "../../../core/types/layout";

export const AppRoute: MenuModel[] = [
  {
    label: "Operation",
    icon: "cl_three_group",
    to: "",
    items: [
      {
        label: "Provider",
        icon: "cl_care_hand",
        to: "",
        items: [
          {
            label: "Group",
            icon: "cl_arrow_right_fill",
            to: "/group",
          },
          {
            label: "Provider",
            icon: "cl_arrow_right_fill",
            to: "/provider",
          },
          {
            label: "Location",
            icon: "cl_arrow_right_fill",
            to: "/location",
          },
        ],
      },
      {
        label: "Member",
        icon: "cl_user_fill",
        to: "",
        items: [
          {
            label: "Member Dashboard",
            icon: "cl_arrow_right_fill",
            to: "/operation/member/member-dashboard",
          },
          {
            label: "Member Enrollment",
            icon: "cl_arrow_right_fill",
            to: "",
            items: [
              {
                label: "Pre-Enrollment",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/pre-enrollment",
              },
              {
                label: "Enrollment",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/enrollment",
              },
              {
                label: "OEC",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/oec-search",
              },
            ],
          },
          {
            label: "CMS Correspondence",
            icon: "cl_arrow_right_fill",
            to: "",
            items: [
              {
                label: "BEQ File Generation",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/cms-correspondence/beq-file-generation",
              },
              {
                label: "CMS Files",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/cms-correspondence/cms-files",
              },
              {
                label: "Marx File Generation",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/cms-correspondence/marx-file-generation",
              },
              {
                label: "Trr Fallouts",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/cms-correspondence/trr-fallouts",
              },
            ],
          },
          {
            label: "Member Correspondence",
            icon: "cl_arrow_right_fill",
            to: "",
            items: [
              {
                label: "Letter Generation",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/member-correspondence/letter-generation",
              },
              {
                label: "ID Cards",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/member-correspondence/id-cards",
              },
              {
                label: "Welcome Kits",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/member-correspondence/welcome-kits",
              },
            ],
          },
          {
            label: "Billing & Payments",
            icon: "cl_arrow_right_fill",
            to: "",
            items: [
              {
                label: "View Invoices",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/billing-and-payments/view-invoices",
              },
              {
                label: "CMS Payments",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/billing-and-payments/cms-payments",
              },
              {
                label: "Member Payment",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/billing-and-payments/member-payments",
              },
              {
                label: "Premium Account",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/billing-and-payments/premium-account-summary",
              },
            ],
          },
          {
            label: "Reports",
            icon: "cl_arrow_right_fill",
            to: "",
            items: [
              {
                label: "Timeliness Reports",
                icon: "cl_arrow_right_fill",
                to: "",
                items: [
                  {
                    label: "Incomplete Apps",
                    icon: "cl_arrow_right_fill",
                    to: "/operation/member/reports/timeliness-reports/incomplete-apps",
                  },
                  {
                    label: "Rfi Over Due",
                    icon: "cl_arrow_right_fill",
                    to: "/operation/member/reports/timeliness-reports/rfi-Overdue",
                  },
                  {
                    label: "Denial Report",
                    icon: "cl_arrow_right_fill",
                    to: "/operation/member/reports/timeliness-reports/denial-report",
                  },
                  {
                    label: "Cms Rejection",
                    icon: "cl_arrow_right_fill",
                    to: "/operation/member/reports/timeliness-reports/cms-rejections-report",
                  },
                  {
                    label: "Cms Pending",
                    icon: "cl_arrow_right_fill",
                    to: "/operation/member/reports/timeliness-reports/cms-pending-report",
                  },
                ],
              },
              {
                label: "Audit",
                icon: "cl_arrow_right_fill",
                to: "/operation/member/reports/audit",
              },
            ],
          },
        ],
      },
      {
        label: "Claims",
        icon: "cl_docs_fill",
        to: "",
        items: [
          {
            label: "Search",
            icon: "cl_arrow_right_fill",
            to: "/claims/search",
          },
          {
            label: "Dental",
            icon: "cl_arrow_right_fill",
            to: "/claims/dental",
          },
          {
            label: "Pharmacy",
            icon: "cl_arrow_right_fill",
            to: "/claims/pharmacy",
          },
          {
            label: "Mass Adjudication",
            icon: "cl_arrow_right_fill",
            to: "/claims/mass-adjudication-list",
          },
          // {
          //   label: "Refund",
          //   icon: "cl_arrow_right_fill",
          //   to: "",
          // },
        ],
      },
    ],
  },
  {
    label: "Administration",
    icon: "cl_case_manager",
    to: "",
    items: [
      {
        label: "Masters",
        icon: "cl_school_fill",
        to: "",
        items: [
          {
            label: "Codes",
            icon: "cl_arrow_right_fill",
            to: "/administration/masters/common-code",
          },
          {
            label: "ICD 9 & 10",
            icon: "cl_arrow_right_fill",
            to: "/administration/masters/icd-code",
          },
          {
            label: "Revenue",
            icon: "cl_arrow_right_fill",
            to: "/administration/masters/revenue-code",
          },
          {
            label: "DRG",
            icon: "cl_arrow_right_fill",
            to: "/administration/masters/drg-code",
          },
          {
            label: "Place Of Service",
            icon: "cl_arrow_right_fill",
            to: "/administration/masters/pos-code",
          },
          {
            label: "NDC",
            icon: "cl_arrow_right_fill",
            to: "/administration/masters/ndc-code",
          },
          {
            label: "HCC",
            icon: "cl_arrow_right_fill",
            to: "/administration/masters/hcc-code",
          },
          {
            label: "Zip Codes",
            icon: "cl_arrow_right_fill",
            to: "/administration/masters/zip-code",
          },
          {
            label: "Home Grown Code",
            icon: "cl_arrow_right_fill",
            to: "/administration/masters/home-grown-code-list",
          },
          {
            label: "Customer Setting",
            icon: "cl_arrow_right_fill",
            to: "/administration/masters/customer-setting-list",
          },
          {
            label: "Code Type",
            icon: "cl_arrow_right_fill",
            to: "/administration/masters/code-type-list",
          },
          {
            label: "Common Code",
            icon: "cl_arrow_right_fill",
            to: "/administration/masters/common-codesection-list",
          },
          {
            label: "Common Code Display Configuration",
            icon: "cl_arrow_right_fill",
            to: "/administration/masters/common-code-display-configuration",
          },
        ],
      },
      {
        label: "Security",
        icon: "cl_lock",
        to: "",
        items: [
          {
            label: "Users",
            icon: "cl_arrow_right_fill",
            to: "/administration/security/users",
          },
          {
            label: "Roles",
            icon: "cl_arrow_right_fill",
            to: "/administration/security/roles",
          },
        ],
      },
      {
        label: "Configuration",
        icon: "cl_settings",
        to: "",
        items: [
          {
            label: "Contracts",
            icon: "cl_arrow_right_fill",
            to: "/administration/configuration/contracts-list",
          },
          {
            label: "Benefits",
            icon: "cl_arrow_right_fill",
            to: "/administration/configuration/benefit-list",
          },
          {
            label: "Copay/Coinsurance",
            icon: "cl_arrow_right_fill",
            to: "/administration/configuration/copay-coinsurance-list",
          },
          {
            label: "Plan Benefit Package",
            icon: "cl_arrow_right_fill",
            to: "/administration/configuration/pbp-list",
          },
          {
            label: "TRC Config",
            icon: "cl_arrow_right_fill",
            to: "/administration/configuration/trc-config-list",
          },
          {
            label: "Line Of Business",
            icon: "cl_arrow_right_fill",
            to: "/administration/configuration/lob-list",
          },
          {
            label: "Organization Rule",
            icon: "cl_arrow_right_fill",
            to: "/administration/configuration/organization-rule-list",
          },
        ],
      },
    ],
  },
  {
    label: "Interfaces",
    icon: "cl_laptop",
    to: "",
    items: [
      {
        label: "Clearing House",
        icon: "cl_account_balance_fill",
        to: "",
        items: [
          {
            label: "834 Member Enrollment",
            icon: "cl_arrow_right_fill",
            to: "/interfaces/clearing-house/member-enrollment-list",
          },
          {
            label: "270 Member Eligibility Inguiry Response",
            icon: "cl_arrow_right_fill",
            to: "/interfaces/clearing-house/member-eligibilty-list",
          },
          {
            label: "837 Professional Claim",
            icon: "cl_arrow_right_fill",
            to: "/interfaces/clearing-house/professional-list",
          },
          {
            label: "837 Institutional Claim",
            icon: "cl_arrow_right_fill",
            to: "/interfaces/clearing-house/institutional-list",
          },
          {
            label: "276 Claim Status",
            icon: "cl_arrow_right_fill",
            to: "/interfaces/clearing-house/claim-status-list",
          },
          {
            label: "Encounter",
            icon: "cl_arrow_right_fill",
            to: "/interfaces/clearing-house/encounter-list",
          },
        ],
      },
    ],
  },
];
