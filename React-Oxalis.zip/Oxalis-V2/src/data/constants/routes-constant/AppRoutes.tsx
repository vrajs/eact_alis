import { MenuModel } from "../../../core/types/layout";
import { AppRoute } from "./AppRoute";

export const AppRoutes = (userRoles: string[]): MenuModel[] => {
  const allRoutes = [...AppRoute];
  return allRoutes.filter(
    (route) => route
      // !route.permittedUserRoles ||
      // route.permittedUserRoles.length === 0 ||
      // route.permittedUserRoles.some((role) => userRoles.includes(role))
  );
};
