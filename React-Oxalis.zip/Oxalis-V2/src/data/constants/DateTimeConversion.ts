import moment from "moment";
import { DateTimeConstant } from "./DateTimeConstants";

const getSQLFormattedDateTime = (date: string | Date | null): string => {
  const dt = date != null ? moment(date).format("YYYY-MM-DD HH:mm:ss") : moment(new Date()).format("YYYY-MM-DD HH:mm:ss");
  return dt;
};

export const utcConversionDateTime = (date: string | Date | null): string => {
  const localTime = moment.utc(getSQLFormattedDateTime(date)).local().format(DateTimeConstant.DTF);
  return localTime;
};
