export const REGEX_CONSTANTS = {
  NPI_VALIDATOR: /^\d{10}$/,
  TIN_VALIDATOR: /^\d{9}$/,
  ZIP_CODE: /^\d{5}$/,
  SSN: /^\d{9}$/,
  PROVIDER_NAME: /^[A-Za-z\s]+$/,
  // EMAIL: /^[A-Za-z][A-Za-z0-9._%+-]*@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/,
  EMAIL: /^[A-Za-z][A-Za-z0-9._%+-]*[A-Za-z0-9]%*@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$/,
  MBI: /\b[1-9][AC-HJKMNP-RT-Yac-hjkmnp-rt-y][AC-HJKMNP-RT-Yac-hjkmnp-rt-y0-9][0-9]-?[AC-HJKMNP-RT-Yac-hjkmnp-rt-y][AC-HJKMNP-RT-Yac-hjkmnp-rt-y0-9][0-9]-?[AC-HJKMNP-RT-Yac-hjkmnp-rt-y]{2}\d{2}\b/gm,
}