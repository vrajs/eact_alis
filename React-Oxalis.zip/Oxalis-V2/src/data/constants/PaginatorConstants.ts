interface PaginatorModel {
  selectionMode: "single" | "multiple";
  pageOptions: Array<number>;
  emptyMessage: string;
}

export const paginatorConstants: PaginatorModel = {
  pageOptions: [5, 10, 25, 50, 100],
  selectionMode: "single",
  emptyMessage: "No Records Found"
}