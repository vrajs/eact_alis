import { Toast } from "primereact/toast"
import { useRef } from "react"

const useToast = () => {
  const toastRef = useRef<Toast>(null);

  const showToast = (severity, summary: string, message: string) => {
    toastRef.current?.show({
      severity,
      summary,
      detail: message,
      life: 1500
    })
  }

  return { toastRef, showToast };
}

export default useToast;