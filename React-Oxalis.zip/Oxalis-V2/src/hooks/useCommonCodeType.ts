import { useEffect, useState } from "react"
import HttpClient from "../utils/http-client";
import { API_ENDPOINTS } from "../data/constants/AppConstants";
import { CommonCodeModel } from "../model/CommonCodeModel";

const useCommonCodeType = (id: number) => {
  const httpClient = new HttpClient();
  const [commonCodeList, setCommonCodeList] = useState<CommonCodeModel[]>([]);
  useEffect(() => {
    if (id > 0) {
      const getCommonCodes = async () => {
        const commonCodes = await httpClient.get<CommonCodeModel[]>(`${API_ENDPOINTS.COMMON_CODES}/${API_ENDPOINTS.GetCommonCodeByCodeTypeId}/${id}`)
        setCommonCodeList(commonCodes);
      }
      getCommonCodes();
    }
  }, [id])

  return commonCodeList;
}

export default useCommonCodeType;
