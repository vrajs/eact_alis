import moment from "moment";

const useFormattedDateTime = (data: Object, name: string) => {
  const value = data?.[name];
  if (value) {
    return moment(value).format("MM/DD/YYYY hh:mm");
  }
  return "N/A";
}

export default useFormattedDateTime;