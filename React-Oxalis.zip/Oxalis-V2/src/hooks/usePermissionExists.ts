import { PermissionValues } from "../data/constants/PermissionConstants";


const usePermissionExists = (permission: PermissionValues) => {
  const userPermissions: PermissionValues[] = JSON.parse(localStorage.getItem("user_permissions")) || [];
  const isPermissionExists = userPermissions.some((access) => access == permission);
  return isPermissionExists;
}

export default usePermissionExists;
