import { useEffect, useState } from "react"
import { KeyValueModel } from "../model/KeyValueModel"
import HttpClient from "../utils/http-client";
import { API_ENDPOINTS } from "../data/constants/AppConstants";

const useCommonCode = (id: number) => {
  const httpClient = new HttpClient();
  const [commonCodeList, setCommonCodeList] = useState<KeyValueModel[]>([]);
  useEffect(()  => {
    const getCommonCodes = async () => {
      const commonCodes = await httpClient.get<KeyValueModel[]>(`${API_ENDPOINTS.COMMON_CODES}/${id}`)
      setCommonCodeList(commonCodes);
    }
    getCommonCodes();
  }, [id])

  return commonCodeList;
}

export default useCommonCode;
