import { useEffect } from "react";
import { useDispatch } from "react-redux";
import { SaveKey } from "../Redux/features/keyboardShortcutSlice";

const useKeyboardShortCuts = () => {

  const dispatch = useDispatch();

  useEffect(() => {
    const handleKeyDown = (event) => {
      console.log(event)
      if (event.ctrlKey && event.altKey && event.keyCode === 83) {
        event.preventDefault();
        dispatch(SaveKey())
      }
    };

    document.addEventListener('keydown', handleKeyDown);

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, []);
}

export default useKeyboardShortCuts;
