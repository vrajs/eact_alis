import { LazyTableState } from "../model/LazyTableState";

const useQueryBuilder = (tableState: LazyTableState) => {
  const { first: skip, rows: take, sortField, sortOrder } = tableState;

  let query = "";
  query = `?skip=${skip}&take=${take}`;
  query += sortField ? `&sortField=${sortField}&sortOrder=${sortOrder}` : "";

  return query;
}

export default useQueryBuilder;