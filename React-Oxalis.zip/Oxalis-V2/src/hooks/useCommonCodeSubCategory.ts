import { useEffect, useState } from "react"
import { KeyValueModel } from "../model/KeyValueModel"
import HttpClient from "../utils/http-client";
import { API_ENDPOINTS } from "../data/constants/AppConstants";

const useCommonCodeSubCategory = (id: number, subCategoryId: number=0) => {
  const httpClient = new HttpClient();
  const [commonCodeList, setCommonCodeList] = useState<KeyValueModel[]>([]);
  useEffect(()  => {
    const getCommonCodes = async () => {
      const commonCodes = await httpClient.get<KeyValueModel[]>(`${API_ENDPOINTS.COMMON_CODES}/${id}/${subCategoryId}`)
      setCommonCodeList(commonCodes);
    }
    getCommonCodes();
  }, [id, subCategoryId])

  return commonCodeList;
}

export default useCommonCodeSubCategory;
