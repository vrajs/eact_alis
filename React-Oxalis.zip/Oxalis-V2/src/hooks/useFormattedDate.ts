import moment from "moment";

const useFormattedDate = (data: Object, name: string) => {
  const value = data?.[name];
  if (value) {
    return moment(value).format("MM/DD/YYYY");
  }
  return "N/A";
}

export default useFormattedDate;