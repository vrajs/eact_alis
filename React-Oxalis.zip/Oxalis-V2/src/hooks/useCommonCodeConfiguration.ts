import { useEffect, useState } from "react"
import { KeyValueModel } from "../model/KeyValueModel"
import HttpClient from "../utils/http-client";
import { API_ENDPOINTS } from "../data/constants/AppConstants";

const useCommonCodeConfiguration = (pageId: string, codeTypeId: number=0) => {
  const httpClient = new HttpClient();
  const [commonCodeList, setCommonCodeList] = useState<KeyValueModel[]>([]);
  useEffect(()  => {
    const getCommonCodes = async () => {
      const commonCodes = await httpClient.get<KeyValueModel[]>(`${API_ENDPOINTS.GET_COMMON_CODE_CONFIGURATION}/${pageId}/${codeTypeId}`)
      setCommonCodeList(commonCodes);
    }
    getCommonCodes();
  }, [pageId, codeTypeId])

  return commonCodeList;
}

export default useCommonCodeConfiguration;
