const useErrorHandler = (error: Error) => {
  if (error instanceof Error) {
    console.log(error.message)
    try {
      const message = JSON.parse(error.message);
      console.log("message message message", message)
      if (typeof (message) === 'string') {
        const errorMessage = message ?? 'Something went wrong';
        return errorMessage
      } else if (typeof (message) === 'object' && message?.["Already Link"]) {
        const errorMessage = message["Already Link"]['errors'][0]["errorMessage"]
        return errorMessage;
      } else if (typeof (message) === 'object' && message?.["errors"]) {
        const errorMessage = message["errors"][0];
        return errorMessage;
      }
    } catch {
      return error.message
    }
  }
}

export default useErrorHandler;