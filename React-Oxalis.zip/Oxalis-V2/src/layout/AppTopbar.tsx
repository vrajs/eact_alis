import { Button } from "primereact/button";
import { forwardRef, useContext, useImperativeHandle, useRef } from "react";
import { LayoutContext } from "./context/layoutcontext";
import { AppTopbarRef } from "../core/types/types";

const AppTopbar = forwardRef<AppTopbarRef>((props, ref) => {
  const { onMenuToggle, showProfileSidebar, showConfigSidebar } = useContext(LayoutContext);
  const menubuttonRef = useRef(null);

  const onConfigButtonClick = () => {
    showConfigSidebar();
  };

  useImperativeHandle(ref, () => ({
    menubutton: menubuttonRef.current,
  }));

  return (
    <div className="layout-topbar py-2 h-16">
      <div className="topbar-start">
        <button ref={menubuttonRef} type="button" className="topbar-menubutton p-link p-trigger" onClick={onMenuToggle}>
          <i className="pi pi-bars"></i>
        </button>
      </div>

      <div className="topbar-end">
        <ul className="topbar-menu">
          <li className="ml-3">
            <Button type="button" icon="pi pi-cog" text rounded severity="secondary" className="flex-shrink-0" onClick={onConfigButtonClick}></Button>
          </li>
          <li className="topbar-profile">
            <button type="button" className="p-link" onClick={showProfileSidebar}>
              <img src="/layout/images/avatar/avatar.png" alt="Profile" />
            </button>
          </li>
        </ul>
      </div>
    </div>
  );
});

AppTopbar.displayName = "AppTopbar";

export default AppTopbar;
