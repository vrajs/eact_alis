import { Toast } from "primereact/toast";
import { useRef } from "react";
import AppSubMenu from "./AppSubMenu";
import { AppRoute } from "../data/constants/routes-constant/AppRoute";

const AppMenu = () => {
  const toast = useRef<Toast>(null);

  const routes = AppRoute;

  return (
    <>
      <Toast ref={toast} />
      <AppSubMenu model={routes} />
    </>
  );
};

export default AppMenu;
