import { Toast, ToastMessageOptions, ToastProps } from "primereact/toast";
import { createContext, useContext, useEffect, useRef } from "react";
import { useSelector } from "react-redux";
import { RootState } from "../../Redux/app/store";

interface ToastProviderProps extends ToastMessageOptions {
  severity: 'success' | 'info' | 'warn' | 'error';
  summary: string;
  detail: string;
  life: 2000;
}

export interface ToastProviderState {
  showToast(options: ToastProviderProps): void;
}

export const ToastContext = createContext(null);

export const ToastProvider = ({ children }) => {
  const toastRef = useRef<Toast>(null);  
  const initialState: ToastProviderState = {
    showToast: (options: ToastProviderProps) => {
      const { severity, summary, detail, life } = options;
      toastRef.current.show({ severity, summary, detail, life })
    }
  };

  return <ToastContext.Provider value={initialState}>
    <Toast position="top-right" ref={toastRef} />
    {children}
  </ToastContext.Provider>
}

export const useToaster = () => {
  return useContext(ToastContext);
};