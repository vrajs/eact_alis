"use client";
import { Ripple } from "primereact/ripple";
import { classNames } from "primereact/utils";
import React, { useContext, useEffect, useRef } from "react";
import { useDispatch } from "react-redux";
import { useNavigate, useLocation } from "react-router";
import { useSubmenuOverlayPosition } from "../hooks/useSubmenuOverlayPosition";
import { LayoutContext } from "./context/layoutcontext";
import { MenuContext } from "./context/menucontext";
import { AppMenuItemProps } from "../core/types/types";
import { SetLayoutState } from "../Redux/features/layoutStateSlice";
import { AppMenuItem } from "../core/types/layout";

const AppMenuitem = (props: AppMenuItemProps) => {
  const location = useLocation();
  const pathname = location.pathname;
  const { activeMenu, setActiveMenu } = useContext(MenuContext);
  const { isSlim, isSlimPlus, isHorizontal, isDesktop, layoutState, layoutConfig } = useContext(LayoutContext);
  const submenuRef = useRef<HTMLUListElement>(null);
  const menuitemRef = useRef<HTMLLIElement>(null);
  const item = props.item;
  const key = props.parentKey ? props.parentKey + "-" + props.index : String(props.index);
  const isActiveRoute = item!.to && pathname === item!.to;
  const active = activeMenu === key || !!(activeMenu && activeMenu.startsWith(key + "-"));
  // const activeMenuItem = useSelector(selectActiveSideMenu);
  const navigate = useNavigate();
  const dispatch = useDispatch();

  useSubmenuOverlayPosition({
    target: menuitemRef.current,
    overlay: submenuRef.current,
    container: menuitemRef.current && menuitemRef.current.closest(".layout-menu-container"),
    when: props.root && active && (isSlim() || isSlimPlus() || isHorizontal()) && isDesktop(),
  });

  useEffect(() => {
    if (layoutState.resetMenu) {
      setActiveMenu("");
      dispatch(
        SetLayoutState({
          resetMenu: false,
        }),
      );
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [layoutState?.resetMenu]);

  useEffect(() => {
    if (!(isSlim() || isSlimPlus() || isHorizontal()) && isActiveRoute) {
      setActiveMenu(key);
    }
    const url = pathname; // + searchParams.toString();
    const onRouteChange = () => {
      if (!(isSlim() || isHorizontal()) && item!.to && item!.to === url) {
        setActiveMenu(key);
      }
    };
    onRouteChange();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    pathname,

    // searchParams,

    layoutConfig,
  ]);

  const itemClick = (event: React.MouseEvent<HTMLAnchorElement>) => {
    event.preventDefault();

    // Avoid processing disabled items
    if (item!.disabled) {
      return;
    }

    // Check if it's a submenu item
    if (item?.items) {
      if (active) {
        // Close only the clicked submenu by clearing the submenu's key
        setActiveMenu(key.substring(0, key.lastIndexOf("-"))); // Keep parent menu active, close only submenu
      } else {
        // Open the clicked submenu
        setActiveMenu(key);
      }

      if (props.root && !active && (isSlim() || isHorizontal() || isSlimPlus())) {
        dispatch(
          SetLayoutState({
            overlaySubmenuActive: true,
          }),
        );
      }
    } else {
      // Handle navigation or command execution for non-submenu items
      if (item?.to) {
        if (!isNaN(parseInt(item.to))) {
          // dispatch(SwitchDataBase(item?.to));
        } else {
          navigate(item?.to);
        }
      }

      if (item?.command) {
        item?.command({ originalEvent: event, item: item });
      }

      if (!isDesktop()) {
        dispatch(
          SetLayoutState({
            staticMenuMobileActive: !layoutState.staticMenuMobileActive,
          }),
        );
      }

      dispatch(
        SetLayoutState({
          menuHoverActive: false,
        }),
      );

      // Activate the clicked menu item
      setActiveMenu(key);
    }
  };

  const onMouseEnter = () => {
    // activate item on hover
    if (props.root && (isSlim() || isHorizontal() || isSlimPlus()) && isDesktop()) {
      if (!active && layoutState.menuHoverActive) {
        setActiveMenu(key);
      }
    }
  };
  const badge = item?.badge ? (
    <span
      className={classNames("layout-menu-badge p-tag p-tag-rounded ml-2 uppercase", {
        [`${item?.badge}`]: true,
        "p-tag-success": item?.badge === "new",
        "p-tag-info": item?.badge === "updated",
      })}
    >
      {item?.badge}
    </span>
  ) : null;
  const subMenu =
    item?.items && item?.visible !== false ? (
      <ul className="sub-menu-panel" ref={submenuRef}>
        {item?.items.map((child: AppMenuItem, i: number) => {
          return <AppMenuitem item={child} index={i} className={child.badgeClass} parentKey={key} key={child.label} />;
        })}
      </ul>
    ) : null;

  return (
    <li
      ref={menuitemRef}
      className={classNames({
        "layout-root-menuitem": props.root,
        "active-menuitem": active,
      })}
    >
      {props.root && item?.visible !== false && <div className="layout-menuitem-root-text">{item?.label}</div>}
      {(!item?.to || item?.items) && item?.visible !== false ? (
        <>
          <a
            href={item?.url}
            onClick={(e) => itemClick(e)}
            className={classNames(item?.class, "p-ripple tooltip-target")}
            target={item?.target}
            data-pr-tooltip={item?.label}
            data-pr-disabled={!(isSlim() && props.root && !layoutState.menuHoverActive)}
            tabIndex={0}
            onMouseEnter={onMouseEnter}
          >
            <i className={classNames("layout-menuitem-icon", item?.icon)}></i>
            <span className="layout-menuitem-text">{item?.label}</span>
            {item?.items && <i className="pi pi-fw pi-angle-down layout-submenu-toggler"></i>}
            <Ripple />
          </a>
        </>
      ) : null}

      {item?.to && !item?.items && item?.visible !== false ? (
        <>
          <a
            href={item?.to}
            onClick={(e) => itemClick(e)}
            className={classNames(item?.class, "p-ripple ", {
              "active-route": isActiveRoute,
            })}
            tabIndex={0}
            onMouseEnter={onMouseEnter}
          >
            <i className={classNames("layout-menuitem-icon", item?.icon)}></i>
            <span className="layout-menuitem-text">{item?.label}</span>
            {badge}
            {item?.items && <i className="pi pi-fw pi-angle-down layout-submenu-toggler"></i>}
            <Ripple />
          </a>
        </>
      ) : null}
      {subMenu}
    </li>
  );
};

export default AppMenuitem;
