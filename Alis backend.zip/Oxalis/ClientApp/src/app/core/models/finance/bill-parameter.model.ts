export class BillParameterModel {

    billParameterID: number;
    lOBID: number;
    sourceTypeID: number;   
    beginBillCycle: number;
    endBillCycle: number;
    daysLate: number;
    dueDate: number;
    latePenalty: number;
    nSF: number;
    administration: number;
    effectiveDate: Date;
    termDate: Date;
    recordStatus: number;
    isFreezed: number;
    recordStatusChangeComment: string;
    createdBy: string;
    createdDate: Date;
    updatedBy: string;
    updatedDate: Date;
}
