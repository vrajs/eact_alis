import { BaseModel } from "@app/core/models";

export class CompanyAccountModel extends BaseModel {
    public accountDetailCompanyStructureID: number;
    public accountDetailID: number;
    public organizationID: number;
    public companyID: number | null | undefined;
    public subCompanyID: number | null | undefined;
    public sponsorID: number | null | undefined;
    public productID: number;
    public categoryID: number | null | undefined;
    public lobID: number | null | undefined;
    public productTypeID: number | null | undefined;
    public healthPlanID: number | null | undefined;
    public organizationName: string;
    public companyName: string | null | undefined;
    public subCompanyName: string | null | undefined;
    public sponsorName: string | null | undefined;
    public productName: string;
    public categoryName: string | null | undefined;
    public lobName: string | null | undefined;
    public planName: string | null | undefined;
    public productTypeName: string | null | undefined;
}
