﻿export class RateCodeModel {

    rateCodeID: number;
    sourceTypeID: number;
    lOBID: number;
    rateTypeID: number;
    code: string;
    rate: number;
    effectiveDate: Date;
    termDate: Date;
    recordStatus: number;
    isFreezed: number;
    recordStatusChangeComment: string;
    createdBy: string;
    createdDate: Date;
    updatedBy: string;
    updatedDate: Date;

}