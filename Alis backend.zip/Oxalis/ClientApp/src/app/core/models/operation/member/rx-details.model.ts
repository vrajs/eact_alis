export class RxDetailsModel{
    primaryRxID: number;
    primaryRxGroup: string;
    primaryRxBin: string;
    primaryRxPcn: string;
}