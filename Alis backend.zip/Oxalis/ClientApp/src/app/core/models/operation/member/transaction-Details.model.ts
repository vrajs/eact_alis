import { BaseModel } from "../../common/base.model";
import { PlaceHolderReplaceViewModel } from "./placeHolder.model";

export class TransactionDetailsModel extends BaseModel {
    placeHolderReplaceViewModel: PlaceHolderReplaceViewModel;
    memberTransactionDetailId: number;
    memberId: number;
    pbpid: number;
    pbpName: string;
    electionTypeId: number;
    electionTypeName: string;
    contractId: number;
    contractName: string;
    transactionTypeId: number;
    transactionTypeName: string;
    sepReasonCodeId: number;
    sepReasonDate: Date;
    effectiveDate: Date;
    termDate: Date;
    signatureDate: Date;
    mBI: string;
    receiptDate: Date;
    isPartDOptOut: boolean;
    premiumWithholdOptionId: number;
    employerSubsidyOverride: string;
    disenrollmentReasonCodeId: number;
    rfiRequestedDate: Date;
    rfiDueDate: Date;
    rfiResponseDate: Date;
    transactionStatusId: number;
    pendReasonId: number;
    incompleteReasonId: number;
    isDenialFlag: boolean;
    denialReasonId: number;
    deniedDate: Date;
    cmsSubmissionDate: Date;
    trrResponseDate: Date;
    beqSubmissionDate: Date;
    beqResponseDate: Date;
    oevLetterSentDate: Date;
    transactionReplyCode: number;
    cmsSubmissionTrackingId: string;
    transactionStatusName: string;
    premiumWithholdOptionName: string;
    MemberStatusId: number;
    pcpid: number;
    pcpName: string;
    subGroupId: number;
    subGroupName: string;
}
export class TransactionDetailMember {
    pbpId: number | null;
    pbpDescription: string;
    contractId: number | null;
    contractDescription: string;
    constructor() {
        this.pbpId = 0;
        this.pbpDescription = "";
        this.contractId = 0;
        this.contractDescription = "";
    }
}
export class MemberLocation {
    city: string;
    address1: string;
    state: string;
    zip: string;
    homephone: string;
    birthDate: Date;
    insuredId: string;
}