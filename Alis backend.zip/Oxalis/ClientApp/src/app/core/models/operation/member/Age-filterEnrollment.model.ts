export class AgeEnrollmentSearchModel {
    trackingID: string;
    mBI: string;
    firstName: string;
    lastName: string;
    memberID: string;
    age: number;
    applicationStatusID: number | null;
    pBPID: number | null;
    contractID: number | null;
    memberStatusID: number | null;
    skip: number;
    take: number;
    transactionTypeId: string;
    transactionStatusId: string;
    effectiveDateFrom: string | null;
    effectiveDateTo: string | null;
    clientMemberId: string;
}