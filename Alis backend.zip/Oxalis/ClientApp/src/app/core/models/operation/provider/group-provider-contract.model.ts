export class GroupProviderContract {
    groupProviderContractId: number;
    providerRelationId: number;
    providerContractId: number;
    providerId: number;
    providerName: string;
    groupId: number | null;
    groupProviderName: string;
    contractHeaderId: number;
    contractHeaderName: string;
    providerStatusName: string;
    lobNames: string;
    effectiveDate: Date;
    termDate: Date | null | undefined;
}

export class GroupProviderContractTerminateModel {
    groupId: number;
    providerContractId?: number | null;
    termReason: string;
    termDate: Date;
}



