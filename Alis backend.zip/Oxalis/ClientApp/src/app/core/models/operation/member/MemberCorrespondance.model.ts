export class MemberCorrespondanceModel {
    mbi: string;
    memberId: number;
    letterType: number;
}