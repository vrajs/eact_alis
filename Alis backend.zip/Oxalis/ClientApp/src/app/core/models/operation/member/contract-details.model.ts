export class ContractDetailsModel{
    language: number;
    accessibilityFormatId: number;
    permanentAddressLine1: string;
    permanentAddressLine2: string;
    permanentAddressCity: string;
    permanentAddressState: string;
    permanentAddressZip:number;
    permanentAddressCounty:string;
    permanentStateAndCountyCode: number;
    phone:number;
    altPhone: number;
    contactPreference: number[];
    email: string;
    mailingAddressLine1: string;
    mailingAddressLine2: string;
    mailingAddressCity: string;
    mailingAddressState: string;
    mailingAddressZip: string;
    emergencyContactName: string;
    emergencyContactPhone: number;
    
}