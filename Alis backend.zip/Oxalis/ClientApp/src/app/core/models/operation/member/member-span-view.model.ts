import { BaseModel } from "../../common/base.model";

export class MemberSpanViewModel extends BaseModel {
        memberSpanId: number;
        memberId: number;
        spanTypeId: number;
        spanEffectivedate: Date;
        spanTermDate: Date;
        spanValue: number;
        spanSourceId: number;
        comments: string;
        isFreezed: number;
        spanType: string;
        spanSource: string;
}

