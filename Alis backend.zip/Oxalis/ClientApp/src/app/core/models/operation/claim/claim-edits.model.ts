
export class ClaimEditsModel {
    public claimEditsId: number;
    public claimHeaderId: number;
    public claimLineId: number;
    public editCode: string;
    public editDescription: string;
    public outComeId: number;
    public outComeCodeId?: number;
    public comments: string;
    public editCodeId: number;
    public isOverride: boolean;
    public lineNumber: number;
    public outCome: string;
    public outComeCode: string;
    public lastUpdatedDate: Date;
    public lastUpdatedBy: string;
    public isFreezedEditCode: number;

    constructor() {
        this.claimLineId = 0;
        this.claimEditsId = 0;
    }
}
