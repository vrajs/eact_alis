export class ProviderEFTModel {
    providerEFTId: number;
    providerId: number;
    accountTypeId: number;
    accountTypeName: string;
    bankName: string;
    nameOnAccount: string;
    accountNumber: string;
    routing: string;
    effectiveDate: Date;
    termDate?: Date | null | undefined;
}
