export class ProviderCodeModel {
    providerCodeId: number;
    providerId: number;
    controlTypeId: number;
    codeTypeId: number;
    codeValue: string;
    codeName: string;
    effectiveDate: Date;
    termDate?: Date | null | undefined;
}
