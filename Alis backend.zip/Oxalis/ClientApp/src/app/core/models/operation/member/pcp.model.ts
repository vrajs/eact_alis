export class PcpModel{
    pcpID: number;
    pcpName: string;
    currentPatient: string;
}