export class ActivityColorAndDate {
    activityType: string;
    date: string | null;
    colour: string;
}