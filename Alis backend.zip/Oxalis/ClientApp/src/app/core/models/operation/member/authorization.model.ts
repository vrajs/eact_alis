export class AuthorizationModel{
    authorisedRepName: string;
    authorisedRepAddress: string;
    authorisedRepRelationship: string;
    authorisedRepContactNumber: string;
}