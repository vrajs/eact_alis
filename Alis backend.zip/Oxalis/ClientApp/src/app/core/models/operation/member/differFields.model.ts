export class DifferFieldsViewModel {
    isFirstName: boolean | null;
    isLastName: boolean | null;
    isGender: boolean | null;
    isDob: boolean | null;
}