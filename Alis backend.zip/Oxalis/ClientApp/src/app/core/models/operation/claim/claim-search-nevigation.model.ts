import { KeyValModel } from '../../common/KeyVal.model';


export class ClaimSearchNevigationModel {
    public currentClaimNumber: string;
    public totalCount: number;
    public totalClaims: Array<KeyValModel>;
    public skip: number;
    public top: number;
    public orderby: string;
    public dataSourceURL;
    public isDisablePreviousButton: boolean = false;
    public isDisableNextButton: boolean = false;
    public isShowNextNPreButton = false;
}
