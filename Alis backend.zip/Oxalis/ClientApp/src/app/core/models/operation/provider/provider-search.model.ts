export class ProviderSearchModel {
    providerCode: string;    
    providerTypeIDs: number[];
    providerName: string;
    lastName: string;
    firstName: string;
    fullName: string;
    npi: string;
    tinNumber: string;
    specialtyIDs: string;
    languageIDs: string;
    constructor() {
        this.providerTypeIDs = [];
    }
}