﻿import { BaseModel } from "@app/core/models/common";

export class ClaimEOBEOPUserModel extends BaseModel {
    claimEobEopUserId: number;
    claimEobEopId: number;
    claimHeaderId: number;
    eobeopTypeId: number;
    line: number;
    code: string;
    description: string;
}