export class InvoiceListModel {
    invoiceId: number;
    invoiceNumber: string;
    mBI: string;
    memberId: number | null;
    invoiceGenDate: string | null;
    invoiceMonth: string;
    firstName: string;
    lastName: string;
    planId: string;
    billedAmount: number | null;
    mailDate: string | null;
    dueDate: string | null;
    paidAmount: number | null;
    paidDate: string | null;
    paidVia: string;
    balance: number | null;
    invoiceType: string;
    attachmentPath: string;
    createdBy: string;
    createdDate: string | null;
}
export class InvoiceListViewModel {
    invoiceList: InvoiceListModel[];
    totalCount: number;
}