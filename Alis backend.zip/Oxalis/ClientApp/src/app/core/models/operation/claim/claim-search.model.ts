// Project Namespace
import { StringFilterType, ClaimType } from '../../../../common/app-enum';

export class ClaimSearchModel {
    claimNumber: string;
    claimNumberFilterId: number;
    providerName: string;
    providerNameFilterId: number;
    providerCode: string;
    providerCodeFilterId: number;
    memberName: string;
    memberNameFilterId: number;
    memberCode: string;
    memberCodeFilterId: number;
    claimTypeId: number;
    checkNumber: number;
    checkNumberFilterId: number;
    authorizationNumber: string;
    authorizationNumberFilterId: number;
    dosFrom: Date;
    dosTo: Date;
    paidFrom: Date;
    paidTo: Date;
    receivedFrom: Date;
    receivedTo: Date;
    isIncludeDeleted: boolean;
    claimStatusReason: number;
    constructor() {
        this.claimNumberFilterId = StringFilterType.Contain;
        this.providerNameFilterId = StringFilterType.Contain;
        this.memberNameFilterId = StringFilterType.Contain;
        this.providerNameFilterId = StringFilterType.Contain;
        this.authorizationNumberFilterId = StringFilterType.Contain;
        this.memberCodeFilterId = StringFilterType.Contain;
        this.providerCodeFilterId = StringFilterType.Contain;
        this.checkNumberFilterId = StringFilterType.Contain;
        this.claimTypeId = ClaimType.All;
        this.isIncludeDeleted = false;
        this.claimStatusReason = StringFilterType.Contain;
    }
}
