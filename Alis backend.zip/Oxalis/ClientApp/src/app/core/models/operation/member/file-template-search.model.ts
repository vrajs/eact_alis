import { GridFilter } from "../../common/grid-filter.model";
export class FileTemplateSearch extends GridFilter {
    
    
    constructor() {
        super();
        this.fileSubCategoryId = 0;
        this.fileCategoryId = 0;
        this.fileName = null;
        this.fileDateFrom = null;
        this.fileDateTo = null;        
        this.orderByColumn = "FileDate";
        this.isDesc = true;
        this.fileTemplateTypeId = 0;
        this.dataFileTemplateId = 0;
    }
    fileSubCategoryId: number;
    fileCategoryId: number;
    fileName: any;
    fileDateFrom: any;
    fileDateTo: any;
    orderByColumn: string;
    isDesc: boolean;
    fileTemplateTypeId: number;
    dataFileTemplateId: number;

    // constructor() {
    //     super();
    //     this.fileTemplateTypeId = 0;
    //     this.dataFileTemplateId = 0;
    //     this.fileName = null;
    //     this.fileDateFrom = null;
    //     this.fileDateTo = null;        
    //     this.orderByColumn = "FileDate";
    //     this.isDesc = true;
    // }
    // fileTemplateTypeId: number;
    // dataFileTemplateId: number;
    // fileName: any;
    // fileDateFrom: any;
    // fileDateTo: any;
    // orderByColumn: string;
    // isDesc: boolean;
}
