export class ClaimsListingSearchModel {
    
}