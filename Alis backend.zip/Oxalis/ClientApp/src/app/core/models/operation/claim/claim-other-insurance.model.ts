import { BaseModel } from '../../common/base.model';

export class ClaimOtherInsuranceModel extends BaseModel {
    claimOtherInsuranceId: number;
    claimHeaderId: number;
    memberId: number;
    isLineLevel: boolean;
    serviceLineNumber: number;
    dosFrom: Date;
    dosTo: Date;
    posCode: string;
    revenueCode: string;
    procedureCode: string;
    modifiers: string;
    billedAmount: number;
    units: number;
    eobDate: Date;
    allowedAmount : number;
    deductibleAmount : number;
    copayAmount : number;
    coinsuranceAmount : number;
    netAllowedAmount : number;
    totalPaidAmount: number;
    sourceInsuranceName: string;
    insuranceCarrierId?: number
    addedSource: string;

    constructor() {
        super();
        this.addedSource = '';
    }

}
