export class PremiumAccountViewModel {
    invoiceMonth: string;
    invoiceNumber: string;
    invoiceAmount: number | null;
    paidDate: string | null;
    paymentReference: string;
    paidVia: string;
    paidAmount: number | null;
}

export class PremiumAccountFilter {
    mBI: string;
    memberCode: string;
    fromDate: string | null;
    toDate: string | null;
    skip: number;
    take: number;
}

export class PremiumAccountResponse {
    data: PremiumAccountViewModel[];
    totals: Totals;
}

export class Totals {
    memberCode: string;
    memberName: string;
    totalInvoiceAmount: number | null;
    totalPaidAmount: number | null;
    totalNetDueAmount: number | null;
}