export class CMSReportModel {
    memberId: string;
    memberName: string;
    pBPID: string;
    contractID: string;
    effectiveDate: string | null;
    transactionType: string;
    cMSSubmissionDate: string | null;
    transactionReplyCode: string;
    tRRResponseDate: string | null;
}