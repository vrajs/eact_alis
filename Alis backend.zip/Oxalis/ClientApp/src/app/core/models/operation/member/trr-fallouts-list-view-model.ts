import { TRRFalloutList } from "./trr-fallout-list.model";

export class TRRFalloutsListViewModel {
    trrFalloutsList: TRRFalloutList[];
    totalRecords: number;
}