import { OtherDocument } from "./otherdocument.model";

export class SaveMemberPreEnrollment {
    memberPreEnrollmentId: number;
    trackingId: string;
    applicationStatusID: number | null;
    contractId: number | null;
    mbi: string;
    dob: Date;
    genderId: number | null;
    firstName: string;
    lastName: string;
    middleInitial: string;
    permanentAddressCity: string;
    permanentAddressState: string;
    permanentAddressZip: string;
    permanentAddressCounty: string;
    medicarePartAEffectiveDate: string;
    medicarePartBEffectiveDate: string;
    isESRD: boolean;
    isEnrolledInStateMedicaid: boolean;
    isEGHP: boolean;
    receiptDate: string;
    memberPreEnrollmentSourceId: number;
    memberId: number;
    effectiveDate: string;
    termDate: string;
    addedSource: string;
    updatedSource: string;
    loadComment: string;
    createdBy: string;
    permanentStateAndCountyCode: string;
    documentList: OtherDocument[];
    attachmentTypeId: number;
}