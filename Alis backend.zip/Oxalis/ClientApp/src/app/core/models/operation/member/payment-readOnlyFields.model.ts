export class PaymentReadOnlyFiels {
    mbi: string;
    memberId: number | null;
    lastName: string;
    firstName: string;
    totalDueAmount: number | null;
}