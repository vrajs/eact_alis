

export class MarxSearchModel {
    constructor()
    {
        this.pbpId=0;
        this.contractId=0;
        this.transactionTypeId=0;
        this.effectiveDate=new Date();
        this.isFormValid=false;
        
    }
 public pbpId:number;
 public contractId:number=51501;
 public transactionTypeId:number;
 public effectiveDate:Date;
 public isFormValid:boolean;
 
}
