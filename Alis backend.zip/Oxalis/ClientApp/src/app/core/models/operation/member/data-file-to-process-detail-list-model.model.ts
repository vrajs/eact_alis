export class DataFileToProcessDetailListModel {
    constructor() {
        this.dataFileToProcessDetailsId = 0;
        this.dataFileToProcessId = 0;
        this.fileName = "";
    }
    dataFileToProcessDetailsId: number;
    dataFileToProcessId: number;
    fileName: string
}
