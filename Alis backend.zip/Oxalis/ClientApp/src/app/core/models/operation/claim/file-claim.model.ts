export class EDI837PUploadFileModel {
    fileID: number;
    tradingPartnerID: string;
    createdBy: string;
    error: boolean;
    errorMessage: string;
    payerName: string;
    fileMonth: string;
    fileName: string;
    total: number;
    pending: number;
    inProgress: number;
    posted: number;
    failed: number;
    createdDate: string;
    fileStatus: string;
    billedAmount: number | null;
    version: string;
    hasError: string;
}