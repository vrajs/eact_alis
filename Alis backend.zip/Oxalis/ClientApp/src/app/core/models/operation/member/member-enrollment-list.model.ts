export class MemberEnrollmentList {
    memberEnrollmentHeaderId: number;
    trackingId: string;
    mbi: string;
    lastName: string;
    firstName: string;
    memberId: string;
    applicationStatusName: string;
    contractDescription: string;
    pbpDescription: string;
    totalCount: number;
    contractIdAndPBP: string;
    memberStatus: string;
}