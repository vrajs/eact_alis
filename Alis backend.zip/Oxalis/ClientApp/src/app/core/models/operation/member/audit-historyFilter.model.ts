export class AuditHistoryFilterModel {
    memberId: number | null;
    modifiedField: string;
    beforeValue: string;
    afterValue: string;
    fromDate: string | null;
    toDate: string | null;
    modifiedBy: string;
    source: string;
    mBI: string;
}