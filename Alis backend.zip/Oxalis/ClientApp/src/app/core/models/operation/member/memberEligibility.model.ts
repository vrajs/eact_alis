import { BaseModel } from "@app/core/models"
import { GetPlanModel } from './getPlanModel.model';


export class MemberEligibilityModel extends BaseModel{
    memberEligibilityID: number;
    memberID: number;
    company: string;
    companyID: number;
    subCompanyID: number;
    subCompany: string;
    lobid: number;
    lob: string;
    healthPlanID: number;
    healthPlan: string;
    coverageTypeID: number;
    coverageType: string;
    insuranceMemberCode: string;
    policyNumber: string;
    groupName: string;
    riskTypeID: number;
    riskType: string;
    effectiveDate: Date;
    termDate?: Date;
    disenrollmentReasonID?: number;
    disenrollmentReason: string;
    healthPlanInfo?: GetPlanModel
    recordStatus: number;
    productType?: string;
    pbp?: string;
    memberCode?: string;
    memberName?: string;
    relationship?: string;
    constructor() {
        super();
        this.memberEligibilityID = 0;
        this.companyID = -1;
        this.subCompanyID = -1;
        this.lobid = -1;
        this.healthPlanID = -1;
        this.riskTypeID = -1;
        this.policyNumber = "";
        this.insuranceMemberCode = "";
        this.groupName = "";
        this.recordStatus = 0;
    }
}
