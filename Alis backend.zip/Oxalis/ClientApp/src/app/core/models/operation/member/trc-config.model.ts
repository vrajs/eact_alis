import { GridFilter } from "../../common/grid-filter.model";
export class TrcConfigSearch extends GridFilter {

    contractId: number;
    pbpId: number[];
    trc: string;
    planAction: string;
    skip: number;
    take: number;
}
export class TrcConfigData extends GridFilter {

    key: number;
    value: string;
}