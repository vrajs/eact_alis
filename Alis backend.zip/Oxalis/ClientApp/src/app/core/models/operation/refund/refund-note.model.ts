export class RefundNoteModel {
    refundNoteId: number;
    refundRequestId: number;
    shortDesc: string;
    longDesc: string;
    effectiveDate: Date;
    termDate: Date;
    createdBy:string;
    createdDate:Date;
    constructor() {
        this.refundNoteId = 0;
    }
}
