export class IPALOBModel {
    ipaLobId: number;
    ipaId: number;
    lobId: number;
    lobName: string;
    premiumPercentage: number;
    effectiveDate: Date;
    termDate: Date;
}