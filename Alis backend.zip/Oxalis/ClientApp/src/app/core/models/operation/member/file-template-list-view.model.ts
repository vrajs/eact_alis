import { FileTemplateList } from "./file-template-list.model";

export class FileTemplateListView {
    fileTemplateList: FileTemplateList[];
    totalRecords: number;
}
