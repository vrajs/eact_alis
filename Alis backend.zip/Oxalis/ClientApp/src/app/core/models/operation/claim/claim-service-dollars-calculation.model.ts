export class DollarsCalculationModel
{
 public benefitHeaderId: number ;
 public feeScheduleId: number ;
 public providerContractId: number ;
 public code: string ;
 public modifiers: string[] ;
 public dosFrom: Date ;
 public dosTo: Date;
 public posCode: string;
}
