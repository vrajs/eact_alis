export class RuleHeaderCapitationModel {
    public ruleHeaderCapitationId: number;
    public ruleHeaderId: number;
    public capitationTypeId: number;
    public ageInDays: number;
    public prorateMethodId: number;
    public startDayOfMonth: number;
    public beforeStartPercentage: number;
    public afterStartPercentage: number;
    public effectiveDate: Date;
    public termDate?: Date;
}
