export class ModifierDiscountModel {
    modifierDiscountId: number;
    modifierDiscountGroupId: number;
    modifierDiscountGroup: string;
    modifierCode: string;
    modifierPercentage: number;
    start: number;
    end: number;
    effectiveDate: Date;
    termDate?: Date | null | undefined;    
}
