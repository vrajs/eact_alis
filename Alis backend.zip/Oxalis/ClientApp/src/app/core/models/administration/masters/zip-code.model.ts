import { BaseModel } from "@app/core/models"

export class ZipCodeModel extends BaseModel {        
    public zipCodeId: number;    
    public code: string;    
    public areaCode: string;    
    public state: string;    
    public stateFullName: string;    
    public city: string;    
    public county: string;    
    public country: string;
    public isRural: boolean;
    public dmeRuralStartDate: Date | null;
    public dmeRuralEndDate: Date | null;    
    public countyCode: string;    

    constructor() {
        super();
        this.country = 'USA';
        this.zipCodeId = 0;
        this.areaCode = '';
        this.dmeRuralStartDate = null;
        this.dmeRuralEndDate = null;
    }
}
