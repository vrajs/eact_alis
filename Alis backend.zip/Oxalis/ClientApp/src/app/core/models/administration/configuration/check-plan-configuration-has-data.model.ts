export class CheckPlanConfigurationHasDataModel {
    hasBenefitData: boolean;
    hasDeductibleMaxoopData: boolean;
}