export class HasBenefitConfigurationDataModel {
    hasCodeData: boolean = false;
    hasServiceGroupData: boolean = false;
    hasModifierData: boolean = false;
    hasDiagnosisData: boolean = false;
    hasPlaceOfServiceData: boolean = false;
    hasBillTypeData: boolean = false;
    hasProviderData: boolean = false;
    hasCopayCoInsuranceData: boolean = false;
    hasCopayPerDiemData: boolean = false;
    hasVisitsData: boolean = false;
    hasDeductibleMAXOOPData: boolean = false;
}