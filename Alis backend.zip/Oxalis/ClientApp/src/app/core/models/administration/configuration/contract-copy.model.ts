export class ContactCopyModel {
    contractCode: string;
    contractId: number;
    contractName: string;
    effectiveDate: Date;
    termDate: Date | null;
    termHeaderIds: number[];
 }