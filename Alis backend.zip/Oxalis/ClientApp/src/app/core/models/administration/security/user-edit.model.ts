import { UserModel } from '@app/core/models';

export class UserEditModel extends UserModel {
    constructor(currentPassword?: string, newPassword?: string, confirmPassword?: string, resetToken?: string, passwordType?: string) {
        super();

        this.currentPassword = currentPassword;
        this.newPassword = newPassword;
        this.confirmPassword = confirmPassword;
        this.resetToken = resetToken;
        this.passwordType = passwordType;
    }

    public currentPassword: string;
    public newPassword: string;
    public confirmPassword: string;
    public resetToken: string;
    public passwordType: string;
}
