export class CompanyParameter {    
    companyId: number;
    subCompanyId: number;
}