export class RuleHeaderMessageModel {
    public ruleHeaderMessageId: number;
    public ruleHeaderId: number;
    public messageTypeId: number;
    public englishMessage: string;
    public alternateLanguageMessage: string;
    public splashMessage: string;
    public formNumber: string;
    public logoPath: string;
    public englishMessageEffectiveDate: Date;
    public englishMessageTermDate?: Date;
    public splashMessageEffectiveDate: Date;
    public splashMessageTermDate?: Date;
    constructor() {
        this.ruleHeaderMessageId = 0;
        this.alternateLanguageMessage = "";
        this.splashMessage = "";
    }
}
