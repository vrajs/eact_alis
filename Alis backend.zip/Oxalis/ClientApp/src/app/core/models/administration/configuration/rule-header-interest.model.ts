export class RuleHeaderInterestModel {
    public ruleHeaderInterestId: number;
    public ruleHeaderId: number;
    public interestQuickPayId: number;
    public schedule: string;
    public effectiveDate: Date;
    public termDate?: Date;
}
