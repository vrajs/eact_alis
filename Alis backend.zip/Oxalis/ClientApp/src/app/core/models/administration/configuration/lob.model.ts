export class LobModel {
    url: string;
    lobId: number;
    lobCode: string;
    lobName: string;
    submitterCode: string;
    caidContractNumber: string;
    careContractNumber: string;
    nICNumber: string;
    effectiveDate: Date;
    termDate: Date | null;
    organizationId: number;
    sponsorId: number;
    categoryId: number;
    subCompanyId:number;
    updatedBy: string | null | undefined;
    updatedDate: Date | null | undefined;
    recordStatus: boolean;
    recordStatusChangeComment: string | null | undefined;
    productId: number;
    companyId: number | null;
    organizationName: string;
    sponsorName: string;
    categoryName: string;
    productName: string;

    constructor() {
        this.lobId = 0;
        this.submitterCode = " ";
        this.caidContractNumber = " ";
        this.careContractNumber = " ";
        this.nICNumber = " ";
        this.companyId = -1;
        this.organizationId = -1;
        this.sponsorId = -1;
        this.productId = -1;
        this.effectiveDate = new Date();
    }
}

/*export class LobModel{
    lobId: number;
    lobCode: string;
    lobName: string;
    companyId: number;
    organizationId: number;
    sponsorId: number;
    categoryId: number;
    productId: number;
    effectiveDate: Date;
    termDate: Date | null;
    recordStatus: boolean;
    recordStatusChangeComment: string | null | undefined;
    createdBy: string;
    createdDate: Date;
    updatedBy: string | null | undefined;
    updatedDate: Date | null | undefined;
    submitterCode: string;
    caidContractNumber: string;
    careContractNumber: string;
    NICNumber: string;
    sponsorName: string;
    categoryName: string;
    productName: string;

    constructor() {
        this.lobId = 0;
        this.submitterCode = " ";
        this.caidContractNumber = " ";
        this.careContractNumber = " ";
        this.NICNumber = " ";
        this.companyId = -1;
        this.organizationId = -1;
        this.sponsorId = -1;
        this.productId = -1;
        this.effectiveDate = new Date();
    }
}*/