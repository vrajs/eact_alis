export class CopyPlanModel {
    planId: number;
    planCode: string;
    planName: string;
    benefitHeaderIds: number[];
    approvalStatusId: number;
    approvalDate: Date;
    effectiveDate: Date;
    termDate: Date;
}