import { BaseModel } from "@app/core/models";

export class HomeGrownCodeModel extends BaseModel {
    public homeGrownCodeId: number;
    public code: string; 
    public codeTypeId: number;
    public shortDescription: string;
    public longDescription: string;
    public mappedCode: string;
    public homeGrown: string;
    public type : string;
    public effectiveDate: Date;
    public termDate: Date | null;
    public standardCodeEffectiveDate: Date;
    public standardCodeTermDate: Date | null;
     
    constructor() {        
        super();
        this.homeGrown = "Y";   
        this.homeGrownCodeId = 0;
    }
}

