import { UserPermissionModel } from '@app/core/models'

export class UserLogin extends UserPermissionModel {
    constructor(email?: string, password?: string, rememberMe?: boolean) {
        super()
        this.email = email;
        this.password = password;
        this.rememberMe = rememberMe;
    }

    email: string;
    password: string;
    rememberMe: boolean;
}