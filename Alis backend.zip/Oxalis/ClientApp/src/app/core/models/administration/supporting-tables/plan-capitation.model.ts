import { BaseModel } from "../../common/base.model";

export class PlanCapitationModel extends BaseModel {

    public capitationPlanId: number;    
    public capitationHeaderId: number;    
    public healthPlanId: number;
    public minAge: number;
    public maxAge: number;    
    public gender: string;
    public pcpZip: string;    
    public memberZip: string;    
    public county: string;
    public eligibleMonths: number;    
    public rate: number;   
    public planName: string;
    public effectiveDate: Date;    
    public termDate: Date;

    constructor() {
        super();
        this.county = '';
        this.memberZip = '';
        this.pcpZip = '';
    }
}
