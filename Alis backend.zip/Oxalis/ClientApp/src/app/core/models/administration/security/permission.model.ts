export type PermissionNames =
    "View Users" | "Manage Users" |
    "View Roles" | "Manage Roles" | "Assign Roles";

export type PermissionValues =
    "G21X" |
    "3AD1" |
    "G059" |
    "K27N" |
    "88MN" |
    "HLM3" |
    "N9BT" |
    "R723" |
    "0CWQ" |
    "2YKU" |
    "N19X" |
    "2VGC" |
    "5Z7G" |
    "AFSN" |
    "5N1V" |
    "87O1" |
    "GT4V" |
    "FHWA" |
    "91MY" |
    "MR6E" |
    "C8BX" |
    "XLN8" |
    "NMVC" |
    "ZOR7" |
    "ZW4B" |
    "FFG4" |
    "DVX3" |
    "88OZ" |
    "Z7LF" |
    "WAUT" |
    "QF8M" |
    "D32K" |
    "ZGQ9" |
    "U11H" |
    "FZAP" |
    "CQEY" |
    "07XQ" |
    "58DQ" |
    "OY8A" |
    "KNLC" |
    "AQ0H" |
    "WXK8" |
    "W8ZI" |
    "ZV15" |
    "6G3L" |
    "SBE2" |
    "40AI" |
    "065E" |
    "5G93" |
    "FJAG" |
    "JI72" |
    "YLO8" |
    "INNE" |
    "BXQ7" |
    "5S0L" |
    "USSR" |
    "MDEB" |
    "RZWQ" |
    "WNIZ" |
    "E7BM" |
    "RWT0" |
    "QC19" |
    "7126" |
    "6DUP" |
    "PP76" |
    "6VVD" |
    "4UVU" |
    "JOME" |
    "BKR6" |
    "LTJ7" |
    "JP0J" |
    "1KRW" |
    "P7S3" |
    "6VJD" |
    "NFL0" |
    "XFHA" |
    "OT8J" |
    "3S2M" |
    "YEIJ" |
    "FM1J" |
    "7WU1" |
    "A8P5" |
    "A489" |
    "TCJY" |
    "GNRW" |
    "7LY1" |
    "L4A1" |
    "IR2R" |
    "3I4P" |
    "J9P5" |
    "W5ML" |
    "NTKP" |
    "9H46" |
    "A97S" |
    "MCHP" |
    "20HG" |
    "RM6W" |
    "G53T" |
    "C9VX" |
    "ZJ83" |
    "CEK9" |
    "SYW9" |
    "T9O0" |
    "A5V4" |
    "LWG7" |
    "WEOY" |
    "DFY9" |
    "L6EZ" |
    "ZWO6" |
    "NY16" |
    "BQ0C" |
    "FZMV" |
    "TUQO" |
    "T5DS" |
    "U1FK" |
    "85Z5" |
    "87X5" |
    "AGQN" |
    "KOF9" |
    "W1O3" |
    "5C1O" |
    "EOFC" |
    "G83E" |
    "49MX" |
    "YBEL" |
    "QTJW" |
    "80QQ" |
    "LDXI" |
    "LESL" |
    "LHJJ" |
    "5GU7" |
    "54CA" |
    "WYN7" |
    "U8T3" |
    "4BIP" |
    "2GKS" |
    "G6TV" |
    "11BV" |
    "353W" |
    "PX2T" |
    "JEYX" |
    "C4X4" |
    "YU0R" |
    "5RVW" |
    "EXLF" |
    "4ETQ" |
    "KZ3A" |
    "IYMG" |
    "ZETK" |
    "5APQ" |
    "8D14" |
    "LS34" |
    "1O2M" |
    "RO7I" |
    "4YM5" |
    "0G45" |
    "00KB" |
    "DCDL" |
    "9O30" |
    "DDGW" |
    "ASAO" |
    "IQPQ" |
    "K05D" |
    "F8US" |
    "2U9L" |
    "8GUP" |
    "7OB4" |
    "WA53" |
    "74W1" |
    "ELH4" |
    "60HR" |
    "NOEC" |
    "Q0VR" |
    "6MHH" |
    "ZCF9" |
    "2UYG" |
    "HQAZ" |
    "CK23" |
    "8SLW" |
    "V0NK" |
    "NM01" |
    "YHR6" |
    "YQZV" |
    "OOSC" |
    "BEXY" |
    "V0RJ" |
    "AA2A" |
    "AA2B" |
    "AA2C" |
    "AA2D" |
    "AL2A" |
    "AL2B" |
    "AL2C" |
    "AL2D";



export class Permission {
    static readonly permission_to_view_users_account_details: PermissionValues = "G21X";
    static readonly permission_to_create_update_users_account_details: PermissionValues = "3AD1";
    static readonly permission_to_view_available_roles: PermissionValues = "G059";
    static readonly permission_to_create_update_roles: PermissionValues = "K27N";
    static readonly permission_to_view_professional_claims: PermissionValues = "88MN";
    static readonly permission_to_add_professional_claims: PermissionValues = "HLM3";
    static readonly permission_to_update_professional_claims: PermissionValues = "N9BT";
    static readonly permission_to_delete_professional_claims: PermissionValues = "R723";
    static readonly permission_to_access_alternate_feeschedule_in_professional_claim: PermissionValues = "0CWQ";
    static readonly permission_to_manual_override_professional_claims: PermissionValues = "2YKU";
    static readonly permission_to_update_professional_claim_edits: PermissionValues = "N19X";
    static readonly permission_to_update_professional_claim_notes: PermissionValues = "2VGC";
    static readonly permission_to_view_institutional_claims: PermissionValues = "5Z7G";
    static readonly permission_to_add_institutional_claims: PermissionValues = "AFSN";
    static readonly permission_to_update_institutional_claims: PermissionValues = "5N1V";
    static readonly permission_to_delete_institutional_claims: PermissionValues = "87O1";
    static readonly permission_to_access_alternate_feeschedule_in_institutional_claim: PermissionValues = "GT4V";
    static readonly permission_to_manual_override_institutional_claims: PermissionValues = "FHWA";
    static readonly permission_to_update_institutional_claim_edits: PermissionValues = "91MY";
    static readonly permission_to_update_institutional_claim_notes: PermissionValues = "MR6E";
    static readonly permission_to_view_dental_claims: PermissionValues = "C8BX";
    static readonly permission_to_add_dental_claims: PermissionValues = "XLN8";
    static readonly permission_to_update_dental_claims: PermissionValues = "NMVC";
    static readonly permission_to_delete_dental_claims: PermissionValues = "ZOR7";
    static readonly permission_to_access_alternate_feeschedule_in_dental_claim: PermissionValues = "ZW4B";
    static readonly permission_to_manual_override_dental_claims: PermissionValues = "FFG4";
    static readonly permission_to_update_dental_claime_dits: PermissionValues = "DVX3";
    static readonly permission_to_update_dental_claim_notes: PermissionValues = "88OZ";
    static readonly permission_to_view_lab_claims: PermissionValues = "Z7LF";
    static readonly permission_to_add_lab_claims: PermissionValues = "WAUT";
    static readonly permission_to_update_lab_claims: PermissionValues = "QF8M";
    static readonly permission_to_delete_lab_claims: PermissionValues = "D32K";
    static readonly permission_to_access_alternate_feeschedule_in_lab_claim: PermissionValues = "ZGQ9";
    static readonly permission_to_manual_override_lab_claims: PermissionValues = "U11H";
    static readonly permission_to_update_lab_claime_dits: PermissionValues = "FZAP";
    static readonly permission_to_update_lab_claim_notes: PermissionValues = "CQEY";
    static readonly permission_to_view_pharmacy_claims: PermissionValues = "07XQ";
    static readonly permission_to_add_pharmacy_claims: PermissionValues = "58DQ";
    static readonly permission_to_update_pharmacy_claims: PermissionValues = "OY8A";
    static readonly permission_to_delete_pharmacy_claims: PermissionValues = "KNLC";
    static readonly permission_to_access_alternate_feeschedule_in_pharmacy_claim: PermissionValues = "AQ0H";
    static readonly permission_to_manual_override_pharmacy_claims: PermissionValues = "WXK8";
    static readonly permission_to_update_pharmacy_claime_dits: PermissionValues = "W8ZI";
    static readonly permission_to_update_pharmacy_claim_notes: PermissionValues = "ZV15";
    static readonly permission_to_view_claim_refund: PermissionValues = "6G3L";
    static readonly permission_to_add_claim_refund: PermissionValues = "SBE2";
    static readonly permission_to_update_claim_refund: PermissionValues = "40AI";
    static readonly permission_to_delete_claim_refund: PermissionValues = "065E";
    static readonly all_permission_for_claims_mass_adjudication: PermissionValues = "5G93";
    static readonly permission_to_view_member: PermissionValues = "FJAG";
    static readonly permission_to_add_member: PermissionValues = "JI72";
    static readonly permission_to_update_member: PermissionValues = "YLO8";
    static readonly permission_to_delete_member: PermissionValues = "INNE";
    static readonly permission_to_view_member_billing: PermissionValues = "BXQ7";
    static readonly permission_to_add_member_billing: PermissionValues = "5S0L";
    static readonly permission_to_update_member_billing: PermissionValues = "USSR";
    static readonly permission_to_delete_member_billing: PermissionValues = "MDEB";
    static readonly permission_to_view_member_billing_paymentmethod: PermissionValues = "RZWQ";
    static readonly permission_to_add_member_billing_paymentmethod: PermissionValues = "WNIZ";
    static readonly permission_to_update_member_billing_paymentmethod: PermissionValues = "E7BM";
    static readonly permission_to_delete_member_billing_paymentmethod: PermissionValues = "RWT0";
    static readonly permission_to_access_member_notes: PermissionValues = "QC19";
    static readonly permission_to_view_provider: PermissionValues = "7126";
    static readonly permission_to_add_provider: PermissionValues = "6DUP";
    static readonly permission_to_update_provider: PermissionValues = "PP76";
    static readonly permission_to_delete_provider: PermissionValues = "6VVD";
    static readonly permission_to_export_group: PermissionValues = "6VJD";
    static readonly permission_to_access_provider_notes: PermissionValues = "4UVU";
    static readonly permission_to_view_ipa: PermissionValues = "JOME";
    static readonly permission_to_add_ipa: PermissionValues = "BKR6";
    static readonly permission_to_update_ipa: PermissionValues = "LTJ7";
    static readonly permission_to_delete_ipa: PermissionValues = "JP0J";
    static readonly permission_to_view_group: PermissionValues = "1KRW";
    static readonly permission_to_add_group: PermissionValues = "P7S3";
    static readonly permission_to_update_group: PermissionValues = "NFL0";
    static readonly permission_to_delete_group: PermissionValues = "XFHA";
    static readonly permission_to_view_lob: PermissionValues = "OT8J";
    static readonly permission_to_add_update_lob: PermissionValues = "3S2M";
    static readonly permission_to_delete_lob: PermissionValues = "YEIJ";
    static readonly permission_to_view_service_groups: PermissionValues = "FM1J";
    static readonly permission_to_add_update_service_groups: PermissionValues = "7WU1";
    static readonly permission_to_delete_service_groups: PermissionValues = "A8P5";
    static readonly permission_to_view_contracts: PermissionValues = "A489";
    static readonly permission_to_add_update_contracts: PermissionValues = "TCJY";
    static readonly permission_to_delete_contracts: PermissionValues = "GNRW";
    static readonly permission_to_view_benefits: PermissionValues = "7LY1";
    static readonly permission_to_add_update_benefits: PermissionValues = "L4A1";
    static readonly permission_to_delete_benefits: PermissionValues = "IR2R";
    static readonly permission_to_view_plan_benefit_package: PermissionValues = "3I4P";
    static readonly permission_to_add_update_plan_benefit_package: PermissionValues = "J9P5";
    static readonly permission_to_delete_plan_benefit_package: PermissionValues = "W5ML";
    static readonly permission_to_view_organizational_structure: PermissionValues = "NTKP";
    static readonly permission_to_add_update_organizational_structure: PermissionValues = "9H46";
    static readonly permission_to_delete_organizational_structure: PermissionValues = "A97S";
    static readonly permission_to_view_feeschedule_limits: PermissionValues = "G53T";
    static readonly permission_to_add_update_feeschedule_limits: PermissionValues = "C9VX";
    static readonly permission_to_delete_feeschedule_limits: PermissionValues = "ZJ83";
    static readonly permission_to_view_copay_coinsurance: PermissionValues = "AA2A";
    static readonly permission_to_add_copay_coinsurance: PermissionValues = "AA2B";
    static readonly permission_to_update_copay_coinsurance: PermissionValues = "AA2C";
    static readonly permission_to_delete_copay_coinsurance: PermissionValues = "AA2D";
    static readonly permission_to_view_location: PermissionValues = "AL2A";
    static readonly permission_to_add_location: PermissionValues = "AL2B";
    static readonly permission_to_update_location: PermissionValues = "AL2C";
    static readonly permission_to_delete_location: PermissionValues = "AL2D";

    //Fee schedule menu
    static readonly permission_to_view_UCRFeeSchedule: PermissionValues = "DFY9";
    static readonly permission_to_add_UCRFeeSchedule: PermissionValues = "L6EZ";
    static readonly permission_to_update_UCRFeeSchedule: PermissionValues = "ZWO6";
    static readonly permission_to_delete_UCRFeeSchedule: PermissionValues = "NY16";
    static readonly permission_to_copy_UCRFeeSchedule: PermissionValues = "BQ0C";
    static readonly permission_to_view_RBRVSCode: PermissionValues = "FZMV";
    static readonly permission_to_add_RBRVSCode: PermissionValues = "TUQO";
    static readonly permission_to_update_RBRVSCode: PermissionValues = "T5DS";
    static readonly permission_to_delete_RBRVSCode: PermissionValues = "U1FK";
    static readonly permission_to_view_RBRVS: PermissionValues = "85Z5";
    static readonly permission_to_add_RBRVS: PermissionValues = "87X5";
    static readonly permission_to_update_RBRVS: PermissionValues = "AGQN";
    static readonly permission_to_delete_RBRVS: PermissionValues = "KOF9";
    static readonly permission_to_view_GPCI: PermissionValues = "W1O3";
    static readonly permission_to_add_GPCI: PermissionValues = "5C1O";
    static readonly permission_to_update_GPCI: PermissionValues = "EOFC";
    static readonly permission_to_delete_GPCI: PermissionValues = "G83E";
    static readonly permission_to_view_Locality: PermissionValues = "49MX";
    static readonly permission_to_add_Locality: PermissionValues = "YBEL";
    static readonly permission_to_update_Locality: PermissionValues = "QTJW";
    static readonly permission_to_delete_Locality: PermissionValues = "80QQ";

    // supporting tables
    static readonly permission_to_view_AgeCategoies: PermissionValues = "LDXI";
    static readonly permission_to_manage_AgeCatergoies: PermissionValues = "LESL";
    static readonly permission_to_delete_AgeCategories: PermissionValues = "LHJJ";
    static readonly permission_to_view_AnesthesiaRegionRates: PermissionValues = "5GU7";
    static readonly permission_to_manage_AnesthesiaRegionRates: PermissionValues = "54CA";
    static readonly permission_to_delete_AnesthesiaRegionRates: PermissionValues = "WYN7";
    static readonly permission_to_view_TimelyFiling: PermissionValues = "MCHP";
    static readonly permission_to_manage_TimelyFiling: PermissionValues = "20HG";
    static readonly permission_to_delete_TimelyFiling: PermissionValues = "RM6W";
    static readonly permission_to_view_InterestQuickPay: PermissionValues = "U8T3";
    static readonly permission_to_manage_InterestQuickPay: PermissionValues = "4BIP";
    static readonly permission_to_delete_InterestQuickPay: PermissionValues = "2GKS";
    static readonly permission_to_view_ModifierDiscountGroup: PermissionValues = "G6TV";
    static readonly permission_to_manage_ModifierDiscountGroup: PermissionValues = "11BV";
    static readonly permission_to_delete_ModifierDiscountGroup: PermissionValues = "353W";
    static readonly permission_to_view_Capitation: PermissionValues = "CEK9";
    static readonly permission_to_manage_Capitation: PermissionValues = "SYW9";
    static readonly permission_to_delete_Capitation: PermissionValues = "T9O0";
    static readonly permission_to_view_EDITradingPartner: PermissionValues = "A5V4";
    static readonly permission_to_manage_EDITradingPartner: PermissionValues = "LWG7";
    static readonly permission_to_delete_EDITradingPartner: PermissionValues = "WEOY";
    static readonly permission_to_view_Regions: PermissionValues = "PX2T";
    static readonly permission_to_manage_Regions: PermissionValues = "JEYX";
    static readonly permission_to_delete_Regions: PermissionValues = "C4X4";
    static readonly permission_to_view_AnesthesiaConversionFactor: PermissionValues = "YU0R";
    static readonly permission_to_manage_AnesthesiaConversionFactor: PermissionValues = "5RVW";
    static readonly permission_to_delete_AnesthesiaConversionFactor: PermissionValues = "EXLF";
    static readonly permission_to_view_AnesthesiaCodeUnit: PermissionValues = "4ETQ";
    static readonly permission_to_manage_AnesthesiaCodeUnit: PermissionValues = "KZ3A";
    static readonly permission_to_delete_AnesthesiaCodeUnit: PermissionValues = "IYMG";

    //masters menu
    static readonly permission_to_view_CPTCode: PermissionValues = "ZETK";
    static readonly permission_to_add_CPTCode: PermissionValues = "5APQ";
    static readonly permission_to_update_CPTCode: PermissionValues = "8D14";
    static readonly permission_to_view_ICDCode: PermissionValues = "LS34";
    static readonly permission_to_add_ICDCode: PermissionValues = "1O2M";
    static readonly permission_to_update_ICDCode: PermissionValues = "RO7I";
    static readonly permission_to_view_RevenueCode: PermissionValues = "4YM5";
    static readonly permission_to_add_RevenueCode: PermissionValues = "0G45";
    static readonly permission_to_update_RevenueCode: PermissionValues = "00KB";
    static readonly permission_to_view_DRGCode: PermissionValues = "DCDL";
    static readonly permission_to_add_DRGCode: PermissionValues = "9O30";
    static readonly permission_to_update_DRGCode: PermissionValues = "DDGW";
    static readonly permission_to_view_PlaceOfService: PermissionValues = "ASAO";
    static readonly permission_to_add_PlaceOfService: PermissionValues = "IQPQ";
    static readonly permission_to_update_PlaceOfService: PermissionValues = "K05D";
    static readonly permission_to_view_NDCCode: PermissionValues = "F8US";
    static readonly permission_to_add_NDCCode: PermissionValues = "2U9L";
    static readonly permission_to_update_NDCCode: PermissionValues = "8GUP";
    static readonly permission_to_view_HCCCode: PermissionValues = "7OB4";
    static readonly permission_to_add_HCCCode: PermissionValues = "WA53";
    static readonly permission_to_update_HCCCode: PermissionValues = "74W1";
    static readonly permission_to_view_ZipCodes: PermissionValues = "ELH4";
    static readonly permission_to_add_ZipCodes: PermissionValues = "60HR";
    static readonly permission_to_update_ZipCodes: PermissionValues = "NOEC";
    static readonly permission_to_view_HomeGrownCode: PermissionValues = "Q0VR";
    static readonly permission_to_add_HomeGrownCode: PermissionValues = "6MHH";
    static readonly permission_to_update_HomeGrownCode: PermissionValues = "ZCF9";
    static readonly permission_to_delete_HomeGrownCode: PermissionValues = "2UYG";
    static readonly permission_to_view_CustomerSetting: PermissionValues = "HQAZ";
    static readonly permission_to_add_CustomerSetting: PermissionValues = "CK23";
    static readonly permission_to_update_CustomerSetting: PermissionValues = "8SLW";
    static readonly permission_to_view_CodeType: PermissionValues = "V0NK";
    static readonly permission_to_view_CommonCode: PermissionValues = "NM01";
    static readonly permission_to_add_CommonCode: PermissionValues = "YHR6";
    static readonly permission_to_update_CommonCode: PermissionValues = "YQZV";
    static readonly permission_to_view_CommonCodeDisplayConfiguration: PermissionValues = "OOSC";
    static readonly permission_to_add_CommonCodeDisplayConfiguration: PermissionValues = "BEXY";
    static readonly permission_to_update_CommonCodeDisplayConfiguration: PermissionValues = "V0RJ";

}
