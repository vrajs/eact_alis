export class TermCodesModel {
    termCodesId: number;
    termHeaderId: number;
    clinicalCodeTypeId: number;
    clinicalCodeType: string;
    minCode: string;
    maxCode: string;
    clinicalCodeGroupDetailId?: number | null | undefined;
    isExclude: boolean;
    effectiveDate: Date;
    termDate?: Date | null | undefined;
}