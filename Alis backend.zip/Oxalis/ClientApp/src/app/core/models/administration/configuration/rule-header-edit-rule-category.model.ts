export class RuleHeaderEditRuleCategoryViewModel {
    public category: string;
    public totalEdits: number;
    public activeEdits: number;
    public isExpand: boolean;
    constructor() {
        this.isExpand = false;
    }
}
