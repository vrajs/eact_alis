export class CPTCodeModel {
    cptCodeId: number;
    code: string;
    homeGrown: string;
    shortDescription: string;
    longDescription: string;
    sequenceNumber: number;
    clinicalCodeTypeId: number;
}