export class FileTemplateModel {
    fileTemplateTypeId: number;
    typeName: string;

    constructor() {
    }
}