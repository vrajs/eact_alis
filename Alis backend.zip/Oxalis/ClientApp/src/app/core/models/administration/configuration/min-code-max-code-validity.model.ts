export class MinCodeMaxCodeValidityModel {
    public isMinCodeValidityValid: boolean;
    public isMaxCodeValidityValid: boolean;
}