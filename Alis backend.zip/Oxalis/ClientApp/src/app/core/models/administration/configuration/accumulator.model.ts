export class AccumulatorModel {
    constructor() {
        this.accumulatorLineItem = [];
    }
    accumulatorID: number;
    benefitYear: number;
    planID: number;
    accumulatorLineItem: AccumulatorLineItem[];
}

export class AccumulatorLineItem {
    constructor() {
        this.accumulatorDetailID = 0;
    }
    accumulatorID: number;
    accumulatorDetailID: number;
    accumulatorCode: string;
    accumulatorId: number;
    accumulatorTypeID: number;
    accumulatorNameID: number;
    maximumLimit: number;
    effectiveDate: Date | string;
    termDate: Date | string;
}

export class AccumulatorHistory {
    accumulatorHistoryID: number;
    oldValue: string;
    newValue: string;
    dataType: string;
    updatedBy: string;
    updatedOn: Date | string;
}