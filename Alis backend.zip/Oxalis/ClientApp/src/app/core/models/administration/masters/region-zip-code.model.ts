export class RegionZipCodeModel {
    regionZipCodeId: number = 0;
    regionId: number;
    zipCodeId: number;
    effectiveDate: Date | null;
    termDate: Date | null;
    regionName: string;
    productTypeId: number;
    productTypeName: string;
}