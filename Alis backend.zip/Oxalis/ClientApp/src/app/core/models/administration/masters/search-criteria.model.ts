export class SearchCriteriaModel {
    public searchCriteriaId: number;
    public screenID: string;
    public name: string;
    public criteriaJson: string;
    constructor() {
        this.searchCriteriaId = 0;
        this.screenID = '';
        this.name = '';
        this.criteriaJson = '';
    }
}
