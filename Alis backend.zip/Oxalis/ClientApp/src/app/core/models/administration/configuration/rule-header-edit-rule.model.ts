import { RuleHeaderEditRuleCriteriaModel } from "./rule-header-edit-rule-criteria.model";
import { RuleHeaderEditRuleDBFieldModel } from "./rule-header-edit-rule-db-field.model";

export class RuleHeaderEditRuleModel {
    public ruleHeaderEditRuleId: number;
    public ruleHeaderId: number;
    public editCodeId: number;
    public isEnabled: boolean;
    public outComeId: number;
    public outComeCodeId: number;
    public adjudicationLevel: number;
    public claimApplyLevel: number;
    public priority: number;
    public effectiveDate: Date;
    public termDate: Date;
    public code: string;
    public codeName: string;
    public isFreezed: number;
    public outCome: string;
    public outComeDescription: string;
    public criteriaDbFields: RuleHeaderEditRuleDBFieldModel[];
    public editCodeCriterias: RuleHeaderEditRuleCriteriaModel[];
    constructor() {
        this.ruleHeaderEditRuleId = 0;
        this.criteriaDbFields = [];
        this.editCodeCriterias = [];
    }
}
