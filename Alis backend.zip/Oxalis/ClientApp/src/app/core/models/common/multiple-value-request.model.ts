export class MultipleValueRequestModel {
    codeTypeIds: number[];
    fetchingTypeId: number;
    constructor() {
        this.codeTypeIds = [];
    }
}
