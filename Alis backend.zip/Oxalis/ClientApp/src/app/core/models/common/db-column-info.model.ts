export class DbColumnInfoModel {
    columnName: string;
    columnType: string;
    length: number;    
}
