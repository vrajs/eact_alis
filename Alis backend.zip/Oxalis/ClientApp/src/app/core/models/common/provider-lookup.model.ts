export class ProviderLookupModel {
    public providerId: number;
    public providerCode: string;
    public providerFirstName: string;
    public providerLastName: string;
    public providerName: string;
    public providerNpi: string;
    public groupId: number;
    public groupCode: string;
    public groupFirstName: string;
    public groupLastName: string;
    public groupName: string;
    public vendor: string;
    public pcp: string;
    public groupNpi: string;
    public tin: string;
    public title: string;
    public effectiveDate?: Date;
    public termDate?: Date;
    public providerEligibilityId?: number;
    public groupEffectiveDate?: Date;
    public groupTermDate?: Date;
    public groupEligibilityId?: number;
    public groupRecordStatus?: number;
    public prEffectiveDate?: Date;
    public prTermDate?: Date;
    public providerRelationId?: number;
    public prRecordStatus?: number;
    public providerTypeId: number;
    public recordStatus?: number;
    public state?: string;
    public zip?: string;
    public city?: string;
    public address1?: string;
    constructor() {
        this.providerId = 0;
    }
}
