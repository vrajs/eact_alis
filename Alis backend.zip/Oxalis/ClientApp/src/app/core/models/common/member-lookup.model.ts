export class MemberLookupModel {
    public memberId: number;
    public memberCode: string;
    public memberName: string;
    public firstName: string;
    public lastName: string;
    public dob?: Date;
    public planName: string;
    public providerId: number;
    public pcpName: string;
    public effectiveDate?: Date;
    public relationshipId: number;
    public relationship: string;
    public recordStatus: number;
    public termDate: Date;
    public lobName: string;
    public gender: string;
    public pcpid: number;
    public formatedDOB: string;
    public memberEligibilityId?: number;
    public memberPCPId?: number;
    public providerCode: string;
    public coverageType: string;
    public formattedEffectiveDate: string;
    public formattedTermDate: string;
    public coverageTypeId: number;
    public medicaidId?: string;
    public medicareId?: string;
    public memberCodeValue?: string;
    public lobid?: number;
    public state?: string;
    public zip?: string;
    public city?: string;
    public address1?: string;
    public homePhone?: string;
    
    constructor() {
        this.memberId = 0;
    }
}
