export class CustomConfimDialogModel {
    title: string;
    textYes: string;
    textNo: string;
    item: any;
    buttonType: string;
    message: string;
    message2?: string;
    componentType?: string;
    componentCallingFrom: number;    
}