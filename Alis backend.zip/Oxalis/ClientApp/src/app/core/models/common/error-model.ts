export class UpdateErrorModel {
    ClaimProfessionalId: number;
    Errorcode: string;
    ServicelineId: number;
    isApplyfix: boolean;

    L2010BA_nm109_subscriber_id: string;
    L2010BA_nm104_subscriber_first_nm: string;
    L2010BA_nm103_subscriber_last_nm: string;
    L2010BA_nm105_subscriber_middle_nm: string;
    L2010BA_dmg02_subscriber_dob: string;
    L2010BA_dmg03_subscriber_gender: string;
    L2010BA_ref02_SY_subscriber_sup_id: string;
    L2010BA_n301_subscriber_address1: string;
    L2010BA_n302_subscriber_address2: string;
    L2000B_sbr02_ind_relationship_code: string;

    L2010AA_nm102_entity_type_qual: string;
    L2010AA_nm109_billing_prov_id: string;
    L2010AA_nm103_billing_prov_last_nm: string;
    L2010AA_nm104_billing_prov_first_nm: string;
    L2010AA_ref02_EI_billing_prov_id: string;
    L2010AA_ref02_SY_billing_prov_id: string;
    L2000A_prv01_provider_code: string;
    L2000A_prv03_taxonomy_code: string;

    public objErrorDiagcodelist: ErrorCodeList[];
    public objErrorCptcodeList: ErrorCodeList[];
    public objErrorModcodeList: ErrorCodeList[];
}
export class ClaimProfessionalErrorModel {
    id: number;
    claimProfessionalId: number;
    claimInstitutionalId: number;
    createdDate: Date;
    errorFixedBy: string;
    errorFixedDate: Date;
    error_desc: string;
    error_desc_long: string;
    errorValue: string;
    pageControlID: string;
}
export class ErrormemberDisplayModel {
    suffix: string;
    firstname: string;
    lastname: string;
    name: string;
    address1: string;
    address2: string;
    city: string;
    state: string;
    zipcode: string;
    country: string;
    id: string;
    dob: string;
    gender: string;
    sSN: string;
    reletionship: string;
    reletionshipcode: string;
    propCasualtyClaimNum:string
}
export class ErrorProviderDisplayModel {
    providerCode: string;
    taxonomyCode: string;
    typeofEntity: string;
    providerNPI: string;
    providerFirstname: string;
    providerLastname: string;
    providerName: string;
    tin: string;
    Address: string;
    city: string;
    state: string;
    zip: string;
    country: string;
    statelicno: string;
    upin: string;
    SSN: string;
    contactname: string;
    contactno: string;
}
export class ErrorDisplayModelList {
    createdDate: string;
    errorFixedBy: string;
    errorFixedDate: string;
    errorValue: string;
    error_desc: string;
    errorDescLong: string;
    id: string;
    pageControlId: string;
    serviceLineId: string;
}
export class ErrorCodeList {
    code?: string;
    id?: string;
    pageControlID?: string;
    Errorid?: string;
}