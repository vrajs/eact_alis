export class FacilityLookupModel {
    public facilityId: number;
    public facilityCode: string;
    public facilityFirstName: string;
    public facilityLastName: string;
    public facilityName: string;
    public facilityNpi: string;
    public vendorName: string;
    public tin: string;
    public effectiveDate?: Date;
    public termDate?: Date;
    public facilityEligibilityId?: number;
    public recordStatus?: number;
    public groupEffectiveDate?: Date;
    public groupTermDate?: Date;
    public groupEligibilityId?: number;
    public groupRecordStatus?: number;
    public prEffectiveDate?: Date;
    public prTermDate?: Date;
    public providerRelationId?: number;
    public prRecordStatus?: number;
    public groupId?: number;
    constructor() {
        this.facilityId = 0;
    }
}
