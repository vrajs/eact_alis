
export class MemberRuleModel {
    ruleId:number;
    sepReasonCodeId: number;
    fieldName: string;
    expression: string;
    inParameter: string;
    outParameter: string;
}

export class ExpressionJsonModel {
    reasonDate: string;
    receiptDate: string;
    addMonth: string;
    addYear: string;
    addDays: string;
    month: string;
    day:string;
    isFirstDay: string;
    isLastDay: string;
    isForMaxDate:string[];
}

export class MaxDateModel {
    reasonDate: string;
    receiptDate: string;
    medicareAEffDate: string;
    medicareBEffDate: string;
    medicareDEffDate: string;
}