export class ClinicalCodeCheckModel {
    id: number;
    clinicalCodeTypeId: number;
    code: string;
    recordStatus: boolean;
    effectiveDate: Date;
    termDate: Date;
    sequenceNumber: number;
}