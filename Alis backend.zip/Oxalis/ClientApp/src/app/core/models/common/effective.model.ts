export class EffectiveModel {
    id: number;
    name: string;
    effectiveDate: Date;
    planEffectiveDate: Date;
    planTermDate: Date;
}