import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { OData, RuleHeaderMessageModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from '../../common/odata-builder.service';

@Injectable()
export class RuleHeaderMessageService {

    apiBaseUrl: string = '/api/RuleHeaderMessage';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    getRuleHeaderMessageData(ruleHeaderId: number, messageId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<RuleHeaderMessageModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/GetRuleHeaderMessageByMessageType`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<RuleHeaderMessageModel>>(`${dynamicUrl}&RuleHeaderID=${ruleHeaderId}&MessageTypeID=${messageId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<RuleHeaderMessageModel>(res);
            })
        );
    }

    getById(ruleHeaderID: number): Observable<RuleHeaderMessageModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ruleHeaderID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as RuleHeaderMessageModel;
            })
        );
    }

    //getByMessageTypeId(ruleHeaderID: number, messageTypeID: number): Observable<RuleHeaderMessage> {
    //    return this.httpClient.get(this.apiBaseUrl + '/GetRuleHeaderMessageByMessageType/' + ruleHeaderID + '/' + messageTypeID).map((res: Response) => <RuleHeaderMessage>res.json())
    //}

    create(ruleHeaderMessageData: RuleHeaderMessageModel): Observable<Number> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ruleHeaderMessageData).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }

    update(ruleHeaderMessageData: RuleHeaderMessageModel): Observable<Number> {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ruleHeaderMessageData).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }

    delete(ruleHeaderMessageID: number): Observable<Number> {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ruleHeaderMessageID}`).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }
}
