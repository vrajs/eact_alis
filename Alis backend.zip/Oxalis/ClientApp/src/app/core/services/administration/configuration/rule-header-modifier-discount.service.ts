import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { OData, RuleHeaderModifierDiscountModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from '../../common/odata-builder.service';

@Injectable()
export class RuleHeaderModifierDiscountService {

    apiBaseUrl: string = '/api/RuleHeaderModifierDiscount';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    getRuleHeaderModifierData(ruleHeaderId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<RuleHeaderModifierDiscountModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/GetRuleHeaderModifierDiscounts`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<RuleHeaderModifierDiscountModel>>(`${dynamicUrl}&$orderby=RuleHeaderModifierDiscountId asc&RuleHeaderID=${ruleHeaderId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<RuleHeaderModifierDiscountModel>(res);
            })
        );
    }

    getById(ruleHeaderID: number): Observable<RuleHeaderModifierDiscountModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ruleHeaderID}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return res as RuleHeaderModifierDiscountModel;
            })
        )
    }

    create(ruleHeaderModifierDiscount: RuleHeaderModifierDiscountModel): Observable<Number> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ruleHeaderModifierDiscount).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }

    update(ruleHeaderModifierDiscount: RuleHeaderModifierDiscountModel): Observable<Number> {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ruleHeaderModifierDiscount).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }

    delete(ruleHeaderModifierDiscountID: number): Observable<Number> {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ruleHeaderModifierDiscountID}`).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }
}
