import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Utils } from "@app/common/app-functions";
import { CPTCodeModel } from "@app/core/models/administration/masters/cpt-code.model";
import { environment } from "@environments/environment";
import { map, Observable } from "rxjs";

@Injectable()

export class CPTCodeService {
    private apiBaseUrl: string = "/api/CPT";

    constructor(private httpClient: HttpClient) {

    }

    getCPTCode(): Observable<CPTCodeModel[]> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/GetModifierCodes`).pipe(
            map((response) => {
                response = Utils.camelizeKeys(response);
                return response as CPTCodeModel[];
            })
        )
    }
}