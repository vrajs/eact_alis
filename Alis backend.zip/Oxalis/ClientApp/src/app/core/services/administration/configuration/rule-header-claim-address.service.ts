import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { OData, RuleHeaderClaimAddressModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { ODataBuilderService } from '../../common/odata-builder.service';

@Injectable()
export class RuleHeaderClaimAddressService {

    apiBaseUrl: string = '/api/RuleHeaderClaimAddress';

    constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService) {
    }

    getRuleHeaderClaimAddressData(ruleHeaderId: number, filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<RuleHeaderClaimAddressModel>> {
        let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/GetRuleHeaderClaimAddress`, filteringArgs, sortingArgs, index, perPage);
        return this.httpClient.get<OData<RuleHeaderClaimAddressModel>>(`${dynamicUrl}&$orderby=RuleHeaderClaimAddressId asc&RuleHeaderID=${ruleHeaderId}`).pipe(
            map(res => {
                res = Utils.camelizeKeys(res);
                return new OData<RuleHeaderClaimAddressModel>(res);
            })
        );
    }


    getById(ruleHeaderID: number): Observable<RuleHeaderClaimAddressModel> {
        return this.httpClient.get(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ruleHeaderID}`).pipe(
            map((res) => {
                res = Utils.camelizeKeys(res);
                return res as RuleHeaderClaimAddressModel;
            })
        );
    }

    create(ruleHeaderClaimAddress: RuleHeaderClaimAddressModel): Observable<Number> {
        return this.httpClient.post(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ruleHeaderClaimAddress).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }

    update(ruleHeaderClaimAddress: RuleHeaderClaimAddressModel): Observable<Number> {
        return this.httpClient.put(`${environment.serviceApiUrl}${this.apiBaseUrl}`, ruleHeaderClaimAddress).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }


    delete(ruleHeaderClaimAddressID: number): Observable<Number> {
        return this.httpClient.delete(`${environment.serviceApiUrl}${this.apiBaseUrl}/${ruleHeaderClaimAddressID}`).pipe(
            map((response) => {
                return response as Number;
            })
        );
    }
}
