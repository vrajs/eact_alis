import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-global';
// import { ClinicalCodeGroupDetailModel, HomeGrownCodeModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { ODataBuilderService } from '@app/core/services';
import { map, Observable } from 'rxjs';
import {HomeGrownCodeModel, OData } from '@app/core/models';
import { IForOfState } from '@infragistics/igniteui-angular';



@Injectable()
export class HomeGrownCodeService {


  constructor(private httpClient: HttpClient, private oDatabuilderService: ODataBuilderService, private oDataService: ODataBuilderService){  }


 gethomeGrownCodeList(dynamicQueryUrl : string,filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number) :  Observable<OData<HomeGrownCodeModel>> {
 
  let dynamicUrl = this.oDatabuilderService.buildDataUrl(`${environment.serviceApiUrl}/odata/HomeGrownCodeList/`, filteringArgs, sortingArgs, index, perPage) + dynamicQueryUrl;
    return this.httpClient.get<OData<HomeGrownCodeModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<HomeGrownCodeModel>(res);
      })
    );
  }
/** */
  getMappedCode(sourceUrl: string , dynamicQueryUrl: string, virtulizationState?: IForOfState, searchText?: string, containProperty?: string):  Observable<OData<HomeGrownCodeModel>> {    
    let url = `${environment.serviceApiUrl}/${sourceUrl}`;
    let buildQuery = this.oDataService.buildDataUrlForScroll(url, virtulizationState, searchText ,containProperty) + dynamicQueryUrl;
    return this.httpClient.get<OData<HomeGrownCodeModel>>(buildQuery).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<HomeGrownCodeModel>(res);
      })
    );
  }

  get(): Observable<HomeGrownCodeModel[]> {
    return this.httpClient.get<HomeGrownCodeModel[]>(`${environment.serviceApiUrl} /api/HomeGrownCode`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as HomeGrownCodeModel[]
      })
    );
  }

  getById(homeGrownCodeId: number): Observable<HomeGrownCodeModel> {
    return this.httpClient.get<HomeGrownCodeModel>(`${environment.serviceApiUrl} /api/HomeGrownCode/${homeGrownCodeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as HomeGrownCodeModel
      })
    );
  }

  getByTypeAndId(homeGrownCodeId: number, codeTypeId: number): Observable<HomeGrownCodeModel> {
    return this.httpClient.get<HomeGrownCodeModel>(`${environment.serviceApiUrl}/api/HomeGrownCode/${homeGrownCodeId}/${codeTypeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as HomeGrownCodeModel;
      })
    );
  }

  create(model: HomeGrownCodeModel): Observable<HomeGrownCodeModel> {
    return this.httpClient.post<HomeGrownCodeModel>(`${environment.serviceApiUrl}/api/HomeGrownCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as HomeGrownCodeModel;
      })
    );
  }

  update(model: HomeGrownCodeModel): Observable<HomeGrownCodeModel> {
    return this.httpClient.put<HomeGrownCodeModel>(`${environment.serviceApiUrl}/api/HomeGrownCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as HomeGrownCodeModel;
      })
    );
  }

  delete(homeGrownCodeId: number, codeTypeId: number) {
    return this.httpClient.delete<HomeGrownCodeModel>(`${environment.serviceApiUrl}/api/HomeGrownCode/${homeGrownCodeId}/${codeTypeId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as HomeGrownCodeModel;
      })
    );
  }
 

  getHomeGrownCodeForStandardCode(mappedCode: string): Observable<boolean> {

    let model = new HomeGrownCodeModel();
    model.mappedCode = mappedCode;

    return this.httpClient.post<boolean>(`${environment.serviceApiUrl}/api/HomeGrownCode/GetHomeGrownCodeForStandardCode`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as boolean
      })
    );
  }
}
