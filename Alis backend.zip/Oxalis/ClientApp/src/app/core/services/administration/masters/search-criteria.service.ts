import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Utils } from '@app/common/app-functions';
import { SearchCriteriaModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';

@Injectable({
  providedIn: "root"
})

export class SearchCriteriaService {

  constructor(private httpClient: HttpClient) { }

  createOrUpdate(model: SearchCriteriaModel): Observable<SearchCriteriaModel> {
    if (model.searchCriteriaId=== 0) {
      return this.httpClient.post<SearchCriteriaModel>(`${environment.serviceApiUrl}/api/SearchCriteria`, model).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return res as SearchCriteriaModel;
        })
      );
    }
    else {
      return this.httpClient.put<SearchCriteriaModel>(`${environment.serviceApiUrl}/api/SearchCriteria`, model).pipe(
        map(res => {
          res = Utils.camelizeKeys(res);
          return res as SearchCriteriaModel;
        })
      );
    }
  }

  delete(searchCriteriaID: number): Observable<Number> {
    return this.httpClient.delete(`${environment.serviceApiUrl}/api/SearchCriteria/${searchCriteriaID}`).pipe(
      map(res => {
        return res as Number;
      })
    );
  }

  getAllSearchCriteriaByUser(userName: string): Observable<SearchCriteriaModel[]> {
    return this.httpClient.get<SearchCriteriaModel[]>(`${environment.serviceApiUrl}/api/SearchCriteria/GetAllSearchCriteriaByUser/${userName}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as SearchCriteriaModel[];
      })
    );
  }

  getAllSearchCriteriaByUserPage(userName: string, pageId: string): Observable<SearchCriteriaModel[]> {
    return this.httpClient.get<SearchCriteriaModel[]>(`${environment.serviceApiUrl}/api/SearchCriteria/GetAllSearchCriteriaByUserPage/${userName}/${pageId}`).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as SearchCriteriaModel[];
      })
    );
  }

}
