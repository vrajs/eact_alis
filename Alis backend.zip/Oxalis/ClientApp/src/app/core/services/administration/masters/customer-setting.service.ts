//#region system namespace
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
//#endregion
//#region app namespace
import { Utils } from '@app/common/app-functions';
import { OData, RegionZipCodeModel } from '@app/core/models';
import { environment } from '@environments/environment';
import { map, Observable } from 'rxjs';
import { SystemSettingModel } from '@app/core/models/administration/masters/system-setting-model';
import { ODataBuilderService } from '../../common/odata-builder.service';
//#endregion
@Injectable()
export class CustomerSettingService {

  constructor(private httpClient: HttpClient,private oDatabuilderSrvice: ODataBuilderService) { }

  create(model:SystemSettingModel): Observable<SystemSettingModel> {
  
    return this.httpClient.post<SystemSettingModel>(`${environment.serviceApiUrl}/api/SystemSetting`, model).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return res as SystemSettingModel;
      })
    );
  }

  
  get(filteringArgs?: any, sortingArgs?: any, index?: number, perPage?: number): Observable<OData<SystemSettingModel>> {
    let dynamicUrl = this.oDatabuilderSrvice.buildDataUrl(`${environment.serviceApiUrl}/odata/GetCustomerSettingList`, filteringArgs, sortingArgs, index, perPage)
    return this.httpClient.get<OData<SystemSettingModel>>(dynamicUrl).pipe(
      map(res => {
        res = Utils.camelizeKeys(res);
        return new OData<SystemSettingModel>(res);
      })
    );
  }


}
