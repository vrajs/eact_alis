import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, CanActivateChild, CanLoad, Route, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable, of } from 'rxjs';
import { AuthService, NotificationService } from '@app/core/services';
import { Utils } from '@app/common/app-functions';
import { AppConstant } from '@app/common/app-constants';
import { AlertMessageType } from '@app/common/app-enum';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate, CanActivateChild, CanLoad {


  constructor(private authService: AuthService, private router: Router, private notificationService: NotificationService) {
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    let url: string = state.url;

    if (this.authService.isLoggedIn) {
      let isSessionExpired = this.authService.isSessionExpired;
      if (!Utils.isBlank(isSessionExpired) && isSessionExpired) {
        this.authService.removeLocalStore();
        this.authService.redirectLogoutUser();
      }
    }

    return this.checkLogin(url);
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean> {
    return this.canActivate(route, state);
  }

  canLoad(route: Route): Observable<boolean> {
    let url = `/${route.path}`;
    return this.checkLogin(url);
  }

  checkLogin(url: string): Observable<boolean> {

    if (this.authService.isLoggedIn && this.authService.isClientAccess == true) {
      return of(true);
    } else if (this.authService.isLoggedIn && this.authService.isClientAccess == false) {
      this.authService.redirectLogoutUser();
    }
    this.authService.storeRedirectUrl(url);
    this.authService.redirectLogoutUser();
    return of(false);
  }

}
