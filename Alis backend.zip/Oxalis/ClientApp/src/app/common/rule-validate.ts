import { ExpressionJsonModel } from "@app/core/models/common/member-rule.model";
import moment from "moment";
import { Utils } from "./app-functions";

export class Rules {


    //create valid Date Range Function
    public static validatedDateRange(value: Date, expressionJsonModel: ExpressionJsonModel) {

        // value = new Date();
        if (!Utils.isBlank(value)) {
            let dateArr = [];
            const yearArray = expressionJsonModel.addYear.split(",");
            const monthArray = expressionJsonModel.addMonth.split(",");
            const dayArray = expressionJsonModel.addDays.split(",");
            const monthOfArray = expressionJsonModel.month.split(",");
            const firstDayArray = expressionJsonModel.isFirstDay.split(",");
            const lastDayArray = expressionJsonModel.isLastDay.split(",");

            //Add and substract year in Date Range
            for (let index = 0; index < yearArray.length; index++) {
                if (!Utils.isBlank(yearArray[index])) {
                    dateArr.push(moment(value).add(yearArray[index], 'year'));
                }
            }

            //Add and substract month in Date Range
            if (!Utils.isBlank(monthArray)) {
                if (monthArray.length > dateArr.length) {
                    dateArr.push(moment(value));
                }
                for (let index = 0; index < monthArray.length; index++) {
                    if (!Utils.isBlank(monthArray[index])) {
                        let dateForMonth = dateArr[index];
                        dateForMonth.add(monthArray[index], 'month');
                        dateArr[index] = dateForMonth;
                    }
                }
            }

            //Add and substract day in Date Range
            if (!Utils.isBlank(dayArray)) {
                if (dayArray.length > dateArr.length) {
                    dateArr.push(moment(value));
                }

                for (let index = 0; index < dayArray.length; index++) {
                    if (!Utils.isBlank(dayArray[index])) {
                        let dateForday = dateArr[index];
                        dateForday.add(dayArray[index], 'day');
                        dateArr[index] = dateForday;
                    }
                }
            }

            // set  month in Date Range
            if (!Utils.isBlank(monthOfArray)) {
                if (monthOfArray.length > dateArr.length) {
                    dateArr.push(moment(value));
                }

                for (let index = 0; index < dateArr.length; index++) {
                    if (!Utils.isBlank(monthOfArray[index]) && monthOfArray[index] != "-1") {
                        let dateForMonth = dateArr[index];
                        dateForMonth.set('month', monthOfArray[index]);
                        dateArr[index] = dateForMonth;
                    }
                }
            }

            //Add and substract first day in Date Range
            if (!Utils.isBlank(firstDayArray)) {
                for (let index = 0; index < dateArr.length; index++) {
                    if (firstDayArray[index] == 'true') {
                        let firstForDay = dateArr[index];
                        firstForDay.startOf('month');
                        dateArr[index] = firstForDay;
                    }
                }
            }

            //Add and substract last day in Date Range
            if (!Utils.isBlank(lastDayArray)) {
                for (let index = 0; index < dateArr.length; index++) {
                    if (lastDayArray[index] == 'true') {
                        let lastForDay = dateArr[index];
                        lastForDay.endOf('month');
                        dateArr[index] = lastForDay;
                    }
                }
            }

            if (!Utils.isBlank(dateArr)) {
                for (let index = 0; index < dateArr.length; index++) {
                  let setDate =  moment(dateArr[index]).set({ 'hours': 0, 'minute': 0, 'second': 0, 'millisecond': 0 });
                  dateArr[index] = setDate;
                }
            }

            console.log(dateArr);
            return dateArr;
        }

        return '';
    }

    //valid Between Date Range Function
    public static validBetweenDate(dateObj: any, value: Date): boolean {
        if (!Utils.isBlank(dateObj)) {

            var setValue = moment(value).set({ 'hours': 0, 'minute': 0, 'second': 0, 'millisecond': 0 });
            var lengthOfDate = dateObj.length;

            if (lengthOfDate == 1) {
                if (dateObj[0] <= setValue) {
                    return true;
                } else {
                    return false;
                }
            }
            else {
                for (let i = 0; i < lengthOfDate; i++) {
                    if (dateObj[i] <= setValue && setValue <= dateObj[i + 1]) {
                        return true;
                    } else {
                        if (i < lengthOfDate - 2) {
                            continue;
                        } else {
                            return false;
                        }
                    }
                }
            }
        } else {
            return false;
        }
    }

    public static compareDates(arr): Date {
        const maxDate = new Date(
            Math.max(
                ...arr.map(
                    element => {
                        return new Date(element);
                    }
                )
            ));
        return maxDate;
    }

    public static getDateRange(value: Date) {
        let dateArr = [];
        if (!Utils.isBlank(value)) {
            var date = new Date(value), y = date.getFullYear(), m = date.getMonth();
            var startDate = new Date(y, m - 3, date.getDay());
            var endDate = new Date(y, m + 3, date.getDay());
            dateArr.push(startDate, endDate);
            return dateArr;
        } else {
            return dateArr;
        }
    }
}