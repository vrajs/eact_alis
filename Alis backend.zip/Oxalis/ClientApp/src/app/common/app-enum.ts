export enum RecordStatus {
    Active = 0,
    Termed = 1,
    InActive = 2,
    Deleted = 3,
    VoidOrInvalid = 4,
    Pend = 5,
    Cancel = 6,
}

/* This Enum use for get different type of data from CommonCode table. Like ShortName, LongName  */
export enum CommonCodeFetchingType {
    Default = 0,
    ByCode = 1,
    ByLongDescription = 2,
    ByDisplayOrder = 3
}

export enum CommonCode {
    PCP = 53106
}

/* Common Code Type Enum */
export enum CodeType {
    QuantityLimitType = 1,
    DurationLimitType = 2,
    MaxLimitType = 3,
    ClaimSource = 4,
    ClinicalCodeType = 5,
    Qualifier = 6,
    COBType = 7,
    ClaimDeny = 25,
    ClaimPend = 27,
    ClaimFormType = 34,
    RefValueType = 35,
    EobReason = 36,
    RemitReason = 37,
    ProviderStatus = 38,
    ProviderType = 39,
    Network = 40,
    ClaimAuditActionType = 48,
    ClaimEditStatus = 49,
    ClaimOutComeReason = 50,
    UBPhysType = 9,
    ANSIqualifier = 12,
    ClaimUBCodeType = 46,
    TimePeriod = 47,
    EPSDT = 85,
    Gender = 100,
    DiagType = 8,
    EditReason = 11,
    Action = 18,
    RefundStatus = 13,
    RefundLetter = 14,
    EntryReason = 15,
    Frequency = 16,
    MassAdjudicationType = 17,
    TypeOfDeductible = 41,
    VisitType = 42,
    MemberRelationship = 51,
    Prefix = 52,
    Suffix = 53,
    MaritalStatus = 54,
    Residing = 55,
    Race = 56,
    Ethnicity = 57,
    Language = 58,
    HIPAACommunication = 59,
    StudentStatus = 60,
    CoverageType = 61,
    RiskType = 62,
    TermReason = 63,
    ContactType = 64,
    EmploymentStatus = 65,
    PCPType = 66,
    Modules = 67,
    PayType = 68,
    CardType = 69,
    InvoiceType = 70,
    DisclosureType = 74,
    DisclosureLimit = 72,
    EditID = 73,
    ApprovalStatus = 71,
    PolicyHolderStatus = 43,
    InsuranceType = 44,
    OtherInsuranceRelationship = 45,
    DisclosureTime = 78,
    AddressType = 79,
    TemplateType = 80,
    CapitationType = 86,
    PaymentType = 87,
    AdmitType = 89,
    AdmitSource = 90,
    SVCSRendered = 91,
    TINType = 92,
    DischargeType = 93,
    TranType = 94,
    FileType = 95,
    UsageIndicator = 96,
    VersionCode = 97,
    ClaimFrequency = 98,
    Title = 99,
    AfterHoursCoverage = 101,
    RefundReason = 102,
    PayForType = 103,
    PayToType = 104,
    RefundReqForType = 105,
    BenefitCategory = 106,
    RefPosEntryReason = 107,
    IdentifierType = 108,
    GroupType = 109,
    AgeGroupType = 501,
    RegionType = 502,
    RefundLetterType = 111,
    AdditionalRequirementType = 503,
    RecordStatus = 112,
    RateType = 75,
    SourceType = 76,
    PaymentDateType = 507,
    FFSParameterType = 508,
    Form1099AMTBox = 509,
    CompanyType = 511,
    ApplicationStatus = 512,
    AttachmentType = 513,
    MemberStatus = 514,
    CMSContractCode = 515,
    CMSPBPCode = 516,
    AccessibilityFormat = 517,
    LisLevel = 519,
    EnrollmentSource = 521,
    EnrollmentMechanism = 522,
    PlanSpecificChronicCondition = 523,
    TransactionType = 524,
    PremiumWithHold = 525,
    DisEnrollmentReasonCode = 526,
    PendReason = 528,
    IncomepleteReason = 529,
    DenialReason = 530,
    ElectionType = 533,
    SubGroup = 534,
    SpanType = 531,
    Source = 532,
    ProviderTermReason = 535,
    FalloutStatus = 536
}

/* Numeric Filter Type */
export enum NumericFilterType {
    Equals = 1,
    NotEqual = 2,
    GreaterThan = 3,
    LessThan = 4,
    GreaterThanEqual = 5,
    LessThanEqual = 6,
}

/* String Filter Type */
export enum StringFilterType {
    StartWith = 1,
    EndsWith = 2,
    Contain = 3,
    NotContain = 4,
    Equals = 5,
    NotEqual = 6,
}

/* Numeric Filter Type */
export enum DateFilterType {
    Before = 1,
    After = 2,
}

/* Par/Nonpar as tinyint in database  */
export enum ParNonParType {
    Nonpar = 0,
    Par = 1,
    Both = 2
}

/*Clinical Code Type */
export enum ClinicalCodeType {
    General = 0,
    ICD9CMDX = 1,
    ICD10CMDX = 2,
    CPT4 = 3,
    HCC = 4,
    RxHCC = 5,
    CPT2 = 6,
    POS = 8,
    LOINC = 9,
    HCPCS = 10,
    UBRevenue = 11, // UB Revenue
    RxNorm = 12,
    CVX = 13,
    LN = 14,
    Snowmed = 15,
    ICD9CMPCS = 16, // ICD-9-CM-PCS
    ICD10CMPCS = 17, // ICD-10-CM-PCS
    UBTOB = 18,   // Bill Type Code
    Modifier = 19,
    MSDRGCodes = 22, // "MS DRG Codes
    HUGS = 23,
    RUGS = 24,
    UBOccurrence = 25,
    UBValue = 26,
    UBCondition = 27,
    NDC9 = 28,
    NDC10 = 29,
    NDC11 = 30
}

export enum ClaimType {
    Professional = 3401,
    Dental = 3402,
    Institutional = 3403,
    Pharmacy = 3404,
    All = -1
}

export enum ClaimComponents {
    Diagnosis = 1,
    Service = 2,
    Reference = 3,
    OtherInsurance = 4,
    Audit = 5,
    Edit = 6,
    Note = 7,
    ClaimSummary = 8,
    ProcessingSteps = 9,
    EOBOEOPMessages = 10,
    OtherPhysicians = 11,
    UBCodes = 12
}

export enum MassAdjudicationJobType {
    RunNow = 1701,
    Recurring = 1702
}

export enum Page {
    MEMBER_ADD_EDIT = <any>"1B009555-7057-4189-AC3F-891065C85006",
    BENEFIT_CODES = <any>"91331913-55F8-4BA2-A9DD-37299E71B645",
    SERVICE_GROUPS = <any>"95C8B023-D191-436B-9B69-37E5475C6E68",
    PLAN_PAGE = <any>"C7AC2754-90B6-4E23-971C-5DB2C9593EED",
    PROVIDER_PAGE = <any>"27568827-6B13-42B5-9DF2-107CA83C4396",
    CLAIM_SEARCH = <any>"CD807C9F-8889-4775-BBE0-EEBB8C09E23A",
    BENEFIT_PAGE = <any>"CD6BFEDF-48D1-4D3D-A08B-FCB9088CB691",
    PROVIDER_SEARCH = <any>"9BC394DF-5949-4D27-8A93-11A1175E4699",
    GROUP_SEARCH = <any>"380976B6-C1A7-40C9-8338-165967D1AB69",
    USER_PROFILE = <any>"BC3C3F7E-9E67-4526-9709-0FB82D40EF7E",
    REFUND_SEARCH = <any>"F3822ED5-EE76-4895-862D-26CC335023C4",
    UCR_FEESCHEDULE_DETAIL = <any>"AAEEA5C0-8F65-4832-8BA4-316DC794BF59",
    GROUP_PAGE = <any>"3BA137C1-EC6A-4965-86C0-5676058633CC",
    ENROLLMENT_PAGE = <any>"992030E6-4959-4DC4-97CB-F413CB99756F"
}

export enum Gender {
    Both = 10001,
    Male = 10002,
    Female = 10003,
    Unknown = 10004
}

export enum GenderById {
    Unknown = 0,
    Male = 1,
    Female = 2
}

export enum HIPAACommunication {
    Email = 5901,
    Mail = 5902,
    Text = 5903,
    VoiceMessage = 5904
}
export enum HTTPStatusCode {
    Ok = 200,
    Created = 201,
    BadRequest = 400,
    NotAcceptable = 406,
    UnAuthorized = 401,
    NotFound = 404
}

export enum PaymentType {
    AmercianExpress = 6901,
    Checking = 6801,
    Discover = 6902,
    Mastercard = 6903,
    Savings = 6802,
    Visa = 6904
}

export enum ContractPaymentType {
    BilledCharges = 8704,
    CustomDRG = 8702,
    CaseRate = 8701,
    DRG = 8705,
    FlatRate = 8706,
    FeeSchedule = 8703,
    NDC = 8708,
    PerDiem = 8710,
    PerUnit = 8712,
    RUGS = 8707,
    RVS = 8709,
    VariablePerDiem = 8711
}

export enum FilterStatus {
    Active = 0,
    Termed = 1,
    InActive = 2,
    All = 3
}

export enum TemplateType {
    Letter = 8001
}

export enum TemplateSubType {
    COBLetter = <any>"COB Letter"
}

export enum ControlType {
    Text = 7701,
    Number = 7702,
    DropDown = 7703,
    Date = 7704,
    CheckBox = 7705,
    TextArea = 7706
}

export enum COBType {
    Line = 701,
    Header = 702
}

export enum ClaimSource {
    EDI = 401,
    Paper = 402
}

export enum ClaimStatus {
    Load = 101,
    Open = 102,
    Pend = 103,
    Deny = 104,
    Adjust = 105,
    Void = 106,
    Reverse = 107,
    ReadyPay = 108,
    ReadyDeny = 109,
    TReversed = 110,
    TPaid = 111,
    TDenied = 112,
    Reversed = 113,
    Paid = 114,
    Denied = 115
}

export enum EOBEOPType {
    EOB = 8801,
    EOP = 8802,
    USER = 8803
}

export enum Modules {
    All = 800,
    Security = 801,
    Claims = 802,
    Member = 803,
    Provider = 804,
    Configuration = 805,
    SupportingTables = 806,
    UtilizationManagement = 807,
    CustomerServices = 808,
    Finance = 809,
}
export enum ValidityCheck {
    EffectiveFrom = 0,
    TermFrom = 1
}

export enum ClaimUBCode {
    Condition = 4601,
    Value = 4603,
    Occurrence = 4602,
    OccurrenceSpan = 4604
}

export enum ProviderType {
    All = 3907,
    Ancillary = 3901,
    Dental = 3902,
    Group = 3903,
    Hospital = 3904,
    IPA = 3905,
    Provider = 3906,
}

export enum GroupType {
    AncillaryGroup = 10901,
    DentalGroup = 10902,
    Group = 10903,
    HospitalGroup = 10904,
}

export enum ReferenceValue {
    FN = 3501,
    Caid = 3502,
    Care = 3503,
    PH = 3504,
    PW = 3505,
    RiskA = 3506,
    RiskB = 3507,
    RiskC = 3508,
    GTPID = 3527,
    IPATPID = 3528
}

export enum EdiCodeType {
    AdmitType = 89,
    AdmitSource = 90,
    DischargeType = 93,
    ClaimFrequency = 98,
    OtherInsuranceRelationship = 45,
    POS = 100,
    AcceptAssignment = 101,
    BenefitsAssignment = 102,
    SpecialProgram = 103,
    DelayReson = 104,
    AttachmentType = 105,
    AttachmentTramission = 106,
    ContractType = 107,
    PricingMethodology = 108,
    PolicyCompliance = 109,
    RejectReason = 110,
    PaymentException = 111,
    TransportReason = 112,
    L2300HICode = 113,
    ServiceAuthCode = 114,
    ServiceCode = 117,
    CoverageLevelCode = 119,
    EligibilityInsType = 120,
    TimePeriodQul = 121,
    QuantityQul = 122,
    PlanNetworkind = 123

}
export enum AuthType {
    AD = 1,
    System = 2
}

export enum RefundReqForType {
    Claims = 10501
}

export enum RefundStatus {
    Initiated = 201,
    Open = 202,
    Fulfilled = 203,
    WriteOff = 204,
    Closed = 205,
    All = -1
}

export enum IdentifierType {
    GroupID = 10801,
    NPI = 10802,
    ProvID = 10803,
    Tax = 10804
}

export enum MemberModuleComponent {
    Eligibility = 1,
    Dependent = 2,
    Contacts = 3,
    PCP = 4,
    Reference = 5,
    Notes = 6,
    Alerts = 7,
    Billing = 8,
    BillingPaymentMethod = 9,
    DisclosureInformation = 10,
    CostShare = 11,
    CoordinationOfBenifit = 12
}

export enum MemberRelationship {
    Adopted = 5101,
    Child = 5102,
    ExSpouse = 5103,
    Foster = 5104,
    LifePartner = 5105,
    Self = 5106,
    Spouse = 5107,
    StepsonOrStepdaughter = 5108
}

export enum ContactType {
    Agent = 6401,
    Billing = 6402,
    Emergency = 6403,
    Employer = 6404,
    Mailing = 6405,
    Other = 6406,
    Pharmacy = 6407,
}

export enum DisclosureType {
    Any = 7401,
    Limited = 7402
}

export enum OrganizationType {
    Organization = 0,
    Company = 1,
    Subcompany = 2
}

export enum VisitType {
    PerBenefit = 4201,
    PerDay = 4201,
    PerLifetime = 4203,
    PerQuarter = 4204,
    PerVisit = 4205,
    PerYear = 4206
}

export enum EditCode {
    MemberNotEligibleOnClaimStartDate = 1001,
    DependentAgeLimitExceeded = 1002,
    NoEnrollmentFoundForPatientBilled = 1003,
    MultipleEnrollments = 1004,
    NoActiveEnrollment = 1005,
    ServiceAfterTermination = 1006,
    MemberRecordSuspended = 1007,
    NoPCPAssignedToMember = 1008,
    NonParPCP = 1009,
    ServicePriorToEffectiveDate = 1010,
    MemberNotEligibleOnDischargeDate = 1011,
    ActiveMemberAlert = 1012,
    MemberHasPossibleOtherInsurance = 1013,
    MemberHasOtherInsurance = 1014,
    MemberHasOtherEnrollment = 1015,
    MemberGroupSuspended = 1016,
    PCPBillingNotInMemberPCPGroup = 1017,
    NoActivePCPAssignedToMember = 1018,
    NotMembersPCP = 1019,
    MemberExcludedFromClaimsEditing = 1020,
    DefaultMemberRecordSelected = 1021,
    NoProviderContractAssigned = 2001,
    ProviderNotActiveOnDOS = 2002,
    ProviderIsNonParticipating = 2003,
    ProviderRecordSuspended = 2004,
    ActiveProviderAlert = 2005,
    ProviderOnWatchList = 2006,
    IncompleteProviderRecord = 2007,
    ProviderNotCredentialed = 2008,
    GroupRecordIsInactive = 2009,
    NoGroupRecordFound = 2010,
    GroupRecordMissingTIN = 2011,
    DefaultProviderRecordSelected = 2012,
    ProviderRecordTerminated = 2013,
    NoActiveProviderToGroupRelationshipFound = 2014,
    NoGroupProviderContractAssigned = 2015,
    ProviderProvisionallyCredentialed = 2016,
    MissingProviderMedicareID = 2017,
    ProviderNotDefinedForLOB = 2018,
    NoContractTermFound = 2019,
    InvalidDischargeStatus = 3001,
    InvalidConditionCode = 3002,
    InvalidOccurrenceCode = 3003,
    DischargeStatusMissing = 3004,
    ConditionCodeMissing = 3005,
    OccurrenceCodeMissing = 3006,
    DischargeHourMissing = 3007,
    DischargeHourInvalid = 3008,
    FutureReceivedDate = 3009,
    HeaderAndClaimLevelTotalDollarMismatch = 3010,
    PossibleDuplicateClaim = 3011,
    DuplicateClaimLineSameClaim = 3012,
    DuplicateClaimLine = 3013,
    ClaimExceedsTimelyFiling = 3014,
    BillTypeNotActiveOnDOS = 3015,
    BillTypeNotValid = 3016,
    CPTHCPCCodeNotActiveOnDOS = 3017,
    CPTHPCPCodeNotValid = 3018,
    FutureUse3019 = 3019,
    DRGCodeNotActiveOnDOS = 3020,
    DRGCodeNotValid = 3021,
    ICDCodeNotActiveOnDOS = 3022,
    ICDCodeNotValid = 3023,
    FutureUse3024 = 3024,
    PlaceOfServiceCodeNotActiveOnDOS = 3025,
    PlaceOfServiceCodeNotValid = 3026,
    ProcedureCodeRequiresNDCCode = 3027,
    CodeNotValidForPatientsGender = 3028,
    CodeNotValidForPatientsAge = 3029,
    ServiceWithinGlobalDays = 3030,
    AllowableOverridden = 3031,
    ClaimLineExceedsHighDollarThreshhold = 3032,
    ClaimExceedsHighDollarThreshhold = 3033,
    ServiceReuqiresManualReview = 3034,
    FutureUse3035 = 3035,
    CorrectedClaim = 3037,
    EDIClaimWithCOBDollars = 3038,
    NoCOBDollarsOnCOBClaim = 3039,
    InvalidOrMissingPrimaryCarrierPaidDate = 3040,
    ClaimDOSSpansFeeTableTermDate = 3041,
    MultipleFeesFoundForSameCode = 3042,
    NotACoveredBenefit = 3043,
    BenefitExhausted = 3044,
    PaidInExcessOfBilled = 3045,
    PaidUpToBilledCharges = 3046,
    ServicesIncludedInCapitation = 3047,
    FutureDateOfService = 3048,
    MissingProvider = 3049,
    MissingMember = 3050,
    FutureUse3051 = 3051,
    PossibleAccidentRelatedDiagnosis = 3052,
    BenefitRequiresInNetworkProvider = 3053,
    FutureUse3054 = 3054,
    BenefitRequiresOutOfNetworkProvider = 3055,
    DateEnteredIsFutureDate = 3056,
    NegativeBilledDollars = 3057,
    UnitsAreRequired = 3058,
    ClaimDatesSpanMemberTerminationSplitClaim = 3059,
    DuplicateClaim = 3060,
    OpenCreditBalanceForProvider = 3061,
    FutureUse3062 = 3062,
    DiagnosisCodeInvalidOnDateOfService = 3063,
    ProcedureCodeInvalidOnDateOfService = 3064,
    RevenueCodeInvalidOnDateOfService = 3065,
    DateOfDeathProvidedOnClaimForm = 3066,
    DelayReasonSubmitted = 3067,
    OIInfoSubmittedOn837 = 3068,
    DelayReasonSubmittedOn837 = 3069,
    ClaimAttachmentIndicatorOnEDIFile = 3070,
    NoteSubmittedOnEDIFile = 3071,
    AmountBilledIsLessThanAmountPaidHeaderRecord = 3072,
    DiagnosisCodeIsRequired = 3074,
    ClaimFlaggedAsPatientReimbursement = 3075,
    ClaimFlaggedAsSplitPay = 3076,
    ClaimMarkedAsNotClean = 30777,
    AlternateFeeScheduleSelected = 3078,
    ClaimMarkedAsEncounter = 3079,
    AutoInsuranceIndicatorOnClaim = 3081,
    EOBSupressedForClaim = 3082,
    PayAndPursueIndicator = 3083,
    EmploymentRelatedIndicator = 3084,
    DateOfServiceIsRequired = 3085,
    PresentOnAdmissionIndicatorIsRequired = 3086,
    DiagnosisPointerRequired = 3087,
    PlaceOfServiceIsRequired = 3088,
    ProcedureCodeRequired = 3089,
    InvalidModifier = 3090,
    ModifierNotActiveForDateOfService = 3091,
    BilledDollarsRequired = 3093,
    ThirdPartyNotesPresentOnClaimEDI = 3093,
    UnitLimitMetOrExceededForDateOfService = 3096,
    DiagnosisCodeNotValid = 3098,
    NDCCodeNotActiveForDOS = 3099,
    NDCCodeNotvalid = 3100,
    DOSFromAfterDOSTo = 3101,
    ServiceRequiresPriorAuthorization = 4001,
    NoAdditionalUnitsOnAuthorization = 4002,
    AuthorizationHasExpired = 4003,
    ServiceNotListedInAuthorization = 4004,
    PriorAuthorizationPenaltyApplies = 4005,
    AuthorizationHasBeenDenied = 4006,
    AuthorizationIsPended = 4007,
    AuthorizationIsVoided = 4008,
    NonParProviderAuthorized = 4009,
    InsufficientUnitsRemainingOnAuthorization = 4010,
    AuthorizationDoesNotMatchClaim = 4011,
    ServiceAuthorizedIsNotCovered = 4012,
    AuthorizedDatesOutsideOfMembersEligibility = 4013,
}

export enum CoverageType {
    Primary = 6103,
    Secondary = 6104,
    Tertiary = 6105
    //, ThirdPartyNotesPresentOnClaimEDI = 3094,
    //OpenEditsRemainOnClaim,
    //MustBeWorkedPriorToReleasingClaim = 3095,
    //NoGroupRecordFound = 2010,
    //GroupRecordIsInactive = 2009,
    //ProviderRecordTerminated = 2013,
    //GroupRecordMissingTIN = 2011,
    //NoActiveProviderToGroupRelationshipFound = 2014,
}

export enum SystemSetting {
    ClaimSeqNo = <any>"ClaimSeqNo",
    MemSeqNo = <any>"MemSeqNo",
    AuthType = <any>"AuthType",
    MemNameFormat = <any>"MemNameFormat",
    ProvNameFormat = <any>"ProvNameFormat"
}

export enum RefundEntryType {
    Cheque = 10701,
    Recoupment = 10702,
    WriteOff = 10703,
    Initiated = 10704,
    Letter = 10705,
    OffSet = 10706,
    Reversed = 10707
}

export enum RoundToType {
    WholeNumber = 1,
    OneDecimal = 2
}

export enum RuleCapitationType {
    Standard = 1,
    Administrative = 2
}

export enum RuleProrateMethod {
    SplitMonth = 1,
    DailyProration = 2,
    DailyProrationValue = <any>"Daily Proration"
}

export enum RuleMessageType {
    EOB = 1,
    EOP = 2
}

export enum DataTypeMaxValue {
    Byte = 255
}

export enum RefundPostedType {
    PendingToPost = 0,
    PartialyPosted = 1,
    Posted = 2,
    PartialyPostedVal = <any>"Partialy Posted",
    PendingToPostVal = <any>"Pending To Post"
}
export enum ApprovalStatus {
    Pending = 7101,
    Rejected = 7102,
    Approved = 7103
}

export enum ClaimStatusCategory {
    InProcess = <any>"In Process",
    ReadyToPay = <any>"Ready To Pay",
    StagingTable = <any>"Staging Table",
    Finalized = <any>"Finalized"
}

export enum MemoryCashingConstant {
    SERCHED_CLAIM_LIST_NEVIGATION = <any>"serched_claim_list_nevigation",
}

export enum FreezedStatus {
    NotFreezed = 0,
    Freezed = 1,
    UnFreezeByUserOrAdmin = 2,
    SystemEditOutcomeConfigurable = 3
}

export enum EditReason {
    Approve = 1101,
    Deny = 1102,
    Ignore = 1103,
    Informational = 1104,
    Pend = 1105
}

export enum FFSParameterType {
    Contract = 50801,
    FeeSchedule = 50802,
    DenialsOnly = 50803,
    Reimbursements = 50804,
    NPProviders = 50805,
    ParProviders = 50806,
    SpecProvider = 50807,
    CapContract = 50808
}


export enum StandardCodeCategory {
    CPTCodes = 101,
    ICDCodes = 102,
    RevenueCodes = 103,
    DRGCodes = 104,
    POSCodes = 105,
    NDCCodes = 106,
    HCCCodes = 107
}

export enum CheckStatus {
    Issued = 10,
    Reissued = 11,
    Void = 12,
    StopPayment = 13,
    Cleared = 14,
}

export enum Form1099ReportType {
    CopyA = 1,
    CopyB = 2,
    CopyC = 3,
    Copy1 = 4,
    Copy2 = 5
}

export enum AlertMessageType {
    Success = 1,
    Error = 2,
    Info = 3,
    Warning = 4
}

export enum PendReasonType {
    Incomplete = 52801,
    Other = 52802
}

export enum ApplicationStatus {
    ENew = 51201,
    EException = 51202,
    EIncomplete = 51203,
    EDenied = 51204,
    EBEQReady = 51205,
    EBEQSent = 51206,
    EBEQPassed = 51207,
    EBEQFailed = 51208,
    EBEQMismatch = 51209,
    EPreEenrollReady = 51210,
    ECMSReady = 51211,
    ECMSSent = 51212,
    ECMSAccepted = 51213,
    ECMSRejected = 51214,
}

export enum TransactionType {
    Enrollment = '61',
    Disenrollment = '51',
    RxDataChange = '72',
    NumberofUncoveredMonths = '73',
    EGHPChange = '74',
    PremiumPaymentOptionChange = '75',
    ResidenceAddressChange = '76',
    SegmentIdChange = '77',
    PartCPremiumChange = '78',
    PartDOptout = '79',
    CancellationofEnrollment = '80',
    CancellationofDisenrollment = '81',
    PersonalInformationChange = '92',
    UpdateEnrollmentSEPReasonCode = '93',
    UpdateDisenrollmentSEPReason = '94'
}

export enum ElectionType {
    AnnualElectionPeriod = 53301,
    PlansubmittedRollover = 53302,
    InitialElectionPeriod = 53303,
    InitialElectionPeriod2 = 53304,
    InitialCoordinatedElectionPeriod = 53305,
    DefaulEnrollmentMechanism = 53306,
    DualLISQuarterlySEP = 53307,
    MedicareAdvantageOpenElectionPeriod = 53308,
    OEPNew = 53309,
    OpenElectionPeriod = 53310,
    StarSEP = 53311,
    OtherSEP = 53312,
    OpenEnrollmentPeriodforInstitutionalizedIndividuals = 53313,
    DualLISSEP = 53314,
    PermanentChangeinResidenceSEP = 53315,
    EGHPSEP = 53316,
    CMSCaseworkSEP = 53317,
    AutoFacilitatedReassignPOSEnrollment = 53318,

}



export enum MembeStatus {
    Active = 51401,
    Pending = 51402,
    Inactive_Termed = 51403,
    Inactive_Cancelled = 51404
}

export enum CMSContractCode {
    H0001 = 51501,
}


export enum FILTER_OPERATION {
    CONTAINS = 'contains',
    STARTS_WITH = 'startswith',
    ENDS_WITH = 'endswith',
    EQUALS = 'eq',
    DOES_NOT_EQUAL = 'ne',
    DOES_NOT_CONTAIN = 'not contains',
    GREATER_THAN = 'gt',
    LESS_THAN = 'lt',
    LESS_THAN_EQUAL = 'le',
    GREATER_THAN_EQUAL = 'ge'
}

export enum HpsGridDataSourceType {
    OdataGridSource = 1,
    StaticList = 2
}

export enum HTTRequestType {
    GET = 1,
    POST = 2,
    PUT = 3,
    DELETE = 4
}

export enum HpsGridFieldType {
    Text = "string",
    Number = "number",
    Date = "date",
    Boolean = "boolean",
    Currency = "currency",
    Object = "object",
    Phone = 5,
    DateTime = 6
}

export enum HpsGridDisplayDensity {
    Compact = "compact",
    Cosy = "cosy",
    Comfortable = "comfortable"
}

export enum HpsGridCellSelection {
    None = "none",
    Single = "single",
    Multiple = "multiple"
}

export enum HpsGridRowSelection {
    None = "none",
    Single = "single",
    Multiple = "multiple"
}

export enum HpsGridFilterMode {
    ExcelStyleFilter = "excelStyleFilter",
    QuickFilter = "quickFilter"
}

export enum HpsGridPagingMode {
    Local = 0,
    Remote = 1
}

export enum enrollmentComponentSequence {
    MemberPlanAndInformation = 1,
    ContactDetails = 2,
    EligibilityDetails = 3,
    PremiumDetails = 4,
    Sales = 5,
    OtherCoverage = 6,
    Authorization = 7,
    PriorEnrollmentData = 8,
    RxDetails = 9,
    PCP = 10,
    TransactionDetails = 11,
    Spans = 12,
    TRRDetails = 13,
    BEQDetails = 14,
    Correspondence = 15,
    Others = 16
}

export enum AttchmentType {
    Enrollment = 51301,
    Disenrollment = 51302,
    Reinstatement = 51303,
    PlanChange = 51304,
    Others = 51305
}

export enum BenefitConfigComponents {
    ServiceGroups = 'Service Groups',
    Codes = 'Codes',
    Modifiers = 'Modifiers',
    Diagnosis = 'Diagnosis',
    PlaceOfService = 'Place Of Service',
    BillTypes = 'Bill Types',
    Providers = 'Providers',
    CopayCoinsurance = 'Copay/Coinsurance',
    CopayPerDiem = 'Copay Per Diem',
    Visits = 'Visits',
    DeductibleMaxoop = 'Deductible/Max OOP'
}

export enum ProviderDetailsComponents {
    Specialty = 'Specialty',
    Reference = 'Reference',
    Notes = 'Notes',
    Locations = "Locations",
    ProviderLocation = 'Provider Location',
    ProviderContract = 'Provider Contract',
    Alert = 'Alert',
    Status = 'Status',
    Cred = 'Credentialing',
    Audit = 'Audit History',
    Contracts = "Contracts"
}

export enum TermComponents {
    ServiceGroups = 'Service Groups',
    Codes = 'Codes',
    Modifiers = 'Modifiers',
    Diagnosis = 'Diagnosis',
    PlaceOfService = 'Place Of Service',
    BillTypes = 'Bill Types',
    Limits = 'Limits',
    Payments = 'Payments'
}

export enum GroupDetailsComponents {
    Contracts = 'Contracts',
    Providers = 'Providers',
    Locations = 'Locations',
    TIN = 'TIN',
    Specialty = 'Specialty',
    ProviderLocation = 'Provider Location',
    ProviderContract = 'Provider Contract',
    Reference = 'Reference',
    Notes = 'Notes',
    EFTInfo = 'EFT Info',
    CheckHistory = 'Check History',
    IPA = 'IPA',
    Alert = 'Alert',
    Finance = 'Finance'
}

export enum OECFileRunStatus {
    Succeeded = "succeeded",
    InProgress = "inprogress",
    Failed = "failed",
}

export enum DataFileTemplate {
    OEC_DataFileTemplate = 18,
}

export enum RuleComponents {
    TimelyFilling = 'Timely Filling',
    ModifierDiscount = 'Modifier Discount',
    Capitation = 'Capitation',
    DefaultFeeSchedule = 'Default Fee Schedule',
    Interest = 'Interest',
    ClaimAddress = 'Claim Address',
    EOBMessage = 'EOB Message',
    EOPMessage = 'EOP Message',
    EditRules = 'Edit Rules',
    AutoPay = 'AutoPay',


}

export enum EdiClaimStatus
{
    Pending = 0,
    Inprogress = 201,
    Success = 202,
    Failed = 203
}